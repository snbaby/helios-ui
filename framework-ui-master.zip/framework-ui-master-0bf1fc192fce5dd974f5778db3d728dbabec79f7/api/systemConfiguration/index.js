import { fetch, json2Param } from '@/core/fetch.js';


export function getTableData(query) {
    return fetch({
        url: '/api/admin/sqlManage/page?!code=like&&!name=like',
        method: 'get',
        params:query
    });
}

export function add(obj) {
    return fetch({
        url: '/api/admin/sqlManage',
        method: 'post',
        data:obj
    });
}

export function deleteone(id) {
    return fetch({
        url: '/api/admin/sqlManage/'+id,
        method: 'delete'
    });
}

export function edit(obj) {
    return fetch({
        url: '/api/admin/sqlManage/'+obj.id,
        method: 'put',
        data:obj
    });
}

export function testsql(query) {
    return fetch({
        url: '/api/admin/sqlManage/testSql',
        method: 'post',
        data:query
    });
}

export function getMetaData() {
    var query = {
        page:1,
        limit:-1
    }
    return fetch({
        url: '/api/soc/metaConfigure/page',
        method: 'get',
        params:query
    });
}

export function getDictData() {
    var query = {
        page:1,
        limit:-1
    }
    return fetch({
        url: '/api/admin/dict/entry/page',
        method: 'get',
        params:query
    });
}

export function getAll() {
    return fetch({
        url: '/api/admin/JdbcDrivers/all',
        method: 'get',
    });
}

