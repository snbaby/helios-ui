import { fetch, json2Param } from '@/core/fetch.js';


export function add(data) {
    return fetch({
        url: '/api/admin/JdbcDrivers',
        method: 'post',
        data:data
    });
}

export function getTableData(query) {
    return fetch({
        url: '/api/admin/JdbcDrivers/page',
        method: 'get',
        params:query
    });
}

export function deleteone(id) {
    return fetch({
        url: '/api/admin/JdbcDrivers/'+id,
        method: 'delete'
    });
}

export function edit(obj) {
    let id = obj.id;
    delete obj.id;
    return fetch({
        url: '/api/admin/JdbcDrivers/'+id,
        method: 'put',
        data:obj
    });
}
