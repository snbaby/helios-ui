
import { fetch, json2Param } from '@/core/fetch.js';
//部门转码
export function getCompleteTaskTableData(search,cb) {
    fetch({
        url:'/api/admin/sqlManage/getSqlResult/queryCompleteTaskInfo',
        method: 'post',
        data:search.data
    }).then((data) => {
        if(data.data){
            var resultJson = data.data;
            if(resultJson.total>0){
                var flowInstanceIds = "";
                var taskArr = resultJson.data;
                //通过查询出来的已办任务信息去查询对应的流程信息
                for(var i in taskArr){
                    flowInstanceIds = flowInstanceIds + "'" + taskArr[i]["flow_instance_id"] +"',"
                }
                flowInstanceIds = flowInstanceIds.substring(0,flowInstanceIds.length-1);
                var query = {
                    "flowInstanceIds":flowInstanceIds,
                    "where":search.queryStr?search.queryStr:"",
                    "PageStart":search.data.PageStart,
                    "PageSize":search.data.PageSize
                };
                fetch({
                    url: '/api/admin/sqlManage/getSqlResult/queryProcessByInstanceId',
                    method: 'post',
                    data:query
                }).then((data) => {
                    if(data.data){
                        var dataJson = data.data;
                        cb(dataJson);
                    }
                })
            }else{
                cb(resultJson);
            }
        }else{
            cb({});
        }
    });
}
