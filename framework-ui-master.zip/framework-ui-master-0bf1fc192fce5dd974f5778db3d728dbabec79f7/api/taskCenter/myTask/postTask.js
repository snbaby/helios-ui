import { fetch, json2Param } from '@/core/fetch.js';

export function getPostTaskMatterClass(cb) {
    fetch('/api/books/matter/getMatterTree', { method: "get", responseType: "json" })
        .then((data) => {
            cb(data)
        })
}
//获取事项分类查询表格
export function getClassMatterTable(search,cb) {
    fetch(`/api/books/matter/queryMattersByCatCode/${search.matterCatCode}/${search.pageNo}/${search.pageSize}`, { method: "get", responseType: "json" })
        .then((data) => {
            cb(data)
        })
}
//获取事项条件查询表格
export function getSearchMatterTable(search,cb) {
    fetch(`/api/books/matter/searchMatter?${search}`, { method: "get", responseType: "json" })
        .then((data) => {
            cb(data)
        })
}
//发起流程状态
export function getPostFlowStatus(search,cb) {
    fetch({
        "url": `/api/bpm/rest/process-definition/key/${search.processKey}/tenant-id/000000/submit-form`,
        "data": search.data,
        "method": "post"
    })
        .then((data) => {
            cb(data)
        });
}
//事项相关信息
export function getMatterInfo(cb) {
    fetch('/api/books/matter/realTimeSearch', { method: "get", responseType: "json" })
        .then((data) => {
            cb(data)
        });
}
