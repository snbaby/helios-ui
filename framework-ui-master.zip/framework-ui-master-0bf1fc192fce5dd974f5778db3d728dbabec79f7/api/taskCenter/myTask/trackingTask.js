
import { fetch, json2Param } from '@/core/fetch.js';
//部门转码
export function getTrackingTaskTableData(search,cb) {
    fetch({
        url:'/api/admin/sqlManage/getSqlResult/queryTrackingTaskProcess',
        method: 'post',
        data:search.data
    }).then((data) => {
        if(data.data){
            var dataJson = data.data;
            cb(dataJson);
        }else{
            cb({});
        }
    });
}
