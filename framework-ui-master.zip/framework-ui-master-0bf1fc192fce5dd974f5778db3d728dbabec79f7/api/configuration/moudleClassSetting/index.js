import {fetch} from '@/core/fetch.js';

export function getDictTree() {
  	return fetch({
    	url: '/api/soc/modelCatalogConfigure/tree',
    	method: 'get',
		responseType:"json"
  	});
}

export function getTableData(query) {
  	return fetch({
    	url: '/api/soc/modelKindConfigure/page?!kindCode=like&!kindName=like',
    	method: 'get',
		params:query
  	});
}

export function add(obj) {
  	return fetch({
    	url: '/api/soc/modelKindConfigure',
    	method: 'post',
		data:obj
  	});
}

export function edit(obj) {
  	return fetch({
    	url: '/api/soc/modelKindConfigure/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function deleteone(id) {
  	return fetch({
    	url: '/api/soc/modelKindConfigure/'+id,
    	method: 'delete'
  	});
}


export function queryAll() {
  	return fetch({
    	url: '/api/soc/modelKindConfigure/all',
    	method: 'get'
  	});
}
