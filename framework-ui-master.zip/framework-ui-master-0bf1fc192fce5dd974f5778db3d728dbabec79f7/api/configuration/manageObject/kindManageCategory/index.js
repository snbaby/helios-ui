import {fetch} from '@/core/fetch.js';

export function getDictTree(kindCode) {
  	return fetch({
    	url: '/api/admin/dict/kind/getTreeData?kindCode='+kindCode,
    	method: 'get',
		responseType:"json"
  	});
}

export function getTableData(query) {
  	return fetch({
    	url: '/api/soc/kindManageCategory/page',
    	method: 'get',
		params:query
  	});
}

export function add(obj) {
  	return fetch({
    	url: '/api/soc/kindManageCategory',
    	method: 'post',
		data:obj
  	});
}

export function deleteone(id) {
  	return fetch({
    	url: '/api/soc/kindManageCategory/'+id,
    	method: 'delete'
  	});
}

export function edit(obj) {
  	return fetch({
    	url: '/api/soc/kindManageCategory/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function insertButtonList(obj) {
    return fetch({
        url: '/api/soc/parameterButton/insert',
        method: 'post',
        data:obj
    });
}

export function getButtonDetail(categroyId) {
    return fetch({
        url: '/api/soc/parameterButton/page?page=1&limit=-1&categroyId='+categroyId,
        method: 'get'
    });
}
