import {fetch} from '@/core/fetch.js';

export function getDictTree() {
  	return fetch({
    	url: '/api/admin/dict/kind/getTreeData?kindCode=organization',
    	method: 'get',
		responseType:"json"
  	});
}

export function getTableData(query) {
  	return fetch({
    	url: '/api/soc/kindMeta/page',
    	method: 'get',
		params:query
  	});
}

export function add(obj) {
  	return fetch({
    	url: '/api/soc/kindMeta/insert',
    	method: 'post',
		data:obj
  	});
}

export function deleteone(id) {
  	return fetch({
    	url: '/api/soc/kindMeta/'+id,
    	method: 'delete'
  	});
}

export function getMetaAll() {
  	return fetch({
    	url: '/api/soc/metaConfigure/all',
    	method: 'get'
  	});
}

export function getMetaTableData(query) {
	query.kindType = 'organization';
  	return fetch({
    	url: '/api/soc/kindMeta/getMetaTable',
    	method: 'post',
		data:query
  	});
}
