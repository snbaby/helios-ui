import {fetch} from '@/core/fetch.js';

export function getDictTree() {
  	return fetch({
    	url: '/api/admin/dict/kind/getTreeData',
    	method: 'get',
		responseType:"json"
  	});
}

export function getKindTableData(query) {
  	return fetch({
    	url: '/api/admin/dict/kind/page?!kindCode=like&!kindName=like',
    	method: 'get',
		params:query
  	});
}

export function addKind(obj) {
  	return fetch({
    	url: '/api/admin/dict/kind',
    	method: 'post',
		data:obj
  	});
}

export function editKind(obj) {
  	return fetch({
    	url: '/api/admin/dict/kind/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function deleteKind(id) {
  	return fetch({
    	url: '/api/admin/dict/kind/'+id,
    	method: 'delete'
  	});
}

export function getAll() {
  	return fetch({
    	url: '/api/admin/dict/kind/all',
    	method: 'get'
  	});
}
