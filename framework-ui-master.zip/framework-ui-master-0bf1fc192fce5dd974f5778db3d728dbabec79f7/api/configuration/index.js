import {fetch} from '@/core/fetch.js';

export function getManageObjectHeadMenu() {
  	return fetch({
    	url: '/api/admin/dict/kind/getManageObjectHeadMenu',
    	method: 'get'
  	});
}
