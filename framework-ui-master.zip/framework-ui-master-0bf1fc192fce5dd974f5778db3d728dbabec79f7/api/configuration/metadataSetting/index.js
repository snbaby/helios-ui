import {fetch} from '@/core/fetch.js';

export function getTableData(query) {
  	return fetch({
    	url: '/api/soc/metaConfigure/page?!metaCode=like&!metaName=like',
    	method: 'get',
		params:query
  	});
}

export function add(obj) {
  	return fetch({
    	url: '/api/soc/metaConfigure',
    	method: 'post',
		data:obj
  	});
}

export function edit(obj) {
  	return fetch({
    	url: '/api/soc/metaConfigure/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function deleteOne(id) {
  	return fetch({
    	url: '/api/soc/metaConfigure/'+id,
    	method: 'delete'
  	});
}

export function getEntryAll(id) {
  	return fetch({
    	url: '/api/admin/dict/entry/all',
    	method: 'get'
  	});
}
