import {fetch} from '@/core/fetch.js';

export function getDictTree() {
  	return fetch({
    	url: '/api/soc/eventCategory/getDataTree',
    	method: 'get',
  	});
}

export function getDatas(id) {
  	return fetch({
    	url: '/api/soc/eventSource/getDataTree?categoryCode='+id,
    	method: 'get',
  	});
}
