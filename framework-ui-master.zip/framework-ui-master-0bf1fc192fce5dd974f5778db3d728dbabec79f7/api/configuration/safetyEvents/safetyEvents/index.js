import {fetch} from '@/core/fetch.js';

export function getDictTree() {
  	return fetch({
    	url: '/api/admin/dict/kind/getTreeData?kindCode=events',
    	method: 'get',
		responseType:"json"
  	});
}

export function getTableData(query) {
  	return fetch({
    	url: '/api/soc/eventCategory/page?!categoryCode=like&!categoryName=like',
    	method: 'get',
		params:query
  	});
}

export function add(obj) {
  	return fetch({
    	url: '/api/soc/eventCategory',
    	method: 'post',
		data:obj
  	});
}

export function edit(obj) {
  	return fetch({
    	url: '/api/soc/eventCategory/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function deleteone(id) {
  	return fetch({
    	url: '/api/soc/eventCategory/'+id,
    	method: 'delete'
  	});
}

export function getRuleList(id) {
  	return fetch({
    	url: '/api/soc/rule/packages',
    	method: 'get'
  	});
}
