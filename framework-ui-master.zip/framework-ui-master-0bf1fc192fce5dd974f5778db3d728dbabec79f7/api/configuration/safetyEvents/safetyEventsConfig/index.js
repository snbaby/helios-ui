import {fetch} from '@/core/fetch.js';

export function getTableData(query) {
  	return fetch({
    	url: '/api/soc/eventCategoryMeta/page',
    	method: 'get',
		params:query
  	});
}

export function add(obj) {
  	return fetch({
    	url: '/api/soc/eventCategoryMeta/insert',
    	method: 'post',
		data:obj
  	});
}

export function deleteone(id) {
  	return fetch({
    	url: '/api/soc/eventCategoryMeta/'+id,
    	method: 'delete'
  	});
}

export function getMetaAll() {
  	return fetch({
    	url: '/api/soc/metaConfigure/all',
    	method: 'get'
  	});
}

export function getMetaTableData(query) {
  	return fetch({
    	url: '/api/soc/eventCategoryMeta/getCategoryMetaTable',
    	method: 'post',
		data:query
  	});
}

export function getDataByCode(query) {
  	return fetch({
    	url: '/api/soc/eventCategory/page',
    	method: 'get',
		params:query
  	});
}
