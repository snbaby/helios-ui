import {fetch} from '@/core/fetch.js';

export function getTableData(query) {
  	return fetch({
    	url: '/api/soc/eventSource/page?!sourceCode=like&!sourceName=like',
    	method: 'get',
		params:query
  	});
}

export function getDataByCode(query) {
  	return fetch({
    	url: '/api/soc/eventCategory/one',
    	method: 'get',
		params:query
  	});
}

export function add(obj) {
	obj.moudleCode = obj.moudleCode.toString();
  	return fetch({
    	url: '/api/soc/eventSource',
    	method: 'post',
		data:obj
  	});
}

export function edit(obj) {
	obj.moudleCode = obj.moudleCode.toString();
  	return fetch({
    	url: '/api/soc/eventSource/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function deleteone(id) {
  	return fetch({
    	url: '/api/soc/eventSource/'+id,
    	method: 'delete'
  	});
}

export function getCategoryNode(query) {
  	return fetch({
    	url: '/api/soc/eventCategory/page?page=1&limit=-1',
    	method: 'get',
		params:query
  	});
}

export function getRuleList(id) {
  	return fetch({
    	url: '/api/soc/rule/packages',
    	method: 'get'
  	});
}

export function getModuleTree() {
  	return fetch({
    	url: '/api/soc/kindManageCategory/getDataTree',
    	method: 'get'
  	});
}

export function getRecord(query) {
    return fetch({
        url: '/api/soc/eventSource/getEventSource',
        method: 'get',
        params:query
    });
}

export function addRecord(query) {
    return fetch({
        url: '/api/soc/eventSource/addRecord',
        method: 'get',
        params:query
    });
}
