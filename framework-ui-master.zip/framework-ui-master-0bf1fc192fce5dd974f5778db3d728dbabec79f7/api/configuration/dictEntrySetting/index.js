import {fetch} from '@/core/fetch.js';

export function getItemTableData(query) {
  	return fetch({
    	url: '/api/admin/dict/item/page?!dictItemCode=like&!dictItemName=like',
    	method: 'get',
		params:query
  	});
}

export function getDataById(id) {
  	return fetch({
    	url: '/api/admin/dict/entry/'+id,
    	method: 'get'
  	});
}

export function addItem(obj) {
  	return fetch({
    	url: '/api/admin/dict/item',
    	method: 'post',
		data:obj
  	});
}

export function editItem(obj) {
  	return fetch({
    	url: '/api/admin/dict/item/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function deleteItem(id) {
  	return fetch({
    	url: '/api/admin/dict/item/'+id,
    	method: 'delete'
  	});
}

export function getEntryAll() {
  	return fetch({
    	url: '/api/admin/dict/entry/all',
    	method: 'get'
  	});
}
