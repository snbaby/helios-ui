import {fetch} from '@/core/fetch.js';

export function getDictTree() {
  	return fetch({
    	url: '/api/admin/dict/kind/getTreeData?kindCode=dict',
    	method: 'get',
		responseType:"json"
  	});
}

export function getEntryTableData(query) {
  	return fetch({
    	url: '/api/admin/dict/entry/page?!dictEntryCode=like&!dictEntryName=like',
    	method: 'get',
		params:query
  	});
}

export function addEntry(obj) {
  	return fetch({
    	url: '/api/admin/dict/entry',
    	method: 'post',
		data:obj
  	});
}

export function editEntry(obj) {
  	return fetch({
    	url: '/api/admin/dict/entry/'+obj.id,
    	method: 'put',
		data:obj
  	});
}

export function deleteEntry(id) {
  	return fetch({
    	url: '/api/admin/dict/entry/'+id,
    	method: 'delete'
  	});
}

export function getKindTableData(query) {
  	return fetch({
    	url: '/api/admin/dict/kind/page?!kindCode=like&!kindName=like',
    	method: 'get',
		params:query
  	});
}
