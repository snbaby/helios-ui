import {fetch} from '@/core/fetch.js';

export function page(query) {
  return fetch({
    url: '/api/admin/element/list',
    method: 'get',
    params: query
  });
}

export function addObj(obj) {
  return fetch({
    url: '/api/admin/element',
    method: 'post',
    data: obj
  });
}

export function getObj(id) {
  return fetch({
    url: '/api/admin/element/' + id,
    method: 'get'
  })
}

export function delObj(id) {
  return fetch({
    url: '/api/admin/element/' + id,
    method: 'delete'
  })
}

export function putObj(id, obj) {
  return fetch({
    url: '/api/admin/element/' + id,
    method: 'put',
    data: obj
  })
}

export function getAuthorityGroupList(resourceType,resourceCode) {
    return fetch({
        url: `/api/admin/element/authority/${resourceType}/${resourceCode}`,
        method: 'get'
    });
}

export function postAuthorityObj(authorityType,resourceType,resourceCode,obj) {
    return fetch({
        url:`/api/admin/element/authority/${authorityType}/${resourceType}/${resourceCode}`,
        method: 'post',
        data: obj
    });
}
