import {fetch} from '@/core/fetch.js';

export function getProcessDefineXml_key(key) {
    if(key == 'P12345678'){
        return fetch({
            url: `/api/bpm/rest/process-definition/key/${key}/tenant-id/000000/xml`,
            method: 'get'
        });
    }else {
        return fetch({
            url: `/api/bpm/rest/process-definition/key/${key}/xml`,
            method: 'get'
        });
    }
}

export function getProcessDefineStartForm_key(key) {
    return fetch({
        url: `/api/bpm/process/start/form/${key}`,
        method: 'get'
    });
}

export function postProcessInInstance_executionId(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/getProcessInInstance`,
        method: 'post',
        data: data
    });
}

export function getProcessApproveUser(processInstanceId,taskNodeId) {
    return fetch({
        url: `/api/bpm/process/assignee/${processInstanceId}/${taskNodeId}`,
        method: 'get'
    });
}

export function getProcessDefineForm_key(key) {
    return fetch({
        url: `/api/bpm/process/forms/${key}`,
        method: 'get'
    });
}

export function postProcessApplyDetail_applyDetailTbName_flowInstanceId(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/queryApplyDetail`,
        method: 'post',
        data: data
    });
}

export function queryFlowApplyInfo_flowInstanceId(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/queryFlowApplyInfo`,
        method: 'post',
        data: data
    });
}

export function getProcessTask(data) {
    return fetch({
        url: `/api/bpm/rest/task`,
        method: 'get',
        params: data
    });
}

export function queryProcessApplyInfo(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/queryProcessByInstanceId',
        method: 'post',
        data: data
    });
}

export function deleteProcessInstance(processInstanceId) {
    return fetch({
        url: `/api/bpm/rest/process-instance/${processInstanceId}`,
        method: 'delete'
    });
}
