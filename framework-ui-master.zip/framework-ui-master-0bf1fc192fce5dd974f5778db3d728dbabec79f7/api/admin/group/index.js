import { fetch } from '@/core/fetch.js';

export function addGroupMember(data) {
    return fetch({
        url: '/api/admin/group/user/addGroup',
        method: 'post',
        params: data
    });
}

export function deleteGroupByUserIdAndGroupId(params) {
    return fetch({
        url: `/api/admin/group/deleteGroupByUserIdAndGroupId`,
        method: 'get',
        params: params
    });
}

export function pagedGroups(query) {
    return fetch({
        url: '/api/admin/group/page',
        method: 'get',
        params: query
    });
}
export function fetchTree(query) {
    return fetch({
        url: '/api/admin/group/tree',
        method: 'get',
        params: query
    });
}

export function addObj(obj) {
    return fetch({
        url: '/api/admin/group',
        method: 'post',
        data: obj
    });
}

export function delObj(id) {
    return fetch({
        url: '/api/admin/group/' + id,
        method: 'delete'
    });
}

export function putObj(id, obj) {
    return fetch({
        url: '/api/admin/group/' + id,
        method: 'put',
        data: obj
    });
}

export function getGroupList(params) {
    return fetch({
        url: '/api/admin/group/list',
        method: 'get',
        params: params
    });
}
