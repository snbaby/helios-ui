import {fetch} from '@/core/fetch.js';

export function selectHostScanResultByCode(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectHostScanResultByCode',
        method: 'post',
        data: data
    });
}

export function queryAllComputer(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectAllScanComputer',
        method: 'post',
        data: data
    });
}

export function selectFlawByCodeIsNot(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectHostFlawResultByCodeIsNotRecord',
        method: 'post',
        data: data
    });
}

export function getLeakRecordId(data) {
    return fetch({
        url: '/api/bpm/process/forms/leak_record',
        method: 'post',
        data: data
    });
}

export function processStart(query) {
    return fetch({
        url: '/api/soc/ProcessStart/leak_record',
        method: 'post',
        data: query
    });
}

export function selectTaskInfoByActivityInstanceId(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectTaskInfoByActivityInstanceId `,
        method: 'post',
        data: data
    });
}

//获取流程当前节点表单数据（表单、按钮）
export function processNodeData(flow_instance_id) {
    return  fetch(`/api/bpm/process/task/form/var/${flow_instance_id}`, {
        method: "get",
        responseType: "json"
    })
}

//签收流程
export function claimProcess(val,taskId) {
    //满足新bpmn数据格式
    var newData= {userId:val};
    return  fetch({
        "url": `/api/bpm/rest/task/${taskId}/claim`,
        "data": newData,
        "method": "post"
    })
}

//审批流程
export function approvalProcess(val,taskId) {
    //满足新bpmn数据格式
    var newData={variables:{}};
    for (let i in val){
        newData.variables[i]={value:val[i]};
    }
    return  fetch({
        "url": `/api/bpm/rest/task/${taskId}/submit-form`,
        "data": newData,
        "method": "post"
    })
}

//获取历史审批信息
export function getHistoryApproveData(activityInstanceId) {
    var query = {
        flow_instance_id:activityInstanceId
    }
    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/queryHistoryProcessTaskList",
        "method": "post",
        data:query
    })
}

export function selectHostFlowRecordById(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectHostFlowRecordById`,
        method: 'post',
        data: data
    });
}

export function upEsData(data) {
    return fetch({
        url: `/api/soc/UpEsIsAgree`,
        method: 'post',
        data: data
    });
}

export function upDataEs(data) {
    return fetch({
        url: `/api/soc/updateLeakRecord`,
        method: 'post',
        data: data
    });
}

export function upData(data) {
    return fetch({
        url: `/api/soc/updateHostFlawScan`,
        method: 'post',
        data: data
    });
}

export function selectRecordByCode(data) {
    return fetch({
        url: `/api/soc/vulScreening`,
        method: 'post',
        data: data
    });
}



