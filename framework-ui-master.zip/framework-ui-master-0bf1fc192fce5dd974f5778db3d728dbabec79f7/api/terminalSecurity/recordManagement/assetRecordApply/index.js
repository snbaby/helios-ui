import {fetch} from '@/core/fetch.js';

export function selectComputerDetailByAssetCode(code) {
    if(code!=""){
        var map = {
            asset_code:code
        }
    }
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectComputerDetailByAssetCode',
        method: 'post',
        data:map
    });
}

export function selectOrgByOrgCode(code) {
    if(code!=""){
        var map = {
            org_code:code
        }
    }
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectOrgByOrgCode',
        method: 'post',
        data:map
    });
}

export function selectAssetUserByUserCodes(code) {
    var data = ""
    if(code){
        for(var i=0;i<code.split(';').length;i++){
            data = data + "'"+code.split(';')[i]+"',";
        }
    }

    if(data.length>0){
        data = data.substring(0,data.length-1);
    }

    var map = {
        wherein:data
    }

    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectAssetUserByUserCodes',
        method: 'post',
        data:map
    });
}

export function getRecordDataTree() {
    return fetch({
        url: '/api/soc/eventCategory/getRecordDataTree',
        method: 'get'
    });
}


export function getRecordResonList(id) {
    return fetch({
        url: '/api/soc/eventSource/getEventSource?id='+id,
        method: 'get'
    });
}

export function queryAllComputer(query) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/queryAllDepComputerByOrgCode',
        method: 'post',
        data:query
    });
}


export function getEventSourceData() {
    return fetch({
        url: '/api/soc/eventSource/page?sourceDescription=1',
        method: 'get'
    });
}

export function getHasRecordItem(query) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/getKeepOnRecordInfo1',
        method: 'post',
        data:query
    });
}

export function getEventCategoryByCode(code) {
    return fetch({
        url: '/api/soc/eventCategory/page?categoryCode='+code,
        method: 'get'
    });
}

export function getEventSourceById(id) {
    return fetch({
        url: '/api/soc/eventSource/'+id,
        method: 'get'
    });
}

export function getHasRecordDataTree(query) {
    return  fetch({
        "url": "/api/soc/eventCategory/queryIDontKnow",
        "method": "post",
        data:query
    })
}

export function querySome(query) {
    return  fetch({
        "url": "/api/soc/eventCategory/querySome",
        "method": "post",
        data:query
    })
}

//发起流程
export function postProcess(val,processKey,businessKey) {
    //满足新bpmn数据格式
    var newData={variables:{}};
    for (let i in val){
        newData.variables[i]={value:val[i].toString()};
    }
    newData.businessKey = businessKey;

    return fetch({
        "url": `/api/bpm/rest/process-definition/key/${processKey}/tenant-id/000000/submit-form`,
        "data": newData,
        "method": "post"
    })
}

//获取流程当前节点表单数据（表单、按钮）
export function processNodeData(flow_instance_id) {
    return  fetch(`/api/bpm/process/task/form/var/${flow_instance_id}`, {
        method: "get",
        responseType: "json"
    })
}

//获取发起流程表单数据（审批展示）
export function processPostData(taskId) {
    return  fetch(`/api/bpm/process/task/form/${taskId}`, {
        method: "get",
        responseType: "json"
    })
}

//审批流程
export function approvalProcess(val,taskId) {
    //满足新bpmn数据格式
    var newData={variables:{}};
    for (let i in val){
        newData.variables[i]={value:val[i]};
    }
    return  fetch({
        "url": `/api/bpm/rest/task/${taskId}/submit-form`,
        "data": newData,
        "method": "post"
    })
}

//签收流程
export function claimProcess(val,taskId) {
    //满足新bpmn数据格式
    var newData= {userId:val};
    return  fetch({
        "url": `/api/bpm/rest/task/${taskId}/claim`,
        "data": newData,
        "method": "post"
    })
}

//获取流程审批时申请的数据
export function getProcessStartForm(type,flow_instance_id) {
    var query = {
        type:type,
        processInstanceId:flow_instance_id
    }

    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/queryTaskApplyInfoByTypeAndInstId",
        "method": "post",
        data:query
    })
}

//通过流程实例ID查询流程发起信息
export function selectTaskInfoByActivityInstanceId(activityInstanceId) {
    var query = {
        activityInstanceId:activityInstanceId
    }
    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/selectTaskInfoByActivityInstanceId",
        "method": "post",
        data:query
    })
}


//获取流程编号
export function getBusinessKey() {
    return  fetch({
        "url": "/api/bpm/process/forms/P12345678",
        "method": "post"
    })
}

//获取历史审批信息
export function getHistoryApproveData(activityInstanceId) {
    var query = {
        flow_instance_id:activityInstanceId
    }
    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/queryHistoryProcessTaskList",
        "method": "post",
        data:query
    })
}

export function queryInstanceIdAndTypeByTaskId(taskId) {
    var query = {
        taskId:taskId
    }
    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/queryInstanceIdAndTypeByTaskId",
        "method": "post",
        data:query
    })
}

export function upEsData(data) {
    return  fetch({
        "url": "/api/soc/UpEsData",
        "method": "post",
        data:data
    })
}
