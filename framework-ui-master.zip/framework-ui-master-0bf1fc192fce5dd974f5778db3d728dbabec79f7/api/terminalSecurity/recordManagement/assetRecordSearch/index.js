import {fetch} from '@/core/fetch.js';

export function getRecordDataTree() {
    return fetch({
        url: '/api/soc/eventCategory/getRecordDataTree',
        method: 'get'
    });
}

export function getMenuData(data) {
    return fetch({
        url: '/api/soc/eventCategory/queryIDontKnow',
        method: 'post',
        data: data
    });
}

export function getRecordType() {
    return fetch({
        url: '/api/soc/eventCategory/page?!categoryCode=like&!categoryName=like&page=1&limit=10&kindId=221',
        method: 'get'
    });
}
