import {fetch} from '@/core/fetch.js';

export function getFormData(query) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectPnumById',
        method: 'post',
        data:query
    });
}

export function getCancelData(query) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectCancelRecordByID',
        method: 'post',
        data:query
    });
}

export function getRecordDataTree() {
    return fetch({
        url: '/api/soc/eventCategory/getRecordDataTree',
        method: 'get'
    });
}

export function getProcessDefineXml_key(key) {
        return fetch({
            url: `/api/bpm/rest/process-definition/key/${key}/xml`,
            method: 'get'
        });
}
//获取流程编号
export function getBusinessKey() {
    return  fetch({
        "url": "/api/bpm/process/forms/cancel_record",
        "method": "post"
    })
}
//发起流程
export function postProcess(val,processKey,businessKey) {
    //满足新bpmn数据格式
    var newData={variables:{}};
    for (let i in val){
        newData.variables[i]={value:val[i].toString()};
    }
    newData.businessKey = businessKey;

    return fetch({
        "url": `/api/bpm/rest/process-definition/key/${processKey}/submit-form`,
        "data": newData,
        "method": "post"
    })
}
