import {fetch} from '@/core/fetch.js';

export function selectFlawByCode(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectHostFlawResultByCode',
        method: 'post',
        data: data
    });
}

export function selectFlawByAssetCode(data) {
    let code = data.asset_code;
    delete data.asset_code;
    return fetch({
        url: '/api/soc/HostVul/'+code,
        method: 'post',
        data: data
    });
}

export function selectFlawByCodeIsNot(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectHostFlawResultByCodeIsNotRecord',
        method: 'post',
        data: data
    });
}

export function slectHostScanResult(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/slectHostScanResult',
        method: 'post',
        data: data
    });
}

export function selectHostScanResultByCode(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectHostScanResultByCode',
        method: 'post',
        data: data
    });
}

export function selectFixedResult(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectFixedResult',
        method: 'post',
        data: data
    });
}

export function selectFixedResultAll(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectFixedResultAll',
        method: 'post',
        data: data
    });
}

export function addFlawFixedResult(data) {
    return fetch({
        url: '/api/soc/rule/action/es/soc_flaw_scan/host_fixed_result/index/'+data.asset_code+'_'+data.vul_id+'_'+data.fixe_time,
        method: 'post',
        data: data
    });
}

export function scheduleSingleScan(data) {
    return fetch({
        url: '/api/soc/ScheduleSingleScan',
        method: 'post',
        data: data
    });
}

export function getLeakRecordId(data) {
    return fetch({
        url: '/api/bpm/process/forms/leak_record',
        method: 'post',
        data: data
    });
}

export function postLeakRecordForm(data) {
    return fetch({
        url: '/api/bpm/rest/process-definition/key/leak_record/submit-form',
        method: 'post',
        data: data
    });
}

export function selectScanResultCountRisk(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectScanResultCountRisk',
        method: 'post',
        data: data
    });
}

export function selectScanStore(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectScanStore`,
        method: 'post',
        data: data
    });
}

export function selectFlawByVulId(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectHostFlawResultByVulId`,
        method: 'post',
        data: data
    });
}

export function selectFlawResultDistribution(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectFlawResultDistribution`,
        method: 'post',
        data: data
    });
}

export function selectScanClassifiedComNum(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectScanClassifiedComNum`,
        method: 'post',
        data: data
    });
}

export function selectCountScanByGrade(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectCountScanByGrade`,
        method: 'post',
        data: data
    });
}

export function selectCounComtNumByVulID(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectCounComtNumByVulID`,
        method: 'post',
        data: data
    });
}

export function queryOsType() {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/queryOsType`,
        method: 'post'
    });
}

export function selectApplicationByCode(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectApplicationByCode`,
        method: 'post',
        data: data
    });
}

export function esUpdate(indexName,type,uid,data) {
    return fetch({
        url: `/api/soc/rule/action/es/${indexName}/${type}/update/${uid}`,
        method: 'post',
        data:data
    });
}


export function selectFlawById(data) {
    let code = data.vul_id;
    delete data.vul_id;
    return fetch({
        url: `/api/soc/VulManyHost/`+code,
        method: 'post',
        data: data
    });
}

export function HostRisk(data) {
    return fetch({
        url: '/api/soc/HostRisk',
        method: 'post',
        data: data
    });
}

export function selectHostRiskTrend(data) {
    return fetch({
        url: '/api/soc/selectHostRiskTrend/'+data.time,
        method: 'post',
    });
}

export function selectNewVul(data) {
    return fetch({
        url: '/api/soc/selectNewVul/'+data.time,
        method: 'post',
    });
}

export function addHighRiskHost(data) {
    return fetch({
        url: '/api/soc/addHighRiskHost/'+data.time,
        method: 'post',
    });
}

export function countZheng(data) {
    return fetch({
        url: '/api/soc/countZheng/'+data.type,
        method: 'post',
    });
}

export function countType(data) {
    return fetch({
        url: '/api/soc/conutType',
        method: 'post',
        data:data
    });
}

export function selectApplication(data) {
    return fetch({
        url: '/api/soc/selectApplication',
        method: 'post',
        data:data
    });
}

export function insertApplication(data) {
    return fetch({
        url: '/api/soc/insertApplication',
        method: 'post',
        data:data
    });
}

export function deleteApplication(data) {
    return fetch({
        url: '/api/soc/deleteApplication',
        method: 'post',
        data:data
    });
}



