import {fetch} from '@/core/fetch.js';

export function getIndexTableData() {
  	return fetch({
        url: '/api/soc/eventCategory/page?!categoryCode=like&!categoryName=like&page=1&limit=-1&kindId=221',
        method: 'get'
  	});
}

export function getEventSourceByCode(code) {
    return fetch({
        url: '/api/soc/eventSource/page?sourceCode='+code,
        method: 'get'
    });
}

export function getRecordItemById(id) {
    return fetch({
        url: '/api/soc/recordItem/page?sourceId='+id,
        method: 'get'
    });
}
