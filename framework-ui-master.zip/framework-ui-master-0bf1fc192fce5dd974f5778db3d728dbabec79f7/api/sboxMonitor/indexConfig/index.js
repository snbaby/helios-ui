import {fetch} from '@/core/fetch.js';

export function getRecordType() {
  	return fetch({
        url: '/api/soc/eventCategory/page?!categoryCode=like&!categoryName=like&page=1&limit=-1&kindId=221',
        method: 'get'
  	});
}
export function getTableData(query) {
    return fetch({
        url: '/api/soc/pluginConfig/page?!pluginCode=like&&!pluginName=like',
        method: 'get',
        params:query
    });
}

export function add(obj) {
    return fetch({
        url: '/api/soc/pluginConfig',
        method: 'post',
        data:obj
    });
}

export function deleteone(id) {
    return fetch({
        url: '/api/soc/pluginConfig/'+id,
        method: 'delete'
    });
}

export function edit(obj) {
    return fetch({
        url: '/api/soc/pluginConfig/'+obj.id,
        method: 'put',
        data:obj
    });
}

export function removeFile(obj) {
    return fetch({
        url: '/api/soc/pluginConfig/removeFile',
        method: 'post',
        params:obj
    });
}

export function download(obj) {
    return fetch({
        url: '/api/soc/pluginConfig/download',
        method: 'post',
        params:obj
    });
}

export function getSboxRunningDetail() {
    return fetch({
        url: '/api/soc/pluginConfig/getSboxRunningDetail',
        method: 'get'
    });
}
