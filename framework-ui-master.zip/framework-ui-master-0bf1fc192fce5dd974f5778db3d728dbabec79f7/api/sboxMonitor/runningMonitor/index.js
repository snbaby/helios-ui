import {fetch} from '@/core/fetch.js';

export function getSqlResult(code) {
  	return fetch({
        url: '/api/admin/sqlManage/getSqlResult/'+code,
        method: 'post'
  	});
}

export function getSqlResultWithQuery(code,query) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/'+code,
        method: 'post',
        data:query
    });
}
