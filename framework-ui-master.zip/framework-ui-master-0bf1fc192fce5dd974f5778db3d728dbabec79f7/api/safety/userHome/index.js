import {fetch} from '@/core/fetch.js';

export function organizationPersonnel(loginUserId) {
  	return fetch({
    	url: '/api/soc/rule/action/es/get/count',
    	method: 'get'
  	});
}

export function countHasInstallSbox(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/countHasInstallSbox',
        method: 'post',
        data:query
    });
}

export function selectPrintOutResultAnalyse(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectPrintOutResultAnalyse',
        method: 'post',
        data:query
    });
}

export function selectSecrecyResultByTitleMatched(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectSecrecyResultByTitleMatched',
        method: 'post',
        data:query
    });
}

export function selectOnlineNumByTime(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectOnlineNumByTime',
        method: 'post',
        data:query
    });
}

export function selectPByProcessId(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectPByProcessId',
        method: 'post',
        data:query
    });
}

export function selectPNormCode(query){
    return fetch({
        url: '/api/soc/rule/action/es/selectPNormCode/'+query,
        method: 'get',
        data:query
    });
}
export function leakTrendHistogram(query){
    return fetch({
        url: '/api/soc/rule/action/es/'+query+'/dateHistogram',
        method: 'get',
    });
}

export function selectPage(query) {
    return fetch({
        url: '/api/soc/flawScanRiskConfig/page',
        method: 'get',
        params: query
    });
}

export function selectHostResultByTypeTime(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectHostResultByTypeTime`,
        method: 'post',
        data: data
    });
}

export function selectHostResultByTypeTimeRisk(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectHostResultByTypeTimeRisk`,
        method: 'post',
        data: data
    });
}

export function slectHostScanResult(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/slectHostScanResult',
        method: 'post',
        data: data
    });
}

export function scheduleSingleScan(data) {
    return fetch({
        url: '/api/soc/ScheduleSingleScan',
        method: 'post',
        data: data
    });
}

export function selectScanResultCountRisk(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectScanResultCountRisk',
        method: 'post',
        data: data
    });
}

export function selectNumFromScanTask(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectNumFromScanTask',
        method: 'post',
        data: data
    });
}

export function selectScanTask(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectScanTask',
        method: 'post',
        data: data
    });
}


export function selectScanStore(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectScanStore`,
        method: 'post',
        data: data
    });
}


export function selectCountScanByGrade(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectCountScanByGrade`,
        method: 'post',
        data: data
    });
}


export function selectCounComtNumByVulID(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectCounComtNumByVulID`,
        method: 'post',
        data: data
    });
}


export function addConfig(query) {
    return fetch({
        url: '/api/soc/flawScanRiskConfig',
        method: 'post',
        data: query
    });
}
export function changeConfig(query) {
    return fetch({
        url: '/api/soc/flawScanRiskConfig/'+query.id,
        method: 'put',
        data: query
    });
}

export function deleteConfig(code) {
    return fetch({
        url: '/api/soc/flawScanRiskConfig/'+code,
        method: 'delete',
    });
}

export function selectTopFiveByScanStore(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/selectTopFiveByScanStore`,
        method: 'post',
        data: data
    });
}
