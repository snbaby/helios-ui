import {
    fetch
} from '@/core/fetch.js';

export function getDepTree() {
    return fetch({
        url: '/api/soc/rule/action/es/org_business/org_business/query/tree',
        method: 'post'
    });
}

export function getSqlResult(code) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/'+code,
        method: 'post'
    });
}

export function getSqlResultWithQuery(code,query) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/'+code,
        method: 'post',
        data:query
    });
}

export function getUserWithSelectPage(query) {
    return fetch({
        url: '/api/admin/user/fetch',
        method: 'get',
        params: query
    });
}

/**
 * 通用文件下载方法
 */
export function fileDownload(url, type, name) {
    fetch({
        url: url,
        method: 'get',
        responseType: 'arraybuffer'
    }).then((res) => {
        let blob = new Blob([res], {
            type: type
        });
        var a = document.createElement('a');
        a.innerHTML = "";
        // 指定生成的文件名
        a.download = name;
        a.href = URL.createObjectURL(blob);

        document.body.appendChild(a);
        var evt = document.createEvent("MouseEvents");
        evt.initEvent("click", false, false);
        a.dispatchEvent(evt);
        document.body.removeChild(a);
    });
};
