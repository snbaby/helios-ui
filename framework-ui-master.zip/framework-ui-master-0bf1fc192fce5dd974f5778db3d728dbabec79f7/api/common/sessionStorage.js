import {
    fetch
} from '@/core/fetch.js';

//数字字典转码
export function getCategoryData(code, key) {
    var codes = JSON.parse(sessionStorage.getItem('codeTable'));
    // var codes = store._modulesNamespaceMap["codeDict/"].state.branch.codeDict;
    //如果参数key非undefind，就按码表类型code，转码key
    if (key != undefined) {
        for (let i = 0; i < codes.length; i++) {
            if (codes[i].id == code) {
                var str = "";
                var keys = key.toString().split(',');
                for (let j = 0; j < codes[i].children.length; j++) {
                    for (let k = 0; k < keys.length; k++) {
                        if (codes[i].children[j].code == keys[k]) {
                            str += codes[i].children[j].label + ',';
                        }
                    }
                }
                if (str.substring(0, str.length - 1).length == 0) {
                    return key;
                } else {
                    return str.substring(0, str.length - 1);
                }
            }
        }
        //否则就按码表类型code，获取对应类型码表
    } else {
        if (codes.filter(val => val.id == code).length > 0) {
            return codes.filter(val => val.id == code)[0].children;
        }
    }
}

//部门转码
export function getDepName(code) {
    var depCodes = JSON.parse(sessionStorage.getItem('depCodeTable'));
    if (code != undefined) {
        for (let i = 0; i < depCodes.length; i++) {
            if (depCodes[i].code == code) {
                return depCodes[i].label;
            }
        }
        return code
    } else {
        return
    }
}

//部门转码
export function getDepNameById(id) {
    var depCodes = JSON.parse(sessionStorage.getItem('depCodeTable'));
    if (id != undefined) {
        for (let i = 0; i < depCodes.length; i++) {
            if (depCodes[i].id == id) {
                return depCodes[i].name;
            }
        }
        return id
    } else {
        return
    }
}
//菜单树
export function getMenuTree() {
    const info = JSON.parse(sessionStorage.getItem('info'));
    return info.menuTree;
}

//菜单树
export function getMenus() {
    const info = JSON.parse(sessionStorage.getItem('info'));
    return info.menus;
}

//当前用户信息
export function getCurrentUser() {
    const info = JSON.parse(sessionStorage.getItem('info'));
    return info;
}



export function fetchTree(query) {
    return fetch({
        url: '/api/admin/group/tree',
        method: 'get',
        params: query
    });
}
export function pagedGroups(query) {
    return fetch({
        url: '/api/admin/group/page',
        method: 'get',
        params: query
    });
}


export function depTree(query) {
    return fetch({
        url:'/api/admin/group/tree?groupType=2&getPerson='+query.getPerson,
        method: "get",
        responseType: "json"
    });
}
