//日期转码格式化
export function formatDateTime(dateObj, dateType) {
    //年月日yyyy-mm-dd
    let dateType1 = 'yyyy-MM-dd';
    //年月日时分秒yyyy-mm-dd-hh-mm-ss
    let dateType2 = 'yyyy-MM-dd hh:mm:ss';
    //时分秒hh-mm-ss
    let dateType3 = 'hh:mm:ss';

    let dateTime = "";
    if(dateObj==undefined){
        return
    }
    let date = new Date(dateObj);
    if (dateType == dateType1) {
        //年月日yyyy-mm-dd
        dateTime = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
    } else if (dateType == dateType2) {
        //年月日时分秒yyyy-mm-dd-hh-mm-ss
        dateTime = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
    } else if (dateType == dateType3) {
        //时分秒hh-mm-ss
        dateTime = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
    }
    return dateTime
};


//时间只取年月日
export function getDataTime(time) {
    if (time) {
        return time.slice(0, 10)
    } else {
        return
    }
};

export function timeStr2timeStamp(strtime) {
    var date = new Date(strtime);
    var timestamp = date.getTime();
    return timestamp
}

export function timestampToTime(timestamp) {
    var date = new Date(timestamp);
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
    var D = date.getDate()<10?'0'+date.getDate() + ' ':date.getDate() + ' ';
    var h = date.getHours()<10?'0'+date.getHours() + ':':date.getHours() + ':';
    var m = date.getMinutes()<10?'0'+date.getMinutes() + ':':date.getMinutes() + ':';
    var s = date.getSeconds()<10?'0'+date.getSeconds():date.getSeconds() + ' ';
    return Y+M+D+h+m+s;
}

export function timestampToTimes(timestamp) {
    var date = new Date(timestamp);
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
    var D = date.getDate()<10?'0'+date.getDate() + ' ':date.getDate() + ' ';
    var h = date.getHours()<10?'0'+date.getHours() + ':':date.getHours() + ':';
    var m = date.getMinutes()<10?'0'+date.getMinutes():date.getMinutes();
    return Y+M+D+h+m;
}

//查询对象中指定属性为真，返回指定属性用逗号隔开
const queryObjMeetConditionsIds = function(obj, attrName1, attrName2, ids) {
    if (attrName1 == undefined || attrName2 == undefined) {
        return
    }
    for (var i = 0; i < obj.length; i++) {
        if (obj[i][attrName1] == true) {
            ids.push(obj[i][attrName2]);
        }
        if (obj[i].children) {
            queryObjMeetConditionsIds(obj[i].children, attrName1, attrName2, ids);
        }
    }
}
export const getObjMeetConditionsIds = function(obj, attrName1, attrName2) {
    let ids = [];
    queryObjMeetConditionsIds(obj, attrName1, attrName2, ids);
    return ids


};
