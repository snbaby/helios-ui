import {fetch} from '@/core/fetch.js';

export function organizationPersonnel(loginUserId) {
  	return fetch({
    	url: '/api/soc/rule/action/es/get/count',
    	method: 'get'
  	});
}

export function countHasInstallSbox(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/countHasInstallSbox',
        method: 'post',
        data:query
    });
}

export function selectPrintOutResultAnalyse(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectPrintOutResultAnalyse',
        method: 'post',
        data:query
    });
}

export function selectSecrecyResultByTitleMatched(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectSecrecyResultByTitleMatched',
        method: 'post',
        data:query
    });
}

export function selectOnlineNumByTime(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectOnlineNumByTime',
        method: 'post',
        data:query
    });
}

export function selectPByProcessId(query){
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/selectPByProcessId',
        method: 'post',
        data:query
    });
}

export function selectPNormCode(query){
    return fetch({
        url: '/api/soc/rule/action/es/selectPNormCode/'+query,
        method: 'get',
        data:query
    });
}
export function leakTrendHistogram(query){
    return fetch({
        url: '/api/soc/rule/action/es/'+query+'/dateHistogram',
        method: 'get',
    });
}

export function selectPage(query) {
    return fetch({
        url: '/api/soc/flawScanRiskConfig/page',
        method: 'get',
        params: query
    });
}

export function getSqlResult(code) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/'+code,
        method: 'post'
    });
}


export function HostRisk(data) {
    return fetch({
        url: '/api/soc/HostRisk',
        method: 'post',
        data: data
    });
}

export function selectHostRiskTrend(data) {
    return fetch({
        url: '/api/soc/selectHostRiskTrend/'+data.time,
        method: 'post',
    });
}
