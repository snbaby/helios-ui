import {fetch} from '@/core/fetch.js';

export function countApproveUser() {
  	return fetch({
    	url: '/api/admin/group/countApproveUser',
    	method: 'get',
		responseType:"json"
  	});
}

export function getApproveUser(id) {
  	return fetch({
    	url: '/api/admin/group/'+id+'/user/page?page=1&limit=1000',
    	method: 'get',
		responseType:"json"
  	});
}

