import {fetch} from '@/core/fetch.js';

//发起流程
export function postProcess(val,processKey,businessKey) {
    //满足新bpmn数据格式
    var newData={variables:{}};
    for (let i in val){
        newData.variables[i]={value:val[i].toString()};
    }
    newData.businessKey = businessKey;

    return fetch({
        "url": `/api/bpm/rest/process-definition/key/${processKey}/tenant-id/000000/submit-form`,
        "data": newData,
        "method": "post"
    })
}

//获取流程当前节点表单数据（表单、按钮）
export function processNodeData(flow_instance_id) {
    return  fetch(`/api/bpm/process/task/form/var/${flow_instance_id}`, {
        method: "get",
        responseType: "json"
    })
}

//获取发起流程表单数据（审批展示）
export function processPostData(taskId) {
    return  fetch(`/api/bpm/process/task/form/${taskId}`, {
        method: "get",
        responseType: "json"
    })
}

//审批流程
export function approvalProcess(val,taskId) {
    //满足新bpmn数据格式
    var newData={variables:{}};
    for (let i in val){
        newData.variables[i]={value:val[i]};
    }
    return  fetch({
        "url": `/api/bpm/rest/task/${taskId}/submit-form`,
        "data": newData,
        "method": "post"
    })
}

//签收流程
export function claimProcess(val,taskId) {
    //满足新bpmn数据格式
    var newData= {userId:val};
    return  fetch({
        "url": `/api/bpm/rest/task/${taskId}/claim`,
        "data": newData,
        "method": "post"
    })
}

//获取流程审批时申请的数据
export function getProcessStartForm(type,flow_instance_id) {
    var query = {
        type:type,
        processInstanceId:flow_instance_id
    }

    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/queryTaskApplyInfoByTypeAndInstId",
        "method": "post",
        data:query
    })
}

//通过流程实例ID查询流程发起信息
export function selectTaskInfoByActivityInstanceId(activityInstanceId) {
    var query = {
        activityInstanceId:activityInstanceId
    }
    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/selectTaskInfoByActivityInstanceId",
        "method": "post",
        data:query
    })
}


//获取流程编号
export function getBusinessKey() {
    return  fetch({
        "url": "/api/bpm/process/forms/P12345678",
        "method": "post"
    })
}

//获取历史审批信息
export function getHistoryApproveData(activityInstanceId) {
    var query = {
        flow_instance_id:activityInstanceId
    }
    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/queryHistoryProcessTaskList",
        "method": "post",
        data:query
    })
}

export function queryInstanceIdAndTypeByTaskId(taskId) {
    var query = {
        taskId:taskId
    }
    return  fetch({
        "url": "/api/admin/sqlManage/getSqlResult/queryInstanceIdAndTypeByTaskId",
        "method": "post",
        data:query
    })
}

export function upEsData(data) {
    return  fetch({
        "url": "/api/soc/UpEsData",
        "method": "post",
        data:data
    })
}
