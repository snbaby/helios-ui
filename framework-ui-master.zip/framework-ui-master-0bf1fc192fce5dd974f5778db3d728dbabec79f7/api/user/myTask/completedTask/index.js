import {fetch} from '@/core/fetch.js';

export function getTableData(query) {
    let id = query.id;
    delete query.id;
    return fetch({
        url: '/api/soc/rule/action/es/queryFlowApplyInfo/'+id,
        method: 'post',
        data: query
    });
}
