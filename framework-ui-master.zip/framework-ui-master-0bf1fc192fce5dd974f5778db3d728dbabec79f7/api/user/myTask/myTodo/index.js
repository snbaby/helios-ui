import {fetch} from '@/core/fetch.js';

export function fetchTree(query) {
    return fetch({
        url: '/api/admin/group/tree',
        method: 'get',
        params: query
    });
}

export function pagedGroups(query) {
    return fetch({
        url: '/api/admin/group/page',
        method: 'get',
        params: query
    });
}

export function queryProcessApplyInfo(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/queryProcessByInstanceId',
        method: 'post',
        data: data
    });
}

export function getProcessTask(data) {
    return fetch({
        url: `/api/bpm/rest/task`,
        method: 'get',
        params: data
    });
}
