import {fetch} from '@/core/fetch.js';

export function queryTrackingTaskProcess(data) {
    return fetch({
        url: '/api/admin/sqlManage/getSqlResult/queryTrackingTaskProcess',
        method: 'post',
        data: data
    });
}
