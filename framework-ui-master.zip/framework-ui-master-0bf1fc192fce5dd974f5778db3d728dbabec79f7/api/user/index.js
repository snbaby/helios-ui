import {fetch} from '@/core/fetch.js';

export function delObj(id) {
  return fetch({
    url: '/api/admin/user/' + id,
    method: 'delete'
  })
}
export function searchProceeeDefineList(query) {
    let url = "/api/bpm/rest/process-definition?"+query;
    return fetch({
        url: url,
        method: 'get'
    });
}

export function getProceeeDefine(id) {
    let url = `/api/bpm/rest/process-definition/${id}/xml`;
    return fetch({
        url: url,
        method: 'get'
    });
}

export function queryProcessList(data) {
    return fetch({
        url: `/api/admin/sqlManage/getSqlResult/queryProcessList`,
        method: 'post',
        data: data
    });
}
