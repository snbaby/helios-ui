import {fetch} from '@/core/fetch.js';

export function getHead() {
  	return fetch({
    	url: '/api/soc/kindManageCategory/getParameterHead',
    	method: 'post'
  	});
}

export function getTableHead(code) {
  	return fetch({
    	url: '/api/soc/kindMeta/getMetaTableHeadView?code='+code,
    	method: 'get'
  	});
}

export function getOrginazationDepTree(orgType) {
  	return fetch({
    	url: '/api/soc/baseData/orgTree?orgType='+orgType,
    	method: 'post'
  	});
}

export function getTableData(index,type,query) {
	var page = query.page;
	var size = query.size;
	delete query.page;
	delete query.size;
  	return fetch({
    	url: '/api/soc/rule/action/es/'+index+'/'+type+'/query/term?page='+page+'&size='+size,
    	method: 'post',
		data:query
  	});
}

export function getTreeData(index,type,query) {
  	return fetch({
    	url: '/api/soc/rule/action/es/'+index+'/'+type+'/query/tree',
    	method: 'post',
		data:query
  	});
}

export function getOneForButton(query) {
    return fetch({
        url: '/api/soc/kindManageCategory/page',
        method: 'get',
        params:query
    });
}

export function getButtonDetail(categroyId) {
    return fetch({
        url: '/api/soc/parameterButton/page?page=1&limit=-1&categroyId='+categroyId,
        method: 'get'
    });
}
