<template>
    <div>
        <div>
            <page-header></page-header>
        </div>
        <div>
            <page-system-menu></page-system-menu>
        </div>
        <div class="framework-skeleton-content">
            <div class="framework-skeleton-inner-tabs">
                <page-system-tabs></page-system-tabs>
            </div>
            <div :class="contentClass">
                <router-view></router-view>
            </div>
        </div>
    </div>
</template>

<script>
    import pageHeader from '@/components/base/appVue/pageHeader';
    import pageSystemMenu from '@/components/base/appVue/pageSystemMenu';
    import pageSystemTabs from '@/components/base/appVue/pageSystemTabs';

    export default {
        name: 'soc',
        components: {
            pageHeader,
            pageSystemMenu,
            pageSystemTabs
        },
        data() {
            return {
                contentClass : "framework-skeleton-inner-content"
            }
        },
        watch: {
            "$route": function (to, from) {
                this.correct();
            }
        },
        methods: {
            correct() {
                if (this.$route.path == "/soc/home-page") {
                    this.contentClass = "framework-skeleton-inner-content soc-home-page";
                } else if (this.$route.path == "/soc/security-situation") {
                    this.contentClass = "framework-skeleton-inner-content soc-security-situation";
                } else {
                    this.contentClass = "framework-skeleton-inner-content";
                }
            }
        },
        created() {
            this.correct();
        }
    };
</script>
