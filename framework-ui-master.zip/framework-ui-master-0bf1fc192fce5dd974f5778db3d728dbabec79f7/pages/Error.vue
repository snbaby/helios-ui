<template>
    <div class="page-error">
        <p>{{ message }}</p>
    </div>
</template>

<script>
export default {
    name: 'error',
    computed: {
        message() {
            return this.$route.params.error || '系统建设中...';
        }
    },
    created() {
        let query = this.$route.query;
        if (Object.keys(query).length !== 0) {
            this.$router.replace({
                name: 'error',
                params: query
            });
        }
    }
};
</script>

<style lang="stylus" scoped>
.page-error
    display flex
    justify-content center
    align-items center
    flex-direction column
</style>
