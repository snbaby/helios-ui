<template>
    <div class="backColor" id="userHome">
        <div class="middleContentImg">
            <div class="pageContent">
                <mu-row style="height: 270px; width: 100%;" gutter>
                    <mu-col desktop="20" style="height: 100%">
                        <div class="cardBack" >
                            <!--<div id="gaugechart" style="height: 100%;width: 100%;"></div>-->
                            <gauge-echarts :risk-num="riskNum" v-if="riskShow" line-ref="gaugechart"></gauge-echarts>
                            <div class="riskNum">
                                <el-col :span="16" class="paddingFont">当前风险值</el-col>
                                <el-col :span="8" class="numSize">{{riskNum}}</el-col>
                            </div>
                        </div>
                    </mu-col>
                    <mu-col desktop="20" style="height: 100%">
                        <div class="cardBack terminalStyle">
                            <el-row>
                                <font style="font-size: 20px">用户终端: {{allNum}}</font>
                            </el-row>
                            <el-row style="margin-top: 10px">
                                <font>园区网: {{terminalNum[0]}}</font>
                            </el-row>
                            <el-row style="padding-left: 40px">
                                <el-row>
                                    <font>机密: {{terminalNum[1]}}</font>
                                </el-row>
                                <el-row>
                                    <font>秘密: {{terminalNum[2]}}</font>
                                </el-row>
                                <el-row>
                                    <font>内部: {{terminalNum[3]}}</font>
                                </el-row>
                            </el-row>
                            <el-row style="margin-top: 10px">
                                <font>单机: {{terminalNum[4]}}</font>
                            </el-row>
                            <el-row style="padding-left: 40px">
                                <el-row>
                                    <font>机密: {{terminalNum[5]}}</font>
                                </el-row>
                                <el-row>
                                    <font>秘密: {{terminalNum[6]}}</font>
                                </el-row>
                                <el-row>
                                    <font>内部: {{terminalNum[7]}}</font>
                                </el-row>
                            </el-row>
                        </div>
                    </mu-col>
                    <mu-col desktop="35" class="cardBack">
                        <div class="cardBack" >
                            <leakTrendCountEcharts line-ref="riskTrend" :risk-trend-data="riskTrendData" name="漏洞趋势" v-if="riskCountShow"></leakTrendCountEcharts>
                        </div>
                    </mu-col>
                    <mu-col desktop="25" style="height: 100%">
                        <div class="cardBack">
                            <mu-row >
                                <mu-tabs :value="activeTab" lineClass="spanBack" @change="handleTabChange">
                                    <mu-tab value="tab1" title="我的待办"/>
                                    <mu-tab value="tab2" title="我的已办"/>
                                    <mu-tab value="tab3" title="我的申请"/>
                                </mu-tabs>
                                <div class="rowsContent" v-if="activeTab == 'tab1'">
                                    <div style="height: 186px">
                                        <el-row v-for="item,index in myTodoTaskTableData" :key="index" class="rowStyle">
                                            <el-col :span="20">
                                                <li class="task" :title="item.norm_title">{{item.flow_proposer_name + '-' + item.flow_proposer_code + '-' + (item.norm_title?item.norm_title:item.flow_instance_name)}}</li>
                                            </el-col>
                                            <el-col :span="4">
                                                <font class="do" @click="doApproval(item)">去处理</font>
                                            </el-col>
                                        </el-row>
                                        <el-row v-if="myTodoTaskTableData&&myTodoTaskTableData.length==0">暂无数据</el-row>
                                    </div>
                                    <el-row class="rowStyle pointMore">
                                        <font class="more" @click="toMyTodo">更多</font>
                                    </el-row>
                                </div>
                                <div class="rowsContent" v-if="activeTab == 'tab2'">
                                    <div style="height: 186px">
                                        <el-row v-for="item,index in completeTaskTableData.data" :key="index" class="rowStyle">
                                            <el-col :span="20">
                                                <li class="task" :title="item.flow_instance_name">{{item.flow_proposer_name + '-' + item.flow_proposer_code + '-' + item.flow_instance_name}}</li>
                                            </el-col>
                                            <el-col :span="4">
                                                <font class="do" @click="viewBpmn(item)">查看</font>
                                            </el-col>
                                        </el-row>
                                        <el-row v-if="completeTaskTableData.rows&&completeTaskTableData.rows.length==0">暂无数据</el-row>
                                    </div>
                                    <el-row class="rowStyle pointMore">
                                        <font class="more" @click="toCompleteTask">更多</font>
                                    </el-row>
                                </div>
                                <div class="rowsContent" v-if="activeTab == 'tab3'">
                                    <div style="height: 186px">
                                        <el-row v-for="item,index in trackingTaskTableData.data" :key="index" class="rowStyle">
                                            <el-col :span="18">
                                                <li class="task" :title="item.flow_instance_name">{{item.flow_instance_name}}</li>
                                            </el-col>
                                            <el-col :span="6">
                                                <font class="do" @click="viewBpmn(item)">查看</font>
                                            </el-col>
                                        </el-row>
                                        <el-row v-if="trackingTaskTableData.rows&&trackingTaskTableData.rows.length==0">暂无数据</el-row>
                                    </div>
                                    <el-row class="rowStyle pointMore">
                                        <font class="more" @click="toPlanTask">更多</font>
                                    </el-row>
                                </div>
                            </mu-row>
                        </div>
                    </mu-col>
                </mu-row>
                <mu-row style="margin-top: 20px">
                    <div class="manageheader">
                        <font>园区网终端当前在线: {{onlineNum}}台</font>
                    </div>
                </mu-row>
                <mu-row style="height: 309px;width: 100%" gutter>
                    <mu-col desktop="33" class="cardBack">
                        <processMonitorEcharts :process-monitor-data="processMonitorData" v-if="processMonitorData.isfinished"></processMonitorEcharts>
                    </mu-col>
                    <mu-col desktop="33" class="cardBack">
                        <div id="VirusesTrend" style="height: 100%;width: 100%;"></div>
                    </mu-col>
                    <mu-col desktop="33" class="cardBack">
                        <leakTrendCountEcharts line-ref="leakTrend" :leak-trend-data="leakTrendData" name="漏洞趋势"></leakTrendCountEcharts>
                    </mu-col>
                </mu-row>
                <mu-row style="height: 220px;width: 100%;margin-top: 10px" gutter>
                    <mu-col desktop="33" class="cardBack">
                        <safetyProtectionEcharts :safety-protection-data="safetyProtectionData"></safetyProtectionEcharts>
                    </mu-col>
                    <mu-col desktop="33" class="cardBack">
                        <openPortsEcharts :open-ports-data="openPortsData"></openPortsEcharts>
                    </mu-col>
                    <mu-col desktop="33" class="cardBack">
                        <recordStatisticsEcharts :record-statistics-data="recordStatisticsData"></recordStatisticsEcharts>
                    </mu-col>
                </mu-row>
                <mu-row style="height: 220px;width: 100%;margin-top: 10px" gutter>
                    <mu-col desktop="33" class="cardBack">
                        <printOutEcharts :print-out-data="printOutData"></printOutEcharts>
                    </mu-col>
                    <mu-col desktop="33" class="cardBack">
                        <div id="getBurnTheOutputTrendOption" style="height: 100%;width: 100%;"></div>
                    </mu-col>
                    <mu-col desktop="33" class="cardBack">
                        <mu-row >
                            <mu-tabs :value="activeTabel" lineClass="spanBack" @change="activeTabelChange">
                                <mu-tab value="tab1" title="制度"/>
                                <mu-tab value="tab2" title="策略"/>
                                <mu-tab value="tab3" title="安全知识"/>
                            </mu-tabs>
                            <div class="rowsContent" v-if="activeTabel == 'tab1'">
                                <el-row class="rowStyle pointMore">
                                    <!--<font class="more" @click="toMyTodo">更多</font>-->
                                </el-row>
                            </div>
                            <div class="rowsContent" v-if="activeTabel == 'tab2'">
                                <el-row class="rowStyle pointMore">
                                    <!--<font class="more" @click="toCompleteTask">更多</font>-->
                                </el-row>
                            </div>
                            <div class="rowsContent" v-if="activeTabel == 'tab3'">
                                <el-row class="rowStyle pointMore">
                                    <!--<font class="more" @click="toPlanTask">更多</font>-->
                                </el-row>
                            </div>
                        </mu-row>
                    </mu-col>
                </mu-row>
                <mu-row style="height: 10px"></mu-row>
            </div>
        </div>
    </div>
</template>

<script>
    import {getCompleteTaskTableData} from '@/api/taskCenter/myTask/completeTask.js';
    import {getTrackingTaskTableData} from '@/api/taskCenter/myTask/trackingTask.js';
    import {organizationPersonnel,countHasInstallSbox,selectPrintOutResultAnalyse,selectSecrecyResultByTitleMatched,
        selectPNormCode,leakTrendHistogram,selectPage,selectOnlineNumByTime,selectPByProcessId,getSqlResult,HostRisk,
        selectHostRiskTrend} from '@/api/userHome/index.js'
    import echarts from "echarts";
    import processMonitorEcharts from '../../components/homeEcharts/processMonitorEcharts.vue';
    import printOutEcharts from '../../components/homeEcharts/printOutEcharts.vue';
    import openPortsEcharts from '../../components/homeEcharts/openPortsEcharts.vue';
    import safetyProtectionEcharts from '../../components/homeEcharts/safetyProtectionEcharts.vue';
    import recordStatisticsEcharts from '../../components/homeEcharts/recordStatisticsEcharts.vue';
    import leakTrendCountEcharts from '../../components/homeEcharts/leakTrendCountEcharts.vue';
    import gaugeEcharts from '../../components/homeEcharts/gaugeEcharts.vue';
    import {
        queryProcessApplyInfo,
        getProcessTask
    } from '@/api/admin/bpmn/index.js';

    import async1 from "async";
    import GaugeEcharts from "../../components/homeEcharts/gaugeEcharts";

    export default {
        name: 'secretHome',
        components: {
            GaugeEcharts,
            processMonitorEcharts,
            printOutEcharts,
            safetyProtectionEcharts,
            openPortsEcharts,
            recordStatisticsEcharts,
            leakTrendCountEcharts,
            gaugeEcharts
        },
        data(){
            return {
                riskNum: null,
                riskShow: false,
                activeTab: 'tab1',
                activeTabel: 'tab1',
                personKindCode: '',
                personCategoryCode: '',
                personCategoryName: '',
                personNumber: '',
                depInfo:{},
                depName:'',
                assets:[],
                myTodoTaskSearch:{},
                completeTaskSearch:{},
                trackingTaskSearch:{},
                myTodoTaskTableData : [],
                terminalNum: [],
                processMonitorData:{
                    normTotal:0,
                    total:0,
                    compliance:0,
                    nocompliance:0,
                    matched:0,
                    nomatched:0,
                    isfinished:false
                },
                allNum: 0,
                countSboxQuery: [{
                    where: "and asset_network = 'YQW'"
                },{
                    where: "and asset_network = 'YQW' and asset_secret ='JM'"
                },{
                    where: "and asset_network = 'YQW' and asset_secret ='MM'"
                },{
                    where: "and asset_network = 'YQW' and asset_secret ='NB'"
                },{
                    where: "and asset_network = 'DJ'"
                },{
                    where: "and asset_network = 'DJ' and asset_secret ='JM'"
                },{
                    where: "and asset_network = 'DJ' and asset_secret ='MM'"
                },{
                    where: "and asset_network = 'DJ' and asset_secret ='NB'"
                }
                ],
                selectFileSecret: [
                    {secret: '公开'},
                    {secret: '内部'},
                    {secret: '秘密'},
                    {secret: '机密'},
                ],
                printOutData:[],
                safetyProtectionMatched: [1,2,0,-1],
                safetyProtectionTitle: ['IdProtect', 'AntiVirus','AllInOne','HostAudit'],
                safetyProtectionData: [],
                openPortsSearch:[
                    {norm_code: 'ParallelPort'},
                    {norm_code: 'SerialPort'},
                    {norm_code: 'RecordingPort'},
                    {norm_code: 'ReadPort'},
                ],
                openPortsData: [],
                recordStatisticsSearch: [
                    {norm_code: 'AdminAccess'},
                    {norm_code: 'Domain'},
                    {norm_code: 'QuickFixEngineering'},
                    {norm_code: 'OSLogComplete'},
                ],
                leakTrendData: {
                    time: [],
                    count: []
                },
                riskTrendData: {
                    time: [],
                    count: []
                },
                riskTime: 30,
                riskCountShow: false,
                recordStatisticsData: [],
                onlineNum: '',
                currentUser:{},
                completeTaskTableData:{},//我的已办任务
                trackingTaskTableData:{} //我的任务跟踪
            }
        },
        methods: {
            selectHostTrend(){
                this.riskCountShow = false;
                let query = {
                    time: this.riskTime
                };
                selectHostRiskTrend(query).then(data => {
                    if(data.status == 200){
                        for(let i = data.data.length-1 ; i >=0; i--){
                            let time = data.data[i].date.substring(8,10)+"/"+data.data[i].date.substring(5,7);
                            this.riskTrendData.time.push(time);
                            this.riskTrendData.count.push(data.data[i].risk);
                        }
                        this.riskCountShow = true;
                    }
                })
            },
            getRiskNum(){
                this.riskShow = false;
                HostRisk().then(data => {
                    if(data.status == 200){
                        this.riskNum = data.data;
                        this.riskShow = true;
                    }
                })
            },
            VirusesTrend(){
                var myChart = echarts.init(document.getElementById('VirusesTrend'));
                myChart.setOption({
                    grid: {
                        right: '40px'
                    },
                    title: {
                        text: '病毒趋势',
                        textStyle: {
                            color: '#9ad7f8',
                            fontWeight: 'bold',
                            fontSize: 14
                        },
                        padding: [30, 0, 0, 24]
                    },
                    tooltip: {
                        trigger: 'axis',
                        backgroundColor: 'rgba(0,78,162,0.8)',
                        borderWidth: '1',
                        borderColor: 'rgba(5,37,110,0.8)',
                        axisPointer: {
                            label: {
                                backgroundColor: 'rgba(131,158,68,0.4)'
                            }
                        },
                        textStyle: {
                            color: '#9ad7f8',
                            fontSize: '12'
                        },
                        formatter: function (params, ticket, callback) {
                            let date = params[0].name
                            let num = params[0].value
                            date = date.substring(3, 5) + '月' + date.substring(0, 2) + '号' + '</br><li>' + '风险值 :' + num
                            return date
                        }
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,

                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: '12',
                                marginTop: '4'
                            },
                            interval: 1,
                            rotate:70,
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#1e4673'
                            }
                        },
                        data: this.leakTrendData.time,
                    },
                    yAxis: {
                        type: 'value',
                        minInterval: 1,
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: '12',
                                marginTop: '4'
                            }
                        },
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#1e4673'
                            }
                        },
                        splitLine: {show: false},
                    },
                    series: [{
                        type: 'line',
                        itemStyle: {
                            normal: {
                                color: '#08e69a',
                                lineStyle: {
                                    color: '#08e69a',
                                    width: 2
                                }
                            }
                        },
                        name: '风险值',
                        data: [
                            2.8, 2.2, 1.5, 2.3, 2.2, 2.8, 3.5,3.2,3.1,2.8,
                            2.8, 2.2, 1.5, 2.3, 2.2, 2.8, 3.5,3.2,3.1,2.8,
                            2.8, 2.2, 1.5, 2.3, 2.2, 2.8, 3.5,3.2,3.1,2.8
                        ],
                        markLine: {
                            silent: true,
                            data: [ {
                                name: '平均线',
                                type: 'average',
                            }],
                            label:{
                                show: false
                            },
                            symbol: 'none',
                            formatter: '',
                        }
                    }]
                });
                myChart.resize();
            },
            getBurnTheOutputTrendOption(){
                var myChart = echarts.init(document.getElementById('getBurnTheOutputTrendOption'));
                myChart.setOption({
                    title: {
                        text: '部门刻录输出统计',
                        textStyle: {
                            color: '#9ad7f8',
                            fontWeight: 'bold',
                            fontSize: 14
                        },
                        padding: [30, 0, 0, 24]
                    },
                    legend: {
                        bottom: 0,
                        align: 'auto',
                        textStyle: {
                            color: '#9ad7fb',
                            fontSize: 10
                        },
                        itemWidth: 8,
                        itemHeight: 8,
                        data: ['公开', '内部', '秘密', '机密']
                    },
                    label: {
                        normal: {
                            color: '#9ad7f8'
                        }
                    },
                    series: [{
                        type: 'pie',
                        radius: ['20%', '50%'],
                        center: ['50%','50%'],
                        roseType: 'radius',
                        label: {
                            normal: {
                                formatter: "{c}",
                                show: true
                            },
                        },
                        data: [{
                            value: 200,
                            name:'公开',
                            itemStyle: {
                                normal: {
                                    color: '#ea7efa'
                                }
                            }
                        },{
                            value: 300,
                            name:'内部',
                            itemStyle: {
                                normal: {
                                    color: '#d953fa'
                                }
                            }
                        },{
                            value:400,
                            name:'秘密',
                            itemStyle: {
                                normal: {
                                    color: '#be22e5'
                                }
                            }
                        },{
                            value: 500,
                            name:'机密',
                            itemStyle: {
                                normal: {
                                    color: '#910bc9'
                                }
                            }
                        }
                        ]
                    }, {
                        type: 'pie',
                        radius: ['60%', '60.5%'],
                        center: ['50%','50%'],
                        hoverAnimation: false,
                        tooltip: {
                            normal: {
                                show: false
                            }
                        },
                        label: {
                            normal: {
                                show: false
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#9ad7f8'
                            }
                        },
                        data: [{
                            value: 1
                        }]
                    }]
                });
                myChart.resize();
            },
            handleTabChange (val) {
                this.activeTab = val;
            },
            activeTabelChange(val){
                this.activeTabel = val;
            },

            //终端保密检查数据获取
            getProcessMonitor() {
                var self = this;
                self.processMonitorData = {
                    normTotal:0,
                        total:0,
                        compliance:0,
                        nocompliance:0,
                        matched:0,
                        nomatched:0,
                        isfinished:false
                };
                async1.parallel([
                    function (call) {
                        //查询所有已安装sbox数量
                        self.getSqlResultWithQuery('countHasInstallSbox', {where: ""}).then((data) => {
                            self.processMonitorData.total = data.data.total;
                            call();
                        });
                    }
                ],
                function(err, results){
                    self.initProcessMonitorData();
                });
            },
            initProcessMonitorData() {
                var self = this;
                async1.series([
                    function (call) {
                        //查询所有指标项
                        self.getSqlResultWithQuery('selectIndexTableDataForSbox', {
                            "where": "",
                            "page": 0,
                            "limit": 10
                        }).then((data) => {
                            self.processMonitorData.normTotal = data.data.total;
                            call();
                        });
                    },
                    function (call) {
                        //查询所有已检查指标项
                        var createTime = new Date()-30*24*60*60*1000;
                        self.getSqlResultWithQuery('getMatchedNormCount', {where: " and create_time > "+createTime}).then((data) => {
                            var arr = data.data.aggs.operater_host_code.buckets;
                            self.processMonitorData.compliance = 0;
                            for (var i in arr) {
                                if (arr[i].doc_count == self.processMonitorData.normTotal) {
                                    self.processMonitorData.compliance++;
                                }
                            }
                            self.processMonitorData.nocompliance = self.processMonitorData.total - self.processMonitorData.compliance;
                            call();
                        });
                    },
                    function (call) {
                        //查询合规项
                        var createTime = new Date()-30*24*60*60*1000;
                        self.getSqlResultWithQuery('getMatchedNormCount', {where: " and create_time > "+createTime +" and norm_matched = 1 or norm_matched = 2"}).then((data) => {
                            var arr = data.data.aggs.operater_host_code.buckets;
                            self.processMonitorData.matched = 0;
                            for (var i in arr) {
                                if (arr[i].doc_count == self.processMonitorData.normTotal) {
                                    self.processMonitorData.matched++;
                                }
                            }
                            self.processMonitorData.nomatched = self.processMonitorData.compliance - self.processMonitorData.matched;
                            call();
                        });
                    }
                ], function () {
                    self.processMonitorData.isfinished = true;
                })
            },

            //终端在线率
            selectOnlineNumByTime(){
                let query={
                    time : new Date().getTime() - 86400000
                };
                selectOnlineNumByTime(query).then(data => {
                    if(data.status == 200) {
                        this.onlineNum = data.data.aggs['COUNT(*)'].value;
                    }else {
                        console.log('获取终端在线数量失败');
                    }
                });
            },

            //部门打印输出数据统计
            selectPrintOutResultAnalyse(){
                const that = this;
                that.printOutData = [];
                async1.map(that.selectFileSecret,function(item,callBack){
                    selectPrintOutResultAnalyse(item).then((data)=>{
                        if(data.status == 200){
                            callBack(null,data.data.total);
                        }else{
                            callBack(null)
                        }
                    });
                }, function(err, results) {
                    if(err){
                        console.log(err);
                    }else{
                        that.printOutData = results;
                    }
                });
            },

            //端口开放项统计
            searchOpenPortsData() {
                const that = this;
                that.openPortsData = [];
                async1.map(that.openPortsSearch,function(item,callBack){
                    selectPNormCode(item.norm_code).then((data)=>{
                        if(data.status == 200){
                            callBack(null,data.data.total);
                        }else{
                            callBack(null)
                        }
                    });
                }, function(err, results) {
                    if(err){
                        console.log(err);
                    }else{
                        that.openPortsData = results;
                    }
                });
            },

            //备案信息统计
            searchRecordStatisticsData(){
                const that = this;
                that.recordStatisticsData = [];
                async1.map(that.recordStatisticsSearch,function(item,callBack){
                    selectPNormCode(item.norm_code).then((data)=>{
                        if(data.status == 200){
                            callBack(null,data.data.total);
                        }else{
                            callBack(null)
                        }
                    });
                }, function(err, results) {
                    if(err){
                        console.log(err);
                    }else{
                        that.recordStatisticsData = results;
                    }
                });
            },

            //安全防护统计
            searchsafetyProtectionData(){
                const that = this;
                that.safetyProtectionData = [];
                async1.map(that.safetyProtectionMatched, function (item, callBack){
                    async1.map(that.safetyProtectionTitle, function (items, callBack) {
                        selectSecrecyResultByTitleMatched({
                            matched: item,
                            title: items
                        }).then((data) => {
                            if (data.status == 200) {
                                callBack(null, data.data.total);
                            } else {
                                callBack(null);
                            }
                        });

                    }, function (err, result) {
                        if (err) {
                            console.log(err);
                        } else {
                            callBack(null,result);
                        }
                    });
                },function (err, results) {
                    if (err) {
                        console.log(err);
                    } else {
                        that.safetyProtectionData = results;
                    }
                });

            },

            //漏洞趋势
            serachleakTrendHistogram(){
                const self = this;
                async1.waterfall([
                    function(callback){
                        let query = {
                            page: 1,
                            limit: 10
                        };
                        selectPage(query).then(data=>{
                            if(data.status == 200) {
                                for (let i in data.data.rows) {
                                    if (data.data.rows[i].name == '中危') {
                                        callback(null, data.data.rows[i].minRisk);
                                        break;
                                    }
                                }
                            }else {
                                callback(null);
                            }
                        });
                    },
                    function(dataVal, callback){
                        leakTrendHistogram(dataVal).then(data => {
                            if(data.status == 200){
                                callback(null,data.data);
                            }else {
                                callback(null);
                            }
                        })
                    }
                ], function (err, result) {
                    if(err){
                        console.log(err);
                    }else {
                        self.leakTrendData = {
                            time: [],
                            count: []
                        };
                        for(let i = result.length-1 ; i >=0; i--){
                            let time = result[i].date.substring(8,10)+"/"+result[i].date.substring(5,7);
                            self.leakTrendData.time.push(time);
                            self.leakTrendData.count.push(result[i].count);
                        }
                        self.VirusesTrend();
                    }
                });
            },

            findDepName(){
                const list = this.getCurrentUser().groups;
                let arr = [];
                for(let i in list){
                    if(list[i].type == 2){
                        arr.push(list[i].name);
                    }
                }
                this.depName = arr.toString();
            },
            //去我的代办任务
            toMyTodo(){
                this.$router.push({
                    path: '/soc/task-center/pending-task',
                })
            },
            //去终端态势
            toTerminalSituation(){
                this.$router.push({
                    path: '/secret/cockpit/terminalSituation',
                })
            },
            //去执行处理
            doApproval(val){
                if(val.process_definition_key == 'P12345678'){
                    this.$router.push({
                        path: '/soc/task-center/approve-loophole-record-process',
                        query:{
                            flow_instance_id:val.flow_instance_id,
                            taskId:val.flow_task_id,
                            type:val.process_definition_key
                        }
                    });
                }else if(val.process_definition_key == 'leak_record'){
                    this.$router.push({
                        path: '/soc/task-center/leak-record-process',
                        query:{
                            flow_instance_id:val.flow_instance_id,
                            type:val.process_definition_key,
                            taskId:val.flow_task_id,
                            flow_business_key: val.flow_business_key
                        }
                    });
                }else if(val.process_definition_key == 'cancel_record'){
                    this.$router.push({
                        path: '/soc/task-center/cancle-record-process',
                        query:{
                            flow_instance_id:val.flow_instance_id,
                            taskId:val.flow_task_id,
                            type:val.process_definition_key
                        }
                    });
                }
            },
            //去计划任务
            toPlanTask(){
                this.$router.push({
                    path: '/soc/task-center/application-task',
                })
            },
            //去任务跟踪
            toTrackingTask(){
                this.$router.push({
                    path: '/secret/user/myTask/taskCenter',
                    query:{
                        v_molde:'trackingTask'
                    }
                })
            },
            //去查看任务跟踪、已办任务
            viewBpmn(val){
                if(val.process_definition_key == 'cancel_record') {
                    this.$router.push({
                        path: '/soc/task-center/cancle-record-search',
                        query: {
                            flow_instance_id: val.flow_instance_id,
                            type: val.process_definition_key,
                            taskId: val.flow_task_id,
                            flow_business_key: val.flow_business_key
                        }
                    })
                } else if(val.process_definition_key == 'P12345678') {
                    this.$router.push({
                        path: '/soc/task-center/approve-loophole-record-search',
                        query: {
                            flow_instance_id: val.flow_instance_id,
                            type: val.process_definition_key,
                            taskId: val.flow_task_id,
                            flow_business_key: val.flow_business_key
                        }
                    })
                } else if(val.process_definition_key == 'leak_record') {
                    this.$router.push({
                        path: '/soc/task-center/leak-record-search',
                        query: {
                            flow_instance_id:val.flow_instance_id,
                            type:val.process_definition_key,
                            taskId:val.flow_task_id,
                            flow_business_key: val.flow_business_key
                        }
                    })
                }
            },
            //去已办任务
            toCompleteTask(){
                this.$router.push({
                    path: '/soc/task-center/completed-task',
                })
            },
            //去台賬
            toLedger(val){
                localStorage.setItem("socParameterManage", JSON.stringify(val));
                this.$router.push({
                    path: '/secret/user/socParameterManage'
                })
            },
            initTask(){
                this.myTodoTaskSearch = {
                    data:{
                        "flow_tasker_code":this.currentUser.username,
                        "PageStart":0,
                        "PageSize":6
                    }
                };
                this.completeTaskSearch = {
                    data:{
                        "flow_tasker_code":this.currentUser.username,
                        "PageStart":0,
                        "PageSize":6
                    }
                };
                this.trackingTaskSearch = {
                    data:{
                        "flow_proposer_code":this.currentUser.username,
                        "where":"",
                        "PageStart":0,
                        "PageSize":6
                    }
                };
                //代办任务
                this.refreshMyTodoTable();
                var self = this;
                //任务跟踪
                getTrackingTaskTableData(this.trackingTaskSearch,function (data) {
                    self.trackingTaskTableData = data;
                });
                getCompleteTaskTableData(this.completeTaskSearch,function (data) {
                    self.completeTaskTableData = data;
                });
            },
            refreshMyTodoTable(){
                const _self = this;
                async function main() {
                    try {
                        const assignedParams = {
                            assignee : _self.currentUser.username
                        };
                        let assignedRes = await getProcessTask(assignedParams);

                        const candidateUserParams = {
                            withCandidateUsers : true,
                            candidateUser : _self.currentUser.username
                        };
                        let candidateUserRes = await getProcessTask(candidateUserParams);

                        let tempTaskRes =  assignedRes.concat(candidateUserRes);
                        let flowInstanceIds = tempTaskRes.map((temp,index)=>"'"+temp.processInstanceId+"'");


                        const processApplyInfoParams = {
                            "flowInstanceIds" : flowInstanceIds.join()||"''",
                            "where":"",
                            "PageStart": 0,
                            "PageSize": 6
                        }
                        let processApplyInfoRes = await queryProcessApplyInfo(processApplyInfoParams);

                        if(processApplyInfoRes&&processApplyInfoRes.hasOwnProperty("data")&&processApplyInfoRes.data.hasOwnProperty("data")){
                            async1.map(processApplyInfoRes.data.data,function(item,callBack){
                                // selectPrintOutResultAnalyse(item).then((data)=>{
                                //     if(data.status == 200){
                                //         callBack(null,data.data.total);
                                //     }else{
                                //         callBack(null)
                                //     }
                                // });
                                if(item.flow_instance_name == '主机备案') {
                                    selectPByProcessId({id: item.flow_instance_id}).then(data => {
                                        if (data.data.status == 200) {
                                            item['norm_title'] = data.data.data[0].norm_title;
                                            callBack(null, item);
                                        } else {
                                            callBack(null);
                                        }
                                    });
                                }else{
                                    callBack(null,item);
                                }
                            }, function(err, results) {
                                if(err){
                                    console.log(err);
                                }else{
                                    for(let i in results){
                                        _self.myTodoTaskTableData = results;
                                    }
                                    // that.printOutData = results;
                                }
                            });

                        }
                    }catch (e) {
                        _self.$notify.error({
                            title: '错误',
                            message: '查询流程待审批记录错误'
                        });
                    }
                };
                main();
            },

            //用户终端统计
            countHasInstallSbox(){
                for(let i in this.countSboxQuery){
                    countHasInstallSbox(this.countSboxQuery[i]).then((data)=>{
                        this.terminalNum[i] = data.data.total
                    });
                }
                getSqlResult('countEquipmentInuseByNetwork').then((data) => {
                    this.allNum = data.data.total;
                });
            }
        },
        created () {
            this.findDepName();
            this.currentUser = this.getCurrentUser();
            this.selectOnlineNumByTime();
            this.getProcessMonitor();
            var self = this;
            var interval = setInterval(function () {
                if(self.currentUser.username){
                    clearInterval(interval);
                    self.initTask();
                }
            },100);
            this.selectHostTrend();
            this.getRiskNum();
            this.countHasInstallSbox();
            this.selectPrintOutResultAnalyse();
            this.searchsafetyProtectionData();
            this.searchOpenPortsData();
            this.searchRecordStatisticsData();
            this.serachleakTrendHistogram();
        },
        mounted() {
            this.getBurnTheOutputTrendOption();
            const that = this;
            window.onresize = function () {
                setTimeout(() => {
                    that.selectHostTrend();
                    that.getProcessMonitor();
                    that.selectPrintOutResultAnalyse();
                    that.searchsafetyProtectionData();
                    that.searchOpenPortsData();
                    that.searchRecordStatisticsData();
                    that.serachleakTrendHistogram();
                    that.getRiskNum();
                    that.getBurnTheOutputTrendOption();
                }, 500);
            };
        },
    };
</script>

<style lang="css" scoped>
    .backColor {
        background-color: #05256e;
        width: 100% ;
        height: 100%;
    }

    .middleContentImg {
        background-image: url(/static/img/userHome/banner.png);
        background-size:100% 100%;
        opacity:0.8;
        z-index: 1;
        width: 100%;
        height: 100%;
    }

    .pageContent{
        height: 100%;
        /*width: 100%;*/
        margin: auto;
        padding-top: 10px;
        max-width: 1280px;
        overflow-x: hidden;
        overflow-y: auto;
    }

    .manageheader{
        padding-left: 24px;
        height: 40px;
        width: 100%;
        border-radius: 8px 8px 0 0;
        background-color: rgba(0, 78, 162, 0.6);
        font-size: 16px;
        font-weight: bold;
        line-height: 40px;
        color: #9ad7f8;
    }

    .cardBack{
        height: 100%;
        background-color: rgba(9, 38, 93, 0.8);
    }

    .terminalStyle{
        padding: 20px;
        color: #9ad7f8;
        font-family: 'Microsoft YaHei'
    }

    .riskNum{
        background-color: #08e69a;
        width: 60%;
        height: 35px;
        position: relative;
        top: -56px;
        border-radius: 5px;
        margin: auto;
        line-height: 35px;
        color: #ffffff;
    }

    .rowStyle {
        padding-top: 5px;
        padding-bottom: 5px;
        padding-left: 12px;
        padding-right: 12px;
    }
    .rowsContent{
        height: 100%;
        width: 100%;
    }
    .rowStyle .task {
        font-size: 14px;
        color: #9ad7f8;
        float: left;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        width: 189px;
        text-align: left;
    }

    .rowStyle .do {
        font-size: 14px;
        color: #86b0c7;
        float: right;
        cursor: pointer;
    }

    .rowStyle .more {
        font-size: 14px;
        color: #9ad7f8;
    }

    .more {
        cursor: pointer;
    }

    .pointMore {
        text-align: center;
    }

    button.mu-tab-link.mu-tab-active,button.mu-tab-link{
        color: #9ad7f8;
        background-color: rgb(9, 38, 93);
    }


    .paddingFont{
        padding-left: 15px;
    }

    .numSize{
        font-size: 25px;
    }

    ::-webkit-scrollbar{display:none}
</style>
<style lang="css">
    #userHome .spanBack {
        background-color: #9ad7f8;
    }
</style>
