<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="角色编码：">
                    <el-input v-model="searchForm.code" placeholder="" clearable></el-input>
                </el-form-item>
                <el-form-item label="角色名称：">
                    <el-input v-model="searchForm.name" placeholder="" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="search(1)" type="primary">查询</el-button>
                    <el-button class="cancel" @click="newRole">新建</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="roalData.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="code"
                    label="角色编码">
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="角色名称">
                </el-table-column>
                <el-table-column
                    prop="descripition"
                    label="角色描述">
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="editRole(scope.row)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            @click.native.prevent="deleteRoal(scope.row)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
        <el-dialog
            title="编辑角色"
            :visible.sync="editDialog">
            <el-form :model="formLabelAlign" label-width="80px">
                <el-form-item label="角色编号">
                    <el-input v-model="formLabelAlign.code"></el-input>
                </el-form-item>
                <el-form-item label="角色名称">
                    <el-input v-model="formLabelAlign.name"></el-input>
                </el-form-item>
                <el-form-item label="角色描述">
                    <el-input v-model="formLabelAlign.description" type="textarea"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editDialog=false">取消</el-button>
                <el-button @click="confirm()" type="primary">确定</el-button>
            </span>
        </el-dialog>
        <el-dialog
            title="新建角色"
            :visible.sync="newDialog">
            <el-form :model="formInline" label-width="80px">
                <el-form-item label="角色编号">
                    <el-input v-model="formInline.code"></el-input>
                </el-form-item>
                <el-form-item label="角色名称">
                    <el-input v-model="formInline.name"></el-input>
                </el-form-item>
                <el-form-item label="角色描述">
                    <el-input v-model="formInline.description" type="textarea"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="newDialog=false">取消</el-button>
                <el-button @click="confirm()" type="primary">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {
        fetch
    } from '@/core/fetch.js';

    export default {
        components: {
            pagination
        },
        data() {
            return {
                roalData: {},
                editDialog: false,
                formLabelAlign: {
                    id: '',
                    code: '',
                    name: '',
                    description: '',
                    type: '4'
                },
                newDialog: false,
                formInline: {
                    code: '',
                    name: '',
                    description: '',
                    type: '4',
                    groupType: '1',
                    parentId: '-1'
                },


                id: "",
                dialog: false,
                pageNo: 1,
                pageSize: 10,


                searchForm: {
                    code: "",
                    name: ""
                }
            }

        },
        computed: {
            pageOption() {
                return {
                    pageNo: this.pageNo,
                    pageSize: this.pageSize,
                    total: this.roalData.total,
                }
            }

        },
        created() {
            this.search(1);
        },
        methods: {
            search(page) {
                var querydata = {
                    "page": page,
                    "groupType":1,
                    limit: '10',
                    "type": "4",
                    orderBy: 'crtTime desc'
                };
                if (this.searchForm.name != "") {
                    querydata.name = this.searchForm.name;
                    querydata["!name"] = "like";
                }
                if (this.searchForm.code != "") {
                    querydata.code = this.searchForm.code;
                    querydata["!code"] = "like";
                }
                fetch({
                    url: "/api/admin/group/page",
                    method: "get",
                    params: querydata
                }).then(res => {
                    if (res && res.hasOwnProperty("status") && res.status == 200) {
                        this.roalData = res.data;
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取角色列表错误'
                    });
                })
            },
            editRole(item) {
                this.editDialog = true;
                this.formLabelAlign.id = item.id;
                this.formLabelAlign.code = item.code;
                this.formLabelAlign.name = item.name;
                this.formLabelAlign.parentId = item.parentId;
                this.formLabelAlign.description = item.description;
            },
            editRoleSave() {
                fetch({
                    url: `/api/admin/group/${this.formLabelAlign.id}`,
                    method: "put",
                    data: this.formLabelAlign
                }).then(res => {
                    if (res && res.hasOwnProperty('status') && res.status == 200) {
                        this.$notify.success({
                            title: '成功',
                            message: '编辑角色成功'
                        });
                        this.pageChange(1);
                        this.editDialog = false;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '编辑角色错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '编辑角色错误'
                    });
                })
            },
            pageChange(val) {
                this.pageNo = val;
                this.search(val)
            },

            confirm() {
                fetch({
                    url: '/api/admin/group',
                    method: 'post',
                    data: this.formInline
                }).then((res) => {
                    if (res.status == 200 && res.rel) {
                        this.$notify.success({
                            title: '成功',
                            message: '新增角色成功'
                        });
                        this.pageChange(1);
                        this.newDialog = false;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: res.message
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '新增角色错误'
                    });
                })
            },

            newRole() {
                this.formInline = {
                    code: '',
                    name: '',
                    description: '',
                    type: '4',
                    groupType: '1',
                    parentId: '-1'
                };
                this.newDialog = true;

            },
            deleteRoal(item) {
                this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    fetch({
                        url: `/api/admin/group/${item.id}`,
                        method: 'delete'
                    }).then(res => {
                        if (res.status == 200 && res.rel) {
                            this.$notify.success({
                                title: '成功',
                                message: '删除角色成功'
                            });
                            this.pageChange(1);
                        } else{
                            this.$notify.error({
                                title: '错误',
                                message: '删除角色错误'
                            });
                        }
                    }).catch(err => {
                        this.$notify.error({
                            title: '错误',
                            message: '删除角色错误'
                        });
                    })
                })
            }

        },
        activated() {
        }
    }

</script>
