<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="查询编码：">
                    <el-input v-model="searchcode" clearable></el-input>
                </el-form-item>
                <el-form-item label="查询名称：">
                    <el-input v-model="searchname" clearable></el-input>
                </el-form-item>
                <el-form-item >
                    <el-button class="search"  @click='doSearch' type="primary">查询</el-button>
                    <el-button class="cancel"  @click="add">添加</el-button>
                    <el-button class="cancel" @click="toConfig">数据源配置</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="menuPersonData.rows">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="code"
                    label="查询编码"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="查询名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="sqlType"
                    label="sql类型"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="sqlValue"
                    label="查询语句"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="sqlDescribe"
                    label="查询描述"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="excuteCount"
                    label="执行次数"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="excuteLastTime"
                    label="最后执行时间"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="crtName"
                    label="创建人"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="edit(scope.row)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            @click.native.prevent="remove(scope.row)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
        <el-dialog title="查询配置" :visible.sync="dialog" width="80%" >
            <el-tag class="tagStyle" type="danger">sql中的参数使用"${}"方式插入</el-tag>
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="150px" class="demo-ruleForm">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="查询编码" prop="code">
                            <el-input v-model="ruleForm.code"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="查询名称" prop="name">
                            <el-input v-model="ruleForm.name"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="sql类型" prop="sqlType">
                            <el-select v-model="sqlType">
                                <el-option
                                    v-for="item in options"
                                    :key="item.value"
                                    :label="item.label"
                                    :value="item.value">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12" v-if="sqlType == 'mysql'">
                        <el-form-item label="数据源" prop="sqlType">
                            <el-select v-model="jdbcCode">
                                <el-option
                                    v-for="item in jdbcOption"
                                    :key="item.jdbcCode"
                                    :label="item.jdbcCode"
                                    :value="item.jdbcCode">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="查询描述" >
                            <el-input type="textarea" v-model="ruleForm.sqlDescribe" ></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="查询语句" prop="sqlValue">
                            <el-input type="textarea" v-model="ruleForm.sqlValue" :rows="2" @input="getSqlParameter"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12" v-for="(val, key, index) in sqlParameter" :key="index">
                        <el-form-item :label="`参数${index+1}`">
                            <el-input v-model="sqlParameter[key]" :placeholder="key"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row id="sqlresult">
                    <el-col :span="24">
                        <el-form-item label="运行结果">
                            <el-input type="textarea" v-model="sqlresult" :rows="10"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
				<el-button @click="testsql">测 试</el-button>
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {getTableData,add,deleteone,edit,testsql,getAll} from "@/api/systemConfiguration/index.js"

    export default {
        components: {
            pagination,
        },
        data() {
            return {
                pageNo:1,
                dialog:false,
                searchcode:"",
                searchname:"",
                menuPersonData:{
                },
                jdbcCode: "",
                sqlresult:"",
                sqlParameter:{
                },
                ruleForm:{
                    code:"",
                    name:"",
                    sqlDescribe:"",
                    sqlValue:""
                },
                jdbcOption: [],
                sqlType:"es",
                options: [{
                    value: 'es',
                    label: 'es'
                },{
                    value: 'mysql',
                    label: 'mysql'
                }],
                rules:{
                    code:[{
                        required: true,
                        message: '请输入编码',
                        trigger: 'change'
                    },{
                        required: true,
                        message: '请输入编码',
                        trigger: 'blur'
                    }],
                    name:[{
                        required: true,
                        message: '请输入名称',
                        trigger: 'change'
                    },{
                        required: true,
                        message: '请输入名称',
                        trigger: 'blur'
                    }],
                    sqlValue:[{
                        required: true,
                        message: '请输入查询语句',
                        trigger: 'change'
                    },{
                        required: true,
                        message: '请输入查询语句',
                        trigger: 'blur'
                    }]
                }
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
            getAll(){
                getAll().then(data=>{
                    this.jdbcOption = data;
                })
            },
            init(){
                let query = {
                    page:this.pageNo,
                    limit:10
                };
                if(this.searchcode != ""){
                    query.code = this.searchcode;
                }
                if(this.searchname != ""){
                    query.name = this.searchname;
                }
                getTableData(query).then((data)=>{
                    this.menuPersonData =data.data;
                });
            },
            formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
            getTableDataByTree(val){

            },
            pageChange(val) {
                this.pageNo = val;
                this.init();
            },
            add(){
                this.sqlType = "es";
                this.jdbcCode = "";
                this.ruleForm={
                    code:"",
                    name:"",
                    sqlDescribe:"",
                    sqlValue:""
                };

                this.sqlresult="",
                this.sqlParameter={

                },
                    this.dialog = true;
            },
            edit(item){
                this.dialog = true;
                this.sqlType = item.sqlType;
                this.jdbcCode = item.jdbcCode;
                this.sqlresult="";
                this.sqlParameter={

                };
                this.ruleForm = item;
                this.getSqlParameter(this.ruleForm.sqlValue);
            },
            remove(id){
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
                    .then(() => {
                        deleteone(id).then((data)=>{
                            if(data.status == 200){
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        this.init();
                                    }
                                });
                            }else{
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            doSubmit(formName){
                var addObj = this.ruleForm;
                if(this.sqlType == 'mysql'){
                    addObj.jdbcCode = this.jdbcCode;
                }
                addObj.sqlType = this.sqlType;
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.dialog = false;
                        if(addObj.id){
                            edit(addObj).then((data)=>{
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        }else{
                            add(addObj).then((data)=>{
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        }
                    } else {
                        return false;
                    }
                });
            },
            doSearch(){
                this.pageNo = 1;
                this.init();
            },
            getSqlParameter(e){
                var reg = /[^\{\}]+(?=\})/g;
                var arr = e.match(reg);
                if(arr == null){
                    return false;
                }
                var map = {};
                for(var i=0;i<e.match(reg).length;i++){
                    map[e.match(reg)[i]] = ""
                }
                this.sqlParameter = map;
            },
            testsql(){
                let sql = this.ruleForm.sqlValue;
                for (var key in this.sqlParameter) {
                    let regexp = new RegExp("\\${" + key + "}", "g");
                    sql = sql.replace(regexp, this.sqlParameter[key]);
                }
                var query = {
                    sql:sql,
                    sqlType: this.sqlType,
                };
                if(this.sqlType == 'mysql'){
                    if(this.jdbcCode == ""){
                        this.$alert(sql, '数据源为空', {
                            confirmButtonText: '确定',
                            callback: action => {
                            }
                        });
                        return ;
                    }else {
                        query['jdbcCode'] = this.jdbcCode;
                        // query.jdbcCode = this.jdbcCode;
                        // console.log(query,this.jdbcCode);
                    }
                }
                testsql(query).then((data)=>{
                    if(data.status == 500){
                        this.$alert(sql, 'sql执行错误', {
                            confirmButtonText: '确定',
                            callback: action => {
                                return false;
                            }
                        });
                    }else{
                        if(data.rel){
                            this.sqlresult = data.data;
                        }else{
                            this.$alert(data.message, '提示', {
                                confirmButtonText: '确定',
                                callback: action => {
                                    return false;
                                }
                            });
                        }
                    }
                });
            },
            toConfig(){
                this.$router.push({
                    path: '/soc/system-configuration/sql-config'
                })
            }
        },
        created() {
            this.init();
            this.getAll();
        },
        activated() {
            this.init();
            this.getAll();
        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }

    .tagStyle {
        position: absolute;
        top: 3%;
        left: 10%;
    }
    .el-select {
        width: 100%;
    }
</style>
<style lang="css">
    #sqlresult textarea {
        font-size: xx-small;
    }
</style>
