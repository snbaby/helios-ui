<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="登录账号：">
                    <el-input v-model="searchForm.userCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="登录名称：">
                    <el-input v-model="searchForm.userName" clearable></el-input>
                </el-form-item>
                <el-form-item label="部门：">
                    <el-cascader placeholder="" v-model="searchForm.depCode"
                                 :options="depTree" :show-all-levels="false" filterable change-on-select clearable
                                 v-if="depTree"
                                 change-on-select>
                    </el-cascader>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="search(1)" type="primary">查询</el-button>
                    <el-button @click="newUser" class="cancel">新建</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="peoples.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="username"
                    label="登录账号"
                >
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="登录名称"
                >
                </el-table-column>
                <el-table-column
                    prop="attr8"
                    label="类别">
                    <template slot-scope="scope">
                        {{getCategoryData('user_type',scope.row.attr8)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="crtTime"
                    label="添加时间">
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            v-if="scope.row.type != 's'"
                            @click.native.prevent="viewEdit(scope.row)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            v-if="scope.row.type != 's'"
                            @click.native.prevent="toPostTask(scope.row)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>

        <el-dialog title="新建人员" :visible.sync="newUserDialog">
            <el-form :model="formInline" :rules="rules" ref="formInline">
                <el-form-item label="类别">
                    <el-select v-model="formInline.attr8" filterable placeholder="类别">
                        <el-option v-for="item in getCategoryData('user_type')" :key="item.code"
                                   :label="item.label"
                                   :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="所在部门" prop="depCode">
                    <el-cascader
                        size="medium"
                        :options="depTree"
                        v-model="formInline.depCode"
                        :show-all-levels="false"
                        change-on-select
                    ></el-cascader>
                </el-form-item>
                <el-form-item label="登录账号" prop="username">
                    <el-input v-model="formInline.username" placeholder="登录账号" ></el-input>
                </el-form-item>
                <el-form-item label="登录名称" prop="name">
                    <el-input v-model="formInline.name" placeholder="登录名称" ></el-input>
                </el-form-item>
                <el-form-item label="登录密码" prop="password">
                    <el-input type="password" v-model="formInline.password" placeholder="登录密码"
                              ></el-input>
                </el-form-item>
                <el-form-item label="确认密码" prop="checkPassword">
                    <el-input type="password" v-model="formInline.checkPassword" placeholder="确认密码"
                              ></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="newUserDialog = false">取 消</el-button>
                <el-button type="primary" @click="confirm()">确 定</el-button>
            </span>
        </el-dialog>

        <el-dialog title="编辑人员" :visible.sync="editUserDialog" width="50%">
            <el-form :model="editFormInline" :rules="rules" ref="editFormInline" label-position="right"
                     label-width="120px"
                     class="demo-form-inline">
                <el-form-item label="类别">
                    <el-select v-model="editFormInline.attr8" filterable placeholder="类别">
                        <el-option v-for="item in getCategoryData('user_type')" :key="item.code"
                                   :label="item.label"
                                   :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="所在部门" prop="depCode">
                    <el-cascader placeholder="" v-model="editFormInline.depCode" style="width: 172px;"
                                 :options="depTree"
                                 :show-all-levels="false" filterable change-on-select
                                 v-if="depTree">
                    </el-cascader>
                </el-form-item>
                <el-form-item label="登录账号" prop="username">
                    <el-input v-model="editFormInline.username" placeholder="登录账号"
                              style="width: 100%;"></el-input>
                </el-form-item>
                <el-form-item label="登录名称" prop="name">
                    <el-input v-model="editFormInline.name" placeholder="登录名称" style="width: 100%;"></el-input>
                </el-form-item>
                <el-form-item label="登录密码" prop="password">
                    <el-input type="password" v-model="editFormInline.password" placeholder="登录密码"
                              style="width: 100%;"></el-input>
                </el-form-item>
                <el-form-item label="确认密码" prop="checkPasswords">
                    <el-input type="password" v-model="editFormInline.checkPasswords" placeholder="确认密码"
                              style="width: 100%;"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editUserDialog = false">取 消</el-button>
                <el-button type="primary" @click="editConfirm()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {
        fetchTree,
        pagedGroups
    } from '@/api/admin/group/index.js';

    import {
        getUserWithSelectPage
    } from '@/api/common/index.js';
    import {
        delObj
    } from '@/api/user/index.js';

    import {
        fetch
    } from "@/core/fetch.js";

    export default {
        components: {
            pagination
        },
        data() {
            var validatePass = (rule, value, callback) => {
                if (value === "") {
                    callback(new Error("请再次输入密码"));
                } else if (value !== this.formInline.password && this.formInline.password) {
                    callback(new Error("两次输入密码不一致!"));
                }
                else {
                    callback();
                }
            };
            var validatePass2 = (rule, value, callback) => {
                if (value === "") {
                    callback(new Error("请再次输入密码"));
                } else if (value !== this.editFormInline.password && this.editFormInline.password) {
                    callback(new Error("两次输入密码不一致!"));
                }
                else {
                    callback();
                }
            };
            return {
                rules: {
                    username: [
                        {
                            required: true,
                            message: "工号不能为空",
                            trigger: "change"
                        }
                    ],
                    name: [{
                        required: true,
                        message: "用户名不能为空",
                        trigger: "blur"
                    }],
                    checkPassword: [{validator: validatePass, trigger: "blur"}],
                    checkPasswords: [{validator: validatePass2, trigger: "blur"}]
                },
                peoples: {
                    total: 0,
                    pageNo: 1,
                    pageSize: 10,
                    rows: []
                },
                searchForm: {
                    depCode: [],
                    userName: "",
                    userCode: ""
                },
                newUserDialog: false,
                formInline: {
                    username: "",
                    name: "",
                    depCode: [],
                    attr8: "",
                    password: "",
                    checkPassword: ""
                },
                editUserDialog: false,
                editFormInline: {
                    id: "",
                    username: "",
                    name: "",
                    depCode: [],
                    attr8: "",
                    password: "",
                },

                groups: [],
                depCode: {
                    value: 'code'
                },
                depTree: [],
            }
        },
        computed: {
            pageOption() {
                return {
                    pageNo: this.peoples.pageNo,
                    pageSize: this.peoples.pageSize,
                    total: this.peoples.total,
                }
            },
        },
        created() {
            this.$store.dispatch('commonDict/branch/depTree', {
                buildTree: true,
                getPerson: false
            });
            this.initGroup();
            this.initDepTree();
            this.search(1);
        },
        methods: {
            initGroup() {
                pagedGroups({
                    "groupType": 2,
                    "type": "2",
                    "limit": 0
                }).then((res) => {
                    if (res && res.hasOwnProperty("status") && res.status == 200) {
                        this.groups = res.data.rows
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取部门列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门列表错误'
                    });
                });
            },
            initDepTree() {
                fetchTree({
                    "level": "2"
                }).then((res) => {
                    this.depTree = res[0].children;
                    this.getValue(this.depTree);
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门树错误'
                    });
                })
            },
            getValue(depTree) {
                for (let i in depTree) {
                    if (depTree[i].children) {
                        this.getValue(depTree[i].children);
                    }
                    depTree[i].value = depTree[i].name;
                }
            },
            //查询
            search(page) {
                var querydata = {
                    page: page,
                    limit: 10,
                    orderBy: "crtTime desc",
                };
                if (this.searchForm.userCode != "") {
                    querydata.username = this.searchForm.userCode;
                    querydata["!username"] = "like";
                }

                if (this.searchForm.userName != "") {
                    querydata.name = this.searchForm.userName;
                    querydata["!name"] = "like";
                }

                if (this.searchForm.depCode.length != 0) {
                    querydata.depCode = this.searchForm.depCode[this.searchForm.depCode.length - 1];
                    querydata.groupType = "2";
                }

                getUserWithSelectPage(querydata).then((res) => {
                    if (res.status == 200) {
                        this.peoples = res.data;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取人员错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取人员错误'
                    });
                })
            },
            //创建
            newUser() {
                this.newUserDialog = true
                this.formInline = {
                    username: "",
                    name: "",
                    depCode: [],
                    attr8: "",
                    password: "",
                };
            },
            deepCopy(obj) {
                if (typeof obj != 'object') {
                    return obj;
                }
                var newobj = {};
                for (var attr in obj) {
                    newobj[attr] = this.deepCopy(obj[attr]);
                }
                return newobj;
            },
            confirm() {
                var formSend = {
                    username: this.formInline.username,
                    name: this.formInline.name,
                    attr8: this.formInline.attr8,
                    password: this.formInline.password,
                };
                formSend.depCode = this.formInline.depCode[this.formInline.depCode.length - 1];
                this.$refs['formInline'].validate((valid) => {
                    if (!valid) {
                        return;
                    }
                    fetch({
                        url: "/api/admin/user",
                        method: "post",
                        data: formSend
                    }).then(res => {
                        if (res.status == 200 && res.rel) {
                            this.$notify.success({
                                title: '成功',
                                message: '添加人员成功'
                            });
                            this.search(1);
                            this.newUserDialog = false
                            this.newUserDialog = false;
                        } else {
                            this.$notify.error({
                                title: '错误',
                                message: res.message
                            });
                        }
                    })
                });
            },
            pageChange(page) {
                this.search(page);
            },
            viewEdit(item) {
                let ids = [];
                let isTrue = [];
                isTrue.push(false);
                this.findID(this.depTree, item.depCode, ids, isTrue);
                console.log(item);
                this.editFormInline = {
                    id: item.id,
                    username: item.username,
                    name: item.name,
                    depCode: ids,
                    attr8: item.attr8
                };
                console.log(this.editFormInline);
                this.editUserDialog = true;
            },
            findID(tree, data, ids, isTrue) {
                for (let i in tree) {
                    if (!isTrue[0]) {
                        let proviceId = tree[i].value;
                        ids.push(proviceId);
                        if (data === proviceId) {
                            isTrue[0] = true;
                            return;
                        }
                        let arry = tree[i].children;
                        if (arry) {
                            this.findID(arry, data, ids, isTrue);
                            if (!isTrue[0]) {
                                ids.pop();
                            }
                        } else {
                            ids.pop();
                        }
                    }
                }
            },
            editConfirm() {
                this.$refs['editFormInline'].validate((valid) => {
                    if (!valid) {
                        return;
                    }
                    var formSend = {
                        username: this.editFormInline.username,
                        name: this.editFormInline.name,
                        attr8: this.editFormInline.attr8,
                        password: this.editFormInline.password,
                    };
                    formSend.depCode = this.editFormInline.depCode[this.editFormInline.depCode.length - 1];

                    fetch({
                        url: `/api/admin/user/${this.editFormInline.id}`,
                        data: formSend,
                        method: "put",
                    }).then(res => {
                        if (res && res.hasOwnProperty("status") && res.status == 200) {
                            this.$notify.success({
                                title: '成功',
                                message: '编辑人员成功'
                            });
                            this.search(1);
                            this.editUserDialog = false;
                        } else {
                            this.$notify.error({
                                title: '错误',
                                message: res.message
                            });
                        }
                    }).catch(err => {
                        this.$notify.error({
                            title: '错误',
                            message: res.message
                        });
                    })
                })
            },

            toPostTask(item) {
                this.$confirm('此操作将永久删除该人员, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    delObj(item.id).then(res => {
                        if (res && res.hasOwnProperty("rel") && res.rel == true) {
                            this.$notify.success({
                                title: '成功',
                                message: '删除人员成功'
                            });
                            this.search(1);
                        }
                    }).catch(err => {
                        this.$notify.error({
                            title: '错误',
                            message: '删除人员错误'
                        });
                    });
                })

            },

        }
    }

</script>
