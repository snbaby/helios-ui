<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="编码：">
                    <el-input v-model="searchForm.code" placeholder="" class="searchFormItemInput" clearable></el-input>
                </el-form-item>
                <el-form-item label="名称：">
                    <el-input v-model="searchForm.name" placeholder="" class="searchFormItemInput" clearable></el-input>
                </el-form-item>
                <el-form-item label="密级：">
                    <el-select v-model="searchForm.attr1" placeholder="" class="searchFormItemInput" clearable>
                        <el-option v-for="item in getCategoryData( 'office_secret')" :key="item.code"
                                   :label="item.label"
                                   :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="search(1)" type="primary">查询</el-button>
                    <el-button class="cancel" @click="newUser">新建</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="secretOffices.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="code"
                    label="编码">
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="名称">
                </el-table-column>
                <el-table-column
                    prop="attr1"
                    label="密级">
                    <template slot-scope="scope">
                        {{getCategoryData('office_secret',scope.row.attr1)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="parentId"
                    label="部门">
                    <template slot-scope="scope">
                        {{getDepNameById(scope.row.parentId)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="edit(scope)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            @click.native.prevent="del(scope)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
        <el-dialog title="新建岗位" :visible.sync="dialogVisible">
            <el-form :model="formInline" ref="newDialogForm" label-position="labelPosition" label-width="80px"
                     class="demo-form-inline">
                <el-form-item label="部门" prop="parentId"
                              :rules="[{ required: true, message: '请选择部门', trigger: 'blur' }]">
                    <el-cascader placeholder="" v-model="formInline.parentId"
                                 :options="depTree"
                                 :show-all-levels="false" filterable change-on-select
                    >
                    </el-cascader>
                </el-form-item>
                <el-form-item label="密级" prop="attr1"
                              :rules="[{ required: true, message: '请选择密级', trigger: 'blur' }]">
                    <el-select v-model="formInline.attr1" placeholder="密级 ">
                        <el-option v-for="item in getCategoryData( 'office_secret')" :key="item.code"
                                   :label="item.label"
                                   :value="item.code ">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="编码" prop="code"
                              :rules="[{ required: true, message: '请输入编码', trigger: 'blur' }]">
                    <el-input v-model="formInline.code" placeholder="编码"></el-input>
                </el-form-item>
                <el-form-item label="名称" prop="name"
                              :rules="[{ required: true, message: '请输入名称', trigger: 'blur' }]">
                    <el-input v-model="formInline.name" placeholder="名称"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="confirm()">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog title="编辑岗位" :visible.sync="editDialogVisible">
            <el-form :model="editFormInline" ref="editDialogForm" label-position="labelPosition" label-width="80px"
                     class="demo-form-inline">
                <el-form-item label="部门" prop="parentId"
                              :rules="[{ required: true, message: '请选择部门', trigger: 'blur' }]">
                    <el-cascader placeholder="" v-model="editFormInline.parentId"
                                 :options="depTree"
                                 :show-all-levels="false" filterable change-on-select>
                    </el-cascader>
                </el-form-item>
                <el-form-item label="密级" prop="attr1"
                              :rules="[{ required: true, message: '请选择密级', trigger: 'blur' }]">
                    <el-select v-model="editFormInline.attr1" placeholder="密级 "
                    >
                        <el-option v-for="item in getCategoryData( 'office_secret')" :key="item.code"
                                   :label="item.label"
                                   :value="item.code ">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="编码" prop="code"
                              :rules="[{ required: true, message: '请输入编码', trigger: 'blur' }]">
                    <el-input v-model="editFormInline.code" placeholder="编码"></el-input>
                </el-form-item>
                <el-form-item label="名称" prop="name"
                              :rules="[{ required: true, message: '请输入名称', trigger: 'blur' }]">
                    <el-input v-model="editFormInline.name" placeholder="名称"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="editConfirm()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';

    import {
        pagedGroups,
        addObj,
        delObj,
        fetchTree,
        putObj
    } from '@/api/admin/group/index.js';
    import {
        fetch,
        json2Param
    } from "@/core/fetch.js";

    export default {
        components: {
            pagination
        },
        data() {
            return {
                secretOffices: {
                    total: 0,
                    pageNo: 1,
                    pageSize: 10,
                    rows: []
                },

                dialogVisible: false,
                groups: [],
                searchForm: {
                    code: "",
                    name: "",
                    attr1: ""
                },
                formInline: {
                    code: '',
                    name: '',
                    attr1: '',
                    parentId: [],
                },
                editDialogVisible: false,
                editFormInline: {
                    id: '',
                    code: '',
                    name: '',
                    attr1: '',
                    parentId: [],
                },
                depTree: []
            }

        },
        computed: {
            pageOption() {
                return {
                    pageNo: this.secretOffices.pageNo,
                    pageSize: this.secretOffices.pageSize,
                    total: this.secretOffices.total,
                }
            }

        },
        created() {
            this.initDepTree();
            this.search(1);
            this.initGroup();
        },
        methods: {
            initGroup() {
                pagedGroups({
                    "groupType": 2,
                    "type": "2",
                    "limit": 0
                }).then((res) => {
                    if (res && res.hasOwnProperty('status') && res.status == 200) {
                        this.groups = res.data.rows
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取部门列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门列表错误'
                    });
                });
            },
            search(page) {
                var querydata = {
                    page: page,
                    limit: 10
                };
                if (this.searchForm.code != "") {
                    querydata.code = this.searchForm.code;
                    querydata["!code"] = "like";
                }
                if (this.searchForm.name != "") {
                    querydata.name = this.searchForm.name;
                    querydata["!name"] = "like";
                }
                if (this.searchForm.attr1 != "") {
                    querydata.attr1 = this.searchForm.attr1;
                }
                fetch({
                    url: '/api/admin/group/page?groupType=2&type=3&' + json2Param(querydata),
                    method: 'get'
                }).then((res) => {
                    if (res.status == 200) {
                        this.secretOffices = res.data;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取岗位列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取岗位列表错误'
                    });
                })
            },
            initDepTree() {
                fetchTree({
                    "groupType": 2
                }).then((res) => {
                    this.depTree = res[0].children;
                    this.getValue(this.depTree);
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门树错误'
                    });
                })
            },
            getValue(depTree) {
                for (let i in depTree) {
                    if (depTree[i].children) {
                        this.getValue(depTree[i].children);
                    }
                    depTree[i].value = depTree[i].id;
                }
            },
            confirm() {
                this.$refs['newDialogForm'].validate((valid) => {
                    if (!valid) {
                        return;
                    }
                    let data = {
                        type: '3',//岗位
                        groupType: '2',
                        code: this.formInline.code,
                        name: this.formInline.name,
                        attr1: this.formInline.attr1,
                        parentId: this.formInline.parentId[this.formInline.parentId.length - 1],
                    };
                    addObj(data).then((res) => {
                        this.dialogVisible = false;
                        if (res.status == 200 && res.rel) {
                            this.$notify.success({
                                title: '成功',
                                message: '新增岗位成功'
                            });
                            this.search(1);
                        } else {
                            this.$notify.error({
                                title: '错误',
                                message: res.message
                            });
                        }
                    }).catch((err) => {
                        this.$notify.error({
                            title: '错误',
                            message: '新增岗位错误'
                        });
                    });
                });
            },
            editConfirm() {
                this.$refs['editDialogForm'].validate((valid) => {
                    if (!valid) {
                        return;
                    }
                    let data = {
                        type: '3',//岗位
                        groupType: '2',//
                        code: this.editFormInline.code,
                        name: this.editFormInline.name,
                        attr1: this.editFormInline.attr1,
                        parentId: this.editFormInline.parentId[this.editFormInline.parentId.length - 1],
                    };
                    putObj(this.editFormInline.id, data).then((res) => {
                        this.editDialogVisible = false;
                        if (res.status == 200 && res.rel) {
                            this.$notify.success({
                                title: '成功',
                                message: '修改岗位成功'
                            });
                            this.search(1);
                        } else {
                            this.$notify.error({
                                title: '错误',
                                message: res.message
                            });
                        }
                    }).catch((err) => {
                        this.$notify.error({
                            title: '错误',
                            message: '修改岗位错误'
                        });
                    });
                });
            },
            edit(item) {
                this.editDialogVisible = true;
                let ids = [];
                let isTrue = [];
                isTrue.push(false);
                this.findID(this.depTree, item.parentId, ids, isTrue);
                this.editFormInline = {
                    id: item.id,
                    code: item.code,
                    name: item.name,
                    attr1: item.attr1,
                    parentId: ids
                }
            },
            findID(tree, data, ids, isTrue) {
                for (let i in tree) {
                    if (!isTrue[0]) {
                        let proviceId = tree[i].id;
                        ids.push(proviceId);
                        if (data === proviceId) {
                            isTrue[0] = true;
                            return;
                        }
                        let arry = tree[i].children;
                        if (arry) {
                            this.findID(arry, data, ids, isTrue);
                            if (!isTrue[0]) {
                                ids.pop();
                            }
                        } else {
                            ids.pop();
                        }
                    }
                }
            },
            del(item) {
                this.$confirm('此操作将永久删除该岗位, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    delObj(item.id).then(res => {
                        this.$notify.success({
                            title: '成功',
                            message: '删除岗位成功'
                        });
                        this.search(1);
                    }).catch(err => {
                        this.$notify.error({
                            title: '错误',
                            message: '删除岗位错误'
                        });
                    })
                })
            },
            pageChange(page) {
                this.search(page);
            },
            newUser() {
                //清空上次残留输入
                this.formInline.code = '';
                this.formInline.name = '';
                this.formInline.attr1 = '';
                this.formInline.parentId = [];
                this.dialogVisible = true;
            },

        }
    }

</script>
