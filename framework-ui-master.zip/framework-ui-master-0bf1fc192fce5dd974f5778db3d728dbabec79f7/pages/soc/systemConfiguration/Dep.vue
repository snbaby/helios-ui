<template>
    <div class="framework-content">
        <div class="framework-left">
            <tree :treedata="depTree" @getValue='handleNodeClick'></tree>
        </div>
        <div class="framework-right">
            <div class="framework-search-form">
                <el-form :inline="true">
                    <el-form-item label="部门编码：">
                        <el-input v-model="searchForm.code" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="部门名称：">
                        <el-input v-model="searchForm.name" clearable></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button @click="search(1)" type="primary">查询</el-button>
                        <el-button v-if="searchForm.parentId != ''" @click="newDep">新建</el-button>
                    </el-form-item>
                </el-form>
            </div>
            <div>
                <el-table :data="departments.rows">
                    <el-table-column
                        type="index"
                        width="50">
                    </el-table-column>
                    <el-table-column
                        prop="code"
                        label="部门编码">
                    </el-table-column>
                    <el-table-column
                        prop="name"
                        label="部门名称">
                    </el-table-column>
                    <el-table-column
                        prop="attr2"
                        label="排序">
                    </el-table-column>
                    <el-table-column
                        prop="crtTime"
                        label="添加时间">
                    </el-table-column>
                    <el-table-column
                        prop="address"
                        label="操作">
                        <template slot-scope="scope">
                            <el-button
                                @click.native.prevent="editDep(scope.row)"
                                type="text"
                                size="small">
                                编辑
                            </el-button>
                            <el-button
                                @click.native.prevent="deleteDep(scope.row)"
                                type="text"
                                size="small">
                                删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
        <el-dialog
            title="新建部门"
            :visible.sync="newDialog">
            <el-form :model="formInline" class="demo-form-inline" label-width="80px">
                <el-form-item label="组织编码">
                    <el-input v-model="formInline.code" placeholder="组织编码" style="width: 100%"></el-input>
                </el-form-item>
                <el-form-item label="组织名称">
                    <el-input v-model="formInline.name" placeholder="组织名称" style="width: 100%"></el-input>
                </el-form-item>
                <el-form-item label="排序">
                    <el-input v-model="formInline.attr2" type="number" min="1" style="width: 100%"></el-input>
                </el-form-item>
                <el-form-item label="上级部门">
                    <el-input v-model="parentGroupName" :readonly="true" style="width: 100%"></el-input>
                </el-form-item>
                <el-form-item label="">
                <span
                    style="color: #B4BCCC;font-size: 0.6em;display: inline-block;position: relative;top:-24px;"><span
                    style="color: red;">*</span> 点击左侧的树节点改变上级部门</span>
                </el-form-item>
                <el-input v-model="formInline.parentId" type="hidden"></el-input>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="newDialog = false">取 消</el-button>
                <el-button type="primary" @click="confirm()">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog
            title="编辑部门"
            :visible.sync="editDialog">
            <el-form :model="editFormInline" class="demo-form-inline" label-width="80px">
                <el-form-item label="组织名称">
                    <el-input v-model="editFormInline.name" placeholder="组织名称" style="width: 100%"></el-input>
                </el-form-item>
                <el-form-item label="排序">
                    <el-input v-model="editFormInline.attr2" type="number" min="1" style="width: 100%"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editDialog = false">取 消</el-button>
                <el-button type="primary" @click="editConfirm()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import {
        pagedGroups,
        fetchTree
    } from '@/api/admin/group/index.js';
    import pagination from '@/components/common/pagination.vue';
    import tree from '@/components/common/tree.vue';
    import {fetch} from '@/core/fetch.js';

    export default {
        components: {
            pagination,
            tree
        },
        data() {
            return {
                departments: {
                    total: 0,
                    pageNo: 1,
                    pageSize: 10,
                    rows: []
                },
                depTree: [],
                searchForm: {
                    name: "",
                    code: "",
                    parentId: ""
                },
                editFormInline: {
                    code: "",
                    name: "",
                    attr2: 1
                },
                parentGroupName: "",
                newDialog: false,
                formInline: {
                    code: "",
                    name: "",
                    attr2: 1,
                    type: "2",
                    groupType: '1',
                    parentId: ""
                },
                editDialog: false,
            }
        },
        computed: {
            pageOption() {
                return {
                    pageNo: this.departments.pageNo,
                    pageSize: this.departments.pageSize,
                    total: this.departments.total,
                }
            }
        },
        created() {
            this.search(1);
            this.initDepTree();
        },
        methods: {
            initDepTree() {
                fetchTree({
                    "groupType": 2
                }).then((res) => {
                    this.depTree = res;
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门树错误'
                    });
                })
            },
            search(page) {
                var querydata = {
                    "page": page,
                    "groupType": 2,
                    "type": "2",
                    "orderBy": "attr2 asc"
                };
                if (this.searchForm.name != "") {
                    querydata.name = this.searchForm.name;
                    querydata["!name"] = "like";
                }
                if (this.searchForm.code != "") {
                    querydata.code = this.searchForm.code;
                    querydata["!code"] = "like";
                }
                if (this.searchForm.parentId && this.searchForm.parentId != "") {
                    querydata.parentId = this.searchForm.parentId;
                }

                pagedGroups(querydata).then((res) => {
                    if (res.status == 200) {
                        this.departments = res.data;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取部门列表错误'
                        });
                    }
                }).catch((err) => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门列表错误'
                    });
                });
            },
            editDep(item) {
                this.editFormInline.code = item.code;
                this.editFormInline.name = item.name;
                this.editFormInline.parentId = item.parentId;
                this.editFormInline.attr2 = item.attr2;
                this.editFormInline.id = item.id;
                this.editDialog = true;
            },
            editConfirm() {
                if (this.editFormInline.name == null || this.editFormInline.name == "") {
                    this.$notify.warning({
                        title: '警告',
                        message: '信息填写不完全',
                    });
                } else {
                    fetch({
                        url: "/api/admin/group/" + this.editFormInline.id,
                        method: "put",
                        data: this.editFormInline
                    }).then(res => {
                        this.editDialog = false;
                        if (res.status == 200) {
                            this.$notify.success({
                                title: '成功',
                                message: '修改部门成功'
                            });
                            this.search(1);
                            this.initDepTree();
                        }
                    }).catch(err => {
                        this.$notify.error({
                            title: '错误',
                            message: '修改部门错误'
                        });
                    })
                }
            },
            handleNodeClick(data) {
                this.formInline.parentId = data.id;
                this.searchForm.parentId = data.id;
                this.parentGroupName = data.label;
                this.search(1);
            },
            newDep() {
                this.formInline.code = "";
                this.formInline.name = "";
                this.formInline.attr2 = 1;
                this.newDialog = true;
            },

            confirm() {
                var data = this.formInline;
                if (data.code == null || data.code == "" || data.name == null || data.name == "") {
                    this.$notify.warning({
                        title: '警告',
                        message: '信息填写不完全',
                    });
                } else {
                    fetch({
                        url: "/api/admin/group",
                        method: "post",
                        data: this.formInline
                    }).then(res => {
                        this.newDialog = false;
                        if (res.status == 200) {
                            this.$notify.success({
                                title: '成功',
                                message: '添加部门成功'
                            });
                            this.search(1);
                            this.initDepTree();
                        } else {
                            this.$notify.error({
                                title: '错误',
                                message: '添加部门错误'
                            });
                        }
                    }).catch(err => {
                        this.$notify.error({
                            title: '错误',
                            message: '添加部门错误'
                        });
                    })
                }
            },

            pageChange(page) {
                this.search(page);
            },

            deleteDep(item) {
                this.$confirm('此操作将永久删除该部门, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    fetch({
                        url: "/api/admin/group/delete?id=" + item.id,
                        method: "delete"
                    }).then(res => {
                        if (res && res.hasOwnProperty("status") && res.status == 200) {
                            this.$notify.success({
                                title: '成功',
                                message: '删除部门成功'
                            });
                            this.search(1);
                            this.initDepTree();
                        } else {
                            this.$notify.error({
                                title: '错误',
                                message: '删除部门错误'
                            });
                        }
                    }).catch(err => {
                        this.$notify.error({
                            title: '错误',
                            message: '删除部门错误'
                        });
                    })
                })
            }
        },
        activated() {
        }
    }

</script>

