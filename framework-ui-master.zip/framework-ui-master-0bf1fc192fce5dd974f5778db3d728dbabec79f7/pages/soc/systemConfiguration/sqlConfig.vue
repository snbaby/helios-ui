<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="数据源配置">
                    <el-button class="search"  @click='$router.back(-1)' type="primary">返回</el-button>
                    <el-button class="cancel"  @click="toAdd">添加</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="menuPersonData.rows">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="jdbcCode"
                    label="连接名"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="jdbcDriver"
                    label="jdbc驱动"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="jdbcUrl"
                    label="url"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="toEdit(scope.row)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            @click.native.prevent="deleteOne(scope.row)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
        <el-dialog title="添加数据源" :visible.sync="dialog" width="40%" >
            <el-form :model="addForm" :rules="rules" ref="addForm" label-width="150px" class="demo-ruleForm">
                <el-row :gutter="20" style="margin-top:24px">
                    <el-col :span="12">
                        <el-form-item label="连接名">
                            <el-input v-model="addForm.jdbcCode" placeholder="连接名"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="jdbc驱动">
                            <el-input v-model="addForm.jdbcDriver" placeholder="jdbc驱动"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="url">
                            <el-input v-model="addForm.jdbcUrl" placeholder="url"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户名">
                            <el-input v-model="addForm.userName" placeholder="用户名"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="密码">
                            <el-input v-model="addForm.passWord" type="password" placeholder="密码"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-button style="margin-left:330px" @click="add('addForm')">确定</el-button>
            </el-form>
        </el-dialog>
        <el-dialog title="修改数据源" :visible.sync="editDialog" width="40%" >
            <el-form :model="editForm" :rules="rules" ref="editForm" label-width="150px" class="demo-ruleForm">
                <el-row :gutter="20" style="margin-top:24px">
                    <el-col :span="12">
                        <el-form-item label="连接名">
                            <el-input v-model="editForm.jdbcCode" :readonly="true" placeholder="连接名"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="jdbc驱动">
                            <el-input v-model="editForm.jdbcDriver" placeholder="jdbc驱动"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="url">
                            <el-input v-model="editForm.jdbcUrl" placeholder="url"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="用户名">
                            <el-input v-model="editForm.userName" placeholder="用户名"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="密码">
                            <el-input v-model="editForm.passWord" type="password" placeholder="密码"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-button style="margin-left:330px" @click="edit('editForm')">确定</el-button>
            </el-form>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {add,getTableData,deleteone,edit} from "@/api/systemConfiguration/sqlConfig/index.js"

    export default {
        components: {
            pagination,
        },
        data() {
            return {
                pageNo:1,
                dialog:false,
                editDialog: false,
                menuPersonData:{
                },
                transferData:[],
                selectMetaArr:[],
                configObject:"",
                addForm: {
                    jdbcCode: "",
                    jdbcDriver: "",
                    jdbcUrl: "",
                    userName: "",
                    passWord: ""
                },
                editForm: {},
                rules: {
                    jdbcCode:[{
                        required: true,
                        message: '请输入连接名',
                        trigger: 'blur'
                    }],
                    jdbcDriver:[{
                        required: true,
                        message: '请输入jdbc驱动',
                        trigger: 'blur'
                    }],
                    jdbcUrl:[{
                        required: true,
                        message: '请输入url',
                        trigger: 'blur'
                    }],
                    userName:[{
                        required: true,
                        message: '请输入用户名',
                        trigger: 'blur'
                    }],
                    passWord:[{
                        required: true,
                        message: '请输入密码',
                        trigger: 'blur'
                    }],
                }
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            }
        },
        methods: {
            init(){
                let query = {
                    page: this.pageNo,
                    limit: 10
                };
                getTableData(query).then(data=>{
                    if(data.status == '200'){
                        this.menuPersonData = data.data;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: data
                        });
                    }
                })
            },
            toAdd(){
                this.dialog = true;
            },
            toEdit(data){
                this.editForm = {
                    jdbcCode: data.jdbcCode,
                    jdbcDriver: data.jdbcDriver,
                    jdbcUrl:data.jdbcUrl,
                    userName: data.userName,
                    passWord: data.passWord,
                    id: data.id
                };
                this.editDialog = true;
            },
            edit(data){
                edit(this.editForm).then(data => {
                    if(data.status == '200'){
                        this.init();
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '修改失败,请重试'
                        });
                    }
                    this.editDialog = false;
                })
            },
            add(){
                add(this.addForm).then(data => {
                    if(data.status == '200'){
                        this.init();
                    }else{
                        this.$notify.error({
                            title: '错误',
                            message: '添加失败,请重试'
                        });
                    }
                    this.dialog = false;
                });
            },
            deleteOne(id){
                deleteone(id).then(data => {
                    if(data.status == '200'){
                        this.init();
                    }else{
                        this.$notify.error({
                            title: '错误',
                            message: '删除失败,请重试'
                        });
                    }
                })
            },
            pageChange(val) {
                this.pageNo = val;
                this.init();
            },
        },
        created() {
            this.init();
        },
        activated() {
            this.init();
        }
    }

</script>


<style lang="css" scoped>
    .margin{
        height: 35px;
        width: 100%;
        background-color: #f0f0f0
    }

    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

    .searchForm {
        width: 100%;
        height: 50px;
        padding: 10px 0;
        background: #f0f0f0;
        /*height: auto;*/
        float: right;
        z-index: 1000;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }

    .transferStyle {

    }
</style>
