<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="流程单号：">
                    <el-input v-model="searchForm.taskNumber" clearable></el-input>
                </el-form-item>
                <el-form-item label="申请人工号：">
                    <el-input v-model="searchForm.taskUserNo" clearable></el-input>
                </el-form-item>
                <el-form-item label="申请人姓名：">
                    <el-input v-model="searchForm.person" clearable></el-input>
                </el-form-item>
                <el-form-item label="申请人组织" prop="depCode">
                    <el-cascader placeholder="" v-model="searchForm.depCode" style="width: 172px;"
                                 :options="depTree"
                                 :show-all-levels="false" filterable change-on-select clearable
                                 v-if="depTree">
                    </el-cascader>
                </el-form-item>
                <el-form-item label="申请时间：" prop="time">
                    <el-date-picker
                        v-model="searchForm.timeRange"
                        type="datetimerange"
                        value-format="timestamp"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        >
                    </el-date-picker>
                </el-form-item>

                <el-form-item>
                    <el-button class="search" @click="searchCompleteTaskTable" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="completeTaskTableData.data">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="flow_business_key"
                    label="流程单号"
                >
                </el-table-column>
                <el-table-column
                    prop="flow_instance_name"
                    label="流程名称"
                >
                </el-table-column>
                <el-table-column
                    prop="flow_proposer_org_code"
                    label="申请人组织"
                >
                </el-table-column>
                <el-table-column
                    prop="flow_proposer_code"
                    label="申请人工号"
                >
                </el-table-column>
                <el-table-column
                    prop="flow_proposer_name"
                    label="申请人姓名"
                >
                </el-table-column>
                <el-table-column
                    prop="flow_start_time"
                    label="申请时间">
                    <template slot-scope="scope">
                        {{timestampToTime(scope.row.flow_start_time)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="viewBpmn(scope.row)"
                            type="text"
                            size="small">
                            查看
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
    </div>
</template>

<script>
    import {getTableData} from '@/api/user/myTask/completedTask/index.js'
    import pagination from '@/components/common/pagination.vue';
    import {
        fetchTree,
        pagedGroups
    } from '@/api/admin/group/index.js';
    export default {
        components: {
            pagination
        },
        data() {
            return {

                pageSize:10,
                pageNo:1,
                groups:[],
                depTree: [],
                depCode: {
                    value: 'name',
                    label: "label",
                    children:"children"
                },
                completeTaskSearch : {},
                completeTaskTableData:{},
                searchForm:{
                    depCode: [],
                    person: "",
                    taskUserNo: "",
                    taskNumber: "",
                    timeRange: []
                }
            }
        },
        computed: {
            //计算出翻页组件所需data
            pageOption(){
                return {
                    pageNo:this.pageNo,
                    pageSize:this.pageSize,
                    total:this.completeTaskTableData.total||0,
                }
            }
        },
        created() {
            this.initGroup();
            this.initDepTree();
            this.refreshCompleteTaskTable();
        },
        methods: {
            initGroup() {
                pagedGroups({
                    "groupType":2,
                    "type": "2",
                    "limit": 0
                }).then((res) => {
                    if (res && res.hasOwnProperty("status") && res.status == 200) {
                        this.groups = res.data.rows
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取部门列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门列表错误'
                    });
                });
            },

            initDepTree() {
                fetchTree({
                    "groupType": 2
                }).then((res) => {
                    this.depTree = res[0].children;
                    this.getValue(this.depTree);
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门树错误'
                    });
                })
            },
            getValue(depTree) {
                for(let i in depTree) {
                    if (depTree[i].children) {
                        this.getValue(depTree[i].children);
                    }
                    depTree[i].value = depTree[i].name;
                }
            },
            //刷新代办任务表格
            refreshCompleteTaskTable(){
                let query = {
                    pageNo: this.pageNo,
                    pageSize: 10,
                    id: this.getCurrentUser().username
                };
                if (this.searchForm.taskNumber != "") {
                    query["flow_business_key"] = this.searchForm.taskNumber;
                }
                if (this.searchForm.person != "") {
                    query["flow_proposer_name"] = this.searchForm.person;
                }
                if (this.searchForm.taskUserNo != "") {
                    query["flow_proposer_code"] = this.searchForm.taskUserNo;
                }
                if (this.searchForm.depCode.length != 0) {
                    query["flow_proposer_org_code"] = this.searchForm.depCode[this.searchForm.depCode.length - 1];
                }
                if (this.searchForm.timeRange.length != 0) {
                    query["Maxtime"] = this.searchForm.timeRange[1];
                    query["Mintime"] = this.searchForm.timeRange[0];
                }
                getTableData(query).then(data => {
                    this.completeTaskTableData = data.data;
                })
            },
            //条件查询代办任务表格
            searchCompleteTaskTable(){
                this.pageNo=1;
                this.refreshCompleteTaskTable();
            },
            //代办任务表格翻页
            pageChange(val){
                this.pageNo=val;
                this.refreshCompleteTaskTable();
            },
            //去查看处理
            viewBpmn(val){
                this.$router.push({
                    path: '/soc/task-center/view-bpmn',
                    query:{
                        processDefinitionkey:val.process_definition_key,
                        flowInstanceId:val.flow_instance_id,
                        random: new Date().getTime()
                    }
                })
            },
            //当用户输入查询条件时，级联选中对应检查
            formChange(val){
                if(this[val]){
                    this['check'+val]=true;
                }else{
                    this['check'+val]=false;
                }
            }
        },
        activated() {

        }
    }
</script>






