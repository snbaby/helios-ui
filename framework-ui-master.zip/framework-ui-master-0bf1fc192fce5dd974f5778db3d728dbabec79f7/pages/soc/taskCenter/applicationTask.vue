<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="流程名称：">
                    <el-input v-model="taskName" clearable></el-input>
                </el-form-item>
                <el-form-item label="流程状态：">
                    <el-select v-model="taskStatus" clearable>
                        <el-option
                            v-for="item in taskStatusOptions"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="流程单号：">
                    <el-input v-model="taskNumber" clearable></el-input>
                </el-form-item>
                <el-form-item label="当前节点：">
                    <el-input v-model="curnode" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="searchMyTodoTable" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="trackingTaskTableData.data">
                <el-table-column type="index" width="50"></el-table-column>
                <el-table-column prop="flow_business_key" label="流程单号"></el-table-column>
                <el-table-column prop="flow_instance_name" label="流程名称"></el-table-column>
                <el-table-column prop="flow_task_name" label="当前节点"></el-table-column>
                <el-table-column label="状态">
                    <template slot-scope="scope">
                        {{scope.row.flow_status=='COMPLETED'?"已完成":"审批中"}}
                    </template>
                </el-table-column>
                <el-table-column label="创建时间">
                    <template slot-scope="scope">
                        {{timestampToTime(scope.row.flow_start_time)}}
                    </template>
                </el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="viewBpmn(scope.row)"
                            type="text"
                            size="small">
                            查看
                        </el-button>
                        <!--<el-button-->
                            <!--@click.native.prevent="toPrint(scope.row.flow_instance_id)"-->
                            <!--v-if="scope.row.flow_status=='COMPLETED' && scope.row.process_definition_key == 'P12345678'"-->
                            <!--type="text"-->
                            <!--size="small">-->
                            <!--报表-->
                        <!--</el-button>-->
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {
        queryTrackingTaskProcess
    } from '@/api/user/myTask/trackingTask/index.js';

    export default {
        components: {
            pagination,
        },
        data() {
            return {
                //search表单
                taskName: "",//任务名称
                taskStatus: "",//任务状态
                taskNumber: "",//单号
                curnode: "",//当前节点
                pageSize: 10,
                pageNo: 1,
                trackingTaskTableData: {},
                taskStatusOptions: [
                    {
                        label: "审批中",
                        value: "ACTIVE"
                    },
                    {
                        label: "已完成",
                        value: "COMPLETED"
                    }
                ]

            }
        },
        computed: {
            //计算出翻页组件所需data
            pageOption() {
                return {
                    pageNo: this.pageNo,
                    pageSize: this.pageSize,
                    total: this.trackingTaskTableData.total || 0,
                }
            }
        },
        created() {
            this.refreshMyTodoTable();
        },
        methods: {
            //刷新任务跟踪表格
            refreshMyTodoTable() {
                var str = '';
                if (this.taskNumber != '') {
                    str = str + ' and flow_business_key =' + "'" + this.taskNumber + "'";
                }
                if (this.taskStatus != '') {
                    str = str + ' and flow_status =' + "'" + this.taskStatus + "'";
                }
                if (this.taskName != '') {
                    str = str + ' and flow_instance_name like ' + "'%" + this.taskName + "%'";
                }
                if (this.curnode != '') {
                    str = str + ' and flow_task_name like' + "'%" + this.curnode + "%'";
                }
                let query = {
                    flow_proposer_code: this.getCurrentUser().username,
                    where: str,
                    PageStart: (this.pageNo - 1) * this.pageSize,
                    PageSize: this.pageSize
                };
                queryTrackingTaskProcess(query).then(data => {
                    this.trackingTaskTableData = data.data;
                })
            },
            //条件查询任务跟踪表格
            searchMyTodoTable() {
                this.pageNo = 1;
                this.refreshMyTodoTable();
            },
            //任务跟踪表格翻页
            pageChange(val) {
                this.pageNo = val;
                this.refreshMyTodoTable();
            },
            //去查看任务跟踪
            viewBpmn(val) {
                if (val.process_definition_key == "leak_record") {
                    this.$router.push({
                        path: '/soc/task-center/view-bpmn',
                        query: {
                            processDefinitionkey: val.process_definition_key,
                            flowInstanceId: val.flow_instance_id,
                            flowBusinessKey: val.flow_business_key,
                            random: new Date().getTime()
                        }
                    })
                } else {
                    this.$router.push({
                        path: '/soc/task-center/view-bpmn',
                        query: {
                            processDefinitionkey: val.process_definition_key,
                            flowInstanceId: val.flow_instance_id,
                            random: new Date().getTime()
                        }
                    })
                }
            },
            toPrint(code) {
                let srcHtml = "http://ureport.seadun.com:8044/ureport/preview?_u=file:formNumber.ureport.xml&Id=" + code;
                this.$router.push({
                    path: "/secret/user/businessCenter/printReport",
                    query: {
                        srcHtml: srcHtml
                    }
                });
            }
        }
    }
</script>
