<template>
    <div class="backColor">
        <div class="contentBox">
            <div class="pageContent">
                <div class="processContent">
                    <el-form ref="ruleForm" label-width="150px" class="demo-ruleForm">
                        <el-row style="text-align:center;margin-bottom:15px;">
                            <font style="font-size: large;font-weight: bold;">漏洞备案申请</font>
                        </el-row>
                        <div class="tabsStyle">
                            <font>主机台账信息</font>
                            <font style="float: right;color: #409eff" @click = "openDialog">流程图</font>
                        </div>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机编号">
                                    <el-input v-model="ruleForm.asset_code" :disabled="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机密级">
                                    <el-select v-model="ruleForm.asset_secret" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_secret')" :key="index.code" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机状态">
                                    <el-select v-model="ruleForm.asset_status" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_status')" :key="index.code" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机用途">
                                    <el-select v-model="ruleForm.asset_useage" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_useage')" :key="index.code" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="IP地址">
                                    <el-input v-model="ruleForm.asset_ip" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="MAC地址">
                                    <el-input v-model="ruleForm.asset_mac" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="硬盘SN">
                                    <el-input v-model="ruleForm.asset_disksn" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用网络">
                                    <el-select v-model="ruleForm.asset_network" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_network')" :key="index.code" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="安装位置">
                                    <el-input v-model="ruleForm.asset_area" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="责任部门">
                                    <el-input v-model="ruleForm.org_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="责任人">
                                    <el-input v-model="ruleForm.asset_duty_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用人">
                                    <el-input v-model="ruleForm.asset_user_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <div class="tabsStyle"><font>备案漏洞</font></div>
                        <div>
                            <el-table
                                ref="multipleTable"
                                :data="menuData"
                                tooltip-effect="dark"
                                style="width: 100%"
                            >
                                <el-table-column
                                    type="index"
                                    width="50"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="severity_grade"
                                    label="严重等级"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="risk"
                                    label="严重分值"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="name"
                                    label="漏洞名称"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="description"
                                    label="漏洞描述"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="solution"
                                    label="解决方案"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    label="发现时间"
                                    show-overflow-tooltip>
                                    <template slot-scope="scope">
                                        {{timestampToTime(scope.row.discover_date)}}
                                    </template>
                                </el-table-column>
                            </el-table>
                        </div>
                        <el-form label-width="80px" label-position="right" style="padding: 40px 20px 20px 20px;width: 100%">
                            <el-row>
                                <el-col :span="24">
                                    <el-form-item label="备案理由" prop="recodeDesp" >
                                        <el-input type="textarea" v-model="ruleForm.recodeDesp" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                        </el-form>
                    </el-form>
                </div>
                <div class="historyProcess">
                    <div class="tabsStyle"><font>流程审批信息</font></div>
                    <el-row>
                        <el-collapse v-model="activeNames">
                            <!--                    发起人-->
                            <el-collapse-item>
                                <template slot="title">
                                    漏洞备案申请<font class="approveResultStyle">{{processStartInfo.flow_proposer_name}} {{timestampToTime(processStartInfo.flow_start_time)}} 发起</font>
                                </template>
                                <el-input type="textarea" :readonly="true" v-model="processStartInfo.flow_instance_name"></el-input>
                            </el-collapse-item>
                            <el-collapse-item v-for="item,index in historyApproveData" :key="item.flow_task_name">
                                <template slot="title">
                                    {{item.flow_task_name}} <font class="approveResultStyle" :style="getApproveResultColor(item.isAgree)">
                                    {{item.flow_tasker_name}}
                                    {{timestampToTime(item.flow_end_time)}} {{getApproveResultShow(item.isAgree)}}</font>
                                </template>
                                <el-input type="textarea" :readonly="true" v-model="item.remark"></el-input>
                            </el-collapse-item>
                            <el-collapse-item name="thisapprove">
                                <template slot="title">
                                    {{activeApproveName}}
                                </template>
                                <el-form ref="form" :model="nowApproveData" label-width="160px">
                                    <el-col :span="24" v-for="item,index in approveFormData" :key="item.id" v-if="item.id=='remark'">
                                        <el-form-item :label="item.label">
                                            <el-input type="textarea" v-model="nowApproveData[item.id]"></el-input>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span="24"  v-else-if="item.type=='tTextarea'">
                                        <el-form-item :label="item.label">
                                            <el-input type="textarea" v-model="nowApproveData[item.id]"></el-input>
                                        </el-form-item>
                                    </el-col>
                                    <el-col :span="24"  v-else-if="item.type=='enum'">
                                        <el-form-item :label="item.label">
                                            <el-radio-group v-model="nowApproveData[item.id]">
                                                <el-radio :label="item1.id" v-for="item1,index1 in item.data" :key="item1.id">
                                                    {{item1.value}}
                                                </el-radio>
                                            </el-radio-group>
                                        </el-form-item>
                                    </el-col>
                                </el-form>
                            </el-collapse-item>

                        </el-collapse>
                    </el-row>
                    <el-row>
                        <el-col :span="getColLength(approveButtonArr.length)"  style="text-align:center;" v-for="item in approveButtonArr" :key="item.btnValue">
                            <el-button type="primary" @click="submit(item.btnValue)" class="submit">{{item.btnName}}</el-button>
                        </el-col>
                    </el-row>
                </div>
                <el-dialog :visible.sync="processDialog" width="70%">
                    <h6>流程图</h6>
                    <div id="container"></div>
                </el-dialog>
            </div>
        </div>
        <font v-loading.fullscreen.lock="fullscreenLoading" text="流程处理中" v-if="fullscreenLoading"></font>
    </div>
</template>

<script>
    import {getProcessDefineXml_key} from '@/api/user/myTask/processInfo/index.js'
    import {selectTaskInfoByActivityInstanceId,processNodeData,approvalProcess,claimProcess,selectHostScanResultByCode,
        getHistoryApproveData,selectHostFlowRecordById,upEsData,upDataEs,upData} from '@/api/terminalSecurity/recordManagement/leakRecordApply/index.js'
    import Viewer from 'bpmn-js/lib/NavigatedViewer.js';

    export default {
        data() {
            return {
                ruleForm: {},
                processDialog: false,
                menuData: [],
                fullscreenLoading: false,
                formData: {},
                rules:{
                    recodeDesp:[{
                        required: true,
                        message: '请输入备案申请事由',
                        trigger: 'blur'
                    },{
                        required: true,
                        message: '请输入备案申请事由',
                        trigger: 'change'
                    }]
                },
                recodeReasonList: [],
                //当前审批意见ID
                activeNames:['thisapprove'],

                //历史审批意见
                historyApproveData:[],
                //当前节点表单
                approveFormData:[],
                //当前节点按钮组
                approveButtonArr:[],
                //当前节点按钮key
                approveButtonKey:'',
                //当前节点name
                activeApproveName:"",
                //当前节点表单
                nowApproveData:{
                },
                processStartInfo:{},
                flow_instance_id : this.$route.query.flow_instance_id,
                type : this.$route.query.type,
                taskId : this.$route.query.taskId,
            }
        },
        methods: {
            init() {
                selectHostFlowRecordById({'ID': this.$route.query.flow_instance_id}).then(data =>{
                    this.ruleForm = data.data.data[0];
                    this.menuData = data.data.data;
                });
                selectTaskInfoByActivityInstanceId({activityInstanceId: this.flow_instance_id}).then(data=>{
                    this.processStartInfo = data.data.data[0];
                });
                getHistoryApproveData(this.flow_instance_id).then((data) =>{
                    this.historyApproveData = data.data.data;
                });
                processNodeData(this.flow_instance_id).then(data =>{
                    var thisnode = {};
                    for(var key in data.data){
                        if(data.data[key].taskId){
                            thisnode=data.data[key];
                        }
                    }
                    this.activeApproveName = thisnode.taskName;
                    var arr = [];//按钮
                    var formarr = [];//表单

                    for(var i=0;i<thisnode.form.length;i++){
                        if(thisnode.form[i].id.indexOf('isAgree')>-1){
                            this.approveButtonKey=thisnode.form[i].id;
                            var obj = thisnode.form[i].options;
                            for(var z=0;z<obj.length;z++){
                                for(var key in obj[z]){
                                    var btnmap = {
                                        btnName:obj[z][key],
                                        btnValue:key,
                                    }
                                    arr.push(btnmap);
                                }
                            }
                        }else if(thisnode.form[i].id=='remark'){
                            let formData={
                                type:"tTextarea",
                                id:thisnode.form[i].id,
                                label:thisnode.form[i].label,
                                data:thisnode.form[i].options,
                            }
                            this.nowApproveData[thisnode.form[i].id] = thisnode.form[i].defaultValue;
                            formarr.push(formData);
                        }else if(thisnode.form[i].id=='recordIndex'){
                            let data=thisnode.form[i].options;
                            let item=[]
                            for(let j=0;j<data.length;j++){
                                for(let key in data[j]){
                                    item.push({id:key,value:data[j][key]})
                                }
                            }
                            let formData={
                                type:thisnode.form[i].dataType,
                                id:thisnode.form[i].id,
                                label:thisnode.form[i].label,
                                data:item,
                            }
                            formarr.push(formData);
                        }
                    }

                    this.approveButtonArr = arr;
                    this.approveFormData =formarr;
                });
            },
            approvalProcess(val){
                this.nowApproveData[this.approveButtonKey]=val;
                approvalProcess(this.nowApproveData,this.taskId).then(()=>{
                    this.fullscreenLoading = false;
                }).catch(()=>{
                    setTimeout(() => {
                        this.fullscreenLoading = false;
                        this.$router.replace({path:"/soc/task-center/pending-task"});
                    }, 1500);
                })
            },
            submit(val){
                this.$confirm('是否确定执行该审批结果?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                }).then(() => {
                    if(this.processStartInfo.flow_proposer_code && this.processStartInfo.flow_task_status!='complete'){
                        var user = this.getCurrentUser().username;
                        claimProcess(user,this.taskId).catch(()=>{
                            this.fullscreenLoading = true;
                            setTimeout(()=>{
                                if(this.activeApproveName == '信息技术部主管领导审批' && val == "true"){
                                    let query = {
                                        processInstanceId: this.$route.query.flow_instance_id,
                                        index: "app_bpmn",
                                        type: "leak_record"
                                    };
                                    upEsData(query).then(data => {
                                        if(data.status != 200){
                                            return ;
                                        }
                                    });
                                    let vul_id = [];
                                    for(let i in this.menuData){
                                        vul_id.push(this.menuData[i].vul_id);
                                    }
                                    let datas = {
                                        asset_code: this.ruleForm.asset_code,
                                        vul_id: vul_id.toString()
                                    };
                                    upData(datas).then(data => {
                                        if(data.status != 200){
                                            return ;
                                        }
                                    });
                                }else if(this.activeApproveName == '申请人重新发起流程' && val == "false"){
                                    let query = {
                                        processInstanceId: this.$route.query.flow_instance_id,
                                    };
                                    upDataEs(query).then(data => {
                                        if(data.status != 200){
                                            return ;
                                        }
                                    });
                                }
                                this.approvalProcess(val);
                            },2000)
                        })
                    }else{
                        this.fullscreenLoading = true;
                        this.approvalProcess(val);
                    }
                }).catch(() => {
                    return false;
                });
            },
            openDialog() {
                this.processDialog = true;
                getProcessDefineXml_key('leak_record').then(res => {
                    document.getElementById("container").innerHTML="";
                    var viewer = new Viewer({container: '#container'});
                    viewer.importXML(res.bpmn20Xml, (err) => {
                        var canvas = viewer.get('canvas');
                        canvas.zoom('fit-viewport');
                    });
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取流程表单错误'
                    });
                })
            },
            getColLength(length){
                return Math.ceil(24/length);
            },
            getApproveResultColor(approveResult){
                if(approveResult == 'true') {
                    return "color:#004ea2;"
                }
                else if(approveResult == 'false'){
                    return "color:red;"
                }
                else if(approveResult == 'tijiao'){
                    return "color:#666666;"
                }
                else {
                    return "color:#000000;"
                }
            },
            getApproveResultShow(approveResult){
                if(approveResult == 'true') {
                    return "同意";
                }
                else if(approveResult == 'false'){
                    return "不同意";
                }
                else if(approveResult == 'tijiao'){
                    return "提交";
                }
                else {
                    return "通过";
                }
            },
        },
        created() {
            this.init();
        },
    }

</script>


<style lang="css" scoped>
    .tabsStyle {
        width: 100%;
        height: 1px;
        background-color: #000000;
        margin-bottom: 15px;
        margin-top: 30px;
    }

    .tabsStyle font {
        position: relative;
        top: -25px;
        font-weight: bold;
    }

    .historyProcess {
        width: 100%;
        height: auto;
        padding: 20px 40px;
    }

    .approveResultStyle {
        float: right;
        margin-right: 20px;
    }
</style>
