<template>
    <div style="height: 100%;background-color: #f0f0f0">
        <el-row style="margin-bottom: 20px;background-color: #ffffff">
            <div class="margin"></div>
            <el-row style="height: 40px;">
                <el-button style="float:right;margin-top: 5px;" @click="$router.back(-1)">返 回</el-button>
            </el-row>
        </el-row>
        <div id="viewBpmn">
            <processInfo :processDefinitionkey="processDefinitionkey" :flowInstanceId="flowInstanceId"></processInfo>
        </div>
    </div>
</template>

<script>
    import processInfo from '@/components/myTask/ProcessInfo'
    export default {
        name: 'viewBpmn',
        components: {
            processInfo
        },
        data() {
            return {
                processDefinitionkey: this.$route.query.processDefinitionkey,
                flowInstanceId:this.$route.query.flowInstanceId,
                // flowBusinessKey:this.$route.query.flowBusinessKey
            }
        },
        mounted() {

        },
        methods: {

        },
        activated(){

        }
    };
</script>
<style lang="css" scoped>
    .margin {
        height: 15px;
        width: 100%;
        background-color: #f0f0f0;
    }
</style>
