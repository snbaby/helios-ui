<template>
    <el-row>
        <div class="backColor" id="loopleRecordCancle">
            <div class="contentBox">
                <div class="pageContent">
                    <div class="margin"></div>
                    <div class="backBottonStyle">
                        <el-button type="primary" @click="$router.back(-1)" class="submit">返回</el-button>
                    </div>
                    <div class="processContent">
                        <el-form :model="loophole" ref="ruleForm" label-width="150px" class="demo-ruleForm">
                            <el-row style="text-align:center;margin-bottom:15px;">
                                <font style="font-size: large;font-weight: bold;">主机备案申请</font>
                            </el-row>
                            <div class="tabsStyle">
                                <font>主机台账信息</font>
                            </div>
                            <el-row>
                                <el-col :span="8">
                                    <el-form-item label="主机编号">
                                        <el-input v-model="ruleForm.asset_code" :disabled="true"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="主机密级">
                                        <el-select v-model="ruleForm.asset_secret" placeholder="" style="width:100%;" :disabled="true">
                                            <el-option v-for="item,index in getCategoryData('asset_secret')" :key="index" :label="item.label" :value="item.code">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="主机状态">
                                        <el-select v-model="ruleForm.asset_status" placeholder="" style="width:100%;" :disabled="true">
                                            <el-option v-for="item,index in getCategoryData('asset_status')" :key="index" :label="item.label" :value="item.code">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="8">
                                    <el-form-item label="主机用途">
                                        <el-select v-model="ruleForm.asset_useage" placeholder="" style="width:100%;" :disabled="true">
                                            <el-option v-for="item,index in getCategoryData('asset_useage')" :key="index" :label="item.label" :value="item.code">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="IP地址">
                                        <el-input v-model="ruleForm.asset_ip" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="MAC地址">
                                        <el-input v-model="ruleForm.asset_mac" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="8">
                                    <el-form-item label="硬盘SN">
                                        <el-input v-model="ruleForm.asset_disksn" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="使用网络">
                                        <el-select v-model="ruleForm.asset_network" placeholder="" style="width:100%;" :disabled="true">
                                            <el-option v-for="item,index in getCategoryData('asset_network')" :key="index" :label="item.label" :value="item.code">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="安装位置">
                                        <el-input v-model="ruleForm.asset_area" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="8">
                                    <el-form-item label="责任部门">
                                        <el-input v-model="ruleForm.org_name" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="责任人">
                                        <el-input v-model="ruleForm.asset_duty_name" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="8">
                                    <el-form-item label="使用人">
                                        <el-input v-model="ruleForm.asset_user_name" :readonly="true"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <div class="tabsStyle"><font>备案详情</font></div>
                            <el-row>
                                <el-col :span="12">
                                    <el-form-item label="备案类别" prop="recodeType">
                                        <el-cascader
                                            v-model="loophole.recodeType"
                                            placeholder=""
                                            :options="recordDataTree"
                                            filterable
                                            style="width:100%;"
                                            @change="getRecordResonList"
                                            :disabled="isReWrite"
                                        ></el-cascader>
                                    </el-form-item>
                                </el-col>
                                <el-col :span="12">
                                    <el-form-item label="备案原因" prop="recodeReason">
                                        <el-select v-model="loophole.recodeReason" placeholder="" style="width:100%;" :disabled="isReWrite">
                                            <el-option v-for="item,index in recodeReasonList" :key="index" :label="item.recordName" :value="item.recordName">
                                            </el-option>
                                        </el-select>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="24">
                                    <el-form-item label="详细描述" prop="recodeDesp">
                                        <el-input type="textarea" v-model="loophole.recodeDesp" :disabled="isReWrite"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row>
                                <el-col :span="3" style="text-align: right;">注</el-col>
                                <el-col :span="21" style="padding-left: 15px"><p  v-for="item in (loophole.recodeAppReason?loophole.recodeAppReason.split('\n'):[''])">{{item}}</p></el-col>
                            </el-row>
                        </el-form>
                    </div>
                </div>
            </div>
        </div>
        <div class="historyProcess">
            <div class="tabsStyle"><font>流程审批信息</font></div>
            <el-row>
                <el-collapse v-model="activeNames">
                    <!--                    发起人-->
                    <el-collapse-item>
                        <template slot="title">
                            密查指标备案申请<font class="approveResultStyle">{{processStartInfo.flow_proposer_name}} {{timestampToTime(processStartInfo.flow_start_time)}} 发起</font>
                        </template>
                        <el-input type="textarea" :readonly="true" v-model="processStartInfo.flow_instance_name"></el-input>
                    </el-collapse-item>
                    <!--                    历史审批-->
                    <el-collapse-item v-for="item,index in historyApproveData" :key="item.flow_task_name">
                        <template slot="title">
                            {{item.flow_task_name}} <font class="approveResultStyle" :style="getApproveResultColor(item.isAgree)">
                            {{item.flow_tasker_name}}
                            {{timestampToTime(item.flow_end_time)}} {{getApproveResultShow(item.isAgree)}}</font>
                        </template>
                        <el-input type="textarea" :readonly="true" v-model="item.remark"></el-input>
                    </el-collapse-item>
                    <!--                    当前节点-->
                    <el-collapse-item name="thisapprove">
                        <template slot="title">
                            {{activeApproveName}}
                        </template>
                        <el-form ref="form" :model="nowApproveData" label-width="160px">
                            <el-col :span="24" v-for="item,index in approveFormData" :key="item.id" v-if="item.id=='remark'">
                                <el-form-item :label="item.label">
                                    <el-input type="textarea" v-model="nowApproveData[item.id]"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="24"  v-else-if="item.type=='tTextarea'">
                                <el-form-item :label="item.label">
                                    <el-input type="textarea" v-model="nowApproveData[item.id]"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="24"  v-else-if="item.type=='enum'">
                                <el-form-item :label="item.label">
                                    <el-radio-group v-model="nowApproveData[item.id]">
                                        <el-radio :label="item1.id" v-for="item1,index1 in item.data" :key="item1.id">
                                            {{item1.value}}
                                        </el-radio>
                                    </el-radio-group>
                                </el-form-item>
                            </el-col>
                        </el-form>
                    </el-collapse-item>
                </el-collapse>
            </el-row>
            <el-row>
                <el-col :span="getColLength(approveButtonArr.length)"  style="text-align:center;" v-for="item in approveButtonArr" :key="item.btnValue">
                    <el-button type="primary" @click="submit(item.btnValue)" class="submit">{{item.btnName}}</el-button>
                </el-col>
            </el-row>
        </div>
        <font v-loading.fullscreen.lock="fullscreenLoading" text="流程处理中" v-if="fullscreenLoading"></font>
    </el-row>
</template>

<script>
    import {processNodeData,approvalProcess,claimProcess,getProcessStartForm,selectTaskInfoByActivityInstanceId,
        getHistoryApproveData,queryInstanceIdAndTypeByTaskId,upEsData} from '@/api/user/myTask/approveLoopholeRecordProcess/index.js';
    import {getFormData} from '@/api/terminalSecurity/recordManagement/loopleRecordCancle/index.js'
    import {getEventSourceData,getRecordDataTree,getRecordResonList,getEventCategoryByCode,getEventSourceById} from "@/api/terminalSecurity/recordManagement/assetRecordApply/index.js"
    export default {
        data() {
            return {
                hasRecordItem: [],
                recodeType: [],
                fullscreenLoading:false,
                startFromData:{

                },
                ruleForm:{
                },
                loophole:{
                    recodeType:[],
                    recodeReason:"",
                    recodeDesp:"",
                    recodeAppReason:"",
                    recordIndex:"false"
                },
                recodeReasonList: [],
                //当前审批意见ID
                activeNames:['thisapprove'],

                //历史审批意见
                historyApproveData:[],

                //当前节点表单
                approveFormData:[],
                //当前节点按钮组
                approveButtonArr:[],
                //当前节点按钮key
                approveButtonKey:'',
                //当前节点name
                activeApproveName:"",
                //当前节点表单
                nowApproveData:{
//					approveId:"",
//					approveNodeName:"",
//					approveDetail:""
                },
                recordDataTree: [],
                processStartInfo:{},
                isReWrite:true,
                approveDate: {},
                type:"",
                recodeList: "",
                flow_instance_id:"",
                taskId:""
            }
        },
        mounted(){
        },
        computed: {
        },
        methods: {
            init(){
                let query = {
                    flowId: this.$route.query.flow_instance_id
                };
                getFormData(query).then(data => {
                    this.ruleForm = data.data.data[0];
                });
                if(this.$route.params.taskId){
                    this.taskId = this.$route.params.taskId;
                    queryInstanceIdAndTypeByTaskId(this.taskId).then((taskInfo) =>{
                        this.type = taskInfo.data.data[0].process_definition_key;
                        this.flow_instance_id = taskInfo.data.data[0].flow_instance_id;
                        this.init2();
                    });
                }else{
                    this.taskId = this.$route.query.taskId;
                    this.type = this.$route.query.type;
                    this.flow_instance_id = this.$route.query.flow_instance_id;
                    this.init2();
                }
            },
            init2(){
                getProcessStartForm(this.type,this.flow_instance_id).then((startForm) =>{
                    if(startForm.data.total == 0){
                        this.startFromData = {}
                    }else{
                        this.startFromData = startForm.data.data[0];
                        var arr = [];
                        for(var item in this.startFromData.recodeType.split(',')){
                            if(isNaN(this.startFromData.recodeType.split(',')[item])){
                                arr.push(this.startFromData.recodeType.split(',')[item]);
                            }else{
                                arr.push(parseInt(this.startFromData.recodeType.split(',')[item]));
                            }
                        }
                        this.startFromData.recodeType = arr;
                    }
                    this.loophole = this.startFromData;
                });
                processNodeData(this.flow_instance_id).then((data) =>{
                    var thisnode = {};
                    for(var key in data.data){
                        if(data.data[key].taskId){
                            thisnode=data.data[key];
                        }
                    }
                    if(thisnode.taskName == '申请人重新申请'){
                        this.isReWrite = false;
                    }
                    this.activeApproveName = thisnode.taskName;
                    var arr = [];//按钮
                    var formarr = [];//表单
                    for(var i=0;i<thisnode.form.length;i++){
                        if(thisnode.form[i].id.indexOf('isAgree')>-1){
                            this.approveButtonKey=thisnode.form[i].id;
                            var obj = thisnode.form[i].options;
                            for(var z=0;z<obj.length;z++){
                                for(var key in obj[z]){
                                    var btnmap = {
                                        btnName:obj[z][key],
                                        btnValue:key,
                                    };
                                    arr.push(btnmap);
                                }
                            }
                        }else if(thisnode.form[i].id=='remark'){
                            let formData={
                                type:"tTextarea",
                                id:thisnode.form[i].id,
                                label:thisnode.form[i].label,
                                data:thisnode.form[i].options,
                            }
                            this.nowApproveData[thisnode.form[i].id] = thisnode.form[i].defaultValue;
                            formarr.push(formData);
                        }else if(thisnode.form[i].id=='recordIndex'){
                            let data=thisnode.form[i].options;
                            let item=[]
                            for(let j=0;j<data.length;j++){
                                for(let key in data[j]){
                                    item.push({id:key,value:data[j][key]})
                                }
                            }
                            let formData={
                                type:thisnode.form[i].dataType,
                                id:thisnode.form[i].id,
                                label:thisnode.form[i].label,
                                data:item,
                            }
                            formarr.push(formData);
                        }
                    }

                    this.approveButtonArr = arr;
                    this.approveFormData =formarr;
                });

                selectTaskInfoByActivityInstanceId(this.flow_instance_id).then((data) =>{
                    this.processStartInfo = data.data.data[0];
                });

                getHistoryApproveData(this.flow_instance_id).then((data) =>{
                    this.historyApproveData = data.data.data;
                });
            },
            getApproveResultColor(approveResult){
                if(approveResult == 'true') {
                    return "color:#004ea2;"
                }
                else if(approveResult == 'false'){
                    return "color:red;"
                }
                else if(approveResult == 'tijiao'){
                    return "color:#666666;"
                }
                else {
                    return "color:#000000;"
                }
            },
            getApproveResultShow(approveResult){
                if(approveResult == 'true') {
                    return "同意";
                }
                else if(approveResult == 'false'){
                    return "不同意";
                }
                else if(approveResult == 'tijiao'){
                    return "提交";
                }
                else {
                    return "通过";
                }
            },
            getColLength(length){
                return Math.ceil(24/length);
            },
            approvalProcess(val){
                this.nowApproveData[this.approveButtonKey]=val;
                approvalProcess(this.nowApproveData,this.taskId).then(()=>{
                    this.fullscreenLoading = false;
                }).catch(()=>{
                    setTimeout(() => {
                        this.fullscreenLoading = false;
                        this.$router.replace({path:"/soc/task-center/pending-task"});
                    }, 1500);
                })
            },
            submit(val){
                this.$confirm('是否确定执行该审批结果?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                }).then(() => {
                    if(this.isReWrite == false){
                        if(this.loophole.recodeType == '' || this.loophole.recodeReason == '' || this.loophole.recodeDesp == ''){
                            this.$notify.error({
                                title: '错误',
                                message: '修改审批信息有空值'
                            });
                            return false;
                        }
                        let query = {
                            id: this.loophole._id,
                            index: this.loophole._index,
                            type: this.loophole._type,
                            norm_code: this.loophole.norm_code,
                            norm_title: this.loophole.norm_title,
                            norm_type: this.loophole.norm_type,
                            norm_type_name: this.loophole.norm_type_name,
                            recodeAppReason: this.loophole.recodeAppReason,
                            recodeDesp: this.loophole.recodeDesp,
                            recodeReason: this.loophole.recodeReason,
                            recodeType: this.loophole.recodeType.toString(),
                        };
                        upEsData(query).then(data => {
                            if(data.status != '200'){
                                this.$notify.error({
                                    title: '错误',
                                    message: '修改审批信息失败，请重试'
                                });
                            }else{
                                this.toClaim(val);
                            }
                        }).catch(err => {
                            this.$notify.error({
                                title: '错误',
                                message: '修改审批信息失败，请重试'
                            });
                        })
                    }else {
                        this.toClaim(val);
                    }
                }).catch(() => {
                    return false;
                });
            },
            toClaim(val){
                if (this.processStartInfo.flow_proposer_code && this.processStartInfo.flow_task_status != 'complete') {
                    var user = this.getCurrentUser().username;
                    claimProcess(user, this.taskId).catch(() => {
                        this.fullscreenLoading = true;
                        setTimeout(() => {
                            this.approvalProcess(val);
                        }, 2000)
                    })
                } else {
                    this.fullscreenLoading = true;
                    this.approvalProcess(val);
                }
            },
            getRecordDataTree(){
                getRecordDataTree().then((data)  =>{
                    this.recordDataTree = data.data;
                    if(this.hasRecordItem.length>0){
                        for(var i=0;i<this.recordDataTree.length;i++){
                            for(var j=0;j<this.recordDataTree[i].children.length;j++){
                                if(this.hasRecordItem.indexOf(this.recordDataTree[i].children.value)>-1){
                                    this.recordDataTree[i].children.disabled = true;
                                }
                            }
                        }
                    }
                });
            },
            getRecordResonList(e){
                this.loophole.recodeReason = "";
                this.loophole.recodeAppReason = "";
                var id = e[e.length - 1];
                getEventSourceData().then((data)  =>{
                    for(var i=0;i<data.data.rows.length;i++){
                        if(data.data.rows[i].id == id){
                            this.loophole.recordIndex = "true";
                            break;
                        }else{
                            this.loophole.recordIndex = "false";
                        }
                    }
                });
                getRecordResonList(id).then((data)  =>{
                    this.recodeReasonList = data.data.recordItems;
                });
                getEventCategoryByCode(e[0]).then((data)  =>{
                    this.loophole.norm_type = data.data.rows[0].categoryCode;
                    this.loophole.norm_type_name = data.data.rows[0].categoryName;
                });
                getEventSourceById(id).then((data)  =>{
                    this.loophole.norm_code = data.data.sourceCode;
                    this.loophole.norm_title = data.data.recordType;
                });
            },
        },
        created() {
            this.init();
            this.getRecordDataTree();
        },
        activated() {
            this.init();
            this.getRecordDataTree();
        }
    }

</script>


<style lang="css" scoped>
    .tabsStyle {
        width: 100%;
        height: 1px;
        background-color: #000000;
        margin-bottom: 15px;
        margin-top: 30px;
    }

    .tabsStyle font {
        position: relative;
        top: -25px;
        font-weight: bold;
    }

    .historyProcess {
        width: 100%;
        height: auto;
        padding: 20px 40px;
    }

    .approveResultStyle {
        float: right;
        margin-right: 20px;
    }
</style>
