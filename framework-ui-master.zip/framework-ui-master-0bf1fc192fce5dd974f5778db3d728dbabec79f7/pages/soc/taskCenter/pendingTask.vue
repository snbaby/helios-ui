<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="流程单号：">
                    <el-input v-model="taskNumber" clearable></el-input>
                </el-form-item>
                <el-form-item label="申请人工号：">
                    <el-input v-model="taskUserNo" clearable></el-input>
                </el-form-item>
                <el-form-item label="申请人姓名：">
                    <el-input v-model="person" clearable></el-input>
                </el-form-item>
                <el-form-item label="申请人部门：">
                    <el-cascader v-model="group"
                                 :options="depTreeDict"
                                 :props="depCode"
                                 :show-all-levels="false"
                                 clearable
                                 filterable
                                 change-on-select>
                    </el-cascader>
                </el-form-item>
                <el-form-item label="当前节点：">
                    <el-input v-model="curnode" clearable></el-input>
                </el-form-item>
                <el-form-item label="申请时间：">
                    <el-date-picker
                        v-model="timeRange"
                        type="datetimerange"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        clearable>
                    </el-date-picker>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="searchMyTodoTable" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="myTodoTaskTableData.data">
                <el-table-column type="index" width="50"></el-table-column>
                <el-table-column prop="flow_business_key" label="流程单号"></el-table-column>
                <el-table-column prop="flow_instance_name" label="流程名称"></el-table-column>
                <el-table-column prop="flow_task_name" label="流程节点"></el-table-column>
                <el-table-column prop="flow_proposer_org_name" label="申请人组织"></el-table-column>
                <el-table-column prop="flow_proposer_code" label="申请人工号"></el-table-column>
                <el-table-column prop="flow_proposer_name" label="申请人姓名"></el-table-column>
                <el-table-column label="创建时间">
                    <template slot-scope="scope">
                        {{timestampToTime(scope.row.flow_start_time)}}
                    </template>
                </el-table-column>

                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="doApproval(scope.row)"
                            type="text"
                            size="small">
                            去处理
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {
        fetchTree,
        pagedGroups,
        queryProcessApplyInfo,
        getProcessTask
    } from '@/api/user/myTask/myTodo/index.js';

    export default {
        components: {
            pagination
        },
        data() {
            return {
                //search表单
                taskNumber: "",//任务单号
                taskUserNo: "",//任务类型
                person: "",//发起人
                contant: "",//申请内容
                group: [],//部门
                timeRange: [],//申请时间
                curnode: "",//当前节点
                pageSize: 10,
                pageNo: 1,
                groups: [],
                depTreeDict: [],
                depTree: [],
                depCode: {
                    value: 'name',
                    label: "label",
                    children: "children"
                },
                myTodoTaskTableData: {
                    total: 0,
                    data: [],
                },
                currentUser: {}
            }
        },
        computed: {
            pageOption() {
                return {
                    pageNo: this.pageNo,
                    pageSize: this.pageSize,
                    total: this.myTodoTaskTableData.total || 0,
                }
            }
        },
        created() {
            this.initGroup();
            this.initDepTree();
            this.refreshMyTodoTable();
        },
        methods: {
            initGroup() {
                pagedGroups({
                    "groupType": 2,
                    "type": "2",
                    "limit": 0
                }).then((res) => {
                    if (res && res.hasOwnProperty("status") && res.status == 200) {
                        this.groups = res.data.rows;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取部门列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门列表错误'
                    });
                });
            },
            initDepTree() {
                fetchTree({
                    "groupType": 2
                }).then((res) => {
                    this.depTree = res[0].children;
                    this.depTreeDict = res;
                    this.getValue(this.depTree);
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取部门树错误'
                    });
                })
            },
            getValue(depTree) {
                for (let i in depTree) {
                    if (depTree[i].children) {
                        this.getValue(depTree[i].children);
                    }
                    depTree[i].value = depTree[i].name;
                }
            },
            //刷新代办任务表格
            refreshMyTodoTable() {
                const _self = this;
                this.currentUser = this.getCurrentUser();

                async function main() {
                    try {
                        const assignedParams = {
                            assignee: _self.currentUser.username
                        };

                        let assignedRes = await getProcessTask(assignedParams);

                        const candidateUserParams = {
                            withCandidateUsers: true,
                            candidateUser: _self.currentUser.username
                        };
                        let candidateUserRes = await getProcessTask(candidateUserParams);

                        let tempTaskRes = assignedRes.concat(candidateUserRes);
                        let flowInstanceIds = tempTaskRes.map((temp, index) => "'" + temp.processInstanceId + "'");

                        let where = '';
                        if (_self.taskNumber != '') {
                            where = where + ' and flow_business_key =' + "'" + _self.taskNumber + "'";
                        }
                        if (_self.person  != '') {
                            where = where + ' and flow_proposer_name like ' + "'%" + _self.person + "%'";
                        }
                        if (_self.contant  != '') {
                            where = where + ' and flow_proposer_content like ' + "'%" + _self.contant + "%'";
                        }
                        if (_self.taskUserNo  != '') {
                            where = where + ' and flow_proposer_code =' + "'" + _self.taskUserNo + "'";
                        }
                        if (_self.group  != '') {
                            where = where + ' and flow_proposer_org_code like' + "'%" + _self.group[_self.group.length - 1] + "%'";
                        }
                        if (_self.timeRange && _self.timeRange.length > 0) {
                            where = where + " and flow_start_time between '" + new Date(_self.timeRange[0]).getTime() + "' and '" + new Date(_self.timeRange[1]).getTime() + "'";
                        }
                        if (_self.curnode  != '') {
                            where = where + ' and flow_task_name like' + "'%" + _self.curnode + "%'";
                        }
                        const processApplyInfoParams = {
                            "flowInstanceIds": flowInstanceIds.join() || "''",
                            "where": where,
                            "PageStart": (`${_self.pageNo}` - 1) * `${_self.pageSize}`,
                            "PageSize": `${_self.pageSize}`
                        }
                        let processApplyInfoRes = await queryProcessApplyInfo(processApplyInfoParams);

                        if (processApplyInfoRes && processApplyInfoRes.hasOwnProperty("data") && processApplyInfoRes.data.hasOwnProperty("data")) {
                            _self.myTodoTaskTableData = processApplyInfoRes.data;
                        } else {
                            _self.myTodoTaskTableData = {
                                total: 0,
                                data: []
                            }
                        }
                    } catch (e) {
                        _self.$notify.error({
                            title: '错误',
                            message: '查询流程待审批记录错误'
                        });
                    }
                };
                main();
            },
            //条件查询代办任务表格
            searchMyTodoTable() {
                this.pageNo = 1;
                this.refreshMyTodoTable();
            },
            //代办任务表格翻页
            pageChange(val) {
                this.pageNo = val;
                this.refreshMyTodoTable();
            },
            //去执行处理
            doApproval(val) {
                if (val.process_definition_key == 'P12345678') {
                    this.$router.push({
                        path: '/soc/task-center/approve-loophole-record-process',
                        query: {
                            flow_instance_id: val.flow_instance_id,
                            taskId: val.flow_task_id,
                            type: val.process_definition_key
                        }
                    });
                } else if (val.process_definition_key == 'leak_record') {
                    this.$router.push({
                        path: '/soc/task-center/leak-record-process',
                        query:{
                            flow_instance_id:val.flow_instance_id,
                            type:val.process_definition_key,
                            taskId:val.flow_task_id,
                            flow_business_key: val.flow_business_key
                        }
                    });
                } else if (val.process_definition_key == 'cancel_record') {
                    this.$router.push({
                        path: '/soc/task-center/cancle-record-process',
                        query: {
                            flow_instance_id: val.flow_instance_id,
                            taskId: val.flow_task_id,
                            type: val.process_definition_key
                        }
                    });
                }
                else {
                    this.$router.push({
                        path: '/secret/user/myTask/approvalTask',
                        query: {
                            processKey: val.processKey,
                            taskId: val.taskId,
                            activityId: val.taskDefinitionKey,
                            nodeName: val.nodeName,
                            processName: val.processName
                        }
                    });
                }
            }
        },
    }
</script>
<style scoped>
    .header {
        padding-left: 25px;
        background: #fff;
        overflow: hidden;
    }

    .headerIco {
        float: left;
        width: 0px;
        height: 18px;
        border: 3px solid #004ea2;
        margin: 13px 0px;
        margin-right: 5px;
    }

    .headerContent {
        float: left;
        font-size: 14px;
        line-height: 14px;
        font-weight: bold;
        color: #333;
        padding: 15px 0px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchFormItem {
        float: left;
        margin-right: 70px;
        margin-top: 5px;
    }

    .searchFormItemLabel {
        float: left;
        line-height: 30px;
    }

    .searchFormItemInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        height: 536px;
    }

    .searchCascader {
        width: 150px;
        height: 30px;
    }

    .el-range-editor.el-input__inner {
        padding: 0px 10px !important;
    }
</style>
