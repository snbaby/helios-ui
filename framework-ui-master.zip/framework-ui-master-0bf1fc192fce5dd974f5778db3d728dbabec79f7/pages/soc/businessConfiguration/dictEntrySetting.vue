<template>
    <div class="framework-content">
        <div class="framework-message">
            <span class="message">当前配置的数据字典分类为：{{configObject.dictEntryName}}（编码：{{configObject.dictEntryCode}}）</span>
            <el-button @click="$router.back(-1)">返 回</el-button>
        </div>
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="条目编码：">
                    <el-input v-model="searchcode" clearable></el-input>
                </el-form-item>
                <el-form-item label="条目名称：">
                    <el-input v-model="searchname" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="doSearch" type="primary">查询</el-button>
                    <el-button @click="add" class="cancel">添加</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="menuPersonData.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="dictItemCode"
                    label="条目编码"
                >
                </el-table-column>
                <el-table-column
                    prop="dictItemName"
                    label="条目名称"
                >
                </el-table-column>
                <el-table-column
                    prop="dictItemOrder"
                    label="条目序号">
                </el-table-column>
                <el-table-column
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="edit(scope.row)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            @click.native.prevent="remove(scope.row)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>

        <el-dialog title="字典条目配置" :visible.sync="dialog">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm">
                <el-form-item label="条目编码" prop="dictItemCode">
                    <el-input v-model="ruleForm.dictItemCode"></el-input>
                </el-form-item>
                <el-form-item label="条目名称" prop="dictItemName">
                    <el-input v-model="ruleForm.dictItemName"></el-input>
                </el-form-item>
                <el-form-item label="条目序号" prop="dictItemOrder">
                    <el-input v-model="ruleForm.dictItemOrder"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import {
        getItemTableData,
        addItem,
        editItem,
        deleteItem,
        getDataById
    } from "@/api/configuration/dictEntrySetting/index.js"

    export default {
        components: {
            pagination,
            tree,
            pagination,
        },
        data() {
            return {
                pageNo: 1,
                dialog: false,
                searchcode: "",
                searchname: "",
                menuList: [],
                menuPersonData: {},
                ruleForm: {
                    dictItemCode: "",
                    dictItemName: "",
                    dictItemOrder: "",
                    dictEntryId: this.$route.query.id,
                },
                rules: {
                    dictItemCode: [{
                        required: true,
                        message: '请输入编码',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入编码',
                        trigger: 'blur'
                    }],
                    dictItemName: [{
                        required: true,
                        message: '请输入名称',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入名称',
                        trigger: 'blur'
                    }],
                    dictItemOrder: [{
                        required: true,
                        message: '请输入序号',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入序号',
                        trigger: 'blur'
                    }]
                },
                entryAllForSelect: [],
                configObject: {}
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
            init() {
                getDataById(this.$route.query.id).then((data) => {
                    this.configObject = data.data;

                    var query = {
                        page: this.pageNo,
                        limit: 10,
                        dictEntryId: this.$route.query.id
                    }
                    if (this.searchcode != '') {
                        query.dictItemCode = this.searchcode;
                    }
                    if (this.searchname != '') {
                        query.dictItemName = this.searchname;
                    }
                    getItemTableData(query).then((data) => {
                        this.menuPersonData = data.data;
                    });
                });
            },
            pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
            refreshTableData() {
                var search = {
                    page: this.pageNo,
                    limit: 10,
                    dictEntryId: this.$route.query.id
                }

                if (this.searchcode != '') {
                    query.dictItemCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.dictItemName = this.searchname;
                }

                getItemTableData(search).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            add() {
                this.ruleForm = {
                    dictItemCode: "",
                    dictItemName: "",
                    dictItemOrder: "",
                    dictEntryId: this.$route.query.id
                };
                this.dialog = true;
            },
            edit(item) {
                this.dialog = true;
                this.ruleForm = item;
            },
            remove(id) {
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
                    .then(() => {
                        deleteItem(id).then((data) => {
                            if (data.status == 200) {
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        this.init();
                                    }
                                });
                            } else {
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            doSubmit(formName) {
                var addObj = this.ruleForm;
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.dialog = false;
                        if (addObj.id) {
                            editItem(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        } else {
                            addItem(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        }
                    } else {
                        return false;
                    }
                });
            },
            doSearch() {
                var query = {
                    page: 1,
                    limit: 10,
                    dictEntryId: this.$route.query.id
                }
                if (this.searchcode != '') {
                    query.dictItemCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.dictItemName = this.searchname;
                }

                getItemTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            }
        },
        created() {
            this.init();
        },
    }

</script>


<style lang="css" scoped>
    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .margin {
        height: 35px;
        width: 100%;
        background-color: #f0f0f0;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }
</style>
