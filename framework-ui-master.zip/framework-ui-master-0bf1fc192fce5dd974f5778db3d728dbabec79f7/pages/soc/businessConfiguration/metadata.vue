<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="元数据编码：">
                    <el-input v-model="searchcode" clearable></el-input>
                </el-form-item>
                <el-form-item label="元数据名称：">
                    <el-input v-model="searchname" clearable></el-input>
                </el-form-item>
                <el-form-item label="元数据类型：">
                    <el-select v-model="searchtype" clearable>
                        <el-option v-for="item,index in getCategoryData('metaData')" :key="index" :label="item.label"
                                   :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="doSearch" type="primary">查询</el-button>
                    <el-button @click="add">添加</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="menuPersonData.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="metaCode"
                    label="元数据编码"
                >
                </el-table-column>
                <el-table-column
                    prop="metaName"
                    label="元数据名称"
                >
                </el-table-column>
                <el-table-column
                    label="元数据类型">
                    <template slot-scope="scope">
                        {{getCategoryData('metaData',scope.row.metaDataType)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="metaLength"
                    label="元数据长度">
                </el-table-column>
                <el-table-column
                    label="能否为空">
                    <template slot-scope="scope">
                        {{scope.row.metaIsnull === 0 ? '否' : '是'}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="metaDescribe"
                    label="元数据描述">
                </el-table-column>
                <el-table-column
                    prop="metaSource"
                    label="元数据码表">
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="edit(scope.row)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            @click.native.prevent="remove(scope.row.id)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>

        <el-dialog title="元数据配置" :visible.sync="dialog">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm">
                <el-form-item label="元数据编码" prop="metaCode">
                    <el-input v-model="ruleForm.metaCode"></el-input>
                </el-form-item>
                <el-form-item label="元数据名称" prop="metaName">
                    <el-input v-model="ruleForm.metaName"></el-input>
                </el-form-item>
                <el-form-item label="元数据类型" prop="metaDataType">
                    <el-select v-model="ruleForm.metaDataType">
                        <el-option v-for="item,index in getCategoryData('metaData')" :key="index" :label="item.label"
                                   :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="元数据长度" prop="metaLength">
                    <el-input type="number" v-model="ruleForm.metaLength"></el-input>
                </el-form-item>
                <el-form-item label="能否为空" prop="metaIsnull">
                    <el-radio-group v-model="ruleForm.metaIsnull">
                        <el-radio :label="0">否</el-radio>
                        <el-radio :label="1">是</el-radio>
                    </el-radio-group>
                </el-form-item>
                <el-form-item label="数据字典编码">
                    <el-select v-model="ruleForm.metaSource" clearable filterable>
                        <el-option
                            v-for="item in entryAll"
                            :key="item.dictEntryCode"
                            :label="`${item.dictEntryName} [ ${item.dictEntryCode} ]`"
                            :value="item.dictEntryCode">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="目录描述" prop="metaDescribe">
                    <el-input v-model="ruleForm.metaDescribe"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {getTableData, add, edit, deleteOne, getEntryAll} from "@/api/configuration/metadataSetting/index.js"

    export default {
        components: {
            pagination,
        },
        data() {
            return {
                pageNo: 1,
                dialog: false,
                searchcode: "",
                searchname: "",
                searchtype: "",
                menuPersonData: {},
                ruleForm: {
                    metaCode: "",
                    metaName: "",
                    metaDataType: "",
                    metaLength: "",
                    metaIsnull: 1,
                    metaDescribe: "",
                    metaSource: ""
                },
                rules: {
                    metaCode: [{
                        required: true,
                        message: '请输入编码',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入编码',
                        trigger: 'blur'
                    }],
                    metaName: [{
                        required: true,
                        message: '请输入名称',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入名称',
                        trigger: 'blur'
                    }],
                    metaDataType: [{
                        required: true,
                        message: '请选择类型',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请选择类型',
                        trigger: 'blur'
                    }],
                    metaLength: [{
                        required: true,
                        message: '请输入长度',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入长度',
                        trigger: 'blur'
                    }],
                    metaIsnull: [{
                        required: true,
                        message: '请选择能否为空',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请选择能否为空',
                        trigger: 'blur'
                    }],
                    metaDescribe: [{
                        required: true,
                        message: '请输入描述信息',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入描述信息',
                        trigger: 'blur'
                    }]
                },
                entryAll: []
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
            init() {
                getEntryAll().then((data) => {
                    this.entryAll = data;
                });

                var query = {
                    page: this.pageNo,
                    limit: 10
                }
                if (this.searchcode != '') {
                    query.metaCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.metaName = this.searchname;
                }
                if (this.searchtype != '') {
                    query.metaDataType = this.searchtype;
                }

                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = {
                    page: this.pageNo,
                    limit: 10
                }

                if (this.searchcode != '') {
                    query.metaCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.metaName = this.searchname;
                }
                if (this.searchtype != '') {
                    query.metaDataType = this.searchtype;
                }

                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            add() {
                this.ruleForm = {
                    metaCode: "",
                    metaName: "",
                    metaDataType: "",
                    metaLength: "",
                    metaIsnull: 1,
                    metaDescribe: "",
                    metaSource: ""
                };
                this.dialog = true;
            },
            edit(item) {
                this.dialog = true;
                this.ruleForm = item;

                var map = {
                    id: item.id,
                    metaCode: item.metaCode,
                    metaName: item.metaName,
                    metaDataType: item.metaDataType,
                    metaIsnull: parseInt(item.metaIsnull),
                    metaLength: item.metaLength,
                    metaDescribe: item.metaDescribe,
                    metaSource: item.metaSource.toString()
                }
                this.ruleForm = map;
            },
            remove(id) {
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
                    .then(() => {
                        deleteOne(id).then((data) => {
                            if (data.status == 200) {
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        this.init();
                                    }
                                });
                            } else {
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            doSubmit(formName) {
                var addObj = this.ruleForm;
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.dialog = false;
                        if (addObj.id) {
                            edit(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        } else {
                            add(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        }
                    } else {
                        return false;
                    }
                });
            },
            doSearch() {
                var query = {
                    page: 1,
                    limit: 10
                }
                if (this.searchcode != '') {
                    query.metaCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.metaName = this.searchname;
                }
                if (this.searchtype != '') {
                    query.metaDataType = this.searchtype;
                }

                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
        },
        created() {
            this.init();
        },
    }

</script>

