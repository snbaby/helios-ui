<template>
    <div class="framework-content">
        <div class="framework-left">
            <tree :treedata="menuList" :defaultEpandedKeys="defaultEpandedKeys" @getValue='getTableDataByTree'></tree>
        </div>
        <div class="framework-right">
            <div class="framework-search-form">
                <el-form :inline="true">
                    <el-form-item label="目录编码：">
                        <el-input v-model="searchcode" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="目录名称：">
                        <el-input v-model="searchname" clearable></el-input>
                    </el-form-item>

                    <el-form-item>
                        <el-button @click="doSearch" type="primary">查询</el-button>
                        <el-button @click="add">添加</el-button>
                    </el-form-item>
                </el-form>
            </div>
            <div>
                <el-table :data="menuPersonData.rows">
                    <el-table-column
                        type="index"
                        width="50">
                    </el-table-column>
                    <el-table-column
                        prop="kindCode"
                        label="目录编码">
                    </el-table-column>
                    <el-table-column
                        prop="kindName"
                        label="目录名称">
                    </el-table-column>
                    <el-table-column
                        prop="remark"
                        label="目录描述">
                    </el-table-column>
                    <el-table-column
                        prop="address"
                        label="操作">
                        <template slot-scope="scope">
                            <el-button
                                @click.native.prevent="edit(scope.row)"
                                type="text"
                                size="small">
                                编辑
                            </el-button>
                            <el-button
                                @click.native.prevent="remove(scope.row.id)"
                                type="text"
                                size="small">
                                删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
        <el-dialog title="字典目录配置" :visible.sync="dialog">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm">
                <el-form-item label="目录编码" prop="kindCode">
                    <el-input v-model="ruleForm.kindCode"></el-input>
                </el-form-item>
                <el-form-item label="目录名称" prop="kindName">
                    <el-input v-model="ruleForm.kindName"></el-input>
                </el-form-item>
                <el-form-item label="父编码">
                    <el-select v-model="ruleForm.parentCode" clearable filterable :disabled="true">
                        <el-option label="根目录" value="-1"></el-option>
                        <el-option
                            v-for="item in selectAll"
                            :key="item.kindCode"
                            :label="item.kindName"
                            :value="item.kindCode">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="目录类别" prop="kindType">
                    <el-input v-model="ruleForm.kindType" :disabled="ruleForm.kindType!=''"></el-input>
                </el-form-item>
                <el-form-item label="目录描述" prop="remark">
                    <el-input type="textarea" v-model="ruleForm.remark"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import axios from "axios";
    import {
        getDictTree,
        getKindTableData,
        addKind,
        deleteKind,
        editKind,
        getAll
    } from "@/api/configuration/dictDirSetting/index.js"

    export default {
        components: {
            pagination,
            tree,
        },
        data() {
            return {
                pageNo: 1,
                dialog: false,
                searchcode: "",
                searchname: "",
                menuList: [],
                menuPersonData: {},
                ruleForm: {
                    kindCode: "",
                    kindName: "",
                    kindType: "",
                    parentCode: "-1",
                    remark: ""
                },
                rules: {
                    kindCode: [{
                        required: true,
                        message: '请输入编码',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入编码',
                        trigger: 'blur'
                    }],
                    kindName: [{
                        required: true,
                        message: '请输入名称',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入名称',
                        trigger: 'blur'
                    }],
                    remark: [{
                        required: true,
                        message: '请输入描述信息',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入描述信息',
                        trigger: 'blur'
                    }],
                    kindType: [{
                        required: true,
                        message: '请输入目录分类',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入目录分类',
                        trigger: 'blur'
                    }]
                },
                selectAll: [],
                selectTreeObject: {
                    id: "",
                    code: "-1",
                    label: "",
                    type: ""
                },
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
            defaultEpandedKeys: function () {
                var arr = [];
                arr.push(this.selectTreeObject.id);
                return arr;
            }
        },
        methods: {
            init() {
                getDictTree().then((data) => {
                    this.menuList = data.data;
                });

                getAll().then((data) => {
                    this.selectAll = data;
                });

                var query = {
                    page: this.pageNo,
                    limit: 10,
                    parentCode: this.selectTreeObject.code == '-1' ? '' : this.selectTreeObject.code
                }
                if (this.searchcode != '') {
                    query.kindCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.kindName = this.searchname;
                }

                getKindTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            getTableDataByTree(val) {
                this.selectTreeObject = val;

                var query = {
                    page: 1,
                    limit: 10,
                    parentCode: val.code
                }

                getKindTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = {
                    page: this.pageNo,
                    limit: 10,
                    parentCode: this.selectTreeObject.code == '-1' ? '' : this.selectTreeObject.code
                }
                if (this.searchcode != '') {
                    query.kindCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.kindName = this.searchname;
                }
                getKindTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            add() {
                this.ruleForm = {
                    kindCode: "",
                    kindName: "",
                    kindType: this.selectTreeObject.type,
                    parentCode: this.selectTreeObject.code,
                    remark: ""
                };
                this.dialog = true;
            },
            edit(item) {
                this.dialog = true;
                this.ruleForm = item;
            },
            remove(id) {
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
                    .then(() => {
                        deleteKind(id).then((data) => {
                            if (data.status == 200) {
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        this.init();
                                    }
                                });
                            } else {
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            doSubmit(formName) {
                var addObj = this.ruleForm;
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.dialog = false;
                        if (addObj.id) {
                            editKind(addObj).then((data) => {
                                if (data.status == 200) {
                                    this.$notify.success({
                                        title: '成功',
                                        message: '编辑目录成功'
                                    });
                                    this.init();
                                    this.$refs[formName].resetFields();
                                } else {
                                    this.$notify.error({
                                        title: '错误',
                                        message: data.message
                                    });
                                }
                            });
                        } else {
                            addKind(addObj).then((data) => {
                                if (data.status == 200) {
                                    this.$notify.success({
                                        title: '成功',
                                        message: '添加目录成功'
                                    });
                                    this.init();
                                    this.$refs[formName].resetFields();
                                } else {
                                    this.$notify.error({
                                        title: '错误',
                                        message: data.message
                                    });
                                }
                            });
                        }
                    } else {
                        return false;
                    }
                });
            },
            doSearch() {
                var query = {
                    page: 1,
                    limit: 10
                }
                this.selectTreeObject.code = '-1';
                if (this.searchcode != '') {
                    query.kindCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.kindName = this.searchname;
                }

                getKindTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            }
        },
        created() {
            this.init();
        }
    }

</script>
