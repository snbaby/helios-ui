<template>
    <div class="framework-content">
        <div class="framework-message">
            <span class="message">当前配置的指标为：{{configObject.categoryName}}（编码：{{configObject.categoryCode}}）</span>
            <el-button @click="$router.back('/soc/business-configuration/events/norm-setting')">返 回</el-button>
        </div>
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item>
                    <el-button @click="add">添加</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="menuPersonData.rows">
                <el-table-column type="index" width="50"></el-table-column>
                <el-table-column prop="sourceCode" label="编码"></el-table-column>
                <el-table-column prop="sourceName" label="名称"></el-table-column>
                <el-table-column label="类型">
                    <template slot-scope="scope">
                        {{getCategoryData('sourceType',scope.row.sourceType)}}
                    </template>
                </el-table-column>
                <el-table-column prop="beforeSourceCode" label="前置编码"></el-table-column>
                <el-table-column label="模型编码">
                    <template slot-scope="scope">
                        {{scope.row.moudleCode.split(',').pop()}}
                    </template>
                </el-table-column>
                <el-table-column label="分析规则">
                    <template slot-scope="scope">
                        {{getRuleName(scope.row.rules)}}
                    </template>
                </el-table-column>
                <el-table-column
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="edit(scope.row)"
                            type="text"
                            size="small">
                            编辑
                        </el-button>
                        <el-button
                            @click.native.prevent="isedit(scope.row)"
                            type="text"
                            size="small">
                            备案
                        </el-button>
                        <el-button
                            @click.native.prevent="remove(scope.row.id)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>

        <el-dialog title="规则配置" :visible.sync="dialog">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm">
                <el-form-item label="编码" prop="sourceCode">
                    <el-input v-model="ruleForm.sourceCode"></el-input>
                </el-form-item>
                <el-form-item label="名称" prop="sourceName">
                    <el-input v-model="ruleForm.sourceName"></el-input>
                </el-form-item>
                <el-form-item label="类型">
                    <el-select v-model="ruleForm.sourceType" clearable filterable>
                        <el-option v-for="item,index in getCategoryData('sourceType')" :key="index" :label="item.label"
                                   :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="前置编码">
                    <el-autocomplete
                        v-model="ruleForm.beforeSourceCode"
                        :fetch-suggestions="querySearchAsync"
                        @select="handleSelect"
                        clearable
                    ></el-autocomplete>
                </el-form-item>
                <el-form-item label="模型编码" prop="moudleCode">
                    <el-cascader
                        v-model="ruleForm.moudleCode"
                        :options="moduleTree"
                        filterable
                        :props="{value: 'code',children: 'children'}"
                    ></el-cascader>
                </el-form-item>
                <el-form-item label="分析规则">
                    <el-select v-model="ruleForm.rules" clearable filterable>
                        <el-option v-for="item,index in ruleList" :key="index" :label="item.name" :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog title="备案配置" :visible.sync="isdialog">
            <el-form :model="recordForm" :rules="recordDetail" ref="recordFormDetail" label-width="120px">
                <el-form-item label="指标是否重要" prop="recordImportant">
                    <el-select v-model="recordForm.recordImportant" prop="recordImportant" placeholder="请选择..."
                               style="width:100%">
                        <el-option label="是" value="Y"></el-option>
                        <el-option label="否" value="N"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="是否允许备案" prop="isRecord">
                    <el-select v-model="recordForm.isRecord" prop="isRecord" placeholder="请选择..."
                               @change="selsectRecord" style="width:100%">
                        <el-option label="是" value="Y"></el-option>
                        <el-option label="否" value="N"></el-option>
                    </el-select>
                </el-form-item>
                <template v-if="recordForm.isRecord == 'Y'">
                    <el-form-item label="备案指标名称" prop="recordType">
                        <el-input v-model="recordForm.recordType" clearable>
                        </el-input>
                    </el-form-item>
                </template>
                <el-form-item label="备案指标须知" prop="record">
                    <el-input v-model="recordForm.record"
                              :disabled="recordForm.isRecord != 'Y'"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="addReason" size="mini"
                               :disabled="recordForm.isRecord != 'Y'">添加
                    </el-button>
                </el-form-item>
                <el-table :data="recordFormReasonList">
                    <el-table-column type="index" width="50"></el-table-column>
                    <el-table-column prop="sourceCode" label="备案理由">
                        <template slot-scope="scope">
                            <el-input v-model="scope.row.reason" prop="reason"
                                      placeholder="请输入备案申请事由"
                                      :disabled="recordForm.isRecord != 'Y'"></el-input>
                        </template>
                    </el-table-column>

                    <el-table-column
                        label="操作">
                        <template slot-scope="scope">
                            <el-button
                                @click="delReason(index, recordFormReasonList)"
                                type="text"
                                size="small"
                                :disabled="recordForm.isRecord != 'Y'">
                                移除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-form>
            <span slot="footer" class="dialog-footer">
            <el-button @click="cleanRecord">取 消</el-button>
            <el-button type="primary" @click="doOnSubmit('recordFormDetail')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {
        getTableData,
        add,
        edit,
        deleteone,
        getCategoryNode,
        getDataByCode,
        getRuleList,
        getModuleTree,
        getRecord,
        addRecord
    } from "@/api/configuration/safetyEvents/correlationConfig/index.js"

    export default {
        components: {
            pagination,
        },
        data() {
            return {
                styleType: false,
                pageNo: 1,
                dialog: false,
                isdialog: false,
                menuPersonData: {},
                ruleForm: {
                    sourceCode: "",
                    sourceName: "",
                    sourceType: "",
                    beforeSourceCode: "",
                    moudleCode: [],
                    rules: "",
                    categoryCode: ""
                },
                recordForm: {
                    isRecord: '',
                    recordImportant: '',
                    record: '',
                    recordType: ''
                },
                recordFormReasonList: [],
                recordDetail: {
                    recordImportant: [{
                        required: true,
                        message: '请选择是否重要',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请选择是否重要',
                        trigger: 'blur'
                    }],
                    isRecord: [{
                        required: true,
                        message: '请选择是否备案',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请选择是否备案',
                        trigger: 'blur'
                    }],
                    recordType: [{
                        required: true,
                        message: '请输入备案指标名称',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入备案指标名称',
                        trigger: 'blur'
                    }],
                    record: [{
                        required: false,
                        message: '请输入备案指标须知',
                        trigger: 'change'
                    }, {
                        required: false,
                        message: '请输入备案指标须知',
                        trigger: 'blur'
                    }]
                },
                rules: {
                    sourceCode: [{
                        required: true,
                        message: '请输入编码',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入编码',
                        trigger: 'blur'
                    }],
                    sourceName: [{
                        required: true,
                        message: '请输入名称',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入名称',
                        trigger: 'blur'
                    }],
                    moudleCode: [{
                        type: 'array',
                        required: true,
                        message: '请选择模型编码',
                        trigger: 'change'
                    }]
                },
                configObject: "",
                ruleList: "",
                timeout: null,
                restaurants: [],
                moduleTree: [],

                thisEditSource: {}
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            }
        },
        methods: {
            init() {
                getRuleList().then((thisobj) => {
                    this.ruleList = thisobj;
                    var queryobj = {
                        categoryCode: this.$route.query.categoryCode
                    }
                    getDataByCode(queryobj).then((thisobj) => {
                        this.configObject = thisobj.data;

                        var query = {
                            page: this.pageNo,
                            limit: 10,
                            categoryCode: this.configObject.categoryCode
                        }
                        getTableData(query).then((data) => {
                            this.menuPersonData = data.data;

                            var arr = [];
                            for (var i = 0; i < data.data.rows.length; i++) {
                                var map = {
                                    value: data.data.rows[i].sourceName,
                                    sourceCode: data.data.rows[i].sourceCode
                                }
                                arr.push(map);
                            }
                            this.restaurants = arr;
                        });


                    });
                });
            },
            getRuleName(code) {
                if (code == "") {
                    return ""
                } else {
                    for (var i = 0; i < this.ruleList.length; i++) {
                        if (this.ruleList[i].code == code) {
                            return this.ruleList[i].name
                        }
                    }
                    return code
                }
            },
            pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = {
                    page: this.pageNo,
                    limit: 10,
                    categoryCode: this.configObject.categoryCode
                }

                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            add() {
                this.ruleForm = {
                    sourceCode: "",
                    sourceName: "",
                    sourceType: "",
                    beforeSourceCode: "",
                    moudleCode: [],
                    rules: "",
                    categoryCode: this.configObject.categoryCode
                };
                this.dialog = true;
            },
            edit(item) {
                this.ruleForm = {
                    id: item.id,
                    sourceCode: item.sourceCode,
                    sourceName: item.sourceName,
                    sourceType: item.sourceType,
                    beforeSourceCode: item.beforeSourceCode,
                    moudleCode: item.moudleCode.split(','),
                    rules: item.rules,
                    categoryCode: item.categoryCode
                };
                this.dialog = true;
            },
            isedit(item) {
                this.thisEditSource = item;
                this.recordForm = {
                    id: item.id,
                    isRecord: '',
                    recordImportant: '',
                    record: '',
                    recortType: ''
                };
                this.recordFormReasonList = [];
                this.isdialog = true;
                let query = {
                    id: item.id
                }
                getRecord(query).then((data) => {
                    if (data.data.recordItems.length) {
                        this.recordItemChange(data.data.recordItems, query.id);
                    }
                });


            },
            recordItemChange(item, id) {
                this.recordForm.isRecord = item[0].allowRecord;
                this.recordForm.recordImportant = item[0].recordImportant;
                this.recordForm.record = item[0].sourceDescription
                this.recordForm.recordType = item[0].recordType
                let arr = [];
                for (let i in item) {
                    let map = {
                        reason: item[i].recordName
                    };
                    arr.push(map);
                }
                this.recordFormReasonList = arr;
            },
            remove(id) {
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
                    .then(() => {
                        deleteone(id).then((data) => {
                            if (data.status == 200) {
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        this.init();
                                    }
                                });
                            } else {
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            doOnSubmit(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        let query = {
                            id: this.recordForm.id,
                            allowRecord: this.recordForm.isRecord,
                            recordImportant: this.recordForm.recordImportant,
                            sourceDescription: this.recordForm.record,
                            recordType: this.recordForm.recordType,
                            reason: ''
                        }
                        let arr = [];
                        for (let i in this.recordFormReasonList) {
                            if (this.recordFormReasonList[i].reason) {
                                arr.push(this.recordFormReasonList[i].reason);
                            }
                        }
                        query.reason = arr.join(',');
                        addRecord(query).then((data) => {
                            if (data.status == 200 && data.rel) {
                                this.$notify.success({
                                    title: '成功',
                                    message: '备案配置成功'
                                });
                            } else {
                                this.$notify.error({
                                    title: '错误',
                                    message: data.message
                                });
                            }
                        });

                        this.thisEditSource.recordType = this.recordForm.recordType;
                        this.thisEditSource.allowRecord = this.recordForm.isRecord;
                        this.thisEditSource.recordImportant = this.recordForm.recordImportant;

                        edit(this.thisEditSource).then((data) => {

                        });
                        this.cleanRecord();
                    }
                });
            },
            doSubmit(formName) {
                let addObj = this.ruleForm;

                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.ruleForm = {
                            sourceCode: "",
                            sourceName: "",
                            sourceType: "",
                            beforeSourceCode: "",
                            moudleCode: [],
                            rules: "",
                            categoryCode: ""
                        }
                        this.dialog = false;
                        if (addObj.id) {
                            edit(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        } else {
                            add(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        }
                    } else {
                        return false;
                    }
                });
            },
            querySearchAsync(queryString, cb) {
                var restaurants = this.restaurants;

                var results = queryString ? restaurants.filter(this.createStateFilter(queryString)) : restaurants;

                clearTimeout(this.timeout);
                this.timeout = setTimeout(() => {
                    cb(results);
                }, 500 * Math.random());
            },
            createStateFilter(queryString) {
                return (state) => {
                    return (state.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
                };
            },
            handleSelect(item) {
                this.ruleForm.beforeSourceCode = item.sourceCode;
            },
            selsectRecord(val) {
                if (val === "Y") {
                    this.styleType = false;
                } else {
                    this.styleType = true;
                }
            },
            //新增备案原因
            addReason() {
                this.recordFormReasonList.push({
                    reason: ""
                });
            },
            delReason(index, rows) {
                rows.splice(index, 1);
            },
            cleanRecord() {
                this.isdialog = false;
            }
        },
        created() {
            this.init();
            getModuleTree().then((moudle) => {
                this.moduleTree = moudle.data;
            });
            this.selsectRecord();
        },
    }
</script>

