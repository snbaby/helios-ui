<template>
    <kindManageCategory :categoryType="data"></kindManageCategory>
</template>

<script>
    import kindManageCategory from '@/components/configuration/manageObject/kindManageCategory.vue';

    export default {
        components: {
            kindManageCategory
        },
        data() {
            return {
                data:"organization"
			}
        },
    }

</script>
