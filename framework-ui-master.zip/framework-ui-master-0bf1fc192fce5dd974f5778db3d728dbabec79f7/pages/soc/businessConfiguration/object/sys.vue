<template>
    <kindManageCategory :categoryType="data"></kindManageCategory>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import kindManageCategory from '@/components/configuration/manageObject/kindManageCategory.vue';

    export default {
        components: {
            kindManageCategory
        },
        data() {
            return {
                data:"sys"
			}
        },
        computed: {

        },
        methods: {

        },
		watch:{

		},
        created() {

		},
        activated() {

        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

	.searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

	.searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

	.contentTable {
		padding-left: 40px;
		padding-right: 40px;
	}

	.tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

	.demo-ruleForm {
		padding-right: 35px;
	}
</style>
