<template>
    <kindManageCategory :categoryType="data"></kindManageCategory>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import kindManageCategory from '@/components/configuration/manageObject/kindManageCategory.vue';

    export default {
        components: {
            kindManageCategory
        },
        data() {
            return {
                data:"assets"
			}
        },
        computed: {

        },
        methods: {

        },
		watch:{

		},
        created() {

		},
        activated() {

        }
    }

</script>
