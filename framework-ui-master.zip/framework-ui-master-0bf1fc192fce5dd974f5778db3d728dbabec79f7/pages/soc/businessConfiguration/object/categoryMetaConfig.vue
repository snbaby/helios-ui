<template>
    <div class="framework-content">
        <div class="framework-message">
            <span class="message">当前配置的管理对象分类为：{{configObject.categoryName}}（编码：{{configObject.categoryCode}}）</span>
            <el-button @click="$router.back(-1)">返 回</el-button>
        </div>
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item>
                    <el-button @click="add" >添加</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="menuPersonData.rows">
                <el-table-column type="index" width="50"></el-table-column>
                <el-table-column prop="metaCode" label="元数据编码"></el-table-column>
                <el-table-column prop="metaName" label="元数据名称"></el-table-column>
                <el-table-column label="是否非空">
                    <template slot-scope="scope">
                        <el-switch
                            v-model="scope.row.attr3"
                            active-value="1"
                            inactive-value="0"
                            @change="changeRequired(scope.row)">
                        </el-switch>
                    </template>
                </el-table-column>
                <el-table-column label="是否标识">
                    <template slot-scope="scope">
                        <el-switch
                            v-model="scope.row.attr2"
                            active-value="1"
                            inactive-value="0"
                            @change="changeIdentity(scope.row)"
                        >
                        </el-switch>
                    </template>
                </el-table-column>
                <el-table-column label="是否查询">
                    <template slot-scope="scope">
                        <el-switch
                            v-model="scope.row.attr4"
                            active-value="1"
                            inactive-value="0"
                            @change="changeSearch(scope.row)">
                        </el-switch>
                    </template>
                </el-table-column>
                <el-table-column label="是否显示">
                    <template slot-scope="scope">
                        <el-switch
                            v-model="scope.row.attr5"
                            active-value="1"
                            inactive-value="0"
                            @change="changeVisibility(scope.row)">
                        </el-switch>
                    </template>
                </el-table-column>
                <el-table-column label="元数据类型">
                    <template slot-scope="scope">
                        {{getCategoryData('metaData',scope.row.metaDataType)}}
                    </template>
                </el-table-column>
                <el-table-column prop="metaLength" label="元数据长度"></el-table-column>
                <el-table-column prop="metaDescribe" label="元数据描述"></el-table-column>
                <el-table-column prop="metaSource" label="元数据码表"></el-table-column>
                <el-table-column
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="remove(scope.row.attr1)"
                            type="text"
                            size="small">
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
        <el-dialog title="元数据配置" :visible.sync="dialog" >
            <el-transfer
                filterable
                :filter-method="filterMethod"
                filter-placeholder="请输入元数据名称"
                :titles="['未配置', '已配置']"
                v-model="selectMetaArr"
                :data="transferData"
                :props="{
      				key: 'id',
					code:'metaCode',
      				label: 'metaName'
    			}">
                <span slot-scope="{ option }">{{option.metaName}}[{{option.metaCode}}]</span>
            </el-transfer>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {
        getTableData,
        add,
        deleteone,
        getMetaAll,
        getMetaTableData,
        getDataById,
        edit
    } from "@/api/configuration/manageObject/categoryMetaConfig/index.js"

    export default {
        components: {
            pagination,
        },
        data() {
            return {
                pageNo: 1,
                dialog: false,
                menuPersonData: {},
                transferData: [],
                selectMetaArr: [],
                configObject: ""
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            }
        },
        methods: {
            init() {
                getDataById(this.$route.query.id).then((thisObj) => {
                    this.configObject = thisObj.data;
                    getMetaAll().then((data) => {
                        this.transferData = data;
                    });

                    var query = {
                        page: this.pageNo,
                        limit: 10,
                        kindId: this.$route.query.id.toString()
                    }
                    getMetaTableData(query).then((data) => {
                        this.menuPersonData = data.data;
                    });
                });
            },
            pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = {
                    page: this.pageNo,
                    limit: 10,
                    kindId: this.$route.query.id.toString()
                }
                getMetaTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            add() {
                var query = {
                    page: 1,
                    limit: -1,
                    kindId: this.$route.query.id.toString()
                }

                getTableData(query).then((data) => {
                    var arr = [];
                    for (var i = 0; i < data.data.rows.length; i++) {
                        arr.push(parseInt(data.data.rows[i].metaId));
                    }
                    this.selectMetaArr = arr;
                    this.dialog = true;
                });
            },
            remove(id) {
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
                    .then(() => {
                        deleteone(id).then((data) => {
                            if (data.status == 200) {
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        this.init();
                                    }
                                });
                            } else {
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            doSubmit() {
                this.dialog = false;

                var obj = {
                    kindId: this.$route.query.id.toString(),
                    metaids: this.selectMetaArr.toString(),
                    kindType: this.configObject.categoryType
                }

                add(obj).then((data) => {
                    this.init();
                });
            },
            filterMethod(query, item) {
                if (item.metaName.indexOf(query) > -1) {
                    return item.metaName.indexOf(query) > -1;
                }
                if (item.metaCode.indexOf(query) > -1) {
                    return item.metaCode.indexOf(query) > -1;
                }
            },
            changeRequired(row) {
                var obj = {
                    id: row.attr1,
                    required: row.attr3
                }
                edit(obj).then((data) => {
                    this.init();
                });
            },
            changeIdentity(row) {
                var obj = {
                    id: row.attr1,
                    identity: row.attr2
                }
                edit(obj).then((data) => {
                    this.init();
                });
            },
            changeSearch(row) {
                var obj = {
                    id: row.attr1,
                    search: row.attr4
                }
                edit(obj).then((data) => {
                    this.init();
                });
            },
            changeVisibility(row) {
                var obj = {
                    id: row.attr1,
                    visibility: row.attr5
                }
                edit(obj).then((data) => {
                    this.init();
                });
            }
        },
        created() {
            this.init();
        }
    }
</script>
