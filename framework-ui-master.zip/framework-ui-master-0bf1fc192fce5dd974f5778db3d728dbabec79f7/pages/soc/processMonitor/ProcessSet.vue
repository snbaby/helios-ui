<template>
    <div class="framework-content">
        <div class="framework-left">
            <tableTree :data="processDefineResult" :columns="columns" @getValue="showProcessDefineDiagram"></tableTree>
        </div>
        <div class="framework-right">
            <div class="process" v-show="processDefineId!=''">
                <div class="processTitle">{{processDefineName}}</div>
                <div class="processContainer" id="processDefineContainer"></div>
            </div>
            <div class="station" v-show="processDefineTaskId!=''">
                <div class="stationTitle">{{processDefineName + '-' + processDefineTaskName}}</div>
                <div class="stationContainer">
                    <el-transfer
                        v-model="approvalStation"
                        filterable
                        :titles="['岗位', '审批岗位']"
                        @change="handleChange"
                        :data="stationGroups">
                    </el-transfer>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Viewer from 'bpmn-js/lib/NavigatedViewer.js';
    import tableTree from '@/components/common/tableTree.vue';

    const _ = require("underscore");
    import {fetch, json2Param} from '@/core/fetch.js';
    import pagination from '@/components/common/pagination.vue';
    import {searchProceeeDefineList, getProceeeDefine} from '@/api/user/index.js';
    import {getGroupList} from '@/api/admin/group/index.js';
    import {getAuthorityGroupList, postAuthorityObj} from '@/api/admin/element/index.js';

    export default {
        data() {
            return {
                columns: [{
                    label: '流程名称',
                    type: 'name',
                }],
                processDefineResult: [],
                processDefineName: "",
                processDefineKey: "",
                processDefineId: "",
                processDefineTaskName: "",
                processDefineTaskId: "",

                stationGroups: [],

                approvalStation: [],
            }
        },
        components: {
            tableTree,
            pagination,
        },
        created() {
            this.initProcessDefine();
        },
        methods: {
            init() {
            },
            initProcessDefine() {
                const _self = this;
                let query = {
                    latest: true
                };
                searchProceeeDefineList(json2Param(query)).then(res => {
                    _self.processDefineResult = res;
                    console.log(_self.processDefineResult)
                }).catch(err => {
                    _self.$notify.error({
                        title: '错误',
                        message: '获取流程列表错误'
                    });
                    _self.processDefineResult = [];
                });
                let params = {
                    groupType: '2',
                    type: '3'
                };
                getGroupList(params).then(res => {
                    _self.stationGroups = [];
                    _self.stationGroups = _.map(res, item => {
                        return {
                            key: item.code,
                            label: item.name + "(" + _self.getDepNameById(item.parentId) + ")"
                        }
                    });
                }).catch(err => {
                    _self.$notify.error({
                        title: '错误',
                        message: '获取审批列表错误'
                    });
                })
            },
            showProcessDefineDiagram(row) {
                const _self = this;
                _self.processDefineName = "";
                _self.processDefineKey = "";
                _self.processDefineId = "";
                _self.processDefineTaskName = "";
                _self.processDefineTaskId = "";
                getProceeeDefine(row.id).then(res => {
                    _self.processDefineName = row.name;
                    _self.processDefineId = row.id;
                    _self.processDefineKey = row.key;
                    document.getElementById("processDefineContainer").innerHTML = "";
                    let viewer = new Viewer({container: '#processDefineContainer'});
                    viewer.importXML(res.bpmn20Xml, (err) => {
                        document.getElementsByClassName("bjs-container")[0].removeChild(document.getElementsByClassName("bjs-powered-by")[0]);
                        if (err) {
                            this.$notify.error({
                                title: '错误',
                                message: '获取流程错误'
                            });
                            return;
                        }
                        var canvas = viewer.get('canvas');
                        canvas.zoom('fit-viewport');
                        var eventBus = viewer.get('eventBus');
                        var events = [
                            'element.click'
                        ];
                        events.forEach(function (event) {
                            eventBus.on(event, function (e) {
                                _self.approvalStation = [];
                                if (e.element.type == "bpmn:UserTask") {//人工任务
                                    _self.processDefineTaskId = e.element.businessObject.id;
                                    _self.processDefineTaskName = e.element.businessObject.name;
                                    getAuthorityGroupList('bpm', _self.processDefineTaskId + "@" + _self.processDefineKey).then(res => {
                                        if(res && res.hasOwnProperty("status")&&res.status == 200){
                                            _self.approvalStation = _.map(res.data.rows,temp =>{
                                                return temp.authorityId;
                                            })
                                        }else{
                                            this.$notify.error({
                                                title: '错误',
                                                message: '获取流程审批岗位错误'
                                            });
                                        }
                                    }).catch(err => {
                                        this.$notify.error({
                                            title: '错误',
                                            message: '获取流程审批岗位错误'
                                        });
                                    })

                                } else {//其他
                                    _self.processDefineTaskId = "";
                                    _self.processDefineTaskName = "";
                                }
                            });
                        });

                    })
                }).catch(err => {
                    if (err) {
                        this.$notify.error({
                            title: '错误',
                            message: '获取流程错误'
                        });
                        return;
                    }
                    _self.processDefineName = '';
                    _self.processDefineId = '';
                    document.getElementById("processDefineContainer").innerHTML = "";
                })
            },
            handleChange(value, direction, movedKeys) {
                const _self = this;
                postAuthorityObj("group", "bpm", _self.processDefineTaskId + "@" + _self.processDefineKey, _self.approvalStation).then(res => {
                    if (res && res.hasOwnProperty("rel") && res.rel == true) {
                        this.$notify.success({
                            title: '成功',
                            message: '修改审批岗位成功'
                        });
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '修改审批岗位错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '修改审批岗位错误'
                    });
                });
            }
        }
    }
</script>


<style lang="css" scoped>
    .process {
        border: solid 1px #CCC;
        height: 40%;
    }

    .processContainer {
        height: 90%;
    }

    .processTitle {
        height: 10%;
        text-align: center;
    }

    .station {
        border: solid 1px #CCC;
        height: 60%;
    }

    .stationTitle {
        height: 10%;
        text-align: center;
    }

    .stationContainer {
        height: 90%;
        text-align: center;
        width: 100%;
    }
</style>
