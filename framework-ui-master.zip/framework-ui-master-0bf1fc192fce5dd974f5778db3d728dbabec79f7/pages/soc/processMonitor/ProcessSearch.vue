<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="流程名称：">
                    <el-select v-model="processDefineKey" clearable>
                        <el-option
                            v-for="item in processDefineResult"
                            :key="item.key"
                            :label="item.name"
                            :value="item.key">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="流程单号：">
                    <el-input v-model="processCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="发起人：">
                    <el-input v-model="personCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="发起人工号：">
                    <el-input v-model="flowProposerCode" clearable></el-input>
                </el-form-item>

                <el-form-item label="流程状态：">
                    <el-select v-model="flowProposerStatus" clearable>
                        <el-option
                            v-for="item in taskStatusOptions"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="申请内容：">
                    <el-input v-model="flowProposerContent" clearable></el-input>
                </el-form-item>
                <el-form-item label="当前节点：">
                    <el-input v-model="curNode" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="queryProcess" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="processTableData.rows">
                <el-table-column type="index" width="50"></el-table-column>
                <el-table-column prop="flow_business_key" label="流程单号"></el-table-column>
                <el-table-column label="流程名称">
                    <template slot-scope="scope">
                        {{getProcessDefineName(scope.row.process_definition_key)}}
                    </template>
                </el-table-column>
                <el-table-column prop="flow_task_name" label="当前节点"></el-table-column>
                <el-table-column prop="flow_proposer_org_name" label="发起部门"></el-table-column>
                <el-table-column prop="flow_proposer_name" label="发起人"></el-table-column>
                <el-table-column prop="flow_proposer_code" label="发起人工号"></el-table-column>
                <el-table-column label="发起时间">
                    <template slot-scope="scope">
                        {{scope.row.flow_start_time?timestampToTime(scope.row.flow_start_time):''}}
                    </template>
                </el-table-column>
                <el-table-column label="结束时间">
                    <template slot-scope="scope">
                        {{scope.row.flow_end_time?timestampToTime(scope.row.flow_end_time):''}}
                    </template>
                </el-table-column>
                <el-table-column prop="username" label="流程状态">
                    <template slot-scope="scope">
                        {{getCategoryData('flow_status',scope.row.flow_status?scope.row.flow_status:"")}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="viewBpmn(scope.row)"
                            type="text"
                            size="small">
                            查看
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
    </div>
</template>

<script>
    const _ = require("underscore");
    import {fetch, json2Param} from '@/core/fetch.js';
    import pagination from '@/components/common/pagination.vue';
    import {searchProceeeDefineList, queryProcessList} from '@/api/user/index.js';

    export default {
        data() {
            return {
                personCode: "",
                processCode: "",
                flowProposerCode: "",
                flowProposerContent: "",
                curNode: "",
                flowProposerStatus: "",

                processDefineResult: [],
                processDefineKey: "",

                pageNo: 1,
                pageSize: 10,
                taskStatusOptions: [
                    {
                        label: "签收中",
                        value: "SIGNIN"
                    },
                    {
                        label: "审批中",
                        value: "ACTIVE"
                    },
                    {
                        label: "已完成",
                        value: "COMPLETED"
                    }
                ],
                processTableData: {
                    total: 0,
                    pageNo: 1,
                    pageSize: 10,
                    rows: []
                }
            }
        },
        components: {
            pagination
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.pageNo,
                    pageSize: this.pageSize,
                    total: this.processTableData.total
                }
            },
        },
        methods: {
            init() {
                this.queryProceeeDefineList();
                this.queryProcess();
            },
            queryProceeeDefineList() {
                const _self = this;
                let query = {
                    latest: true
                };
                searchProceeeDefineList(json2Param(query)).then(res => {
                    _self.processDefineResult = res;
                }).catch(err => {
                    _self.$notify.error({
                        title: '错误',
                        message: '获取流程列表错误'
                    });
                    _self.processDefineResult = [];
                });
            },
            queryProcess() {
                const _self = this;
                _self.processTableData = {
                    total: 0,
                    pageNo: 1,
                    pageSize: 10,
                    rows: []
                };
                let query = {
                    where: "",
                    PageStart: (_self.pageNo - 1) * _self.pageSize,
                    PageSize: _self.pageSize,
                };

                if (_self.personCode != '') {
                    query.where = "where flow_proposer_name like '*%" + _self.personCode + "%*' ";
                }

                if (_self.processCode != '') {
                    if (query.where.length > 0) {
                        query.where = query.where + " and flow_business_key = '" + _self.processCode + "' ";
                    } else {
                        query.where = "where flow_business_key = '" + _self.processCode + "' ";
                    }
                }

                if (_self.flowProposerCode != '') {
                    if (query.where.length > 0) {
                        query.where = query.where + " and flow_proposer_code = '" + _self.flowProposerCode + "' ";
                    } else {
                        query.where = "where flow_proposer_code = '" + _self.flowProposerCode + "' ";
                    }
                }

                if (_self.flowProposerContent != '') {
                    if (query.where.length > 0) {
                        query.where = query.where + " and flow_proposer_content like '%" + _self.flowProposerContent + "%' ";
                    } else {
                        query.where = "where flow_proposer_content like '%" + _self.flowProposerContent + "%' ";
                    }
                }
                if (_self.flowProposerStatus != '') {
                    if (query.where.length > 0) {
                        query.where = query.where + " and flow_status = '" + _self.flowProposerStatus + "' ";
                    } else {
                        query.where = "where flow_status = '" + _self.flowProposerStatus + "' ";
                    }
                }

                if (_self.processDefineKey.length > 0) {
                    if (query.where.length > 0) {
                        query.where = query.where + " and process_definition_key = '" + _self.processDefineKey + "' ";
                    } else {
                        query.where = "where process_definition_key = '" + _self.processDefineKey + "' ";
                    }
                }
                if (_self.curNode != '') {
                    if (query.where.length > 0) {
                        query.where = query.where + " and flow_task_name like '%" + _self.curNode + "%' ";
                    } else {
                        query.where = "where flow_task_name like '%" + _self.curNode + "%' ";
                    }
                }
                queryProcessList(query).then(res => {
                    if (res.hasOwnProperty("rel") && res.rel == true) {
                        if (res.data.hasOwnProperty("rel") && res.data.rel == true) {
                            _self.processTableData = {
                                total: res.data.total,
                                pageNo: _self.pageNo,
                                pageSize: _self.pageSize,
                                rows: res.data.hasOwnProperty("data") ? res.data.data : []
                            };
                        } else {
                            throw "";
                        }
                    } else if (res.hasOwnProperty("rel") && res.rel == false && res.hasOwnProperty("status") && res.status == 403) {
                        //正常 数据查出来为空
                    } else {
                        throw "";
                    }
                }).catch(err => {
                    _self.$notify.error({
                        title: '错误',
                        message: '获取流程列表错误'
                    });
                });

            },
            getProcessDefineName(processDefineKey) {
                const _self = this;
                let result = "";
                _.each(_self.processDefineResult, temp => {
                    if (temp.key == processDefineKey) {
                        result = temp.name;
                    }
                })
                return result;
            },
            viewBpmn(val) {
                this.$router.push({
                    path: '/soc/task-center/view-bpmn',
                    query:{
                        processDefinitionkey:val.process_definition_key,
                        flowInstanceId:val.flow_instance_id,
                        // random: new Date().getTime()
                    }
                })

            },
            pageChange(val) {
                this.pageNo = val;
                this.queryProcess();
            }
        },
        created() {
            this.init();
        }
    }
</script>
