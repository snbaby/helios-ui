<template>
    <div class="framework-content">
        <div class="framework-left">
            <tableTree :data="roleList.rows" :columns="columns" @getValue="getRoleAuthorization"></tableTree>
        </div>
        <div class="framework-right">
            <el-row class="sd-bts-line" v-if="roleCode">
                <el-col :span="24" v-for="item,index in activeRoleAuthorization" :key="index" class="sd-bbs-line">
                    <el-checkbox v-model="item.spread" @change="setRoleAuthorization($event,item.id)">
                        {{item.title}}
                    </el-checkbox>
                    <template v-if="item.children">
                        <el-row class="sd-pl">
                            <el-col :span="24" v-for="item1,index in item.children" :key="index">
                                <el-checkbox v-model="item1.spread" @change="setRoleAuthorization($event,item1.id)">
                                    {{item1.title}}
                                </el-checkbox>
                                <el-row class="sd-pl">
                                    <el-col :span="6" v-for="item2,index in item1.children" :key="index">
                                        <el-checkbox v-model="item2.spread" @change="setRoleAuthorization($event,item2.id)">
                                            {{item2.title}}
                                        </el-checkbox>
                                    </el-col>
                                </el-row>
                            </el-col>
                        </el-row>
                    </template>
                    <template v-else>
                        <el-row class="sd-pl">
                            <el-col :span="6" v-for="item1,index in item.childs" :key="index">
                                <el-checkbox v-model="item1.spread">
                                    {{item1.name}}
                                </el-checkbox>
                            </el-col>
                        </el-row>
                    </template>
                </el-col>
            </el-row>
            <div v-else class="sd-ta-center">
                <div>暂无数据</div>
            </div>
        </div>
    </div>
</template>

<script>
    import tableTree from '@/components/common/tableTree.vue';
    import {
        getObjMeetConditionsIds
    } from '@/api/common/util.js';

    import {
        fetch,
        json2Param
    } from '@/core/fetch.js';


    export default {
        name: 'RoleSet',
        components: {
            tableTree,
        },
        data() {
            return {
                searchRoleVal: "",
                roleCode: "", //角色编码
                roleList: [],
                activeRoleAuthorization: [],
                columns: [{
                    label: '角色编码',
                    type: 'code',
                }, {
                    label: '角色名称',
                    type: 'name',
                }],
            }
        },
        computed: {},
        created() {
            this.searchRole();
        },
        methods: {
            //查询角色
            searchRole() {
                let search = "";
                if (this.searchRoleVal) {
                    search = '&name=' + this.searchRoleVal;
                    search = search + '&!name=like';
                }
                fetch('/api/admin/group/fetch?type=4' + search, {
                    method: "get",
                    responseType: "json"
                }).then(data => {
                    if (data && data.hasOwnProperty('status') && data.status == 200) {
                        this.roleList = data.data;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取角色列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取角色列表错误'
                    });
                });
            },
            //获得角色授权
            getRoleAuthorization(val) {
                this.roleCode = val.id;
                let url = `/api/admin/menu/tree?appCode=soc&authorityType=group&authorityId=${this.roleCode}`;
                fetch(url, {
                    method: "get",
                    responseType: "json"
                }).then(data => {
                    this.activeRoleAuthorization = data;
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取菜单列表错误'
                    });
                    this.$notify({
                        title: '成功',
                        message: '获取菜单列表成功',
                        type: 'success'
                    });
                });
            },
            //修改当前角色授权
            setRoleAuthorization(e, id) {
                let ids = getObjMeetConditionsIds(this.activeRoleAuthorization, 'spread', 'id').join();
                fetch({
                    url: `/api/admin/group/${this.roleCode}/authority/menu`,
                    data: json2Param({
                        id: this.roleCode,
                        appCode: 'soc',
                        menuTrees: ids,
                        authorityType: 'group'
                    }),
                    method: "post"
                }).then((res) => {
                    if (res && res.hasOwnProperty("status") && res.status == 200) {
                        this.$notify({
                            title: '成功',
                            message: '菜单添加成功',
                            type: 'success'
                        });
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '菜单添加失败'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '菜单添加失败'
                    });
                })
            },
        },
    };

</script>
