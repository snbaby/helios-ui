<template>
    <div id="officeSetting">
        <el-row>
            <el-col :span="6" v-for="item,index in processOfficeTableData" :key="index">
                <div class="officeContent" v-bind:class="item.isSelected ? 'active' : ''"
                     @click="getOfficePerson(item,index)">
                    <el-row>
                        <el-col :span="16">
                            <el-row >
                                <span class="officeName">{{item.officeName}}</span>
                            </el-row>
                            <el-row>
                                <font class="officeCode">编号：{{item.officeCode}}</font>
                            </el-row>
                        </el-col>
                        <el-col :span="8" style="text-align: right;">
                            <font class="personNumber">{{item.personNumber}}</font>
                            <font>人</font>
                        </el-col>
                    </el-row>
                </div>
            </el-col>
        </el-row>
        <el-row v-if="showTable">
            <el-transfer
                style="text-align:left;width: 100%"
                filterable
                :titles="['待选', '已选']"
                @change="handleChange"
                v-model="chooseID"
                :data="data2">
            </el-transfer>
        </el-row>
    </div>
</template>

<script>
    import {
        countApproveUser,
        getApproveUser
    } from '@/api/user/init/index.js';
    import {
        getUserWithSelectPage
    } from '@/api/common/index.js';
    import {
        deleteGroupByUserIdAndGroupId,
        addGroupMember
    } from '@/api/admin/group/index.js';

    export default {
        data() {
            return {
                processOfficeTableData: [],
                approveOfficeSelectedId: "",
                approveUserTableData: {
                    total: 0,
                    pageNo: 1,
                    rows: []
                },
                showTable: false,
                chooseID: [],
                data2: [],
                showUserPage: false,

                searchForm: {
                    userCode: "",
                    userCodeChecked: false,
                    userName: "",
                    userNameChecked: false,
                    depCode: [],
                    depCodeChecked: false,
                    status: "",
                    statusChecked: false,
                },
                userTableData: {
                    total: 0,
                    pageNo: 1,
                    pageSize: 10,
                    rows: []
                },
                props: {
                    value: 'code',
                },
                isSelectPerson: [],
                isSelectPersonUserName: [],
                depTree: [],
            }
        },
        created() {
            this.init();
            this.userSearch();
        },
        methods: {
            init() {
                countApproveUser().then((res) => {
                    this.processOfficeTableData = res;
                    for (var i in this.processOfficeTableData) {
                        if (this.processOfficeTableData[i].id == this.approveOfficeSelectedId) {
                            this.processOfficeTableData[i].isSelected = true;
                        } else {
                            this.processOfficeTableData[i].isSelected = false;
                        }
                    }
                })
                    .catch((err) => {
                        this.$notify.error({
                            title: '错误',
                            message: '获取审批岗位错误'
                        });
                    });
            },
            handleChange(value, direction, movedKeys) {
                if (direction == "right") {
                    this.userAdd(movedKeys);
                } else if (direction == "left") {
                    for (let i in movedKeys) {
                        this.remove(movedKeys[i]);
                    }
                }
            },
            getOfficePerson(item, index) {
                this.chooseID = [];
                this.showTable = true;
                for (var i = 0; i < this.processOfficeTableData.length; i++) {
                    this.processOfficeTableData[i].isSelected = false;
                    if (i == index) {
                        var temp = this.processOfficeTableData[i];
                        temp.isSelected = true;
                        this.$set(this.processOfficeTableData, index, temp);
                    }
                }
                this.approveOfficeSelectedId = item.id;
                getApproveUser(this.approveOfficeSelectedId).then((res1) => {
                    this.approveUserTableData = res1.data;
                    for (var i in this.approveUserTableData.rows) {
                        this.chooseID.push(this.approveUserTableData.rows[i].id);
                    }
                }).catch((err) => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取审批岗位人员列表错误'
                    });
                });
            },
            remove(personid) {
                let params = {
                    "userId": personid,
                    "groupId": this.approveOfficeSelectedId
                }
                deleteGroupByUserIdAndGroupId(params).then((res) => {
                    if (res.status == '200') {
                        this.init();
                        this.$notify.success({
                            title: '成功',
                            message: '删除审批人员成功'
                        });
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: res.message
                        });
                    }
                }).catch((err) => {
                    this.init();
                    this.$notify.error({
                        title: '错误',
                        message: '删除该审批人员错误'
                    });
                });
            },
            userSearch() {
                var querydata = {
                    page: 1,
                    limit: -1,
                };
                getUserWithSelectPage(querydata).then((res) => {
                    for (let i in res.data.rows) {
                        this.data2.push({
                            key: res.data.rows[i].id,
                            label: res.data.rows[i].username + '-' + res.data.rows[i].name + '-' + this.getCategoryData('user_type', res.data.rows[i].attr8),
                            disabled: res.data.rows[i].type == 's',
                        })
                    }
                }).catch((err) => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取人员失败'
                    });
                });
            },
            userAdd(isSelectPerson) {
                let params = {
                    userId: isSelectPerson.toString(),
                    groupId: this.approveOfficeSelectedId
                }
                addGroupMember(params).then(res => {
                    if (res.status == 200) {
                        this.$notify.success({
                            title: '成功',
                            message: '修改审批人员成功'
                        });
                        this.showUserPage = false;
                        this.init();
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '修改审批人员错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '修改审批人员错误'
                    });
                })
            },

        }
    }
</script>

<style lang="css" scoped>
    .officeContent {
        padding: 10px;
        border: 1px #666666 solid;
        margin: 5px;
    }

    .active {
        background-color: #004ea2;
        color: white;
    }

    .officeName {
        font-size: 18px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .officeCode {
        font-size: 14px;
    }

    .personNumber {
        font-size: 30px;
    }

    span {
        word-break: normal;
        width: auto;
        display: block;
        white-space: pre-wrap;
        word-wrap: break-word;
        overflow: hidden;
    }
</style>

<style lang="css">
    #officeSetting .el-transfer-panel {
        width: calc(50% - 48px);
    }

    #officeSetting .el-transfer-panel__list.is-filterable {
        height: 386px;
    }

    #officeSetting .el-transfer-panel__body {
        height: 431px;
    }
</style>
