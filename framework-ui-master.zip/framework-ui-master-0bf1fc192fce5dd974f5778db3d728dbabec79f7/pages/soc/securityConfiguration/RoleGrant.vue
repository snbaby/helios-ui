<template>
    <div class="framework-content">
        <div class="framework-left">
            <tableTree :data="roleList.rows" :columns="columns" @getValue="getRolePerson"></tableTree>
        </div>
        <div class="framework-right">
            <el-row style="height:100%;" v-if="showData" id="roleAllocate">
                <el-transfer
                    filterable
                    :titles="['待选', '已选']"
                    @change="handleChange"
                    v-model="chooseID"
                    :data="data2">
                </el-transfer>
            </el-row>
        </div>
    </div>
</template>

<script>
    import {
        fetch,
        json2Param
    } from '@/core/fetch.js';
    import tableTree from '@/components/common/tableTree.vue';
    import {
        getUserWithSelectPage
    } from '@/api/common/index.js';

    export default {
        components: {
            tableTree,
        },
        data() {
            return {
                showData: false,
                searchRoleVal: "", //角色查询
                roleList: [],
                personId: "",
                roleCode: "", //角色code
                rolePersonTableData: {
                    pageNo: 1,
                    rows: [],
                    total: 0
                },
                data2: [],
                chooseID: [],
                columns: [{
                    label: '角色编码',
                    type: 'code',
                }, {
                    label: '角色名称',
                    type: 'name',
                }],
            }
        },
        created() {
            this.searchRole();
            this.userSearch();
        },
        methods: {
            handleChange(value, direction, movedKeys) {
                if (direction == "right") {
                    this.addUser(movedKeys);
                } else if (direction == "left") {
                    for (let i in movedKeys) {
                        this.remove(movedKeys[i]);
                    }
                }
            },
            //查询角色
            searchRole() {
                let search = "";
                if (this.searchRoleVal) {
                    search = '&name=' + this.searchRoleVal;
                    search = search + '&!name=like';
                }
                fetch('/api/admin/group/fetch?type=4' + search, {
                    method: "get",
                    responseType: "json"
                }).then(data => {
                    if (data && data.hasOwnProperty('status') && data.status == 200) {
                        this.roleList = data.data;
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取角色列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取角色列表错误'
                    });
                });
            },
            //刷新人员表格
            refreshRolePerson() {
                var str = `page=0&limit=0`;
                this.chooseID = [];
                this.showData = true;
                fetch(
                    `/api/admin/group/${this.roleCode}/user/page?` + str, {
                        responseType: "json",
                        method: "get"
                    }
                ).then(data => {
                    if (data && data.hasOwnProperty('status') && data.status == 200) {
                        for (let i in data.data.rows) {
                            this.chooseID.push(data.data.rows[i].id);
                        }
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取人员列表错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取人员列表错误'
                    });
                });
            },
            //获得角色id,查询角色对应人员
            getRolePerson(val) {
                this.roleCode = val.id;
                this.refreshRolePerson();
            },
            //删除当前角色人员
            remove(id) {
                this.personId = id;
                fetch(`/api/admin/group/deleteGroupByUserIdAndGroupId?userId=${this.personId}&groupId=${this.roleCode}`, {
                    method: "get",
                    responseType: "json"
                }).then((res) => {
                    if (res && res.hasOwnProperty('status') && res.status == 200) {
                        this.$notify.success({
                            title: '成功',
                            message: '删除该人员成功'
                        });
                    } else {
                        this.$notify.error({
                            title: '错误',
                            message: res.message ? res.message : '删除该人员错误'
                        });
                        this.refreshRolePerson();
                    }

                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '删除该人员错误'
                    });
                })
            },
            //添加角色分配人员
            addUser(codes) {
                let search = {
                    groupId: this.roleCode,
                    userId: codes.toString()
                }
                fetch({
                    url: '/api/admin/group/user/addGroup',
                    data: json2Param(search),
                    method: 'post'
                }).then((res) => {
                    this.$notify.success({
                        title: '成功',
                        message: '添加人员成功'
                    });
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '添加人员失败'
                    });
                    //刷新
                    this.refreshRolePerson();
                })
            },

            userSearch() {
                var querydata = {
                    page: 1,
                    limit: -1,
                };
                getUserWithSelectPage(querydata).then((res) => {
                    for (let i in res.data.rows) {
                        this.data2.push({
                            key: res.data.rows[i].id,
                            label: res.data.rows[i].username + '-' + res.data.rows[i].name + '-' + this.getCategoryData('user_type', res.data.rows[i].attr8),
                            disabled: res.data.rows[i].type == 's',
                        })
                    }
                }).catch((err) => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取人员失败'
                    });
                });
            },
        },
    }
</script>

<style lang="css">
    #roleAllocate .el-transfer-panel {
        width: calc(50% - 48px);
    }

    #roleAllocate .el-transfer-panel__list.is-filterable {
        height: 386px;
    }

    #roleAllocate .el-transfer-panel__body {
        height: 431px;
    }
</style>
