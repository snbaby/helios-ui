<template>
    <router-view></router-view>
</template>

<script>
function setState(store) {}

export default {
    name: 'TerminalSecurity',
};
</script>
