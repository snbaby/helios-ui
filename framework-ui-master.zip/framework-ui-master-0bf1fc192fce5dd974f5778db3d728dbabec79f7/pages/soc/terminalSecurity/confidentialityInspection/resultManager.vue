<template>
    <div class="framework-content">
        <div class="echartsContent">
            <safetyCheckEcharts :safety-check-data="processMonitorData" v-if="processMonitorData.isfinished" @clickEvent="doSearch"></safetyCheckEcharts>
        </div>
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="统一编号：">
                    <el-input v-model="searchassetcode" clearable></el-input>
                </el-form-item>
                <el-form-item label="责任人：">
                    <el-input v-model="searchassetdutyname" clearable></el-input>
                </el-form-item>
                <el-form-item label="IP地址：">
                    <el-input v-model="searchassetip" clearable></el-input>
                </el-form-item>
                <el-form-item label="部门：">
                    <el-cascader placeholder="" v-model="group"
                                 :options="depTreeDict"
                                 :props="depCode" :show-all-levels="false" filterable clearable change-on-select>
                    </el-cascader>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="doSearch" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="menuPersonData.data">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="org_name"
                    label="责任单位"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_code"
                    label="统一编号"
                    min-width="80"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_duty_name"
                    label="责任人"
                    min-width="80"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_secret"
                    label="密级"
                    min-width="60"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_secret',scope.row.asset_secret)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_network"
                    label="联网类别"
                    min-width="80"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_network',scope.row.asset_network)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    label="IP地址"
                    min-width="110"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_os"
                    label="操作系统"
                    min-width="100"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="用途"
                    min-width="80"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_useage',scope.row.asset_useage)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_area"
                    label="安装位置"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_status"
                    label="设备状态"
                    min-width="80"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_status',scope.row.asset_status)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="check_time"
                    label="检查时间"
                    min-width="140"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{timestampToTimes(scope.row.update_time)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop=""
                    label="检查结果"
                    show-overflow-tooltip
                    min-width="130">
                    <template slot-scope="scope">
                        <div style="display: -webkit-inline-box">
                            <div class="checkResult" title="人工检测" :style="getCheckResultColor(scope.row.manualCheckCheckStatus)">{{scope.row.manualCheckResult?scope.row.manualCheckResult:0}}</div>
                            <div class="checkResult" title="主机配置" :style="getCheckResultColor(scope.row.hostConfigCheckStatus)">{{scope.row.hostConfigResult?scope.row.hostConfigResult:0}}</div>
                            <div class="checkResult" title="安全防护" :style="getCheckResultColor(scope.row.hostProtectCheckStatus)">{{scope.row.hostProtectResult?scope.row.hostProtectResult:0}}</div>
                        </div>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    min-width="80"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="toDetail(scope.row.asset_code)"
                            type="text"
                            size="small">
                            查看
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
    </div>
</template>
<script>
    import {mapState} from 'vuex';
    import pagination from '@/components/common/pagination.vue';
    import safetyCheckEcharts from '@/components/terminalSecurity/confidentialityInspection/safetyCheckEcharts';
    import async1 from "async";
    import {getSboxRunningDetail} from '@/api/sboxMonitor/indexConfig/index.js';
    export default {
        data(){
            return {
                pageNo:0,
                refresh:true,
                searchassetcode:"",
                searchassetcodeChecked:false,
                searchassetip:"",
                searchassetipChecked:false,
                searchassetdutycode:"",
                groupChecked:false,
                group:[],//部门
                searchassetdutycodeChecked:false,
                searchassetdutyname:"",
                searchassetdutynameChecked:false,
                menuList:[],
                menuPersonData:{
                    pageNo:0,
                    pageSize:15,
                    total:133,
                    rows:[]
                },
                processMonitorData:{
                    normTotal:0,
                    total:0,
                    compliance:0,
                    nocompliance:0,
                    matched:0,
                    nomatched:0,
                    data:[[0],[0],[0],[0]],
                    isfinished:false
                },
                groups:[],
                depCode: {
                    value: 'name',
                    label: "label",
                    children:"children"
                },
                currentUser:{},
                depTreeDict:[]
            }
        },
        components: {
            pagination,
            safetyCheckEcharts,
        },
        computed:{
            //当前用户信息
            pageOption: function () {
                return {
                    pageNo: this.pageNo+1,
                    pageSize: 15,
                    total: this.menuPersonData.total
                }
            },
        },
        watch:{
            //发起任务成功，刷信任务跟踪、代办任务
            depTreeDict(val){
            },
        },
        methods: {
            init(){
                var self = this;
                this.getCheckTimeByCode("limit 0,15");
                setTimeout(() => { this.refresh = true; }, 1000);
                this.initProcessMonitorData();
            },
            pageChange(val) {
                this.pageNo = val-1;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = "limit "+this.pageNo*15+",15";
                this.getCheckTimeByCode(query);
            },
            doSearch(status){
                var query = "";
                if(this.searchassetcode){
                    query = query + "and asset_code like '%"+this.searchassetcode+"%' "
                }
                if(this.searchassetip){
                    query = query + "and asset_ip like '%"+this.searchassetip+"%' "
                }
                if(this.searchassetdutyname){
                    query = query + "and asset_duty_name like '%"+this.searchassetdutyname+"%' or asset_duty_code like '%"+this.searchassetdutyname+"%' "
                }
                if(this.group.length>0){
                    query=query+' and org_full_path like'+"'%"+this.group[this.group.length-1]+"%'";
                }
                if(status && !status.type){
                    query=query+' and checkResult ="'+status+'"';
                }
                query = query + " limit 0,15"

                this.getCheckTimeByCode(query);
            },
            formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
            toDetail(asset_code) {
                this.$router.push({
                    path:"/soc/terminal-security/confidentiality-inspection/result-manage-detail",
                    query: {
                        asset_code:asset_code
                    }
                });
            },

            loopholeRecordProcess(asset_code){
                this.$router.push({
                    path:"/secret/user/socParameterManage/loopholeRecordProcess",
                    query: {
                        asset_code:asset_code
                    }
                });
            },

            getCheckTimeByCode(where){
                var self = this;
                var rtnobj = {};
                self.getSqlResultWithQuery('getsecretCheckStandingBook',{where:where}).then((data) => {
                    self.menuPersonData = JSON.parse(JSON.stringify(data.data));
                });
            },
            initProcessMonitorData() {
                var self = this;
                self.getSqlResultWithQuery('getSecretCheckStandingBookCount', {}).then((data) => {
                    var arr = data.data.aggs.checkResult.buckets;
                    self.processMonitorData.total = data.data.total;
                    for(var i in arr){
                        if(arr[i].key == "1"){
                            self.processMonitorData.matched = arr[i].doc_count;
                            self.processMonitorData.data[0]=[arr[i].doc_count]
                        }else if(arr[i].key == "2"){
                            self.processMonitorData.data[1]=[arr[i].doc_count]
                        }else if(arr[i].key == "3"){
                            self.processMonitorData.data[2]=[arr[i].doc_count]
                        }else if(arr[i].key == "0"){
                            self.processMonitorData.data[3]=[arr[i].doc_count]
                        }
                    }
                    self.processMonitorData.isfinished = true;
                });
            },
            getCheckResultColor(checkStatus){
                return checkStatus == "0"?"border-color: #8c939d":checkStatus == "1"?"border-color: #08e69b":checkStatus == "2"?"border-color: #fe0000":"border-color: #ff800a";
            }
        },
        created() {
            var self = this;
            this.refresh = false;
            this.init();
            this.currentUser = this.getCurrentUser();
            this.depTree({
                buildTree: true,
                getPerson: false
            }).then(data => {
                if(data) {
                    self.depTreeDict = data;
                }else{
                    console.log('获取部门树失败');
                }
            });
        },
        activated() {
            this.refresh = false;
            this.init();
        }
    }
</script>

<style scoped>
    .backColor {
        background-color: #f0f0f0;
        width: 100%;
        height: calc(100% - 110px) !important;
        height:100%;
    }

    .contentBox {
        width: 100%;
        height: 100%;
        z-index: 1;
        background-color: #ffffff;
    }

    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
        height: 100%;
    }

    .echartsContent {
        height: 80px;
        position: relative;
        margin-top: -30px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .echartsTitle {
        position: absolute;
        font-size: 15px;
        font-weight: bold;
        left: 5px;
        top: 5px;
    }

    .checkResult {
        width: 26px;
        height: 26px;
        border-radius: 50%;
        border: 2px solid #ffb6c1;
        margin-right: 5px;
        text-align: center;
        color: #333;
        line-height: 2;
        font-size: xx-small;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .searchCascader {
        width: 150px;
        height: 30px;
    }
</style>
