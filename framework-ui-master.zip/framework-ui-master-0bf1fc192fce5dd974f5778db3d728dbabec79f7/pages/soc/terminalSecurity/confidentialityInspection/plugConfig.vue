<template>
    <div class="soc-main">
        <div class="soc-main-content" style="margin: auto;">
            <el-row class="searchForm">
                <el-col :span="16" style="padding-left:30px;">
                    <el-row>
                        <el-col :span="8" >
                            <el-checkbox v-model="searchcodeChecked" class="searchCheckBox">插件编码：</el-checkbox>
                            <el-input v-model="searchcode" placeholder="" class="searchInput" @input="formChange('searchcode')"></el-input>
                        </el-col>
                        <el-col :span="8">
                            <el-checkbox v-model="searchnameChecked" class="searchCheckBox">插件名称：</el-checkbox>
                            <el-input v-model="searchname" placeholder="" class="searchInput" @input="formChange('searchname')"></el-input>
                        </el-col>
                    </el-row>
                </el-col>
                <el-col :span="8">
                    <el-row>
                        <el-col :span="4" style="float:right;" >
                            <el-button class="search" @click='doSearch'>查询</el-button>
                        </el-col>
                        <el-col :span="4"  style="float:right;margin-left:10px;">
                            <el-button class="add" @click="add">添加</el-button>
                        </el-col>
                    </el-row>
                </el-col>
            </el-row>
            <el-row>
                <div class="contentTable">
                    <mu-table :showCheckbox="false">
                        <mu-thead slot="header">
                            <mu-tr>
                                <mu-th tooltip="序号" width="80">序号</mu-th>
                                <mu-th tooltip="插件编码">插件编码</mu-th>
                                <mu-th tooltip="插件名称">插件名称</mu-th>
                                <mu-th tooltip="插件描述">插件描述</mu-th>
                                <mu-th tooltip="运行策略">运行策略</mu-th>
                                <mu-th tooltip="指标分类">指标分类</mu-th>
                                <mu-th tooltip="上传人"  width="80">上传人</mu-th>
                                <mu-th tooltip="上传时间" width="100">上传时间</mu-th>
                                <mu-th tooltip="插件大小" width="100">插件大小</mu-th>
                                <mu-th tooltip="操作" width="160" style="text-align:center !important;">操作</mu-th>
                            </mu-tr>
                        </mu-thead>
                        <mu-tbody v-if="menuPersonData">
                            <mu-tr v-for="item,index in menuPersonData.rows" :key="index">
                                <mu-td width="80" :title="(menuPersonData.pageNo-1)*menuPersonData.pageSize+index+1">
                                    {{(menuPersonData.pageNo-1)*menuPersonData.pageSize+index+1}}</mu-td>
                                <mu-td :title="item.pluginCode">{{item.pluginCode}}</mu-td>
                                <mu-td :title="item.pluginName">{{item.pluginName}}</mu-td>
                                <mu-td :title="item.pluginDetail">{{item.pluginDetail}}</mu-td>
                                <mu-td :title="item.pluginRunningStrategy">{{item.pluginRunningStrategy}}</mu-td>
                                <mu-td :title="getCategoryName(item.indexType)">{{getCategoryName(item.indexType)}}</mu-td>
                                <mu-td :title="item.crtName"  width="80">{{item.crtName}}</mu-td>
                                <mu-td :title="item.crtTime" width="100">{{item.crtTime}}</mu-td>
                                <mu-td :title="item.pluginSize" width="100">{{item.pluginSize}}</mu-td>
                                <mu-td width="160" style="text-align:center !important;">
                                    <button @click="download(item)" class="tableButtonStyle">下载</button>
                                    <button @click="configPlugin(item)" class="tableButtonStyle">编辑</button>
                                    <button @click="remove(item)" class="tableButtonStyle">删除</button>
                                </mu-td>
                            </mu-tr>
                        </mu-tbody>
                    </mu-table>
                </div>
            </el-row>
            <div style="position: relative;bottom: -20px;text-align: center;" v-if="menuPersonData.total">
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
            <div class="norows" v-else style="text-align: center;margin-top:50px;">
                <font>暂无数据</font>
            </div>
        </div>
        <el-dialog title="插件配置" :visible.sync="dialog" width="50%" id="indexConfigDialog">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="120px" class="demo-ruleForm">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="插件编码" prop="pluginCode">
                            <el-input v-model="ruleForm.pluginCode" :readonly="true"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="插件名称" prop="pluginName">
                            <el-input v-model="ruleForm.pluginName"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="插件描述" prop="pluginDetail">
                            <el-input v-model="ruleForm.pluginDetail" type="textarea"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="指标分类">
                            <el-select v-model="ruleForm.indexType" style="width: 100%;" placeholder="" clearable>
                                <el-option
                                    v-for="item in recordList"
                                    :key="item.categoryCode"
                                    :label="item.categoryName"
                                    :value="item.categoryCode">
                                </el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="运行策略" prop="pluginRunningStrategy">
                            <el-input v-model="ruleForm.pluginRunningStrategy"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="插件上传">
                            <el-upload
                                name="plugin"
                                :file-list="fileList"
                                :headers="token"
                                :on-change="fileChange"
                                :on-remove="fileRemove"
                                class="upload-demo"
                                :auto-upload="false"
                                ref="upload"
                                drag
                                action="/api/soc/pluginConfig/upload"
                                multiple
                                :limit="1">
                                <i class="el-icon-upload"></i>
                                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                                <div class="el-upload__tip" slot="tip">只能上传可执行的js脚本</div>
                            </el-upload>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="">测 试</el-button>
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {getRecordType,getTableData,add,deleteone,edit,removeFile,download,getSboxRunningDetail} from '@/api/sboxMonitor/indexConfig/index.js'
    import {
        fileDownload
    } from '@/api/common/index.js';
    export default {
        components: {
            pagination,
        },
        data() {
            return {
                token: {
                    Authorization: sessionStorage.getItem("token")
                },
                idEditFile:false,
                dialog:false,
                pageNo:0,
                where:"",
                dialog:false,
                searchcode:"",
                searchcodeChecked:false,
                searchname:"",
                searchnameChecked:false,
                recordList:[],
                fileList:[],
                ruleForm:{
                    pluginCode:"",
                    pluginName:"",
                    pluginDetail:"",
                    pluginRunningStrategy:"",
                    indexType:"",
                    pluginSize:"",
                    pluginPath:""
                },
                rules:{
                    pluginCode:[{
                        required: true,
                        message: '请输入编码',
                        trigger: 'change'
                    },{
                        required: true,
                        message: '请输入编码',
                        trigger: 'blur'
                    }],
                    pluginName:[{
                        required: true,
                        message: '请输入名称',
                        trigger: 'change'
                    },{
                        required: true,
                        message: '请输入名称',
                        trigger: 'blur'
                    }],
                    pluginDetail:[{
                        required: true,
                        message: '请输入描述',
                        trigger: 'change'
                    },{
                        required: true,
                        message: '请输入描述',
                        trigger: 'blur'
                    }],
                    pluginRunningStrategy:[{
                        required: true,
                        message: '请输入执行策略',
                        trigger: 'change'
                    },{
                        required: true,
                        message: '请输入执行策略',
                        trigger: 'blur'
                    }],
                },
                menuPersonData:{

                },
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
            init(){
                getRecordType().then((data) => {
                    this.recordList = data.data.rows;
                });
                getTableData().then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            getCategoryName(code){
                for(var i=0;i<this.recordList.length;i++){
                    if(code == this.recordList[i].categoryCode){
                        return this.recordList[i].categoryName
                    }
                }
            },
            formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
            pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = {
                    page: this.pageNo,
                    limit: 10
                }

                if(this.searchcodeChecked){
                    query.pluginCode = this.searchcode;
                }
                if(this.searchnameChecked){
                    query.pluginName = this.searchname;
                }
                getTableData(query).then((data)=>{
                    this.menuPersonData =data.data;
                });
            },
            doSearch(){
                var query = {
                    page:1,
                    limit:10
                }
                if(this.searchcodeChecked){
                    query.pluginCode = this.searchcode;
                }
                if(this.searchnameChecked){
                    query.pluginName = this.searchname;
                }
                getTableData(query).then((data)=>{
                    this.menuPersonData =data.data;
                });
            },
            configPlugin(item){
                this.idEditFile = false;
                this.ruleForm = item;
                this.dialog = true;
                this.fileList = [{
                    name:item.pluginPath.split('/').pop(),
                    url:item.pluginPath
                }];
            },
            add(){
                this.idEditFile = false;
                this.dialog = true;
                this.ruleForm = {
                    pluginCode:"",
                    pluginName:"",
                    pluginDetail:"",
                    pluginRunningStrategy:"",
                    indexType:"",
                    pluginSize:"",
                    pluginPath:""
                }
                this.fileList = [];
            },
            remove(item){
                var id = item.id;
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                        deleteone(id).then((data)=>{
                            if(data.status == 200){
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        var obj = {
                                            filePath:item.pluginPath
                                        }
                                        removeFile(obj).then(()=>{
                                            this.init();
                                        });
                                    }
                                });
                            }else{
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            download(item){
                fileDownload('/api/soc/pluginConfig/download?fileName='+item.pluginPath.split('/').pop(), "application/x-javascript", item.pluginPath.split('/').pop());
            },
            fileChange(file, fileList){
                this.idEditFile = true;
                if(this.ruleForm.pluginCode ==''){
                    this.ruleForm.pluginCode = file.name.substring(0,file.name.indexOf('.js'));
                }
                if(this.ruleForm.pluginName ==''){
                    this.ruleForm.pluginName = file.name.substring(0,file.name.indexOf('.js'));
                }
                this.ruleForm.pluginSize = file.size/1000 + 'KB';
                this.ruleForm.pluginPath = '/opt/dev/agent/upgrade/plugins/'+file.name;
            },
            fileRemove(file, fileList){
                this.ruleForm.pluginCode = "";
                this.ruleForm.pluginName = "";
                this.ruleForm.pluginSize = "";
                this.ruleForm.pluginPath = "";
            },
            doSubmit(formName){
                var addObj = this.ruleForm;
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.dialog = false;
                        if(addObj.id) {
                            edit(addObj).then((data)=>{
                                if(this.idEditFile){
                                    var obj = {
                                        filePath:addObj.pluginPath
                                    }
                                    removeFile(obj).then(()=>{
                                        this.$refs.upload.submit();
                                        this.init();
                                    });
                                }else{
                                    getSboxRunningDetail()
                                }
                            });
                        }else{
                            add(addObj).then((data) => {
                                this.$refs.upload.submit();
                                this.init();
                            });
                        }
                    }else{
                        return false;
                    }
                });
            }
        },
        created() {
            this.init();
        },
        activated() {
            this.init();
        }
    }

</script>

<style lang="css">
    #indexConfigDialog .el-upload-list__item-name{
        width: 100%;
    }
</style>
<style lang="css" scoped>
    .backColor {
        background-color: #f0f0f0;
        width: 100%;
        height: calc(100% - 110px) !important;
        height:100%;
    }

    .contentBox {
        width: 100%;
        height: 100%;
        z-index: 1;
        background-color: #ffffff;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }

    .upload-demo{
        display: inline-grid;
    }
</style>
