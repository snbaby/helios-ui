<template>
    <div class="soc-main">
        <div class="soc-main-content" style="margin: auto;">
            <el-row style="height: 30%;">
                <el-col :span="12" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">主机检查概况</font>
                        <processMonitorEcharts :process-monitor-data="processMonitorData" v-if="processMonitorData.isfinished"></processMonitorEcharts>
                    </div>
                </el-col>
                <el-col :span="12" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">主机人工处理概况</font>
                        <recordMonitorEcharts :record-monitor-data="recordMonitorData" v-if="recordMonitorData.isfinished"></recordMonitorEcharts>
                    </div>
                </el-col>
            </el-row>
            <el-row style="height: 30%;margin-top: 10px;">
                <el-col :span="12" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">指标检查概况</font>
                        <doneIndicatorsEcharts :done-indicators-data="doneIndicatorsData" v-if="doneIndicatorsData.isfinished"></doneIndicatorsEcharts>
                    </div>
                </el-col>
                <el-col :span="12" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">指标人工处理概况</font>
                        <processIndicatorsEcharts :process-indicators-data="processIndicatorsData" v-if="processIndicatorsData.isfinished"></processIndicatorsEcharts>
                    </div>
                </el-col>
                <!--<el-col :span="8" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">指标备案概况</font>
                        <recordIndicatorsEcharts :record-indicators-data="recordIndicatorsData" v-if="recordIndicatorsData.isfinished"></recordIndicatorsEcharts>
                    </div>
                </el-col>-->
            </el-row>
            <el-row style="height: 35%;margin-top: 10px;">
                <el-col :span="12" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">重要指标合规占比</font>
                        <importentIndexEcharts :importent-index-data="importentIndexData" v-if="importentIndexData.isfinished"></importentIndexEcharts>
                    </div>
                </el-col>
                <el-col :span="6" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">终端不合规数TOP5</font>
                        <div class="splitline"></div>
                        <div class="riskTop5Table">
                            <div style="witdh:100%;height:100%;">
                                <mu-row :gutter="true" v-for="item,index in deviceList" :key="index">
                                    <mu-col width="15" tablet="15" desktop="15">
                                        {{index+1}}
                                    </mu-col>
                                    <mu-col width="65" tablet="65" desktop="65">
                                        {{item.deviceCode}}
                                    </mu-col>
                                    <mu-col width="20" tablet="20" desktop="20" style="text-align: right;">
                                        {{item.count}}
                                    </mu-col>
                                </mu-row>
                            </div>
                        </div>
                    </div>
                </el-col>
                <el-col :span="6" style="height: 100%;">
                    <div class="echartsContent">
                        <font class="echartsTitle">指标不合规数TOP5</font>
                        <div class="splitline"></div>
                        <div class="riskTop5Table">
                            <div style="witdh:100%;height:100%;">
                                <mu-row :gutter="true" v-for="item,index in indexList" :key="index">
                                    <mu-col width="15" tablet="15" desktop="15">
                                        {{index+1}}
                                    </mu-col>
                                    <mu-col width="65" tablet="65" desktop="65">
                                        {{item.indexName}}
                                    </mu-col>
                                    <mu-col width="20" tablet="20" desktop="20" style="text-align: right;">
                                        {{item.count}}
                                    </mu-col>
                                </mu-row>
                            </div>
                        </div>
                    </div>
                </el-col>
            </el-row>
        </div>
	</div>
</template>

<script>
    import processMonitorEcharts from '@/components/terminalSecurity/confidentialityInspection/processMonitorEcharts';
    import recordMonitorEcharts from '@/components/terminalSecurity/confidentialityInspection/recordMonitorEcharts';
    import doneIndicatorsEcharts from '@/components/terminalSecurity/confidentialityInspection/doneIndicatorsEcharts';
    import processIndicatorsEcharts from '@/components/terminalSecurity/confidentialityInspection/processIndicatorsEcharts';
    import importentIndexEcharts from '@/components/terminalSecurity/confidentialityInspection/importentIndexEcharts';
    import async1 from "async";
    import _ from "underscore"

    export default {
        components: {
            processMonitorEcharts,
            recordMonitorEcharts,
            doneIndicatorsEcharts,
            processIndicatorsEcharts,
            importentIndexEcharts
        },
        data() {
            return {
                deviceList:[],
                indexList:[],
                processMonitorData:{
                    normTotal:0,
                    total:0,
                    compliance:0,
                    nocompliance:0,
                    matched:0,
                    nomatched:0,
                    isfinished:false
                },
                recordMonitorData:{
                    normTotal:0,
                    total:0,
                    hasCompleted:0,
                    noCompleted:0,
                    isfinished:false
                },
                doneMonitorData:{
                    total:0,
                    recording:0,
                    recorded:0,
                    canceled:0,
                    canceling:0,
                    isfinished:false
                },
                doneIndicatorsData:{
                    normTotal:0,
                    total:0,
                    compliance:0,
                    nocompliance:0,
                    matched:0,
                    nomatched:0,
                    isfinished:false
                },
                processIndicatorsData:{
                    normTotal:0,
                    total:0,
                    hasCompleted:0,
                    noCompleted:0,
                    isfinished:false
                },
                recordIndicatorsData:{
                    total:0,
                    noCompleted:0,
                    hasCompleted:0,
                    isfinished:false
                },
                importentIndexData:{
                    datax:[],
                    datay:[],
                    temp:{},
                    isfinished:false
                },
			}
        },
        computed: {

        },
        methods: {
            init(){
                var self = this;
                async1.parallel([
                        function (call) {
                            //查询所有已安装sbox数量
                            self.getSqlResultWithQuery('countHasInstallSbox', {where: ""}).then((data) => {
                                self.processMonitorData.total = data.data.total;
                                self.recordMonitorData.total = data.data.total;
                                self.doneIndicatorsData.total = data.data.total;
                                self.processIndicatorsData.normTotal = data.data.total;
                                self.importentIndexData.total = data.data.total;
                                call();
                            });
                        }
                    ],
                    function(err, results){
                        self.initProcessMonitorData();
                        self.initRecordMonitor();
                        // self.initDoneMonitor();
                        self.initDoneIndicators();
                        self.processIndicatorsMonitor();
                        // self.recordIndicatorsMonitor();
                        self.importentIndexMonitor();
                        self.initNotMatchedHost();
                        self.initNotMatchedNorm();
                    });
            },
            initProcessMonitorData() {
                var self = this;
                async1.series([
                    function (call) {
                        //查询所有指标项
                        self.getSqlResultWithQuery('selectIndexTableDataForSbox', {
                            "where": "",
                            "page": 0,
                            "limit": 10
                        }).then((data) => {
                            self.processMonitorData.normTotal = data.data.total;
                            call();
                        });
                    },
                    function (call) {
                        //查询所有已检查指标项
                        var createTime = new Date()-30*24*60*60*1000;
                        self.getSqlResultWithQuery('getMatchedNormCount', {where:" and create_time > "+createTime +" and create_time > "+createTime +" and create_time > "+createTime}).then((data) => {
                            var arr = data.data.aggs.operater_host_code.buckets;
                            self.processMonitorData.compliance = 0;
                            for (var i in arr) {
                                if (arr[i].doc_count == self.processMonitorData.normTotal) {
                                    self.processMonitorData.compliance++;
                                }
                            }
                            self.processMonitorData.nocompliance = self.processMonitorData.total - self.processMonitorData.compliance;
                            call();
                        });
                    },
                    function (call) {
                        //查询合规项
                        var createTime = new Date()-30*24*60*60*1000;
                        self.getSqlResultWithQuery('getMatchedNormCount', {where:" and create_time > "+createTime +" and norm_matched = 1 or norm_matched = 2"}).then((data) => {
                            var arr = data.data.aggs.operater_host_code.buckets;
                            self.processMonitorData.matched = 0;
                            for (var i in arr) {
                                if (arr[i].doc_count == self.processMonitorData.normTotal) {
                                    self.processMonitorData.matched++;
                                }
                            }
                            self.processMonitorData.nomatched = self.processMonitorData.compliance - self.processMonitorData.matched;
                            call();
                        });
                    }
                ], function () {
                    self.processMonitorData.isfinished = true;
                })
            },
            initRecordMonitor(){
                var self = this;
                async1.series([
                    function (call) {
                        self.getSqlResultWithQuery('selectIndexTableDataForSbox',{"where":"and category_code in ('manualCheck','OpenPorts')","page":0,"limit":50}).then((data) => {
                            self.recordMonitorData.normTotal = data.data.total;
                            call();
                        });
                    },
                    function (call) {
                        var createTime = new Date()-30*24*60*60*1000;
                        self.getSqlResultWithQuery('getMatchedNormCount',{where:" and create_time > "+createTime +" and norm_type in ('manualCheck','OpenPorts') and norm_matched = 1"}).then((data) => {
                            var arr = data.data.aggs.operater_host_code.buckets;
                            self.recordMonitorData.hasCompleted = 0;
                            for(var i in arr){
                                if(arr[i].doc_count >= self.recordMonitorData.normTotal){
                                    self.recordMonitorData.hasCompleted ++ ;
                                }
                            }
                            self.recordMonitorData.noCompleted = self.recordMonitorData.total - self.recordMonitorData.hasCompleted;
                            call();
                        });
                    }
                ],function () {
                    self.recordMonitorData.isfinished = true;
                })
            },
            initDoneMonitor(){
                var self = this;
                async1.series([
                    function (call) {
                        self.getSqlResultWithQuery('countRecordInfo',{where:""}).then((data) => {
                            var arr = data.data.aggs.norm_code.buckets;
                            self.doneMonitorData.total = 0;
                            for(var i in arr){
                                self.doneMonitorData.total += arr[i].asset_code.buckets.length;
                            }
                            call();
                        });
                    },
                    function (call) {
                        self.getSqlResultWithQuery('countRecordInfo',{where:"where processInstanceId in (select flow_instance_id from app_bpmn/flow_apply_info where flow_status = 'COMPLETED')"}).then((data) => {
                            var arr = data.data.aggs.norm_code.buckets;
                            self.doneMonitorData.recorded = 0;
                            for(var i in arr){
                                self.doneMonitorData.recorded += arr[i].asset_code.buckets.length;
                            }
                            self.doneMonitorData.recording = self.doneMonitorData.total - self.doneMonitorData.recorded;
                            call();
                        });
                    }
                ],function () {
                    self.doneMonitorData.isfinished = true;
                })
            },
            initDoneIndicators(){
                var self = this;
                async1.series([
                    function (call) {
                        //查询所有指标项
                        self.getSqlResultWithQuery('selectIndexTableDataForSbox', {
                            "where": "",
                            "page": 0,
                            "limit": 10
                        }).then((data) => {
                            self.doneIndicatorsData.normTotal = data.data.total;
                            call();
                        });
                    },
                    function (call) {
                        //查询所有已检查指标项
                        self.getSqlResultWithQuery('getMatchedNormByNormCode', {where: ""}).then((data) => {
                            var arr = data.data.aggs.norm_code.buckets;
                            self.doneIndicatorsData.compliance = 0;
                            for (var i in arr) {
                                if (arr[i].doc_count >= self.doneIndicatorsData.total) {
                                    self.doneIndicatorsData.compliance++;
                                }
                            }
                            self.doneIndicatorsData.nocompliance = self.doneIndicatorsData.normTotal - self.doneIndicatorsData.compliance;
                            call();
                        });
                    },
                    function (call) {
                        //查询合规项
                        self.getSqlResultWithQuery('getMatchedNormByNormCode', {where: "and norm_matched = 1 or norm_matched = 2 or norm_matched = 4"}).then((data) => {
                            var arr = data.data.aggs.norm_code.buckets;
                            self.doneIndicatorsData.matched = 0;
                            for (var i in arr) {
                                if (arr[i].doc_count >= self.doneIndicatorsData.total) {
                                    self.doneIndicatorsData.matched++;
                                }
                            }
                            self.doneIndicatorsData.nomatched = self.doneIndicatorsData.compliance - self.doneIndicatorsData.matched;
                            call();
                        });
                    }
                ],function () {
                    self.doneIndicatorsData.isfinished = true;
                })
            },
            processIndicatorsMonitor(){
                var self = this;
                self.processIndicatorsData.total = 0;
                async1.series([
                    function (call) {
                        //查询所有人工确认指标项
                        self.getSqlResultWithQuery('selectIndexTableDataForSbox',{"where":"and category_code in ('manualCheck','OpenPorts')","page":0,"limit":50}).then((data) => {
                            self.processIndicatorsData.total = data.data.total * self.processIndicatorsData.normTotal;
                            self.processIndicatorsData.normTotal = data.data.total;
                            call();
                        });
                    },
                    function (call) {
                        var createTime = new Date()-30*24*60*60*1000;
                        self.getSqlResultWithQuery('getMatchedNormCount',{where:" and create_time > "+createTime +" and norm_type in ('manualCheck','OpenPorts') and norm_matched = 1"}).then((data) => {
                            var arr = data.data.aggs.operater_host_code.buckets;
                            self.processIndicatorsData.hasCompleted = 0;
                            for(var i in arr){
                                self.processIndicatorsData.hasCompleted += arr[i].doc_count;
                            }
                            self.processIndicatorsData.noCompleted = self.processIndicatorsData.total - self.processIndicatorsData.hasCompleted;
                            call();
                        });
                    }
                ],function () {
                    self.processIndicatorsData.isfinished = true;
                })
            },
            recordIndicatorsMonitor(){
                var self = this;
                async1.series([
                    function (call) {
                        self.getSqlResultWithQuery('countRecordInfo',{where:""}).then((data) => {
                            self.recordIndicatorsData.total = data.data.total
                            call();
                        });
                    },
                    function (call) {
                        self.getSqlResultWithQuery('countRecordInfo',{where:"where processInstanceId in (select flow_instance_id from app_bpmn/flow_apply_info where flow_status = 'COMPLETED')"}).then((data) => {
                            self.recordIndicatorsData.hasCompleted = data.data.total
                            self.recordIndicatorsData.noCompleted = self.recordIndicatorsData.total - self.recordIndicatorsData.hasCompleted;
                            call();
                        });
                    }
                ],function () {
                    self.recordIndicatorsData.isfinished = true;
                })
            },
            importentIndexMonitor(){
                var self = this;
                async1.series([
                    function (call) {
                        async1.waterfall([
                            function(callback){
                                //查询重要指标
                                self.getSqlResultWithQuery('getImportantNorm', {}).then((data) => {
                                    callback(null, data);
                                });
                            },
                            function(arg1,callback){
                                var norm_code = "";
                                self.importentIndexData.temp = {};
                                for(var i in arg1.data.rows){
                                    self.importentIndexData.temp[arg1.data.rows[i].source_code] = 0;
                                    norm_code = norm_code + arg1.data.rows[i].source_code + ",";
                                    self.importentIndexData.datax.push(arg1.data.rows[i].source_name);
                                }
                                norm_code = norm_code.substring(0,norm_code.length-1);
                                //统计重要指标合规率
                                self.getSqlResultWithQuery('getImportantNormCount', {norm_code:norm_code}).then((data) => {
                                    var arr = data.data.aggs.norm_code.buckets;
                                    for(var i in arr){
                                        self.importentIndexData.temp[arr[i].key] = Math.round(arr[i].doc_count / self.importentIndexData.total * 100);
                                    }
                                    self.importentIndexData.datay = _.values(self.importentIndexData.temp);
                                    callback(null, data);
                                });
                            }
                        ], function (err, result) {
                            self.importentIndexData.isfinished = true;
                        });
                    }
                ],function () {
                    self.doneMonitorData.isfinished = true;
                })
            },
            initNotMatchedHost(){
                var self = this;
                self.deviceList = [];
                self.getSqlResultWithQuery('getNotMatchedHost',{code:"operater_host_code"}).then((data) => {
                    var arr = data.data.aggs.operater_host_code.buckets;
                    self.deviceList = [];
                    for(var i in arr){
                        var item = {
                            deviceCode:arr[i].key,
                            count:arr[i].doc_count
                        };
                        self.deviceList.push(item);
                    }
                });
            },
            initNotMatchedNorm(){
                var self = this;
                self.getSqlResultWithQuery('getNotMatchedHost',{code:"norm_title"}).then((data) => {
                    var arr = data.data.aggs.norm_title.buckets;
                    self.indexList = [];
                    for(var i in arr){
                        var item = {
                            indexName:arr[i].key,
                            count:arr[i].doc_count
                        };
                        self.indexList.push(item);
                    }
                });
            },
        },
        created() {
            this.init();
		},
        activated() {
            this.init();
        }
    }
</script>


<style lang="css" scoped>
    .echartsContent {
        border: 1px solid #e4e7ed;
        height: 100%;
        position: relative;
        margin: 0 5px;
        border-radius: 8px;
    }

    .echartsTitle {
        position: absolute;
        font-size: 15px;
        font-weight: bold;
        left: 5px;
        top: 5px;
    }

    .splitline {
        height: 1px;
        width: 100%;
        background-color: #e4e7ed;
        margin-top: 11%;
    }

    .riskTop5Table {
        padding: 10px 20px 10px 20px;
        font-size: 15px;
    }

    .riskTop5Table .row {
        margin-top:10px;
    }
</style>
