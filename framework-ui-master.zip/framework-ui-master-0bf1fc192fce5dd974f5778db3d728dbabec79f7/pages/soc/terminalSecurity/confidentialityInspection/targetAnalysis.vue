<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="指标名称：">
                    <el-select v-model="searchCode" clearable>
                        <el-option v-for="item,index in normCodeOptions.rows" :key="index" :label="item.source_name" :value="item.source_code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="检查结果：">
                    <el-select v-model="searchResult" clearable>
                        <el-option label="合规" value="1,2"></el-option>
                        <el-option label="不合规" value="0,3"></el-option>
                        <el-option label="未检查" value="-1"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button class="search" @click="doSearch" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>

        <div>
            <el-table :data="menuPersonData.data">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="org_name"
                    label="责任单位"
                    show-overflow-tooltip
                >
                </el-table-column>
                <el-table-column
                    prop="asset_code"
                    label="统一编号"
                    min-width="80"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_duty_name"
                    label="责任人"
                    min-width="80"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_secret"
                    label="密级"
                    min-width="80"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_secret',scope.row.asset_secret)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_network"
                    label="联网类别"
                    min-width="80"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_network',scope.row.asset_network)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    label="IP地址"
                    min-width="110"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_os"
                    label="操作系统"
                    min-width="100"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_useage"
                    label="用途"
                    min-width="70"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_useage',scope.row.asset_useage)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_area"
                    label="安装位置"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_status"
                    label="设备状态"
                    width="80"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getCategoryData('asset_status',scope.row.asset_status)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="norm_title"
                    label="指标名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_expected"
                    label="标准值"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span >{{getNormExpectedCategory(scope.row.norm_code,scope.row.norm_expected)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="norm_actual"
                    label="采集值"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop=""
                    label="检查结果"
                    min-width="80"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span :style="getShowColor(scope.row.norm_matched)">{{getCategoryData('norm_result_type',scope.row.norm_matched)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="check_time"
                    label="检查时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{timestampToTimes(scope.row.create_time)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="showHistroy(scope.row.norm_code,scope.row.asset_code)"
                            type="text"
                            size="small">
                            查看
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
        <el-dialog :visible.sync="dialog" width="70%" id="historyNormDialog">
            <div class="framework-search-form">
                <el-form :inline="true">
                    <el-form-item label="检查结果：">
                        <el-select v-model="checkResult.value" placeholder="">
                            <el-option
                                v-for="item in checkResult.options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="检查时间：">
                        <el-date-picker
                            v-model="checkTime"
                            type="daterange"
                            align="right"
                            unlink-panels
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            :picker-options="pickerOptions2">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item>
                        <el-button class="search" @click="doSearch1" type="primary">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>

            <el-table :data="historyCheckResultData.data">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="operater_host_code"
                    label="统一编号"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_title"
                    label="指标名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_expected"
                    label="标准值"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span >{{getNormExpectedCategory(scope.row.norm_code,scope.row.norm_expected)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="norm_actual"
                    label="采集值"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_matched"
                    label="检查结果"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span :style="getShowColor(scope.row.norm_matched)">{{getCategoryData('norm_result_type',scope.row.norm_matched)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="create_time"
                    label="检查时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{timestampToTimes(scope.row.create_time)}}</span>
                    </template>
                </el-table-column>
            </el-table>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {getIndexTableData} from '@/api/sboxMonitor/indexAnalysis/index.js';
    import async1 from "async";
    import _ from "underscore";
    export default {
        components: {
            pagination,
        },
        data() {
            return {
                pageNo:0,
                where:"",
                dialog:false,
                searchCode:"",
                searchResult:"",
                menuPersonData:{},
                historyCheckResultData:{},
                normCodeOptions:{},
                currentNormCode:false,
                currentAssetCode:false,
                checkTime:false,
                checkResult:{
                    options:[{
                        value: '-1',
                        label: '未检查'
                    }, {
                        value: '0',
                        label: '不合规'
                    }, {
                        value: '1',
                        label: '合规'
                    }, {
                        value: '2',
                        label: '不合格已备案'
                    }, {
                        value: '3',
                        label: '合格已备案'
                    }],
                    value:""
                },
                pickerOptions2: {
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.pageNo+1,
                    pageSize: 15,
                    total: this.menuPersonData.total
                }
            }
        },
        watch:{
        },
        methods: {
            init(){
                this.doSearch();
                this.selectIndexTableDataForSbox();
            },
            pageChange(val) {
                this.pageNo = val - 1;
                var query = {
                    where:this.where,
                    page:this.pageNo*15,
                    size:15
                };
                this.getCheckProcessData(query);
            },
            doSearch(){
                var query = {
                    page:0,
                    size:15
                };
                var where = "";
                if(this.searchCode != ''){
                    where = where + ' and norm_code = "' + this.searchCode + '"'
                }
                if(this.searchResult != ''){
                    where = where + ' and norm_matched in (' + this.searchResult + ')'
                }

                query.where = where;
                this.where = where;
                this.getCheckProcessData(query);
            },
            getCheckProcessData:function(query){
                var self = this;
                async1.waterfall([
                    function(callback){
                        self.getSqlResultWithQuery("getAllNormCheckList",query).then((data) => {
                            callback("",data.data);
                        });
                    },
                    function(dataVal, callback){
                        var host_code = _.pluck(dataVal.data,"operater_host_code").join(",");
                        self.getSqlResultWithQuery('getComputerInfoList',{asset_code:host_code}).then((data) => {
                            for(var i in dataVal.data){
                                for(var j in data.data.data){
                                    if(dataVal.data[i].operater_host_code == data.data.data[j].asset_code){
                                        _.extend(dataVal.data[i],data.data.data[j]);
                                    }
                                }
                            }
                            callback("",dataVal);
                        })
                    }
                ], function (err, result) {
                    self.menuPersonData = result;
                });
            },
            getShowColor(checkResult){
                if(checkResult == '0'||checkResult == '3'){
                    return 'color:#d30b0b !important'
                }
                if(checkResult == '1'||checkResult == '2'){
                    return 'color:#0f9c6c !important'
                }
            },
            getShowRowColor({row, rowIndex}){
                if(row.norm_matched == '0'||row.norm_matched == '2'){
                    return 'check-failed'
                }
                if(row.norm_matched == '1'||row.norm_matched == '3'){
                    return 'check-success'
                }
            },
            showHistroy(norm_code,asset_code){
                this.currentNormCode = norm_code;
                this.currentAssetCode = asset_code;
                var query = {
                    asset_code:asset_code,
                    norm_code:norm_code,
                    where:" and 1 = 1"
                };
                this.getSqlResultWithQuery('queryNormHistoryResultByCodes',query).then((data) => {
                    this.historyCheckResultData = data.data;
                    this.dialog = true;
                });
            },
            selectIndexTableDataForSbox(){
                var self = this;
                var query = {
                    where:"",
                    page:0,
                    limit:100
                };
                self.getSqlResultWithQuery("selectIndexTableDataForSbox",query).then((data) => {
                    self.normCodeOptions = data.data;
                });
            },
            getHandlePerson(comments) {
                var arr = comments.split("/");
                if(arr.length>1){
                    return arr[0];
                }else{
                    return "";
                }
            },
            doSearch1(norm_code){
                var query = {
                    asset_code:this.currentAssetCode,
                    norm_code:this.currentNormCode
                };
                var where = "";
                if(this.checkResult.value){
                    where = where + " and norm_matched = '"+this.checkResult.value+"' "
                }
                if(this.checkTime){
                    where = where + " and create_time > "+new Date(this.checkTime[0]).getTime()+" and create_time < " + new Date(this.checkTime[1]).getTime()
                }
                if(where){
                    query.where = where;
                }
                this.getSqlResultWithQuery('queryNormHistoryResultByCodes',query).then((data) => {
                    this.historyCheckResultData = data.data;
                    this.dialog = true;
                });
            },
            getNormExpectedCategory(norm_code,norm_expected){
                if(norm_code == 'SecretLevel'){
                    return this.getCategoryData("asset_secret",norm_expected);
                }else if(norm_code == 'Purpose'){
                    return this.getCategoryData("asset_useage",norm_expected);
                }else if(norm_code == 'AllInOne' || norm_code == 'AntiVirus' || norm_code == 'HostAudit'|| norm_code == 'IdProtect'){
                    return "";
                }else {
                    return norm_expected;
                }
            }
        },
        created() {
            if(this.$route.query.searchCode){
                this.searchCode = this.$route.query.searchCode;
            }
            this.init();
        }
    }

</script>

<style>
    #historyNormDialog .el-dialog{
        height: 70%;
    }

    #historyNormDialog .el-dialog__body{
        height: 95%;
        overflow-y: auto;
    }
    .el-range-editor.el-input__inner{
        padding: 0px;
    }
    .el-table .check-success {
        color: #08e69a!important;
    }
    .el-table .check-failed {
        color: #d30b0b!important;;
    }
</style>
<style lang="css" scoped>
    .backColor {
        background-color: #f0f0f0;
        width: 100%;
        height: calc(100% - 110px) !important;
        height:100%;
    }

    .contentBox {
        width: 100%;
        height: 100%;
        z-index: 1;
        background-color: #ffffff;
    }

    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 200px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }
</style>
