<template>
    <div class="framework-content">
        <div>
            <el-button class="buttonBack" @click="$router.push('/soc/terminal-security/confidentiality-inspection/result-manager')">返 回</el-button>
        </div>
        <div class="soc-mt20">
            <el-row class="sd-bas-line soc-h200">
                <el-col :span="4" class="soc-h198 sd-brs-line">
                    <div class="echartsContent">
                        <checkMonitorEcharts :record-monitor-data="doneIndicatorsData" v-if="doneIndicatorsData.isfinished"></checkMonitorEcharts>
                    </div>
                    <div class="soc-center" style="color: #909399">终端检查合规度：{{doneIndicatorsData.checkResult}}</div>
                </el-col>
                <el-col :span="6" class="soc-h198 sd-brs-line">
                    <div class="soc-h200">
                        <div class="elTitle">
                            <font>主机信息</font>
                        </div>
                        <div style="font-size: 13px">
                            <el-row class="elPadding">
                                <el-col :span="6" class="soc-right">主机编号:</el-col>
                                <el-col :span="6" class="overflow" :title="assetDetail.asset_code">{{assetDetail.asset_code}}</el-col>
                                <el-col :span="6" class="soc-right">责任单位:</el-col>
                                <el-col :span="6" class="overflow" :title="assetDetail.org_name">{{assetDetail.org_name}}</el-col>
                            </el-row>
                            <el-row class="elPadding">
                                <el-col :span="6" class="soc-right">责任人:</el-col>
                                <el-col :span="6" class="overflow" :title="assetDetail.asset_duty_name">{{assetDetail.asset_duty_name}}</el-col>
                                <el-col :span="6" class="soc-right">密级:</el-col>
                                <el-col :span="6" class="overflow" :title="getCategoryData('asset_secret',assetDetail.asset_secret)">{{getCategoryData('asset_secret',assetDetail.asset_secret)}}</el-col>
                            </el-row>
                            <el-row class="elPadding">
                                <el-col :span="6" class="soc-right">联网类别:</el-col>
                                <el-col :span="6" class="overflow" :title="getCategoryData('asset_network',assetDetail.asset_network)">{{getCategoryData('asset_network',assetDetail.asset_network)}}</el-col>
                                <el-col :span="6" class="soc-right">IP地址:</el-col>
                                <el-col :span="6" class="overflow" :title="assetDetail.asset_ip">{{assetDetail.asset_ip}}</el-col>
                            </el-row>
                            <el-row class="elPadding">
                                <el-col :span="6" class="soc-right">操作系统:</el-col>
                                <el-col :span="6" class="overflow" :title="assetDetail.org_name">{{assetDetail.org_name}}</el-col>
                                <el-col :span="6" class="soc-right">用途:</el-col>
                                <el-col :span="6" class="overflow" :title="getCategoryData('asset_useage',assetDetail.asset_useage)">{{getCategoryData('asset_useage',assetDetail.asset_useage)}}</el-col>
                            </el-row>
                            <el-row class="elPadding">
                                <el-col :span="6" class="soc-right">安装位置:</el-col>
                                <el-col :span="6" class="overflow" :title="assetDetail.asset_area">{{assetDetail.asset_area}}</el-col>
                                <el-col :span="6" class="soc-right">设备状态:</el-col>
                                <el-col :span="6" class="overflow" :title="getCategoryData('asset_status',assetDetail.asset_status)">{{getCategoryData('asset_status',assetDetail.asset_status)}}</el-col>
                            </el-row>
                        </div>
                    </div>
                </el-col>
                <el-col :span="7" class="soc-h198 sd-brs-line">
                    <div class="elTitle">
                        <font>安全防护备案</font>
                    </div>
                    <div style="height: 160px;padding-left: 15px;overflow: auto">
                        <el-row v-for="item,index in hostProtectRecord" :key="index" class="rowStyle">
                            <el-col :span="20">
                                <li class="task" :title="item.flow_instance_name">{{item["b.norm_title"] + '-' +timestampToTimes(item["a.flow_start_time"])}}</li>
                            </el-col>
                            <el-col :span="4">
                                <font class="do" @click="viewBpmn(item)">查看</font>
                            </el-col>
                        </el-row>
                        <el-row v-if="hostProtectRecord&&hostProtectRecord.length==0">无</el-row>
                    </div>
                </el-col>
                <el-col :span="7" class="soc-h198">
                    <div class="elTitle">
                        <font>端口开放备案</font>
                    </div>
                    <div style="height: 160px;padding-left: 15px;overflow: auto">
                        <el-row v-for="item,index in openPortRecord" :key="index" class="rowStyle">
                            <el-col :span="20">
                                <li class="task" :title="item.flow_instance_name">{{item["b.norm_title"]+ '-' +timestampToTimes(item["a.flow_start_time"])}}</li>
                            </el-col>
                            <el-col :span="4">
                                <font class="do" @click="viewBpmn(item)">查看</font>
                            </el-col>
                        </el-row>
                        <el-row v-if="openPortRecord&&openPortRecord.length==0">无</el-row>
                    </div>
                </el-col>
            </el-row>
        </div>

        <div class="soc-mt20">
            <el-tabs v-model="normType" type="card" @tab-click="handleClick">
                <el-tab-pane label="人工检测" name="manualCheck"></el-tab-pane>
                <el-tab-pane label="系统配置" name="hostConfig"></el-tab-pane>
                <el-tab-pane label="安全防护" name="hostProtect"></el-tab-pane>
            </el-tabs>
            <el-table :data="menuResultData.data">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="norm_title"
                    label="指标名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_expected"
                    label="标准值"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span >{{getNormExpectedCategory(scope.row.norm_code,scope.row.norm_expected)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="norm_actual"
                    label="采集值"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_matched"
                    label="检查结果"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span :style="getShowColor(scope.row.norm_matched)">{{getCategoryData('norm_result_type',scope.row.norm_matched)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="norm_comments"
                    label="备注"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{getNormComments(scope.row.norm_matched,scope.row.norm_comments)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_duty_name"
                    label="检查人"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="create_time"
                    label="检查时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{timestampToTimes(scope.row.create_time)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="confirmYes(scope.row)"
                            :disabled="scope.row.norm_matched!='1' || scope.row.norm_matched!='2'"
                            type="text"
                            size="small">
                            合规
                        </el-button>
                        <el-button
                            @click.native.prevent="doNotCheck(scope.row)"
                            type="text"
                            :disabled="scope.row.norm_matched!='1' || scope.row.norm_matched!='2'"
                            size="small">
                            不合规
                        </el-button>
                        <el-button
                            @click.native.prevent="showHistroy(scope.row.norm_code)"
                            type="text"
                            size="small">
                            查看
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
            <div class="soc-mt10">
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
        <el-dialog :visible.sync="dialog" width="70%" id="historyNormDialog">
            <div class="framework-search-form">
                <el-form :inline="true">
                    <el-form-item label="检查结果：">
                        <el-select v-model="checkResult.value" placeholder="">
                            <el-option
                                v-for="item in checkResult.options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="检查时间：">
                        <el-date-picker
                            v-model="checkTime"
                            type="daterange"
                            align="right"
                            unlink-panels
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            :picker-options="pickerOptions2">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item>
                        <el-button class="search" @click="doSearch" type="primary">查询</el-button>
                    </el-form-item>
                </el-form>
            </div>

            <el-table :data="historyCheckResultData.data">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="operater_host_code"
                    label="统一编号"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_title"
                    label="指标名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_expected"
                    label="标准值"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span >{{getNormExpectedCategory(scope.row.norm_code,scope.row.norm_expected)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="norm_actual"
                    label="采集值"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_matched"
                    label="检查结果"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span :style="getShowColor(scope.row.norm_matched)">{{getCategoryData('norm_result_type',scope.row.norm_matched)}}</span>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="create_time"
                    label="检查时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <span>{{timestampToTimes(scope.row.create_time)}}</span>
                    </template>
                </el-table-column>
            </el-table>
        </el-dialog>
    </div>
</template>

<script>
    import {mapState} from 'vuex';
    import pagination from '@/components/common/pagination.vue';
    import processIndicatorsEcharts from '@/components/terminalSecurity/confidentialityInspection/processIndicatorsEcharts';
    import recordIndicatorsEcharts from '@/components/terminalSecurity/confidentialityInspection/recordIndicatorsEcharts';
    import checkMonitorEcharts from '@/components/terminalSecurity/confidentialityInspection/checkMonitorEcharts';
    import async1 from "async";
    import { fetch, json2Param } from '@/core/fetch.js';

    export default {
        name: "resultManageDetail",
        components: {
            processIndicatorsEcharts,
            recordIndicatorsEcharts,
            checkMonitorEcharts,
            pagination
        },
        data() {
            return {
                pageNo:0,
                where:"and (norm_type in ('manualCheck','OpenPorts') or norm_code in ('BootPassword','AdminAccess'))",
                searchcode:"",
                searchcodeChecked:false,
                searchname:"",
                searchnameChecked:false,
                searchresult:"",
                searchresultChecked:false,
                dialog: false,
                assetDetail:{},
                menuResultData: {},
                dialogVisible:false,
                inputValue:"",
                rowData:false,
                historyCheckResultData:{},
                openPortRecord:[],
                hostProtectRecord:[],
                normType: 'manualCheck',
                currentUser:{},
                checkTime:"",
                currentNormCode:false,
                checkResult:{
                    options:[{
                        value: '-1',
                        label: '未检查'
                    }, {
                        value: '0',
                        label: '不合规'
                    }, {
                        value: '1',
                        label: '合规'
                    }, {
                        value: '2',
                        label: '不合格已备案'
                    }, {
                        value: '3',
                        label: '合格已备案'
                    }],
                    value:""
                },
                pickerOptions2: {
                    shortcuts: [{
                        text: '最近一周',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近一个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
                            picker.$emit('pick', [start, end]);
                        }
                    }, {
                        text: '最近三个月',
                        onClick(picker) {
                            const end = new Date();
                            const start = new Date();
                            start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
                            picker.$emit('pick', [start, end]);
                        }
                    }]
                },
                doneIndicatorsData:{
                    normTotal:0,
                    matched:0,
                    nomatched:0,
                    isfinished:false
                }
            }
        },
        computed:{
            pageOption: function () {
                return {
                    pageNo: this.pageNo+1,
                    pageSize: 10,
                    total: this.menuResultData.total
                }
            },
        },
        methods: {
            init(){
                this.getSqlResultWithQuery('selectComputerDetailByAssetCode',{asset_code:this.$route.query.asset_code}).then((data) => {
                    this.assetDetail = data.data.data[0];
                });
                this.refreshTableData();
                var self = this;
                this.initAllRecord();
                this.initRecordMonitor();
            },
            getShowColor(checkResult){
                if(checkResult == '0'||checkResult == '3'){
                    return 'color:#d30b0b !important'
                }
                if(checkResult == '1'||checkResult == '2'){
                    return 'color:#0f9c6c !important'
                }
            },
            pageChange(val) {
                this.pageNo = val-1;
                this.refreshTableData();
            },
            refreshTableData() {
                this.getSqlResultWithQuery('queryCheckNormDetailByAssetCode',{code:this.$route.query.asset_code,pageNo:this.pageNo*10,pageSize:10,where:this.where}).then((data) => {
                    this.menuResultData = data.data;
                });
            },
            initAllRecord() {
                var self = this;
                this.getSqlResultWithQuery('getKeepOnRecordInfo1',{asset_code:this.$route.query.asset_code}).then((data) => {
                    self.openPortRecord = [];
                    self.hostProtectRecord = [];
                    if(data.data && data.data.data){
                        for(var i in data.data.data){
                            var temp = data.data.data[i];
                            if(temp["b.norm_type"] == "OpenPorts"){
                                self.openPortRecord.push(temp);
                            }else if(temp["b.norm_type"] == "hostProtect"){
                                self.hostProtectRecord.push(temp);
                            }
                        }
                    }
                });
            },
            formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
            showHistroy(norm_code){
                this.currentNormCode = norm_code;
                var query = {
                    asset_code:this.$route.query.asset_code,
                    norm_code:norm_code,
                    where:" and 1 = 1"
                };
                this.getSqlResultWithQuery('queryNormHistoryResultByCodes',query).then((data) => {
                    this.historyCheckResultData = data.data;
                    this.dialog = true;
                });
            },
            confirmYes(item){
                this.$confirm('请确定是否人工设置合规?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    let data={
                        operater_host_code: item.operater_host_code,
                        norm_matched: 1,
                        asset_duty_name:this.currentUser.name,
                        norm_actual:"合规",
                        norm_code: item.norm_code,
                        norm_type:item.norm_type
                    };
                    this.confirmData(data);
                    this.getSqlResultWithQuery('queryCheckNormDetailByAssetCode',{code:this.$route.query.asset_code,pageNo:this.pageNo*10,pageSize:10,where:this.where}).then((data) => {
                        this.menuResultData = data.data;
                    });
                }).catch(() => {
                });
            },
            //不合规
//            doNotCheck(row,e){
//                this.dialogVisible=true;
//                this.rowData = row;
//            },
            confirmData(data){
                fetch({
                    url: '/api/sbox/confirm/'+data.operater_host_code,
                    method: 'post',
                    data:data
                }).then((data) => {
                    this.getSqlResultWithQuery('queryCheckNormDetailByAssetCode',{code:this.$route.query.asset_code,pageNo:this.pageNo*10,pageSize:10,where:this.where}).then((data) => {
                        this.menuResultData = data.data;
                    });
                });
            },
            //去查看任务跟踪、已办任务
            viewBpmn(val){
                this.$router.push({
                    path: '/soc/task-center/view-bpmn',
                    query:{
                        processDefinitionkey:val["a.process_definition_key"],
                        flowInstanceId:val["a.flow_instance_id"],
                        random: new Date().getTime()

                    }
                })
            },
            handleClick(tab, event) {
                if(this.normType == "hostProtect"){
                    this.where = "and norm_type = 'hostProtect' and norm_code <> 'BootPassword'";
                }else if(this.normType == "hostConfig"){
                    this.where = "and norm_type = 'hostConfig' and norm_code <> 'AdminAccess'";
                }else if(this.normType == "manualCheck"){
                    this.where = "and (norm_type in ('manualCheck','OpenPorts') or norm_code in ('BootPassword','AdminAccess'))";
                }
                this.pageNo = 0
                this.refreshTableData();
            },
            getHandlePerson(comments) {
                var arr = comments.split("/");
                if(arr.length>1){
                    return arr[0];
                }else{
                    return "";
                }
            },
            doSearch(){
                var query = {
                    asset_code:this.$route.query.asset_code,
                    norm_code:this.currentNormCode
                };
                var where = "";
                if(this.checkResult.value){
                    where = where + " and norm_matched = '"+this.checkResult.value+"' "
                }
                if(this.checkTime){
                    where = where + " and create_time > "+new Date(this.checkTime[0]).getTime()+" and create_time < " + new Date(this.checkTime[1]).getTime()
                }
                if(where){
                    query.where = where;
                }
                this.getSqlResultWithQuery('queryNormHistoryResultByCodes',query).then((data) => {
                    this.historyCheckResultData = data.data;
                    this.dialog = true;
                });
            },
            initRecordMonitor(){
                var self = this;
                async1.series([
                    function (call) {
                        //查询所有指标项
                        self.getSqlResultWithQuery('selectIndexTableDataForSbox', {
                            "where": "",
                            "page": 0,
                            "limit": 10
                        }).then((data) => {
                            self.doneIndicatorsData.normTotal = data.data.total;
                            call();
                        });
                    },
                    function (call) {
                        //查询所有已检查指标项
                        self.getSqlResultWithQuery('getMatchedNormByNormCode', {where: " and operater_host_code = '"+self.$route.query.asset_code + "' and norm_matched in (1,2)"}).then((data) => {
                            self.doneIndicatorsData.matched = data.data.total;
                            self.doneIndicatorsData.nomatched = self.doneIndicatorsData.normTotal - self.doneIndicatorsData.matched;
                            call();
                        });
                    }
                ],function () {
                    self.doneIndicatorsData.checkResult = Math.round(self.doneIndicatorsData.matched / self.doneIndicatorsData.normTotal * 100) + '%';
                    self.doneIndicatorsData.isfinished = true;
                })
            },
            getNormExpectedCategory(norm_code,norm_expected){
                if(norm_code == 'SecretLevel'){
                    return this.getCategoryData("asset_secret",norm_expected);
                }else if(norm_code == 'Purpose'){
                    return this.getCategoryData("asset_useage",norm_expected);
                }else if(norm_code == 'AllInOne' || norm_code == 'AntiVirus' || norm_code == 'HostAudit'|| norm_code == 'IdProtect'){
                    return "";
                }else{
                    return norm_expected;
                }
            },
            //不合规
            doNotCheck(row,e){
                var self = this;
                this.$prompt(row.norm_title+"不合规详细原因：", '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    inputValidator: function (value) {
                        if(!value){
                            return false;
                        }
                        if(value.length>100 || value.length<2){
                            return false
                        }else{
                            return true
                        }
                    },
                    inputErrorMessage: '备注信息长度必须在2到100个字节之间'
                }).then(({ value }) => {
                    let data={
                        operater_host_code: row.operater_host_code,
                        norm_matched: 0,
                        asset_duty_name:this.currentUser.name,
                        norm_comments:"不合规：" + value,
                        norm_code: row.norm_code,
                        norm_type: row.norm_type
                    };
                    this.confirmData(data);
                }).catch(() => {

                });
            },
            getNormComments(status,comments){
                return status == 0?comments:"";
            },
        },
        created() {
            this.currentUser = this.getCurrentUser();
            this.init();
        }
    }
</script>
<style>
    #historyNormDialog .el-dialog{
        height: 70%;
    }

    #historyNormDialog .el-dialog__body{
        height: 95%;
        overflow-y: auto;
    }
    .el-table .check-success {
        color: #08e69a!important;
    }
    .el-table .check-failed {
        color: #d30b0b!important;;
    }

    .elPadding {
        padding: 5px 15px;
    }
    .elPadding div{
        text-overflow: ellipsis!important;
        white-space: nowrap!important;
        overflow: hidden!important;
    }
    .elTitle {
        height: 30px;
        font-size: 15px;
        font-weight: bold;
        padding-left: 15px;
        padding-top: 5px;
    }
    .echartsContent {
        height: 160px;
        position: relative;
        margin: 0 5px;
    }
    .el-range-editor.el-input__inner{
        padding: 0px;
    }
    .task{
        line-height: 30px;
    }
    .el-table .cell{
        text-overflow: ellipsis!important;
        white-space: nowrap!important;
    }
    .buttonBack{
        float: right;
    }
    .el-message-box__input .el-input__inner{
        width: 320px;
    }
</style>
