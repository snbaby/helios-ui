<template>
    <div class="soc-main" id="runningMonitorSelf">
        <div class="soc-main-content">

            <mu-row style="width: 100%;">
                <font class="carouselTitle">密查客户端运行监控</font>
            </mu-row>
            <el-row style="width: 100%">
                <el-col :span="8">
                    <div class="borderStyle cardStyle">
                        <mu-row style="height: 100%;width: 100%">
                            <div style="width: 145px;height: 100%;padding: 100px 40px">
                                <div class="fontStyle" style="margin-bottom: 16px;">设备概况</div>
                                <div class="imgBackground-equipment"></div>
                                <div class="fontStyle" >在用</div>
                            </div>
                            <div style="width: calc(100% - 145px) !important;width 100%;height: 100%">
                                <el-form label-width="90px" label-position="left">
                                    <el-form-item label="设备总数：">
                                        <font class="buttonStyle" style="background-color: rgb(0,161,255);cursor: pointer;" @click="linkParameter">{{equepments.total}}</font>
                                    </el-form-item>
                                    <el-form-item :label="`${item.label}：`" v-for="item in getCategoryData('asset_network')" :key="item.code">
                                        <template v-if="networkarr.indexOf(item.code) > -1">
                                            <font v-for="that in equepments.aggs.asset_network.buckets" v-if="that.key == item.code" class="countStyle" @click="linkParameter" :key="that.key">{{that.doc_count}}/{{equepments.total}}</font>
                                        </template>
                                        <template v-else>
                                            <font>0</font>
                                        </template>
                                    </el-form-item>
                                    <el-form-item label="未联网：">
                                        <font :class="nonetwork!=0?'countStyle':''" @click="linkParameter">{{nonetwork}}/{{equepments.total}}</font>
                                    </el-form-item>
                                </el-form>
                            </div>
                        </mu-row>
                    </div>
                </el-col>
                <el-col :span="8">
                    <div class="borderStyle cardStyle">
                        <mu-row style="height: 100%;width: 100%">
                            <div style="width: 145px;height: 100%;padding: 100px 40px">
                                <div class="fontStyle" style="margin-bottom: 16px;">安装情况</div>
                                <div class="imgBackground-installation"></div>
                                <div class="fontStyle" >无上限</div>
                            </div>
                            <div style="width: calc(100% - 145px) !important;height: 100%">
                                <el-form label-width="90px" label-position="left">
                                    <el-form-item label="可安装：">
                                        <font class="buttonStyle" style="background-color: rgb(0,161,255);cursor: pointer;">{{canInstall.total}}</font>
                                    </el-form-item>
                                    <el-form-item label="已安装：">
                                        <font :class="hasInstall.total!=0?'countStyle':''"  @click="opDialog('hasInstall')">{{hasInstall.total}}</font>
                                    </el-form-item>
                                    <el-form-item label="未安装：">
                                        <font :class="notInstall.total!=0?'countStyle':''" @click="opDialog('notInstall')">{{notInstall.total}}</font>
                                    </el-form-item>
                                    <el-form-item label="金航网：">
                                        <font :class="hasInstall.jhw!=0?'countStyle':''">{{hasInstall.jhw}}/{{canInstall.jhw}}</font>
                                    </el-form-item>
                                    <el-form-item label="园区网：">
                                        <font :class="hasInstall.yqw!=0?'countStyle':''">{{hasInstall.yqw}}/{{canInstall.yqw}}</font>
                                    </el-form-item>
                                    <el-form-item label="工控网：">
                                        <font :class="hasInstall.gkw!=0?'countStyle':''">{{hasInstall.gkw}}/{{canInstall.gkw}}</font>
                                    </el-form-item>
                                    <el-form-item label="win_xp：">
                                        <font :class="hasInstall.win_xp!=0?'countStyle':''">{{hasInstall.win_xp}}/{{canInstall.win_xp}}</font>
                                    </el-form-item>
                                    <el-form-item label="win_server：">
                                        <font :class="hasInstall.win_server!=0?'countStyle':''">{{hasInstall.win_server}}/{{canInstall.win_server}}</font>
                                    </el-form-item>
                                    <el-form-item label="win7：">
                                        <font :class="hasInstall.win7!=0?'countStyle':''">{{hasInstall.win7}}/{{canInstall.win7}}</font>
                                    </el-form-item>
                                </el-form>
                            </div>
                        </mu-row>
                    </div>
                </el-col>
                <el-col :span="8">
                    <div class="borderStyle cardStyle">
                        <mu-row style="height: 100%;width: 100%">
                            <div style="width: 145px;height: 100%;padding: 100px 40px">
                                <div class="fontStyle" style="margin-bottom: 16px;">运行情况</div>
                                <div class="imgBackground-running"></div>
                                <div class="fontStyle" >{{running.abnormal == 0 ? '正常' : '异常'}}</div>
                            </div>
                            <div style="width: calc(100% - 145px) !important;width 100%;height: 100%">
                                <el-form label-width="90px" label-position="left">
                                    <el-form-item label="已安装：">
                                        <font class="buttonStyle" style="background-color: rgb(0,161,255);cursor: pointer;">{{hasInstall.total}}</font>
                                    </el-form-item>

                                    <el-form-item label="正常运行：">
                                        <font :class="running.normal!=0?'countStyle':''">{{running.normal}}</font>
                                    </el-form-item>
                                    <el-form-item label="异常运行：">
                                        <font :class="running.abnormal!=0?'countStyle':''">{{running.abnormal}}</font>
                                    </el-form-item>
                                    <el-form-item label="金航网：">
                                        <font :class="running.jhw!=0?'countStyle':''">{{running.jhw}}/{{running.abnormal}}</font>
                                    </el-form-item>
                                    <el-form-item label="园区网：">
                                        <font :class="running.yqw!=0?'countStyle':''">{{running.yqw}}/{{running.abnormal}}</font>
                                    </el-form-item>
                                    <el-form-item label="工控网：">
                                        <font :class="running.gkw!=0?'countStyle':''">{{running.gkw}}/{{running.abnormal}}</font>
                                    </el-form-item>
                                    <el-form-item label="win_xp：">
                                        <font :class="running.win_xp!=0?'countStyle':''">{{running.win_xp}}/{{running.abnormal}}</font>
                                    </el-form-item>
                                    <el-form-item label="win_server：">
                                        <font :class="running.win_server!=0?'countStyle':''">{{running.win_server}}/{{running.abnormal}}</font>
                                    </el-form-item>
                                    <el-form-item label="win7：">
                                        <font :class="running.win7!=0?'countStyle':''">{{running.win7}}/{{running.abnormal}}</font>
                                    </el-form-item>
                                </el-form>
                            </div>
                        </mu-row>
                    </div>
                </el-col>
            </el-row>
            <el-row style="width: 100%;margin-top: 10px;">
                <el-col :span="8">
                    <div class="warnStyle">
                        <font>统计信息显示：</font>
                        <font>联网类型计算机/计算机总数</font>
                    </div>
                </el-col>
                <el-col :span="8">
                    <div class="warnStyle">
                        <font>统计信息显示：</font>
                        <font>已安装总数/可安装总数</font>
                    </div>
                </el-col>
                <el-col :span="8">
                    <div class="warnStyle">
                        <font>统计信息显示：</font>
                        <font>分类异常数/异常总数</font>
                    </div>
                </el-col>
            </el-row>
        </div>
        <el-dialog :visible.sync="dialog" width="70%" id="historyNormDialog">
            <h6>{{labelText}}</h6>
            <mu-table :showCheckbox="false">
                <mu-thead slot="header">
                    <mu-tr>
                        <mu-th tooltip="序号" width="50">序号</mu-th>
                        <mu-th tooltip="责任部门">责任部门</mu-th>
                        <mu-th tooltip="主机编号">主机编号</mu-th>
                        <mu-th tooltip="主机密级">主机密级</mu-th>
                        <mu-th tooltip="主机用途">主机用途</mu-th>
                        <mu-th tooltip="IP地址">IP地址</mu-th>
                        <mu-th tooltip="操作系统">操作系统</mu-th>
                        <mu-th tooltip="责任人">责任人</mu-th>
                    </mu-tr>
                </mu-thead>
                <mu-tbody v-if="menuPersonData">
                    <mu-tr v-for="item,index in menuPersonData.rows" :key="item.org_name">
                        <mu-td width="50">{{index+1}}</mu-td>
                        <mu-td :title="item.org_name">{{item.org_name}}</mu-td>
                        <mu-td :title="item.asset_code">{{item.asset_code}}</mu-td>
                        <mu-td :title="getCategoryData('asset_secret',item.asset_secret?item.asset_secret:'')">{{getCategoryData('asset_secret',item.asset_secret?item.asset_secret:'')}}</mu-td>
                        <mu-td :title="getCategoryData('asset_useage',item.asset_secret?item.asset_useage:'')">{{getCategoryData('asset_useage',item.asset_secret?item.asset_useage:'')}}</mu-td>
                        <mu-td :title="item.asset_ip">{{item.asset_ip}}</mu-td>
                        <mu-td :title="item.asset_os">{{item.asset_os}}</mu-td>
                        <mu-td :title="item.asset_duty_name">{{item.asset_duty_name}}</mu-td>
                    </mu-tr>
                </mu-tbody>
            </mu-table>
            <div style="position: relative;bottom: -4px;text-align: center;" v-if="menuPersonData.total">
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
            <div class="norows" v-else style="text-align: center;margin-top:50px;">
                <font>暂无数据</font>
            </div>
        </el-dialog>
    </div>
</template>
<script>
    import {getSqlResult,getSqlResultWithQuery} from '@/api/sboxMonitor/runningMonitor/index.js';
    import async1 from "async";
    import pagination from '@/components/common/pagination.vue';
    const _ = require("underscore");
    export default {
        data(){
            return {
                equepments:{},
                labelText:"",
                canInstall:{
                    total:0,
                    jhw:0,
                    yqw:0,
                    gkw:0,
                    win_xp:0,
                    win_server:0,
                    win7:0
                },
                hasInstall:{
                    total:0,
                    jhw:0,
                    yqw:0,
                    gkw:0,
                    win_xp:0,
                    win_server:0,
                    win7:0,
                    list:[]
                },
                running:{
                    normal:0,
                    abnormal:0,
                    jhw:0,
                    yqw:0,
                    gkw:0,
                    win_xp:0,
                    win_server:0,
                    win7:0
                },
                notInstall:{
                    total:0,
                    list:[]
                },
                menuPersonData:{
                    pageNo:0,
                    pageSize:10,
                    total:0,
                    rows:[]
                },
                configDay:7,
                pageNo:0,
                pageSize:10,
                dialog:false,
                statusLabel:null
            }
        },
        components: {
            pagination
        },
        computed:{
            networkarr:function(){
                var arr = [];
                if(JSON.stringify(this.equepments) != JSON.stringify({})){
                    for(var i in this.equepments.aggs.asset_network.buckets){
                        arr.push(this.equepments.aggs.asset_network.buckets[i].key);
                    }
                }
                return arr;
             },
            nonetwork:function(){
                var count = 0;
                if(JSON.stringify(this.equepments) != JSON.stringify({})) {
                    for (var i in this.equepments.aggs.asset_network.buckets) {
                        count = count + this.equepments.aggs.asset_network.buckets[i].doc_count
                    }
                    return this.equepments.total - count;
                }else{
                    return 0;
                }
            },
            JHWCOUNT:function(){
                if(JSON.stringify(this.equepments) != JSON.stringify({})) {
                    for (var i in this.equepments.aggs.asset_network.buckets) {
                        if(this.equepments.aggs.asset_network.buckets[i].key == 'JHW'){
                            return this.equepments.aggs.asset_network.buckets[i].doc_count;
                        }
                    }
                }
            },
            pageOption: function () {
                return {
                    pageNo: this.pageNo+1,
                    pageSize: 10,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
            init(){
                getSqlResult('countEquipmentInuseByNetwork').then((data) => {
                    this.equepments = data.data;
                });
                getSqlResultWithQuery('countCanInstallSboxEquepments',{where:""}).then((data) => {
                    this.canInstall.total = data.data.total;
                });
                getSqlResultWithQuery('countCanInstallSboxEquepments',{where:"and asset_network = 'YQW'"}).then((data) => {
                    this.canInstall.yqw = data.data.total;
                });
                getSqlResultWithQuery('countCanInstallSboxEquepments',{where:"and asset_network = 'JHW'"}).then((data) => {
                    this.canInstall.jhw = data.data.total;
                });
                getSqlResultWithQuery('countCanInstallSboxEquepments',{where:"and asset_network = 'GKW'"}).then((data) => {
                    this.canInstall.gkw = data.data.total;
                });
                getSqlResultWithQuery('countCanInstallSboxEquepments',{where:"and asset_os like '%xp%'"}).then((data) => {
                    this.canInstall.win_xp = data.data.total;
                });
                getSqlResultWithQuery('countCanInstallSboxEquepments',{where:"and (asset_os like '%2000%' or asset_os like '%2003%' or asset_os like '%2008%' or asset_os like '%2012%')"}).then((data) => {
                    this.canInstall.win_server = data.data.total;
                });
                getSqlResultWithQuery('countCanInstallSboxEquepments',{where:"and asset_os like '%7%'"}).then((data) => {
                    this.canInstall.win7 = data.data.total;
                });

                getSqlResultWithQuery('countHasInstallSbox',{where:""}).then((data) => {
                    this.hasInstall.total = data.data.total;
                });
                getSqlResultWithQuery('countHasInstallSbox',{where:"and asset_network = 'YQW'"}).then((data) => {
                    this.hasInstall.yqw = data.data.total;
                });
                getSqlResultWithQuery('countHasInstallSbox',{where:"and asset_network = 'JHW'"}).then((data) => {
                    this.hasInstall.jhw = data.data.total;
                });
                getSqlResultWithQuery('countHasInstallSbox',{where:"and asset_network = 'GKW'"}).then((data) => {
                    this.hasInstall.gkw = data.data.total;
                });
                getSqlResultWithQuery('countHasInstallSbox',{where:"and asset_os like '%xp%'"}).then((data) => {
                    this.hasInstall.win_xp = data.data.total;
                });
                getSqlResultWithQuery('countHasInstallSbox',{where:"and (asset_os like '%2000%' or asset_os like '%2003%' or asset_os like '%2008%' or asset_os like '%2012%')"}).then((data) => {
                    this.hasInstall.win_server = data.data.total;
                });
                getSqlResultWithQuery('countHasInstallSbox',{where:"and asset_os like '%7%'"}).then((data) => {
                    this.hasInstall.win7 = data.data.total;
                });

                getSqlResultWithQuery('countSboxNormalRunning',{time:this.getComputeData(this.configDay)}).then((data) => {
                    this.running.normal = data.data.total;
                });

                getSqlResultWithQuery('countSboxAbnormalRunning',{time:this.getComputeData(this.configDay),where:''}).then((data) => {
                    this.running.abnormal = data.data.total;
                });
                getSqlResultWithQuery('countSboxAbnormalRunning',{time:this.getComputeData(this.configDay),where:"and asset_network = 'YQW'"}).then((data) => {
                    this.running.yqw = data.data.total;
                });
                getSqlResultWithQuery('countSboxAbnormalRunning',{time:this.getComputeData(this.configDay),where:"and asset_network = 'JHW'"}).then((data) => {
                    this.running.jhw = data.data.total;
                });
                getSqlResultWithQuery('countSboxAbnormalRunning',{time:this.getComputeData(this.configDay),where:"and asset_network = 'GKW'"}).then((data) => {
                    this.running.gkw = data.data.total;
                });
                getSqlResultWithQuery('countSboxAbnormalRunning',{time:this.getComputeData(this.configDay),where:"and asset_os like '%xp%'"}).then((data) => {
                    this.running.win_xp = data.data.total;
                });
                getSqlResultWithQuery('countSboxAbnormalRunning',{time:this.getComputeData(this.configDay),where:"and (asset_os like '%2000%' or asset_os like '%2003%' or asset_os like '%2008%' or asset_os like '%2012%')"}).then((data) => {
                    this.running.win_server = data.data.total;
                });
                getSqlResultWithQuery('countSboxAbnormalRunning',{time:this.getComputeData(this.configDay),where:"and asset_os like '%7%'"}).then((data) => {
                    this.running.win7 = data.data.total;
                });
                var self = this;
                async1.parallel([
                        function(callback){
                            getSqlResultWithQuery('getHasAuthorizationHost').then((data) => {
                                var arr = [];
                                if(data.data && data.data.rows){
                                    arr = _.pluck(data.data.rows,"asset_code");
                                }
                                callback("",arr);
                            });
                        },
                        function(callback){
                            getSqlResultWithQuery('countHasInstallSbox',{where:""}).then((data) => {
                                var arr = [];
                                if(data.data && data.data.data){
                                    arr = _.pluck(data.data.data,"asset_code");
                                }
                                self.hasInstall.list = arr;
                                callback("",arr);
                            });
                        }
                    ],
                    function(err, results){
                        if(results[0] && results[1]){
                            self.notInstall.total = _.difference(results[0],results[1]).length;
                            self.notInstall.list = _.difference(results[0],results[1]);
                        }else{
                            self.notInstall.total = results[0].length;
                            self.notInstall.list = results[0];
                        }
                    });
            },
            getComputeData(day){
                var now = Date.parse(new Date());
                var that =now - day*24*60*60*1000;
                return that;
            },
            linkParameter(){

            },
            linkDetail(query){
                this.$router.push({
                    path:"/secret/user/sboxMonitor/equepmentDetail",
                    query:query
                });
            },
            pageChange(val) {
                this.pageNo = val-1;
                this.toDetail();
            },
            opDialog(status){
                this.statusLabel = status;
                if(this.statusLabel == 'hasInstall'){
                    if(this.hasInstall.total == 0){
                        return false;
                    }
                    this.labelText = "已安装主机列表";
                }else{
                    if(this.notInstall.total == 0){
                        return false;
                    }
                    this.labelText = "未安装主机列表";
                }
                this.dialog = true;
                this.toDetail();
            },
            toDetail() {
                var query = "";
                if(this.statusLabel == 'hasInstall'){
                    if(this.pageNo*this.pageSize>=this.hasInstall.list.length){
                        query = "''";
                    }else{
                        var min = this.pageNo*this.pageSize;
                        var max = (this.pageNo+1)*this.pageSize;
                        max = (max<this.hasInstall.list.length)? max:this.hasInstall.list.length;
                        for(var i=min;i< max;i++){
                            query = query +  this.hasInstall.list[i] + ",";
                        }
                    }
                }else{
                    if(this.pageNo*this.pageSize>=this.notInstall.list.length){
                        query = "''";
                    }else{
                        var min = this.pageNo*this.pageSize;
                        var max = (this.pageNo+1)*this.pageSize;
                        max = (max<this.notInstall.list.length)? max:this.notInstall.list.length;
                        for(var i=min;i< max;i++){
                            query = query +  this.notInstall.list[i] + ",";
                        }
                    }
                }

                query = query.substring(0,query.length-1);
                var self = this;
                getSqlResultWithQuery('getComputers',{where:"where asset_code in (" + query + ")"}).then((data) => {
                    self.menuPersonData.rows = data.data.data;
                    if(this.statusLabel == 'hasInstall'){
                        self.menuPersonData.total = this.hasInstall.list.length;
                    }else{
                        self.menuPersonData.total = this.notInstall.list.length;
                    }

                });
            },
        },
        created() {
            this.init();
        },
        activated() {
            this.init();
        }
    }
</script>
<!--<style>
    #runningMonitorSelf .el-form-item__content{
        line-height: 1.5 !important;
    }
</style>-->
<style scoped>
    .allOverflow {
        height:calc(100% - 138px) !important;
        height: 100%;
        overflow-y: auto
    }

    .allPadding {
        width:100%;
        height:100%;
        padding: 0px 15px
    }

    .borderStyle {
        border: 1px solid #dddddd;
        border-radius: 8px;
        box-shadow: 7px 7px 0px #888888;
    }

    .carouselTitle {
        font-size: 18px;
        font-weight: bold;
        color: #666666;
        line-height: 72px;
    }

    .cardStyle {
        height: 380px;
        width: 374px;
        padding: 10px 0px;
    }

    ::-webkit-scrollbar{display:none}

    .imgBackground-equipment {
        height: 65px;
        width: 100%;
        background-image: url("/static/img/sbox/equipment.png");
        background-size: 100% 100%;
        margin-bottom: 16px;
    }

    .imgBackground-installation {
        height: 65px;
        width: 100%;
        background-image: url("/static/img/sbox/installation.png");
        background-size: 100% 100%;
        margin-bottom: 16px;
    }

    .imgBackground-running {
        height: 65px;
        width: 100%;
        background-image: url("/static/img/sbox/running.png");
        background-size: 100% 100%;
        margin-bottom: 16px;
    }

    .fontStyle {
        width: 100%;
        text-align: center;
        font-size: 14px;
        font-weight: bold;
        color: rgb(0,161,255);
    }

    .fontPosition {
        width: 100%;
        margin-top: 12px
    }

    .fontLeft {
        font-size: 14px;
        color: #a6a6a6;
    }

    .highFont {
        color:#d30b0b;
    }

    .buttonStyle {
        height: 30px;
        width: 40px;
        color: #ffffff;
        border: 1px solid;
        border-radius: 8px;
        position: absolute;
        text-align: center;
        line-height: 30px;
    }

    .el-form-item {
        margin-bottom: 0px !important;
    }

    .countStyle {
        cursor: pointer;
        color: #004ea2;
    }

    .warnStyle {
        height: 100px;
        width: 374px;
        padding: 10px 0px;
        text-align: center;
    }
</style>
