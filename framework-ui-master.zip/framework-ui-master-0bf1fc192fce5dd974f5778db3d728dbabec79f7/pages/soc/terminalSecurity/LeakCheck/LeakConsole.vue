<template>
    <div class="allOverflow">
        <div class="allPadding">
            <el-row :gutter="20">
                <el-col :span="8">
                    <div class="borderStyle" style="height: 320px;">
                        <div class="titleHeader">
                            <font>主机当前风险</font>
                        </div>
                        <host-risk class="hasTitleContent" v-if="riskShow" :riskNum="riskNum" line-ref="currentRiskValue">
                        </host-risk>
                        <div class="fontCurrentRisk">
                            <div class="riskFont">当前风险值：<font class="fontCurrentRiskNum">{{riskNum}}</font>
                            </div>
                        </div>
                    </div>
                </el-col>
                <el-col :span="16"style="height: 320px;">
                    <div class="borderStyle" style="height: 100%">
                        <div class="titleHeader">
                            <font>主机风险趋势</font>
                        </div>
                        <div class="hasTitleContent">
                            <echarts-line lineRef="lineOne" :countData="riskCount" v-if="riskCountShow">

                            </echarts-line>
                        </div>
                    </div>
                </el-col>
            </el-row>
            <mu-row style="width: 100%;">
                <font class="carouselTitle">涉密应用系统风险概况</font>
            </mu-row>
            <el-row :gutter="20">
                <template v-for="item,index in ERPSystems">
                    <el-col :span="8" v-if="index%3 === 0">
                        <div class="borderStyle cardLeft">
                            <system-risk-profile :ERPSystem=item></system-risk-profile>
                        </div>
                    </el-col>
                    <el-col :span="8" v-else-if="index%3 === 1">
                        <div class="borderStyle cardCenter">
                            <system-risk-profile :ERPSystem=item></system-risk-profile>
                        </div>
                    </el-col>
                    <el-col :span="8" v-else-if="index%3 === 2">
                        <div class="borderStyle cardRight">
                            <system-risk-profile :ERPSystem=item></system-risk-profile>
                        </div>
                    </el-col>
                </template>
            </el-row>
            <mu-row  class="borderStyle">
                <el-col :span="6" style="height: 320px;">
                    <echarts-bar name="近30天扫描情况" lineRef="barOne" :num="scanThirtyNum"></echarts-bar>
                </el-col>
                <el-col :span="18">
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie line-ref="barOne" :name="hostData[0].name" :num="hostData[0].data"></situation-use-pie>
                        </div>
                    </el-col>
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie line-ref="barTwo" :name="hostData[1].name" :num="hostData[1].data"></situation-use-pie>
                        </div>
                    </el-col >
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie line-ref="barThree" :name="hostData[2].name" :num="hostData[2].data"></situation-use-pie>
                        </div>
                    </el-col >
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie line-ref="barFour" :name="hostData[3].name" :num="hostData[3].data"></situation-use-pie>
                        </div>
                    </el-col>
                </el-col>
            </mu-row>
            <mu-row style="height: 320px;width: 100%;margin-top: 20px" class="borderStyle">
                <el-col :span="6" style="height: 320px;">
                    <echarts-bar name="近30天整改情况" lineRef="barTwo"></echarts-bar>
                </el-col>
                <el-col :span="18">
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie-two line-ref="EchartsPieTwoOne" name="服务器整改率"></situation-use-pie-two>
                        </div>
                    </el-col>
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie-two line-ref="EchartsPieTwoTwo" name="台式计算机整改率"></situation-use-pie-two>
                        </div>
                    </el-col>
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie-two line-ref="EchartsPieTwoThree" name="交换机整改率"></situation-use-pie-two>
                        </div>
                    </el-col>
                    <el-col :span="6">
                        <div style="height: 320px;width: 100%">
                            <situation-use-pie-two line-ref="EchartsPieTwoFour" name="打印机整改率"></situation-use-pie-two>
                        </div>
                    </el-col>
                </el-col>
            </mu-row>
            <el-row style="margin-top: 20px" :gutter="20">
                <el-col :span="12">
                    <div style="height: 296px" class="borderStyle">
                        <div class="titleHeader">
                            <font>新增高危漏洞趋势</font>
                        </div>
                        <div class="hasTitleContent">
                            <echartsLine lineRef="lineTwo" :countData="vulCount" v-if="vulCountShow"></echartsLine>
                        </div>
                    </div>
                </el-col>
                <el-col :span="12">
                    <div style="height: 296px" class="borderStyle">
                        <div class="titleHeader">
                            <font>新增高危主机趋势</font>
                        </div>
                        <div class="hasTitleContent">
                            <echartsLine :countData="highRiskHost" lineRef="lineThree" v-if="highRiskHostShow"></echartsLine>
                        </div>
                    </div>
                </el-col>
            </el-row>
            <el-row style="margin-top: 20px" :gutter="20">
                <el-col :span="12">
                    <div style="height: 230px" class="borderStyle">
                        <div class="titleHeader">
                            <font>近30天新增高危漏洞TOP5</font>
                            <font class="fontMore">更多>></font>
                        </div>
                        <div class="hasTitleContent">
                            <mu-row v-for="message,index in loopholeTop" :key="index" class="fontTop">
                                <mu-col width="5" tablet="5" desktop="5">
                                    {{index + 1}}
                                </mu-col>
                                <mu-col width="80" tablet="80" desktop="80">
                                    {{message.name}}
                                </mu-col>
                                <mu-col width="5" tablet="5" desktop="5">
                                    {{message.risk}}
                                </mu-col>
                            </mu-row>
                        </div>
                    </div>
                </el-col>
                <el-col :span="12">
                    <div style="height: 230px" class="borderStyle">
                        <div class="titleHeader">
                            <font>近30天新增高危主机TOP5</font>
                            <font class="fontMore">更多>></font>
                        </div>
                        <div class="hasTitleContent">
                            <mu-row v-for="message,index in hostTop" :key="index" class="fontTop">
                                <mu-col width="5" tablet="5" desktop="5">
                                    {{index + 1}}
                                </mu-col>
                                <mu-col width="80" tablet="80" desktop="80">
                                    {{message.name}}
                                </mu-col>
                                <mu-col width="5" tablet="5" desktop="5">
                                    {{message.number}}
                                </mu-col>
                            </mu-row>
                        </div>
                    </div>
                </el-col>
            </el-row>
        </div>
    </div>
</template>
<script>
    import echarts  from "echarts";
    import echartsLine from "@/components/echartsCommon/echartsLine.vue";
    import echartsBar from "@/components/echartsCommon/echartsBar.vue";
    import echartsPie from "@/components/echartsCommon/echartsPie.vue";
    import hostRisk from "@/components/echartsCommon/hostRisk.vue";
    import echartsPieTwo from "@/components/echartsCommon/echartsPieTwo.vue";
    import systemRiskProfile from "@/components/echartsCommon/systemRiskProfile.vue";
    import situationUsePieTwo from "@/components/echartsCommon/situationUsePieTwo.vue";
    import SituationUsePie from "@/components/echartsCommon/situationUsePie";
    import {selectHostResultByTypeTime,selectHostResultByTypeTimeRisk,selectTopFiveByScanStore} from "@/api/safety/userHome/index.js";
    import {HostRisk,selectHostRiskTrend,selectNewVul,addHighRiskHost,countZheng} from "@/api/terminalSecurity/leakCheck/index.js"
    import async1 from "async";

    export default {

        data(){
            return {
                riskNum: null,
                riskShow: false,
                riskTime: 30,//主机风险统计天数
                riskCount: {
                    time: [],
                    count: []
                },
                riskCountShow: false,
                vulTime: 30,//新增高危漏洞统计天数
                vulCount: {
                    time: [],
                    count: []
                },
                vulCountShow: false,
                highRiskHost:{
                    time: [],
                    count: []
                },
                highRiskTime: 30,
                highRiskHostShow: false,
                ERPSystems: [{
                    currentRisk: 1.97,
                    company: '研发部1',
                    associatedHost: '7',
                    highRiskHosts: '1',
                    hosts: '2',
                    highRiskVulnerability: '1',
                    riskVulnerability: '2',
                    times: '2018 02-07 10:56:57',
                },{
                    currentRisk: 5,
                    company: '研发部2',
                    associatedHost: '7',
                    highRiskHosts: '1',
                    hosts: '2',
                    highRiskVulnerability: '1',
                    riskVulnerability: '2',
                    times: '2018 02-07 10:56:57',
                },{
                    currentRisk: 7,
                    company: '研发部3',
                    associatedHost: '7',
                    highRiskHosts: '1',
                    hosts: '2',
                    highRiskVulnerability: '1',
                    riskVulnerability: '2',
                    times: '2018 02-07 10:56:57',
                }],
                loopholeTop: [],
                hostTop: [],
                hostData: [{
                    name: '服务器',
                    data: []
                },{
                    name: '台式计算机',
                    data: []
                }, {
                    name: '交换机',
                    data: []
                },{
                    name:'打印机',
                    data: []
                }],
                scanThirtyNum: [],
                time: new Date().getTime() - 86400000*30,
                hostType: [2010103,2010104,2010202,2010601],
                riskType: ['高危','中危','低危'],
            }
        },
        components: {
            SituationUsePie,
            echartsLine,
            systemRiskProfile,
            echartsBar,
            echartsPie,
            echartsPieTwo,
            situationUsePieTwo,
            hostRisk,
        },
        mounted(){
        },
        methods: {
            //新增高危主机趋势
            addHighRiskHost() {
                let query= {
                    time: this.highRiskTime
                };
                addHighRiskHost(query).then(data => {
                    if(data.status == 200){
                        for(let i = data.data.length-1 ; i >=0; i--){
                            let time = data.data[i].date.substring(8,10)+"/"+data.data[i].date.substring(5,7);
                            this.highRiskHost.time.push(time);
                            this.highRiskHost.count.push(data.data[i].count);
                        }
                        this.highRiskHostShow = true;
                    }
                })
            },
            countZheng() {
                const that = this;
                async1.map(that.hostType,function(item,callBack){
                    let query = {
                        type: item,
                    };
                    countZheng(query).then((data)=>{
                        if(data.status == 200){
                        }else{
                            callBack(null);
                        }
                    });
                }, function(err, results) {
                    if(err){
                        console.log(err);
                    }else{

                    }
                });
            },
            //近30天扫描情况
            selectHostResultByTypeTime() {
                const that = this;
                async1.map(that.hostType,function(item,callBack){
                    let query = {
                        type: item,
                        time: that.time
                    };
                    selectHostResultByTypeTime(query).then((data)=>{
                        if(data.status == 200){
                            callBack(null,data.data.aggs['COUNT(DISTINCT asset_code)'].value);
                        }else{
                            callBack(null);
                        }
                    });
                }, function(err, results) {
                    if(err){
                        console.log(err);
                    }else{
                        that.scanThirtyNum = results;
                    }
                });
            },
            selectHostResultByTypeTimeRisk() {
                const that = this;
                for(let i in that.hostType){
                    async1.map(that.riskType,function (name,callBack) {
                        let query = {
                            type: that.hostType[i],
                            time: that.time,
                            name: name
                        };
                        selectHostResultByTypeTimeRisk(query).then(data => {
                            if(data.status == 200){
                                callBack(null, {
                                        value: data.data.aggs['COUNT(DISTINCT asset_code)'].value,
                                        name: name
                                    }
                                );
                            }else {
                                callBack(null);
                            }
                        })
                    },function (err,results) {
                        if(err){
                            console.log(err);
                        }else{
                            that.hostData[i].data = results;
                        }
                    })
                }
            },
            selectTopFiveByScanStore(){
                let query = {
                    time: this.time,
                    page: 0,
                    size: 5
                };
                selectTopFiveByScanStore(query).then(data => {
                    if(data.status == '200'){
                        this.loopholeTop = data.data.data;
                    }
                })
            },

            //主机当前风险
            HostRisk(){
                HostRisk().then(data => {
                    if(data.status == 200){
                        this.riskNum = data.data;
                        this.riskShow = true;
                    }
                })
            },
            //主机30天风险统计
            selectHostRiskTrend(){
                let query = {
                    time: this.riskTime
                };
                selectHostRiskTrend(query).then(data => {
                    if(data.status == 200){
                        for(let i = data.data.length-1 ; i >=0; i--){
                            let time = data.data[i].date.substring(8,10)+"/"+data.data[i].date.substring(5,7);
                            this.riskCount.time.push(time);
                            this.riskCount.count.push(data.data[i].risk);
                        }
                        this.riskCountShow = true;
                    }
                })
            },
            //新增高危漏洞30天统计
            selectNewVul(){
                let query = {
                    time: this.vulTime
                };
                selectNewVul(query).then(data => {
                    if(data.status == 200){
                        for(let i = data.data.length-1 ; i >=0; i--){
                            let time = data.data[i].date.substring(8,10)+"/"+data.data[i].date.substring(5,7);
                            this.vulCount.time.push(time);
                            this.vulCount.count.push(data.data[i].count);
                        }
                        this.vulCountShow = true;
                    }
                })
            }
        },
        created(){
            this.HostRisk();
            this.selectHostRiskTrend();
            this.selectNewVul();

            this.selectHostResultByTypeTime();
            this.selectHostResultByTypeTimeRisk();
            this.selectTopFiveByScanStore();
            this.addHighRiskHost();
            this.countZheng();
        },
        activated(){
        }
    }
</script>

<style scoped>
    .allOverflow {
        height:calc(100% - 138px) !important;
        height: 100%;
        overflow-y: auto
    }

    .allPadding {
        width:100%;
        height:100%;
        padding: 0px 15px
    }

    .riskFont {
        text-align: center;
    }

    .borderStyle {
        border: 1px solid #e5e5e5;
        border-radius: 8px;
    }

    .titleHeader {
        padding-left: 20px;
        height: 48px;
        width: 100%;
        border-bottom: 1px solid #e5e5e5;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        line-height: 48px;
    }

    .hasTitleContent {
        width: 100%;
        height: calc(100% - 48px) !important;
        height: 100%;
    }

    .carouselTitle {
        font-size: 18px;
        font-weight: bold;
        color: #666666;
        line-height: 72px;
    }

    .cardLeft {
        margin-bottom: 20px;
    }

    .cardCenter {
        margin: auto;
        margin-bottom: 20px;
    }

    .cardRight {
        margin-bottom: 20px
    }

    .fontMore{
        color: rgb(93,158,250);
        font-weight: normal;
        float: right;
        font-size: 14px;
        padding-right: 20px;
        cursor: pointer;
    }

    .fontTop {
        padding: 12px 20px 0px 20px;
    }

    .fontCurrentRisk {
        margin-top: -52px;
        color: #00a1ff;
        height: 25px;
        line-height: 9px;
    }

    .fontCurrentRiskNum {
        font-size: 25px;
        color: #1f67fb;
    }

    ::-webkit-scrollbar{display:none}
</style>
