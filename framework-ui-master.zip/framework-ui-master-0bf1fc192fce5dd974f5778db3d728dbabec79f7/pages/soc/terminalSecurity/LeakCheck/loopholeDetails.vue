<template>
    <div>
        <div class="margin"><el-button class="buttonBack" @click="$router.back(-1)">返 回</el-button></div>
        <el-col :span="18">
            <el-row class="titleBox">
                <font class="fontTitle">漏洞指标详情</font>
                <font class="records" @click="openDialog">备案</font>
            </el-row>
            <el-row>
                <el-form label-width="100px" label-position="right">
                    <el-row v-if="vulData.isRecord">
                        <el-col :span="8">
                            <el-form-item label="是否备案:">
                                已备案
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="备案系统:">
                                <label>{{vulData.osTypes.toString()}}</label>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="备案原因:">
                                {{vulData.reason}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="漏洞ID:">
                                {{vulData.vul_id}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="CVEID:">
                                {{vulData.cve_id}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="发布日期:">
                                {{timestampToTime(vulData.discover_date)}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="最近发现日期:">
                                {{timestampToTime(vulData.modify_time)}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="风险值:">
                                {{vulData.risk}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="漏洞等级:">
                                {{vulData.severity_grade}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="8">
                            <el-form-item label="发现主机数:">
                                {{this.menuLoopholeData.total||0}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="涉密主机数:">
                                {{num}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="漏洞名称:">
                                {{vulData.name}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="漏洞描述:">
                                {{vulData.description}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="解决方案:">
                                {{vulData.solution}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </el-row>
            <el-row class="titleBox" >
                <font class="fontTitle">主机漏洞分布</font>
            </el-row>
            <div>
                <el-table :data="menuLoopholeData">
                    <el-table-column
                        type="index"
                        width="50"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="org_name"
                        label="责任部门"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="asset_code"
                        label="主机编号"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="asset_ip"
                        label="扫描IP"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="scope"
                        label="主机密级"
                        show-overflow-tooltip>
                        <template slot-scope="scope">
                            {{getCategoryData('asset_secret',scope.row.asset_secret)}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="name"
                        label="主机用途"
                        show-overflow-tooltip>
                        <template slot-scope="scope">
                            {{getCategoryData('asset_useage',scope.row.asset_useage)}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="asset_os"
                        label="操作系统"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="asset_duty_name"
                        label="责任人"
                        show-overflow-tooltip>
                    </el-table-column>
                </el-table>
            </div>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </el-col>
        <el-col :span="6">
            <mu-row>
                <situation-use-pie-three line-ref="EchartsPieThree" :pieData="osData.data" :isTrue="osData.isTrue" name="操作系统分布"></situation-use-pie-three>
            </mu-row>
            <mu-row>
                <situation-use-pie-three line-ref="EchartsPieThree" :pieData="typeData.data" :isTrue="typeData.isTrue" name="主机类型分布"></situation-use-pie-three>
            </mu-row>
            <mu-row>
                <situation-use-pie-three line-ref="EchartsPieThree" :pieData="secreData.data" :isTrue="secreData.isTrue" name="主机密级分布"></situation-use-pie-three>
            </mu-row>
            <mu-row>
                <situation-use-pie-three line-ref="EchartsPieThree" :pieData="useageData.data" :isTrue="useageData.isTrue" name="主机用途分布"></situation-use-pie-three>
            </mu-row>
        </el-col>
        <div>
            <el-dialog title="漏洞指标备案" :visible.sync="dialogFormVisible">
                <el-form label-width="100px">
                    <el-form-item label="是否备案:" >
                        <el-switch
                            v-model="isRecord"
                            @change="switchChange"
                        >
                        </el-switch>
                    </el-form-item>
                    <el-form-item label="漏洞ID:" >
                        {{$route.query.vulId}}
                    </el-form-item>
                    <el-form-item label="操作系统:" >
                        <el-select v-model="osTypes" multiple placeholder="请选择"  style="width: 700px" :disabled="!isRecord">
                            <el-option
                                v-for="item in osOptions"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="备案理由:" >
                        <el-input type="textarea" v-model="reason" style="width: 700px" :disabled="!isRecord"></el-input>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="save">确 定</el-button>
                </div>
            </el-dialog>
        </div>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import situationUsePieThree from "@/components/echartsCommon/situationUsePieThree.vue";
    import {selectScanStore,selectFlawById,selectScanClassifiedComNum,
        selectFlawResultDistribution, queryOsType,esUpdate,countType} from "@/api/terminalSecurity/leakCheck/index.js";

    export default {
        name: "loopholeDetails",
        components: {
            pagination,
            situationUsePieThree
        },
        data() {
            return {
                vulData:{},
                pageNo: 1,
                menuLoopholeData: [],
                osData: {
                    data: [],
                    isTrue: false
                },
                typeData: {
                    data: [],
                    isTrue: false
                },
                secreData: {
                    data: [],
                    isTrue: false
                },
                useageData: {
                    data: [],
                    isTrue: false
                },
                total: 0,
                num: '',
                vul_id: this.$route.query.vulId,
                dialogFormVisible: false,
                isRecord: false,
                osTypes: [],
                osOptions: [],
                reason: '',
            }
        },
        computed: {
            pageOption(){
                return {
                    pageNo:this.pageNo,
                    pageSize:10,
                    total:this.total||0,
                }
            }
        },
        created() {
            this.getStoreDetail();
            this.selectDistribution();
            this.doSearch();
        },
        methods: {
            getStoreDetail(){
                let query={
                    page:0,
                    size:1,
                    where: 'where vul_id=\''+this.$route.query.vulId+'\''
                };
                selectScanStore(query).then((data)=>{
                    if(data.status == '200') {
                        this.vulData = data.data.data[0];
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取漏洞信息错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
            },
            doSearch() {
                let query = {
                    pageSize: 10,
                    pageNo:this.pageNo,
                    vul_id: this.$route.query.vulId
                };
                selectFlawById(query).then((data)=>{
                    if(data.status == 200) {
                        this.menuLoopholeData = data.data.data[0][this.vul_id];
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取主机信息错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                selectScanClassifiedComNum({'id': this.$route.query.vulId}).then(data=>{
                    if(data.status == 200) {
                        this.num = data.data.aggs['COUNT(*)'].value;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取涉密主机数错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
            },
            selectDistribution() {
                let query = {
                    vulId: this.$route.query.vulId,
                    type: "asset_os"
                };
                let query2 = {
                    vulId: this.$route.query.vulId,
                    type: "asset_type"
                };
                let query3 = {
                    vulId: this.$route.query.vulId,
                    type: "asset_secret"
                };
                let query4 = {
                    vulId: this.$route.query.vulId,
                    type: "asset_useage"
                };
                countType(query).then(data=>{
                    if(data.status == "200") {
                        let arry = data.data;
                        for (let i in arry) {
                            this.osData.data.push({
                                value: arry[i],
                                name: i
                            })
                        }
                        this.osData.isTrue = true;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '按操作系统分类统计错误'
                        });
                    }
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                countType(query2).then(data=>{
                    if(data.status == "200") {
                        let arry = data.data;
                        for (let i in arry) {
                            this.typeData.data.push({
                                value: arry[i],
                                name: this.getCategoryData('gb_asset_entry',i)
                            })
                        }
                        this.typeData.isTrue = true;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '按主机类型分类统计错误'
                        });
                    }
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                countType(query3).then(data=>{
                    if(data.status == "200") {
                        let arry = data.data;
                        for (let i in arry) {
                            this.secreData.data.push({
                                value: arry[i],
                                name: this.getCategoryData('asset_secret',i)
                            })
                        }
                        console.log(this.secreData.data);
                        this.secreData.isTrue = true;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '按主机密级分类统计错误'
                        });
                    }
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                countType(query4).then(data=>{
                    if(data.status == "200") {
                        let arry = data.data;
                        for (let i in arry) {
                            this.useageData.data.push({
                                value: arry[i],
                                name: this.getCategoryData('asset_useage',i)
                            })
                        }
                        this.useageData.isTrue = true;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '按主机用途分类统计错误'
                        });
                    }
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
            },
            pageChange(val){
                this.pageNo=val;
                this.doSearch();
                this.osData.isTrue = false;
                this.typeData.isTrue = false;
                this.secreData.isTrue = false;
                this.useageData.isTrue = false;
                this.selectDistribution();
            },
            openDialog(){
                const self = this;

                if(self.vulData.isRecord){
                    self.isRecord = self.vulData.isRecord;
                }else{
                    self.isRecord = false;
                }

                if(self.vulData.osTypes){
                    self.osTypes = self.vulData.osTypes;
                }else{
                    self.osTypes = [];
                }

                self.osOptions = [];
                if(self.vulData.reason){
                    self.reason = self.vulData.reason;
                }else{
                    self.reason = '';
                }
                queryOsType().then(res=>{
                    res.data.aggs.asset_os.buckets.forEach(option=>{
                        self.osOptions.push({
                            value: option.key,
                            label: option.key,
                        })
                    })
                    this.dialogFormVisible = true;
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: '获取操作系统类型错误'
                    });
                })
            },
            save(){
                const self = this;
                const indexName = 'soc_flaw_scan';
                const type = 'flaw_scan_store';
                const uid = this.$route.query.vulId;
                const params = {
                    isRecord: self.isRecord,
                    osTypes: self.osTypes,
                    reason: self.reason
                }
                esUpdate(indexName,type,uid,params).then(res=>{
                    setTimeout(()=>{
                        self.getStoreDetail();
                    },2000);
                    self.dialogFormVisible = false;
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: '更新备案状态失败'
                    });
                })
            },
            switchChange(){
                if(!this.isRecord){
                    this.osTypes = [];
                    this.reason = '';
                }
            }
        }
    }
</script>

<style scoped>
    .margin{
        height: 35px;
        width: 100%;
    }

    .titleBox {
        height: 32px;
        background-color: #bbbbbb;
        width: 100%;
    }

    .fontTitle {
        font-size: 16px;
        color: #333;
        line-height: 32px;
        padding-left: 20px;
    }

    .records {
        float:right;
        font-size: 16px;
        color: #004ea2;
        line-height: 32px;
        padding-right: 20px;
        cursor: pointer;
    }

    .buttonBack {
        float:right;
        margin-top: 5px;
    }

</style>

