<template>
    <div class="framework-content">
        <div>
            <el-table :data="menuLoopholeData.rows">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="等级名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="riskGrade"
                    label="等级级别"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="description"
                    label="等级描述"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="code"
                    label="等级编号"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="minRisk"
                    label="最小风险值"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="maxRisk"
                    label="最大风险值"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="edit(scope.row,scope.$index)"
                            type="text"
                            size="small">
                            修改
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <el-dialog title="漏洞等级" :visible.sync="isdialog" width="60%">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="等级名称" >
                            <el-input v-model="ruleForm.name"  :disabled="true"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="等级级别">
                            <el-input v-model="ruleForm.riskGrade"  :disabled="true"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="等级描述" prop="description">
                            <el-input v-model="ruleForm.description"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item label="最小风险值" prop="minRisk">
                            <el-input type="number" v-model.number="ruleForm.minRisk"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <el-form-item label="最大风险值" prop="maxRisk">
                            <el-input type="number" v-model.number="ruleForm.maxRisk"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="isdialog = false">取 消</el-button>
                <el-button @click="changeLevelConfig('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {selectPage,addConfig,changeConfig,deleteConfig} from '@/api/safety/userHome/index.js';

    export default {
        components: {
            pagination,
        },
        data() {
            var validate = (rule, value, callback) => {
                if(value < 0){
                    callback(new Error('不能为负'));
                }
                for(let i in this.menuLoopholeData.rows){
                    if(i != this.changeIndex){
                        if(value< this.menuLoopholeData.rows[i].maxRisk && value>=this.menuLoopholeData.rows[i].minRisk){
                            callback(new Error('区间重合'));
                        }
                    }
                }
                callback();
            };

            var validate2 = (rule, value, callback) => {
                if(value < 0){
                    callback(new Error('不能为负'));
                }
                if (value < this.ruleForm.minRisk) {
                    callback(new Error("最大值不能小于最小值"));
                }
                for(let i in this.menuLoopholeData.rows){
                    if(i != this.changeIndex){
                        // if(value< this.menuLoopholeData.rows[i].maxRisk && value>this.menuLoopholeData.rows[i].minRisk){
                        //     callback(new Error('区间重合'));
                        // }else if(value >= this.menuLoopholeData.rows[i].maxRisk || this.ruleForm.minRisk<= this.menuLoopholeData.rows[i].minRisk){
                        //     callback(new Error('区间重合'));
                        // }
                        if( !((value<=this.menuLoopholeData.rows[i].minRisk && this.ruleForm.minRisk<this.menuLoopholeData.rows[i].minRisk) ||
                            (value>=this.menuLoopholeData.rows[i].maxRisk && this.ruleForm.minRisk>=this.menuLoopholeData.rows[i].maxRisk))
                        ){
                            callback(new Error('区间重合'));
                        }
                    }
                }
                callback();
            };
            return {
                ruleForm:{
                },
                menuLoopholeData: [],
                dialog: false,
                isdialog: false,
                pageNo: 1,
                rules: {
                    description: [
                        {
                            required: true,
                            message: "等级描述不能为空",
                            trigger: "change"
                        }
                    ],
                    minRisk: [
                        { required: true, message: '最小值不能为空'},
                        { validator: validate, required: true,trigger: "blur" }
                    ],
                    maxRisk: [{ required: true, message: '最小值不能为空'},
                        { validator: validate2, required: true,trigger: "blur" }]
                },
                changeIndex: 0,
            }
        },
        computed: {
            pageOption(){
                return {
                    pageNo:this.pageNo,
                    pageSize:10,
                    total:this.menuLoopholeData.total||0,
                }
            }
        },
        methods: {
            edit(item,index){
                this.isdialog = true;
                this.ruleForm = {
                    maxRisk: item.maxRisk,
                    minRisk: item.minRisk,
                    name: item.name,
                    id: item.id,
                    riskGrade: item.riskGrade,
                    description: item.description,
                };
                this.changeIndex = index;
            },
            toSearch() {
                this.pageNo = 1;
                this.doSearch();
            },
            doSearch() {
                let query = {
                    page: this.pageNo,
                    limit: 10,
                };
                selectPage(query).then((data)=>{
                    if(data.status == '200') {
                        this.menuLoopholeData = data.data;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '系统失败'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '访问失败'
                    });
                });
            },
            add(){
                this.ruleForm = {};
                this.dialog = true;
            },
            addLevelConfig() {
                addConfig(this.ruleForm).then((data)=>{
                    if(data.status== '200'){
                        this.doSearch();
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '添加失败'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '访问失败'
                    });
                });
                this.dialog = false;
            },
            changeLevelConfig(formName) {
                this.$refs[formName].validate((valid) => {
                    if(valid) {
                        this.ruleForm.maxRisk =  Math.round(this.ruleForm.maxRisk*100)/100;
                        this.ruleForm.minRisk =  Math.round(this.ruleForm.minRisk*100)/100;
                        changeConfig(this.ruleForm).then((data) => {
                            if (data.status == '200') {
                                this.$notify.success({
                                    title: '成功',
                                    message: '修改成功'
                                });
                                this.doSearch();
                            } else {
                                this.$notify.error({
                                    title: '错误',
                                    message: '修改失败'
                                });
                            }
                        }).catch(err => {
                            this.$notify.error({
                                title: '错误',
                                message: '访问失败'
                            });
                        });
                        this.isdialog = false;
                    }else {
                        return false
                    }
                })
            },
            deleteConfig(code){
                deleteConfig(code).then((data)=>{
                    if(data.status == '200') {
                        this.doSearch();
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '删除失败'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '访问失败'
                    });
                });
            }
        },
        created(){
            this.doSearch();
        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }
</style>
