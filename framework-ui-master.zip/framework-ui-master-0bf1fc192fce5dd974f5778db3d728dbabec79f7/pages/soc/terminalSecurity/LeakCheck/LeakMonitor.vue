<template>
    <div class="framework-content">
        <el-row style="width: 100%;height: 320px;">
            <el-col :span="6" style="height: 320px;">
                <situation-use-pie-two name="本月扫描进度" lineRef="barTwo" :pieData="allData.data" :isTrue="allData.isTrue"></situation-use-pie-two>
            </el-col>
            <el-col :span="18">
                <el-col :span="6">
                    <div style="height: 320px;width: 100%">
                        <situation-use-pie-two line-ref="EchartsPieTwoOne" :pieData="serverData.data" :isTrue="serverData.isTrue" name="服务器扫描率"></situation-use-pie-two>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div style="height: 320px;width: 100%">
                        <situation-use-pie-two line-ref="EchartsPieTwoTwo" :pieData="desktopData.data" :isTrue="desktopData.isTrue" name="台式计算机扫描率"></situation-use-pie-two>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div style="height: 320px;width: 100%">
                        <situation-use-pie-two line-ref="EchartsPieTwoThree" :pieData="switcheData.data" :isTrue="switcheData.isTrue" name="交换机扫描率"></situation-use-pie-two>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div style="height: 320px;width: 100%">
                        <situation-use-pie-two line-ref="EchartsPieTwoFour" :pieData="printerData.data" :isTrue="printerData.isTrue" name="打印机扫描率"></situation-use-pie-two>
                    </div>
                </el-col>
            </el-col>
        </el-row>
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="主机编号：">
                    <el-input v-model="asset_code" clearable></el-input>
                </el-form-item>
                <el-form-item label="主机类型：">
                    <el-select v-model="secretType" clearable>
                        <el-option v-for="item,index in hostType" :key="index.value"
                                   :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="扫描状态：">
                    <el-select v-model="scan_state" clearable>
                        <el-option v-for="item,index in getCategoryData('scan_state')" :key="index"
                                   :label="item.label" :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="IP地址：">
                    <el-input v-model="assetIp" clearable></el-input>
                </el-form-item>
                <el-form-item >
                    <el-button  @click='search' type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="menuPersonData.data">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_code"
                    label="主机编号"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="org_name"
                    label="责任部门"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="主机密级"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('asset_secret',scope.row.asset_secret)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="主机类型"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('gb_asset_entry',scope.row.asset_type)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    label="IP地址"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="扫描开始时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{scope.row.scan_creat_time?timestampToTime(scope.row.scan_creat_time):""}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="扫描结束时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{scope.row.scan_end_time?timestampToTime(scope.row.scan_end_time):""}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="扫描状态"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('scan_state',scope.row.scan_state)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="toDialog(scope.row)"
                            type="text"
                            size="small">
                            详情
                        </el-button>
                        <el-button
                            @click.native.prevent="toRescan(scope.row.asset_ip)"
                            type="text"
                            size="small">
                            扫描
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
        <el-dialog :visible.sync="dialog" width="500px">
            <el-form label-width="100px" class="demo-ruleForm">
                <el-row>
                    <el-form-item label="扫描返回信息:" prop="desc">{{message}}
                        <!--<el-input v-model="message" type="textarea" :rows="4" :readonly="true"></el-input>-->
                    </el-form-item>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">确定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import situationUsePieTwo from "@/components/echartsCommon/situationUsePieTwo.vue";
    import pagination from '@/components/common/pagination.vue';
    import {selectScanTask,selectNumFromScanTask,scheduleSingleScan} from '@/api/safety/userHome/index.js';
    import async1 from "async";

    export default {
        name: "scanSurveillance",
        components: {
            situationUsePieTwo,
            pagination
        },
        data() {
            return {
                pageNo: 1,
                menuPersonData:{
                },
                asset_code: "",
                message: "",
                hostType: [{
                    value: '2010103',
                    label: '服务器',
                },{
                    value:'2010104',
                    label: '台式计算机',
                }, {
                    value:'2010202',
                    label: '交换机',
                },{
                    value:'2010601',
                    label:'打印机',
                }],
                dialog: false,
                secretType: "",
                scan_state: "",
                comple_status: "",
                assetIp: "",
                selectAssetType: [
                    {
                        name: "服务器",
                        asset_type: "2010103"
                    },{
                        name: "台式计算机",
                        asset_type: "2010104"
                    },{
                        name: "交换机",
                        asset_type: "2010202"
                    },{
                        name: "打印机",
                        asset_type: "2010601"
                    }],
                desktopData: {
                    data:[{
                        value: 0,
                        name: "已扫描",
                        label: {
                            normal: {
                                formatter: "{d} %",
                                textStyle: {
                                    fontSize: 20
                                }
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: "#3fa7dc"
                            }
                        }
                    },
                        {
                            value: 0,
                            name: "未完成",
                            label: {
                                normal: {
                                    formatter: "\n扫描率",
                                    textStyle: {
                                        color: "#666666",
                                        fontSize: 12
                                    }
                                }
                            },
                            tooltip: {
                                show: true
                            },
                            itemStyle: {
                                normal: {
                                    color: "#e6e6e6"
                                }
                            }
                        }],
                    isTrue: false,
                },
                serverData: {
                    data:[{
                        value: 0,
                        name: "已扫描",
                        label: {
                            normal: {
                                formatter: "{d} %",
                                textStyle: {
                                    fontSize: 20
                                }
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: "#3fa7dc"
                            }
                        }
                    },
                        {
                            value: 0,
                            name: "未完成",
                            label: {
                                normal: {
                                    formatter: "\n扫描率",
                                    textStyle: {
                                        color: "#666666",
                                        fontSize: 12
                                    }
                                }
                            },
                            tooltip: {
                                show: true
                            },
                            itemStyle: {
                                normal: {
                                    color: "#e6e6e6"
                                }
                            }
                        }],
                    isTrue: false,
                },
                switcheData: {
                    data:[{
                        value: 0,
                        name: "已扫描",
                        label: {
                            normal: {
                                formatter: "{d} %",
                                textStyle: {
                                    fontSize: 20
                                }
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: "#3fa7dc"
                            }
                        }
                    },
                        {
                            value: 0,
                            name: "未完成",
                            label: {
                                normal: {
                                    formatter: "\n扫描率",
                                    textStyle: {
                                        color: "#666666",
                                        fontSize: 12
                                    }
                                }
                            },
                            tooltip: {
                                show: true
                            },
                            itemStyle: {
                                normal: {
                                    color: "#e6e6e6"
                                }
                            }
                        }],
                    isTrue: false,
                },
                printerData: {
                    data:[{
                        value: 0,
                        name: "已扫描",
                        label: {
                            normal: {
                                formatter: "{d} %",
                                textStyle: {
                                    fontSize: 20
                                }
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: "#3fa7dc"
                            }
                        }
                    },
                        {
                            value: 0,
                            name: "未完成",
                            label: {
                                normal: {
                                    formatter: "\n扫描率",
                                    textStyle: {
                                        color: "#666666",
                                        fontSize: 12
                                    }
                                }
                            },
                            tooltip: {
                                show: true
                            },
                            itemStyle: {
                                normal: {
                                    color: "#e6e6e6"
                                }
                            }
                        }],
                    isTrue: false,
                },
                allData: {
                    data:[{
                        value: 0,
                        name: "已扫描",
                        label: {
                            normal: {
                                formatter: "{d} %",
                                textStyle: {
                                    fontSize: 20
                                }
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: "#3fa7dc"
                            }
                        }
                    },
                        {
                            value: 0,
                            name: "未完成",
                            label: {
                                normal: {
                                    formatter: "\n扫描率",
                                    textStyle: {
                                        color: "#666666",
                                        fontSize: 12
                                    }
                                }
                            },
                            tooltip: {
                                show: true
                            },
                            itemStyle: {
                                normal: {
                                    color: "#e6e6e6"
                                }
                            }
                        }],
                    isTrue: false,
                },
                scanState: [{
                    value: '未扫描',
                    label: '未扫描',
                },{
                    value:'正在扫描',
                    label: '正在扫描',
                }, {
                    value:'扫描完成',
                    label: '扫描完成',
                }],
                compleStatus: [{
                    value: '未完成',
                    label: '未完成',
                },{
                    value:'成功',
                    label: '成功',
                }, {
                    value:'失败',
                    label: '失败',
                }],
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.pageNo,
                    pageSize: 10,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
            search() {
                this.desktopData.isTrue = false;
                this.serverData.isTrue = false;
                this.switcheData.isTrue = false;
                this.printerData.isTrue = false;
                this.allData.isTrue = false;
                this.desktopData.data[1].value = 0;
                this.serverData.data[1].value = 0;
                this.switcheData.data[1].value = 0;
                this.printerData.data[1].value = 0;
                this.allData.data[1].value = 0;
                let str = '';
                if(this.asset_code != ""){
                    if(str == ""){
                        str = str + 'where asset_code like' + "'%" + this.asset_code + "%'"
                    }else {
                        str = str + 'and asset_code like' + "'%" + this.asset_code + "%'"
                    }
                }
                if(this.scan_state != ""){
                    if(str == ""){
                        str = str + 'where scan_state ='+"'"+this.scan_state+"'"
                    }else {
                        str = str + 'and scan_state ='+"'"+this.scan_state+"'"
                    }
                }
                if(this.secretType != ""){
                    if(str == ''){
                        str = 'where asset_type ='+"'"+this.secretType+"'";
                    }else {
                        str = str + 'and asset_type ='+"'"+this.secretType+"'"
                    }
                }
                if(this.comple_status != ""){
                    if(str == ""){
                        str = 'where comple_status ='+"'"+this.comple_status+"'"
                    }else {
                        str = str + 'and comple_status ='+"'"+this.comple_status+"'"
                    }
                }
                if(this.assetIp != ""){
                    if(str == ''){
                        str = 'where asset_ip like'+"'%"+this.assetIp+"%'";
                    }else {
                        str = str + 'and asset_ip like'+"'%"+this.assetIp+"%'"
                    }
                }
                str += " order by asset_code limit "+(this.pageNo - 1)*10+",10";
                let query = {
                    where: str
                };
                selectScanTask(query).then(data => {
                    if(data.status == 200) {
                        this.menuPersonData = data.data;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取待扫描主机信息错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                this.searchDesktop();
            },
            searchDesktop:function () {
                var self = this;
                async1.map(self.selectAssetType, function (item, callback) {
                        let query = {
                            where: "where asset_type = '" + item.asset_type + "'"
                        };
                        selectNumFromScanTask(query).then(data => {
                            if (data.status == 200) {
                                let arry = data.data.aggs.scan_state.buckets;
                                for (let i in arry){
                                    if(arry[i].key != 0){
                                        if(item.name == "台式计算机"){
                                            self.desktopData.data[1].value += arry[i].doc_count;
                                        }else if(item.name == "服务器"){
                                            self.serverData.data[1].value += arry[i].doc_count;
                                        }else if(item.name == "交换机"){
                                            self.switcheData.data[1].value += arry[i].doc_count;
                                        }else if(item.name == "打印机"){
                                            self.printerData.data[1].value += arry[i].doc_count;
                                        }
                                    }else{
                                        if(item.name == "台式计算机"){
                                            self.desktopData.data[0].value = arry[i].doc_count;
                                        }else if(item.name == "服务器"){
                                            self.serverData.data[0].value = arry[i].doc_count;
                                        }else if(item.name == "交换机"){
                                            self.switcheData.data[0].value = arry[i].doc_count;
                                        }else if(item.name == "打印机"){
                                            self.printerData.data[0].value = arry[i].doc_count;
                                        }
                                    }
                                }
                                callback(null,null);
                            } else {
                                callback(null);
                            }
                        }).catch(err => {
                            callback(err)
                        });
                    }, function (err, result) {
                        if (err) {
                            self.$notify.error({
                                title: '错误',
                                message: err
                            });
                        } else {
                            self.desktopData.isTrue = true;
                            self.serverData.isTrue = true;
                            self.switcheData.isTrue = true;
                            self.printerData.isTrue = true;
                        }
                    }
                );
                selectNumFromScanTask({where: ""}).then(data => {
                    if(data.status == '200') {
                        let arry = data.data.aggs.scan_state.buckets;
                        for (let i in arry) {
                            if (arry[i].key == "未扫描") {
                                self.allData.data[1].value += arry[i].doc_count;
                            } else if (arry[i].key == "扫描完成") {
                                self.allData.data[0].value = arry[i].doc_count;
                            }else if (arry[i].key == "正在扫描") {
                                self.allData.data[1].value += arry[i].doc_count;
                            }
                        }
                        self.allData.isTrue = true;
                    }else {
                        self.$notify.error({
                            title: '错误',
                            message: '获取扫描进度信息错误'
                        });
                    }
                }).catch(err => {
                    self.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
            },
            pageChange(val){
                this.pageNo=val;
                this.search();
            },
            formChange(val){
                if(this[val]){
                    this['check'+val]=true;
                }else{
                    this['check'+val]=false;
                }
            },
            toRescan(ip) {
                let query = {
                    ip: ip,
                    flag: true
                };
                scheduleSingleScan(query).then(data=>{
                    if(data.status == '200'){
                        this.$notify.success({
                            title: '成功',
                            message: '已成功发起重新扫描,请稍后查看扫描结果'
                        });
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '重新扫描发起失败,请重试'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '服务访问失败,请稍后重试'
                    });
                });
            },
            toDialog(item) {
                this.message = item.message;
                this.dialog = true;

            },
        },
        created() {
            this.search();
        }
    }
</script>

<style scoped>
    .allOverflow {
        height:calc(100% - 138px) !important;
        overflow-y: auto;
        border-top: 1px solid #e6e6e6;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }
    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }
    ::-webkit-scrollbar{display:none}
</style>
