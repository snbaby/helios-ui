<template>
    <div class="framework-content">
        <div class="framework-left">
            <tableTree :data="roleList" :columns="columns" @getValue="getRolePerson"></tableTree>
        </div>
        <div class="framework-right">
            <el-row style="height:100%;" v-if="showData" id="roleAllocate">
                <el-transfer
                    filterable
                    :titles="['待选', '已选']"
                    @change="handleChange"
                    v-model="chooseID"
                    :data="data2">
                </el-transfer>
            </el-row>
        </div>
    </div>
</template>

<script>
    import {
        fetch,
        json2Param
    } from '@/core/fetch.js';
    import tableTree from '@/components/common/tableTree.vue';
    import {
        getUserWithSelectPage
    } from '@/api/common/index.js';
    import {selectApplication,insertApplication,deleteApplication,selectApplicationByCode} from "@/api/terminalSecurity/leakCheck/index.js"
    export default {
        components: {
            tableTree,
        },
        data() {
            return {
                showData: false,
                searchRoleVal: "", //角色查询
                roleList: [],
                personId: "",
                roleCode: "", //角色code
                rolePersonTableData: {
                    pageNo: 1,
                    rows: [],
                    total: 0
                },
                data2: [],
                chooseID: [],
                columns: [{
                    label: '应用编码',
                    type: 'code',
                }, {
                    label: '应用名称',
                    type: 'label',
                }],
            }
        },
        created() {
            this.searchRole();

        },
        methods: {
            handleChange(value, direction, movedKeys) {
                if (direction == "right") {
                    this.addUser(movedKeys);
                } else if (direction == "left") {
                    this.remove(movedKeys);
                }
            },
            searchRole() {
                selectApplication().then(data => {
                    for(let i in data.data){
                        this.data2.push({
                            key: data.data[i].asset_ip,
                            label: data.data[i].asset_code +"  "+ data.data[i].asset_ip,
                        })
                    }
                });
                this.roleList = this.getCategoryData('application');
            },
            //获得角色id,查询角色对应人员
            getRolePerson(val) {
                this.roleCode = val.code;
                this.getMenuData();
            },
            getMenuData(){
                let query = {
                    code: this.roleCode
                };
                selectApplicationByCode(query).then(data => {
                    for(let i in data.data.data){
                        this.chooseID.push(data.data.data[i].ips)
                    }
                });
                this.showData = true;
            },
            //删除当前角色人员
            remove(codes) {
                let query = {
                    ips: codes.toString(),
                    description: this.roleCode
                };
                deleteApplication(query).then(data => {
                    if (data.status != 200) {
                        this.$notify.error({
                            title: '错误',
                            message: '删除失败'
                        });
                        this.getMenuData();
                    }
                });

            },

            addUser(codes) {
                let query = {
                    ips: codes.toString(),
                    description: this.roleCode
                };
                insertApplication(query).then(data => {
                    if (data.status != 200) {
                        this.$notify.error({
                            title: '错误',
                            message: '添加失败'
                        });
                        this.getMenuData();
                    }
                });

            },
        },
    }
</script>

<style lang="css">
    #roleAllocate .el-transfer-panel {
        width: calc(50% - 48px);
    }

    #roleAllocate .el-transfer-panel__list.is-filterable {
        height: 386px;
    }

    #roleAllocate .el-transfer-panel__body {
        height: 431px;
    }
</style>
