<template>
    <div class="framework-content">
        <mu-row style="width: 100%;height: 160px;">
            <div style="height: 100%;width: 25%">
                <div class="analysisImg"></div>
                <div class="analysisFont">漏洞指标分析</div>
            </div>
            <div style="height: 100%;width: 25%">
                <div style="border-top: 2px solid #FF0000;" class="loopholeBox" @click="toSearchRisk('高危')">
                    <div style="color: #FF0000" class="loopholeBoxNum">{{highRisk?highRisk:0}}</div>
                    <div style="border: 1px solid #ff0000;" class="loopholeBoxFont">
                        已发现高危漏洞数
                    </div>
                </div>
            </div>
            <div style="height: 100%;width: 25%">
                <div style="border-top: 2px solid #FF800A;" class="loopholeBox" @click="toSearchRisk('中危')">
                    <div style="color: #FF800A" class="loopholeBoxNum">{{middleRisk?middleRisk:0}}</div>
                    <div style="border: 1px solid #FF800A;" class="loopholeBoxFont">
                        已发现中危漏洞数
                    </div>
                </div>
            </div>
            <div style="height: 100%;width: 25%">
                <div style="border-top: 2px solid #08e69a;" class="loopholeBox" @click="toSearchRisk('低危')">
                    <div style="color: #08e69a" class="loopholeBoxNum">{{lowRisk?lowRisk:0}}</div>
                    <div style="border: 1px solid #08e69a;" class="loopholeBoxFont">
                        已发现低危漏洞数
                    </div>
                </div>
            </div>
        </mu-row>
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="漏洞等级：">
                    <el-select v-model="severityGrade" clearable>
                        <el-option v-for="item,index in gradeType" :key="index.value"
                                   :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="CVEID：">
                    <el-input v-model="cveId" clearable></el-input>
                </el-form-item>
                <el-form-item label="漏洞名称：" >
                    <el-input v-model="name" clearable></el-input>
                </el-form-item>
                <el-form-item >
                    <el-button class="search"  @click='doSearch' type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="menuLoopholeData.data">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="row"
                    label="漏洞等级"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        <div :class="getShowImg(scope.row.severity_grade)"></div>
                    </template>
                </el-table-column>
                <el-table-column
                    prop="risk"
                    label="漏洞风险值"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="vul_id"
                    label="VULID"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="cve_id"
                    label="CVEID"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="漏洞名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="最新发现时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{timestampToTime(scope.row.modify_time)}}
                    </template>
                </el-table-column>
                <!--<el-table-column-->
                    <!--prop="foundNum"-->
                    <!--label="发现主机数"-->
                    <!--show-overflow-tooltip>-->
                <!--</el-table-column>-->
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="link(scope.row.vul_id)"
                            type="text"
                            size="small">
                            查看详情
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div >
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
    </div>
</template>

<script>
    import {selectScanStore,selectCountScanByGrade,selectCounComtNumByVulID} from '@/api/safety/userHome/index.js';
    import pagination from '@/components/common/pagination.vue';

    const async1 = require("async");

    export default {
        name: "analysisOfVulnerabilityIndex",
        data() {
            return {
                checkseverityGrade: false,
                severityGrade: '',
                checkcveId: false,
                cveId: '',
                checkname: false,
                name: '',
                pageNo: 1,
                menuLoopholeData: [],
                highRisk: '',
                middleRisk: '',
                lowRisk: '',
                gradeType: [{
                    value: '低危',
                    label: '低危',
                },{
                    value:'中危',
                    label: '中危',
                }, {
                    value:'高危',
                    label: '高危',
                },{
                    value:'其他',
                    label:'其他',
                }],
            }
        },
        components: {
            pagination
        },
        computed: {
            pageOption(){
                return {
                    pageNo:this.pageNo,
                    pageSize:10,
                    total:this.menuLoopholeData.total||0,
                }
            }
        },
        methods: {
            link(vulId){
                this.$router.push({
                    path:"/soc/terminal-security/Leak-check/loophole-details",
                    query: {
                        vulId: vulId
                    }
                });
            },
            init() {

            },
            pageChange(val){
                this.pageNo=val;
                this.doSearch();
            },
            formChange(val){
                if(this[val]){
                    this['check'+val]=true;
                }else{
                    this['check'+val]=false;
                }
            },
            doSearch() {
                let str = '';
                if(this.severityGrade != ''){
                    if(this.severityGrade != '其他') {
                        if (str == '') {
                            str = 'where severity_grade =' + "'" + this.severityGrade + "'";
                        } else {
                            str = str + 'and severity_grade =' + "'" + this.severityGrade + "'"
                        }
                    }else {
                        if (str == '') {
                            str = "where severity_grade not in  ('高危','中危','低危')";
                        } else {
                            str = str + "and severity_grade not in  ('高危','中危','低危')";
                        }
                    }
                }
                if(this.cveId != ''){
                    if(str == ''){
                        str = 'where cve_id like'+" '%"+this.cveId+"%'";
                    }else {
                        str = str + 'and cve_id like'+" '%"+this.cveId+"%'"
                    }
                }
                if(this.name != ''){
                    if(str == ''){
                        str = 'where name like'+"'%"+this.name+"%'";
                    }else {
                        str = str + 'and name like'+"'%"+this.name+"%'"
                    }
                }
                let query = {
                    where: str,
                    page:(this.pageNo-1)*10,
                    size:10,
                };
                this.getCheckProcessData(query);
                this.getNum();
            },
            getNum(){
                selectCountScanByGrade({severity_grade: '高危'}).then((data)=>{
                    if(data.status == '200') {
                        this.highRisk = data.data.aggs['COUNT(*)'].value;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取高危漏洞数错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                selectCountScanByGrade({severity_grade: '中危'}).then((data)=>{
                    if(data.status == '200') {
                        this.middleRisk = data.data.aggs['COUNT(*)'].value;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取中危漏洞数错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                selectCountScanByGrade({severity_grade: '低危'}).then((data)=>{
                    if(data.status == '200') {
                        this.lowRisk = data.data.aggs['COUNT(*)'].value;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取低危漏洞数错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
            },
            getCheckProcessData:function(query) {
                const self = this;
                async1.waterfall([
                    function (callback) {
                        self.getSqlResultWithQuery("selectScanStore",query).then((data)=>{
                            if(data.data){
                                callback(null,data.data);
                            }else{
                                callback(null);
                            }
                        });
                    },
                    // function (scanStoreObj, callback) {
                    //     async1.map(scanStoreObj.data, function(item,cb){
                    //         self.getSqlResultWithQuery('selectCounComtNumByVulID', {vul_id: item.vul_id}).then((data) => {
                    //             item['foundNum']= data.data.aggs['COUNT(*)'].value;
                    //             cb(null,item);
                    //         }).catch(err=>{
                    //             cb(err)
                    //         })
                    //
                    //     }, function(err, results) {
                    //         if(err){
                    //             callback(err);
                    //         }else{
                    //             scanStoreObj.data = results;
                    //             callback(null,scanStoreObj);
                    //         }
                    //     });
                    // }
                ],function (err, result) {
                    if(err){
                        this.$notify.error({
                            title: '错误',
                            message: err
                        });
                    }else{
                        self.menuLoopholeData = result;
                    }
                });
            },
            getShowImg(level) {
                if(level == '高危') {
                    return 'riskLevelOne'
                }
                else if(level == '中危') {
                    return 'riskLevelTwo'
                }
                else if(level == '低危') {
                    return 'riskLevelThree'
                }
            },
            toSearchRisk(risk) {
                this.severityGrade = risk;
                this.doSearch();
            }
        },
        created(){
            this.doSearch();
        },
        activated(){
            // this.doSearch();
        }
    }
</script>

<style scoped>

    .analysisFont {
        text-align: center;
        font-size: 14px;
    }

    .loopholeBox {
        height: 100px;
        width: 247px;
        margin: auto;
        border: 1px solid #eeeeee;
        margin-top: 30px;
        cursor: pointer;
    }

    .loopholeBoxNum {
        height: 57px;
        width: 100%;
        line-height: 57px;
        text-align: center;
        font-size: 32px;
    }

    .loopholeBoxFont {
        height: 28px;
        width: 188px;
        margin: auto;
        border-radius: 14px;
        text-align: center;
        line-height: 28px
    }

    .analysisImg {
        height: 53px;
        width: 53px;
        background-image: url("/static/img/businessCenter/analysis.png");
        background-size: 100% 100%;
        margin: auto;
        margin-top: 40px;
    }

    .allOverflow {
        height:calc(100% - 138px) !important;
        height: 100%;
        overflow-y: auto;
        border-top: 1px solid #e6e6e6;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }

    .riskLevelOne{
        background: url(/static/img/safetyCockpit/icon_red.png) left no-repeat ;
        height: 33px;
        width: 100%;
    }

    .riskLevelTwo{
        background: url(/static/img/safetyCockpit/icon_yellow.png) left no-repeat ;
        height: 33px;
        width: 100%;
    }

    .riskLevelThree{
        background: url(/static/img/safetyCockpit/icon_green.png) left no-repeat ;
        height: 33px;
        width: 100%;
    }

    ::-webkit-scrollbar{display:none}
</style>
