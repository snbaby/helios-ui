<template>
    <div>
        <div class="margin"><el-button class="buttonBack" @click="$router.back(-1)">返 回</el-button></div>
        <el-col :span="18">
            <el-row class="titleBox">
                <font class="fontTitle">主机资产详情</font>
            </el-row>
            <el-row style="width: 100%;height: 100%;">
                <el-form label-width="100px" label-position="right">
                    <el-row >
                        <el-col :span="8">
                            <el-form-item label="主机类型:">
                                {{host.asset_type?getCategoryData('gb_asset_entry',host.asset_type):""}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="主机编号:">
                                {{host.asset_code}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="主机密级:">
                                {{host.asset_secret?getCategoryData('asset_secret',host.asset_secret):""}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row >
                        <el-col :span="8">
                            <el-form-item label="责任部门:">
                                {{host.org_name}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="责任人工号:">
                                {{host.asset_duty_code}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="责任人姓名:">
                                {{host.asset_duty_name}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row  >
                        <el-col :span="8">
                            <el-form-item :title="host.asset_ip" label="IP地址:" id="viewDetailsIp">
                                {{host.asset_ip}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="操作系统:">
                                {{host.asset_os}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="用途:">
                                {{host.asset_useage?getCategoryData('asset_useage',host.asset_useage):""}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-row >
                        <el-col :span="8">
                            <el-form-item label="风险等级:">
                                {{host.manage_risk_name}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="风险值:">
                                {{host.manage_risk_num}}
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="扫描时间:">
                                {{host.scan_end_time?timestampToTime(host.scan_end_time):''}}
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </el-row>
            <el-row class="titleBox" >
                <font class="fontTitle">主机漏洞分布</font>
            </el-row>
            <div>
                <el-table :data="menuLoopholeData.data">
                    <el-table-column
                        type="index"
                        width="50"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="gradeType"
                        label="风险等级"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="risk"
                        label="风险值"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="vul_id"
                        label="vul_id"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="asset_ip"
                        label="ip地址"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="name"
                        label="漏洞名称"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="description"
                        label="漏洞描述"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="solution"
                        label="解决方案"
                        show-overflow-tooltip>
                    </el-table-column>
                    <el-table-column
                        prop="scope"
                        label="发现时间"
                        show-overflow-tooltip>
                        <template slot-scope="scope">
                            {{timestampToTime(scope.row.creat_time)}}
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="address"
                        label="操作">
                        <template slot-scope="scope">
                            <el-button
                                @click.native.prevent="link(scope.row.vul_id)"
                                type="text"
                                size="small">
                                详情
                            </el-button>
                            <el-button
                                @click.native.prevent="toDialog(scope.row)"
                                type="text"
                                size="small">
                                整改
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
            <div>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </el-col>
        <el-col :span="6">
            <el-row>
                <div class="rightPadding">
                    <font class="rightTitle">主机整改历史</font>
                </div>
                <div class="rightPadding">
                    <mu-timeline>
                        <template v-for="item,index in fixeDataTen">
                            <mu-timeline-item>
                                <span slot="time">{{timestampToTime(item.fixe_time)}}</span>
                                <span slot="des">{{item.name}}</span>
                            </mu-timeline-item>
                        </template>
                        <mu-timeline-item>
                            <span @click="showMore()" style="cursor: pointer">更多</span>
                        </mu-timeline-item>
                    </mu-timeline>
                </div>
            </el-row>
        </el-col>
        <el-dialog :visible.sync="dialogAdd" width="500px">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
                <el-row>
                    <el-form-item label="整改说明" prop="desc">
                        <el-input v-model="ruleForm.desc" type="textarea" :rows="4"></el-input>
                    </el-form-item>
                </el-row>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogAdd = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog :visible.sync="dialogShow" width="70%" id="historyNormDialog">
            <el-table :data="fixeData.data">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="vul_id"
                    label="vul_id"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="vul_ip"
                    label="扫描IP"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_code"
                    label="主机编号"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="漏洞名称"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="fixed_desc"
                    label="整改描述"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="整改时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{timestampToTime(scope.row.fixe_time)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="完成状态"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{scope.row.comple_status?getCategoryData('comple_status',scope.row.comple_status):""}}
                    </template>
                </el-table-column>
            </el-table>
        </el-dialog>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {selectFlawByCode,selectHostScanResultByCode,addFlawFixedResult,selectFixedResult,selectFixedResultAll,selectFlawByAssetCode} from "@/api/terminalSecurity/leakCheck/index.js"

    export default {
        name: "viewTheDetails",
        components: {
            pagination,
        },
        data() {
            return {
                assetCode:this.$route.query.asset_code,
                pageNo: 1,
                host: {},
                menuLoopholeData: {},
                dialogAdd: false,
                ruleForm: {
                    desc: '',
                },
                rules: {
                    desc: [
                        { required: true, message: '请输入活动名称', trigger: 'blur' },
                    ],
                },
                temporary: {},
                fixeDataTen: [],
                fixeData: [],
                dialogShow: false,
            }
        },
        computed: {
            pageOption(){
                return {
                    pageNo:this.pageNo,
                    pageSize:10,
                    total:this.menuLoopholeData.total||0,
                }
            }
        },
        created() {
            this.init();
        },
        activated() {
            this.init();
        },
        methods: {
            init(){
                selectHostScanResultByCode({'asset_code': this.assetCode}).then((data)=>{
                    if(data.status == '200') {
                        this.host = data.data.data[0];
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取主机信息错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                this.doSearch();
            },
            doSearch() {
                let query = {
                    pageSize: 10,
                    pageNo: this.pageNo,
                    asset_code: this.assetCode,
                };
                selectFlawByAssetCode(query).then((data) => {
                    if(data.status == '200') {
                        this.menuLoopholeData = data.data;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取漏洞信息错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                this.searchFixed();
            },
            searchFixed() {
                let query = {
                    page: 0,
                    size: 10,
                    asset_code: this.assetCode
                };
                selectFixedResult(query).then(data=>{
                    if(data.status == '200') {
                        this.fixeDataTen = data.data.data;
                    }else {
                        // this.$notify.error({
                        //     title: '错误',
                        //     message: '获取整改历史数据错误'
                        // });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
            },
            pageChange(val){
                this.pageNo=val;
                this.doSearch();
            },
            getShowImg(level) {
                if(level == '高危') {
                    return 'riskLevelOne'
                }
                else if(level == '中危') {
                    return 'riskLevelTwo'
                }
                else if(level == '低危') {
                    return 'riskLevelThree'
                }
            },
            link(vulId){
                this.$router.push({
                    path:"/soc/terminal-security/Leak-check/loophole-details",
                    query: {
                        vulId: vulId
                    }
                });
            },
            doSubmit(formName) {
                const _self = this;
                this.$refs[formName].validate((valid) => {
                    if(valid) {
                        let arry = {
                            comple_status: 'comple_status',
                            fixed_desc: this.ruleForm.desc,
                            fixe_time: new Date().getTime()
                        };
                        Object.assign(arry,this.temporary);
                        delete arry._index;
                        delete arry._id;
                        delete arry._type;
                        addFlawFixedResult(arry).then(data=>{
                            if(data.status == "200") {
                                this.$notify.success({
                                    title: '成功',
                                    message: '整改信息添加成功'
                                });
                                setTimeout(_self.searchFixed,1000);
                            }else {
                                this.$notify.error({
                                    title: '错误',
                                    message: '整改信息添加失败，请重试'
                                });
                            }
                        }).catch(err => {
                            this.$notify.error({
                                title: '错误',
                                message: '服务错误，请稍后重试'
                            });
                        });
                    }
                    this.dialogAdd = false;
                })
            },
            toDialog(item) {
                this.temporary = item;
                this.ruleForm.desc = '';
                this.dialogAdd = true;

            },
            showMore(){
                selectFixedResultAll({asset_code: this.assetCode}).then(data=>{
                    if(data.status == '200') {
                        this.fixeData = data.data;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取整改历史数据错误'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
                this.dialogShow = true;
            }
        }
    }
</script>

<style scoped>
    .margin{
        height: 35px;
        width: 100%;
    }

    .rightPadding{
        padding: 10px 20px;
    }

    .titleBox {
        height: 32px;
        background-color: #bbbbbb;
        width: 100%;
    }

    .fontTitle {
        font-size: 16px;
        color: #333;
        line-height: 32px;
        padding-left: 20px;
    }

    .buttonBack {
        float:right;
        margin-top: 2px;
    }

    .rightTitle {
        font-size: 14px;
        color: #666;
        font-weight: bold;
    }
    .riskLevelOne{
        background: url(/static/img/safetyCockpit/icon_red.png) left no-repeat ;
        height: 100%;
        width: 100%;
    }

    .riskLevelTwo{
        background: url(/static/img/safetyCockpit/icon_yellow.png) left no-repeat ;
        height: 100%;
        width: 100%;
    }

    .riskLevelThree{
        background: url(/static/img/safetyCockpit/icon_green.png) left no-repeat ;
        height: 100%;
        width: 100%;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }

</style>

