<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="主机编号：">
                    <el-input v-model="assetCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="主机类型：">
                    <el-select v-model="secretType" clearable>
                        <el-option v-for="item,index in hostType" :key="index.value"
                                   :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="主机密级：" >
                    <el-select v-model="secret" clearable>
                        <el-option v-for="item,index in getCategoryData('asset_secret')"
                                   :key="index.code"
                                   :label="item.label"
                                   :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="IP地址：" >
                    <el-input v-model="assetIp" clearable></el-input>
                </el-form-item>
                <el-form-item label="业务风险：" >
                    <el-select v-model="business_risk_name" clearable>
                        <el-option v-for="item,index in gradeType" :key="index.code"
                                   :label="item.label"
                                   :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="管理风险：">
                    <el-select v-model="manage_risk_name" clearable>
                        <el-option v-for="item,index in gradeType" :key="index.value"
                                   :label="item.label" :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item >
                    <el-button class="search"  @click='doSearch' type="primary">查询</el-button>
                    <el-button  @click='linshi'>临时</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="menuLoopholeData.data">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="business_risk_name"
                    label="风险等级"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="org_name"
                    label="责任部门"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="主机类型"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('gb_asset_entry',scope.row.asset_type)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="主机密级"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('asset_secret',scope.row.asset_secret)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_code"
                    label="主机编号"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_os"
                    label="操作系统"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    label="IP地址"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_duty_name"
                    label="责任人"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="用途"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('asset_secret',scope.row.asset_secret)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="用途"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('asset_useage',scope.row.asset_useage)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="扫描时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{timestampToTime(scope.row.update_time)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="address"
                    label="操作">
                    <template slot-scope="scope">
                        <el-button
                            @click.native.prevent="toLink(scope.row.asset_code)"
                            type="text"
                            size="small">
                            详情
                        </el-button>
                        <el-button
                            @click.native.prevent="toRescan(scope.row.asset_ip)"
                            type="text"
                            size="small">
                            重扫
                        </el-button>
                        <el-button
                            @click.native.prevent="link(scope.row.asset_code)"
                            type="text"
                            size="small">
                            备案
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
    </div>
</template>

<script>
    import {fetch,json2Param} from '@/core/fetch.js';
    import pagination from '@/components/common/pagination.vue';
    import {slectHostScanResult,scheduleSingleScan,selectScanResultCountRisk,selectNumFromScanTask} from '@/api/safety/userHome/index.js';

    export default {
        name: "vulnerabilityResultManagement",
        data() {
            return {
                currentUser: null,
                checksecret: false,
                secret: [],
                checksecretType: false,
                secretType: [],
                checkassetCode: false,
                orgName: "",
                checkorgName: false,
                assetCode: "",
                checkassetIp: false,
                manage_risk_name: "",
                checkmanage_risk_name: false,
                business_risk_name: "",
                checkbusiness_risk_name: false,
                gradeType: [{
                    value: '低危',
                    label: '低危',
                },{
                    value:'中危',
                    label: '中危',
                }, {
                    value:'高危',
                    label: '高危',
                }],
                assetIp: "",
                pageNo: 1,
                menuLoopholeData: [],
                hostType: [{
                    value: '2010103',
                    label: '服务器',
                },{
                    value:'2010104',
                    label: '台式计算机',
                }, {
                    value:'2010202',
                    label: '交换机',
                },{
                    value:'2010601',
                    label:'打印机',
                }],
            }
        },
        components: {
            pagination
        },
        computed: {
            pageOption(){
                return {
                    pageNo:this.pageNo,
                    pageSize:10,
                    total:this.menuLoopholeData.total||0,
                }
            },
        },
        methods: {
            linshi(){
                this.$router.push({
                    path:"/soc/terminal-security/Leak_check/application-config",
                });
            },
            link(assetCord){
                this.$router.push({
                    path:"/soc/terminal-security/record-management/leak-record-apply",
                    query:{
                        asset_code:assetCord
                    }
                });
            },
            toLink(assetCord) {
                this.$router.push({
                    path:"/soc/terminal-security/Leak-check/view-the-details",
                    query:{
                        asset_code:assetCord
                    }
                });
            },
            doSearch() {
                this.currentUser = this.getCurrentUser();
                this.doSearchs(this.currentUser);
            },
            doSearchs(currentUser){
                let code = currentUser.groups[0].code;
                for(let i in currentUser.groups){
                    if(currentUser.groups[i].code == "socManager"){
                        code = "";
                    }
                }
                // var self = this;
                let str = '';
                if(code){
                    if(str == ''){
                        str = 'where org_full_path like '+"'%"+code+"%'";
                    }else {
                        str += 'org_full_path like '+"'%"+code+"%'";
                    }
                }
                if(this.secret != ""){
                    if(str == ''){
                        str = 'where asset_secret ='+"'"+this.secret+"'";
                    }else {
                        str = str + 'and asset_secret ='+"'"+this.secret+"'"
                    }
                }
                if(this.secretType != ""){
                    if(str == ''){
                        str = 'where asset_type ='+"'"+this.secretType+"'";
                    }else {
                        str = str + 'and asset_type ='+"'"+this.secretType+"'"
                    }
                }
                if(this.assetCode != ""){
                    if(str == ''){
                        str = 'where asset_code like'+"'%"+this.assetCode+"%'";
                    }else {
                        str = str + 'and asset_code like'+"'%"+this.assetCode+"%'"
                    }
                }
                if(this.orgName != ""){
                    if(str == ''){
                        str = 'where org_name like'+"'%"+this.orgName+"%'";
                    }else {
                        str = str + 'and org_name like'+"'%"+this.orgName+"%'"
                    }
                }
                if(this.assetIp != ""){
                    if(str == ''){
                        str = 'where asset_ip like'+"'%"+this.assetIp+"%'";
                    }else {
                        str = str + 'and asset_ip like'+"'%"+this.assetIp+"%'"
                    }
                }
                if(this.business_risk_name != ""){
                    if(str == ''){
                        str = 'where business_risk_name ='+"'"+this.business_risk_name+"'";
                    }else {
                        str = str + 'and business_risk_name =' + "'" +this.business_risk_name+"'";
                    }
                }
                if(this.manage_risk_name != ""){
                    if(str == ''){
                        str = 'where manage_risk_name ='+"'"+this.manage_risk_name+"'";
                    }else {
                        str = str + 'and manage_risk_name =' + "'" +this.manage_risk_name+"'";
                    }
                }

                let query = {
                    where: str,
                    page:(this.pageNo-1)*10,
                    size:10,
                };
                slectHostScanResult(query).then(data=> {
                    if(data.status == 200) {
                        this.menuLoopholeData = data.data;
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '获取扫描主机信息错误'
                        });
                    }
                }).catch(err=>{
                    this.$notify.error({
                        title: '错误',
                        message: err
                    });
                });
            },
            pageChange(val){
                this.pageNo=val;
                this.doSearch();
            },
            getShowImg(level) {
                if(level == '高危') {
                    return 'riskLevelOne'
                }
                else if(level == '中危') {
                    return 'riskLevelTwo'
                }
                else if(level == '低危') {
                    return 'riskLevelThree'
                }
            },
            getBackColor(level) {
                if(level == '高危') {
                    return 'backColorOne'
                }
                else if(level == '中危') {
                    return 'backColorTwo'
                }
                // else if(level == '低危') {
                //     // return 'backColorThree'
                // }
            },
            formChange(val){
                if(this[val]){
                    this['check'+val]=true;
                }else{
                    this['check'+val]=false;
                }
            },
            toRescan(ip) {
                let query = {
                    ip: ip,
                };
                scheduleSingleScan(query).then(data=>{
                    if(data.status == '200'){
                        this.$notify.success({
                            title: '成功',
                            message: '已成功发起重新扫描,请稍后查看扫描结果'
                        });
                    }else {
                        this.$notify.error({
                            title: '错误',
                            message: '重新扫描发起失败,请重试'
                        });
                    }
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '服务访问失败,请稍后重试'
                    });
                });
            },
        },
        created() {
            this.doSearch();
        },
        activated() {
            this.doSearch();
        }
    }
</script>

<style scoped>
    .titleHeader {
        padding-left: 20px;
        /*height: 48px;*/
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        /*line-height: 48px;*/
    }

    .allOverflow {
        height:calc(100% - 138px) !important;
        overflow-y: auto;
        border-top: 1px solid #e6e6e6;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }

    .riskLevelOne{
        background: url(/static/img/safetyCockpit/icon_red.png) left no-repeat ;
        height: 100%;
        width: 100%;
    }

    .riskLevelTwo{
        background: url(/static/img/safetyCockpit/icon_yellow.png) left no-repeat ;
        height: 100%;
        width: 100%;
    }

    .riskLevelThree{
        background: url(/static/img/safetyCockpit/icon_green.png) left no-repeat ;
        height: 100%;
        width: 100%;
    }

    .backColorOne {
        background-color: rgba(255,0,0,0.2);
    }
    .backColorTwo {
        background-color: rgba(255,128,10,0.2);
    }
    tr.mu-tr.selected.backColorOne {
        background-color: rgba(255,0,0,0.2);
    }
    tr.mu-tr.selected.backColorTwo{
        background-color: rgba(255,128,10,0.2);
    }
    tr.mu-tr.hover.backColorOne {
        background-color: rgba(255,0,0,0.2);
    }
    tr.mu-tr.hover.backColorTwo{
        background-color: rgba(255,128,10,0.2);
    }

    /*.backColor{*/
    /*!*background-color: #ff800a;*!*/
    /*background-color: rgba(255,128,10,0.3);*/
    /*}*/

    ::-webkit-scrollbar{display:none}
</style>
