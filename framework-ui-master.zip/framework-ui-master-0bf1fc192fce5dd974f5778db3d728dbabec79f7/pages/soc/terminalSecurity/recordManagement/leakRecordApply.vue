<template>
    <div class="backColor">
        <div class="contentBox">
            <div class="pageContent">
                <div class="processContent">
                    <el-form ref="ruleForm" label-width="150px" class="demo-ruleForm">
                        <el-row style="text-align:center;margin-bottom:15px;">
                            <font style="font-size: large;font-weight: bold;">漏洞备案申请</font>
                        </el-row>
                        <div class="tabsStyle">
                            <font>主机台账信息</font>
                            <font style="float: right;color: #409eff" @click = "openDialog">流程图</font>
                        </div>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机编号" v-if="isSelect">
                                    <el-input v-model="ruleForm.asset_code" :disabled="true"></el-input>
                                </el-form-item>
                                <el-form-item label="主机编号" v-else>
                                    <el-select v-model="ruleForm.asset_code" placeholder="" filterable style="width:100%;" @change="selectHost">
                                        <el-option v-for="item,index in allComputerList" :key="index" :label="item.asset_code" :value="item.asset_code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机密级">
                                    <el-select v-model="ruleForm.asset_secret" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_secret')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机状态">
                                    <el-select v-model="ruleForm.asset_status" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_status')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机用途">
                                    <el-select v-model="ruleForm.asset_useage" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_useage')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="IP地址">
                                    <el-input v-model="ruleForm.asset_ip" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="MAC地址">
                                    <el-input v-model="ruleForm.asset_mac" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="硬盘SN">
                                    <el-input v-model="ruleForm.asset_disksn" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用网络">
                                    <el-select v-model="ruleForm.asset_network" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_network')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="安装位置">
                                    <el-input v-model="ruleForm.asset_area" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="责任部门">
                                    <el-input v-model="ruleForm.org_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="责任人">
                                    <el-input v-model="ruleForm.asset_duty_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用人">
                                    <el-input v-model="ruleForm.asset_user_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <div class="tabsStyle"><font>备案漏洞</font></div>
                        <div>
                            <el-table
                                ref="multipleTable"
                                :data="menuData"
                                tooltip-effect="dark"
                                style="width: 100%"
                                @selection-change="handleSelectionChange"
                                >
                                <el-table-column
                                    type="selection"
                                    width="55">
                                </el-table-column>
                                <el-table-column
                                    type="index"
                                    width="50"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="severity_grade"
                                    label="严重等级"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="risk"
                                    label="严重分值"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="name"
                                    label="漏洞名称"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="description"
                                    label="漏洞描述"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    prop="solution"
                                    label="解决方案"
                                    show-overflow-tooltip>
                                </el-table-column>
                                <el-table-column
                                    label="发现时间"
                                    show-overflow-tooltip>
                                    <template slot-scope="scope">
                                        {{timestampToTime(scope.row.discover_date)}}
                                    </template>
                                </el-table-column>
                            </el-table>
                        </div>
                        <el-form label-width="80px" :model="formData" :rules="rules" ref="formData" label-position="right" style="padding: 40px 20px 20px 20px;width: 100%">
                            <el-row>
                                <el-col :span="24">
                                    <el-form-item label="备案理由" prop="recodeDesp" >
                                        <el-input type="textarea" v-model="formData.recodeDesp"></el-input>
                                    </el-form-item>
                                </el-col>
                            </el-row>
                            <el-row style="margin-top: 15px;">
                                <el-col :span="12"  style="text-align:center;">
                                    <el-button type="primary" @click="submitProcess('formData')" class="submit">提交申请</el-button>
                                </el-col>
                                <el-col :span="12"  style="text-align:center;">
                                    <el-button type="primary" @click="$router.back(-1)" class="submit">取消申请</el-button>
                                </el-col>
                            </el-row>
                        </el-form>

                    </el-form>
                </div>
                <el-dialog :visible.sync="processDialog" width="70%">
                    <h6>流程图</h6>
                    <div id="container"></div>
                </el-dialog>
            </div>
        </div>
        <font v-loading.fullscreen.lock="fullscreenLoading" text="流程处理中" v-if="fullscreenLoading"></font>
    </div>
</template>

<script>
    import {getProcessDefineXml_key} from '@/api/user/myTask/processInfo/index.js'
    import {selectRecordByCode,queryAllComputer,selectHostFlawResultByCodeIsNotRecord,selectHostScanResultByCode,
        selectFlawByCodeIsNot,getLeakRecordId,processStart} from '@/api/terminalSecurity/recordManagement/leakRecordApply/index.js'
    import Viewer from 'bpmn-js/lib/NavigatedViewer.js';

    export default {
        data() {
            return {
                isSelect: this.$route.query.asset_code?true:false,
                ruleForm: {},
                processDialog: false,
                allComputerList: [],
                menuData: [],
                fullscreenLoading: false,
                formData: {},
                rules:{
                    recodeDesp:[{
                        required: true,
                        message: '请输入备案申请事由',
                        trigger: 'blur'
                    },{
                        required: true,
                        message: '请输入备案申请事由',
                        trigger: 'change'
                    }]
                },
                selectVulData: [],
                currentDep: {}
            }
        },
        methods: {
            init() {
                if(this.isSelect == true){
                    this.selectHost(this.$route.query.asset_code);
                }else {
                    queryAllComputer().then((data)  =>{
                        if(data.data.data&&data.data.data.length>0){
                            this.allComputerList = data.data.data;
                        }
                    });
                }
            },
            openDialog() {
                this.processDialog = true;
                getProcessDefineXml_key('leak_record').then(res => {
                    document.getElementById("container").innerHTML="";
                    var viewer = new Viewer({container: '#container'});
                    viewer.importXML(res.bpmn20Xml, (err) => {
                        var canvas = viewer.get('canvas');
                        canvas.zoom('fit-viewport');
                    });
                }).catch(err => {
                    this.$notify.error({
                        title: '错误',
                        message: '获取流程表单错误'
                    });
                })
            },
            selectHost(e) {
                this.selectVulData = [];
                let query = {
                    asset_code: e
                };
                let query2 = {
                    assetCode: e
                };
                selectHostScanResultByCode(query).then(data=>{
                    if(data.status == '200') {
                        this.ruleForm = data.data.data[0];
                    }
                });
                selectRecordByCode(query2).then(data => {
                    if(data.status == '200'){
                        this.menuData = data.data;
                    }
                })
            },
            handleSelectionChange(val) {
                this.selectVulData = val;
            },
            submitProcess(formData){
                let b = [];
                let a = [];
                for(let i in this.selectVulData) {
                    b.push({
                        vul_id : this.selectVulData[i].vul_id
                    });
                    a.push(this.selectVulData[i].vul_id);
                }
                if(b.length == 0) {
                    this.$alert('请选择需要备案的设备和漏洞！', '提示', {
                        confirmButtonText: '确定',
                        callback: action => {
                            return false;
                        }
                    });
                    return false;
                }
                const user = this.getCurrentUser();
                for (let i in user.groups) {
                    if (user.groups[i].type == 2) {
                        this.currentDep = user.groups[i];
                        break;
                    }
                }
                if(JSON.stringify(this.currentDep) == JSON.stringify({})){
                    this.$alert('发起人用户所属组织未设置，流程不能处理，请联系管理员！', '提示', {
                        confirmButtonText: '确定',
                        callback: action => {
                            return false;
                        }
                    });
                    return false;
                }
                this.$refs[formData].validate((valid) => {
                    if (valid) {
                        getLeakRecordId().then(data=>{
                            let key = data.businessKey;
                            let query = {
                                businessKey: key,
                                variables: {
                                    asset_code: {
                                        value: this.ruleForm.asset_code,
                                    },
                                    asset_ip: {
                                        value: this.ruleForm.asset_ip
                                    },
                                    vul_ids: {
                                        value: JSON.stringify(b),
                                    },
                                    recodeDesp: {
                                        value: this.formData.recodeDesp
                                    },
                                },
                                data:{
                                    businessKey: key,
                                    asset_code: this.ruleForm.asset_code,
                                    vul_id: a.toString(),
                                    vul_ids: a.toString(),
                                    recodeDesp: this.formData.recodeDesp,
                                    userId: user.username,
                                    name: user.name,
                                }
                            };
                            processStart(query).then(data=>{
                                if(data.status == 200 && data.message == '成功'){
                                    this.$alert('发起流程成功！', '提示', {
                                        confirmButtonText: '关闭',
                                        callback: action => {
                                            this.$router.push({
                                                path:'/soc/task-center/pending-task'
                                            });
                                        }
                                    });
                                }
                            });
                        });
                    }
                })
            }
        },
        created() {
            this.init();
        },
    }

</script>


<style lang="css" scoped>
    p{
        margin-bottom: 0px;
    }
    .backColor {
        background-color: #f0f0f0;
        width: 100%;
        height: auto;
    }

    .contentBox {
        width: 100%;
        height: auto;
        z-index: 1;
        background-color: #ffffff;
    }

    .pageContent {
        height: auto;
    }

    .margin {
        height: 35px;
        width: 100%;
        background-color: #f0f0f0;
    }

    .processContent {
        width: 100%;
        height: auto;
        padding: 20px 40px;
    }

    .tabsStyle {
        width: 100%;
        height: 1px;
        background-color: #000000;
        margin-bottom: 15px;
        margin-top: 30px;
    }

    .tabsStyle font {
        position: relative;
        top: -25px;
        font-weight: bold;
    }

    .backBottonStyle {
        position: absolute;
        right: 80px;
        top: 60px;
        z-index: 9999999;
    }

    #container{
        height: 600px;
        width: 100%;
        padding: 10px;
    }
</style>
