<template>
    <div class="backColor">
        <div class="contentBox">
            <div class="pageContent">
                <div class="margin"></div>
                <div class="backBottonStyle" v-if="isApproveProcess">
                    <el-button type="primary" @click="$router.push('/secret/user/myTask/taskCenter')" class="submit">返回</el-button>
                </div>
                <div class="processContent">
                    <el-form :model="loophole" :rules="rules" ref="ruleForm" label-width="150px" class="demo-ruleForm">
                        <el-row style="text-align:center;margin-bottom:15px;">
                            <font style="font-size: large;font-weight: bold;">主机备案申请</font>
                        </el-row>
                        <div class="tabsStyle">
                            <font>主机台账信息</font>
                            <font  v-if="!isApproveProcess" style="float: right;color: #409eff" @click = "openDialog">流程图</font>
                        </div>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机编号" v-if="isSelect">
                                    <el-input v-model="ruleForm.asset_code" :disabled="true"></el-input>
                                </el-form-item>
                                <el-form-item label="主机编号" v-else>
                                    <el-select v-model="ruleForm.asset_code" placeholder="" filterable style="width:100%;" @change="getComputerDetail">
                                        <el-option v-for="item,index in allComputerList" :key="index" :label="item.asset_code" :value="item.asset_code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机密级">
                                    <el-select v-model="ruleForm.asset_secret" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_secret')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机状态">
                                    <el-select v-model="ruleForm.asset_status" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_status')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机用途">
                                    <el-select v-model="ruleForm.asset_useage" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_useage')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="IP地址">
                                    <el-input v-model="ruleForm.asset_ip" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="MAC地址">
                                    <el-input v-model="ruleForm.asset_mac" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="硬盘SN">
                                    <el-input v-model="ruleForm.asset_disksn" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用网络">
                                    <el-select v-model="ruleForm.asset_network" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_network')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="安装位置">
                                    <el-input v-model="ruleForm.asset_area" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="责任部门">
                                    <el-input v-model="ruleForm.org_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="责任人">
                                    <el-input v-model="ruleForm.asset_duty_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用人">
                                    <el-input v-model="ruleForm.asset_user_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <div class="tabsStyle"><font>备案详情</font></div>
                        <el-row>
                            <el-col :span="12">
                                <el-form-item label="备案类别" prop="recodeType">
                                    <el-cascader
                                        v-model="loophole.recodeType"
                                        placeholder=""
                                        :options="recordDataTree"
                                        filterable
                                        style="width:100%;"
                                        @change="getRecordResonList"
                                        :disabled="isApproveProcess&&isReWrite"
                                    ></el-cascader>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="备案原因" prop="recodeReason">
                                    <el-select v-model="loophole.recodeReason" placeholder="" style="width:100%;" @change="getLoopholeDetail" :disabled="isApproveProcess&&isReWrite">
                                        <el-option v-for="item,index in recodeReasonList" :key="index" :label="item.recordName" :value="item.recordName">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="24">
                                <el-form-item label="详细描述" prop="recodeDesp">
                                    <el-input type="textarea" v-model="loophole.recodeDesp" :disabled="isApproveProcess&&isReWrite"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="3" style="text-align: right;">注</el-col>
                            <el-col :span="21" style="padding-left: 15px"><p  v-for="item in (loophole.recodeAppReason?loophole.recodeAppReason.split('\n'):[''])">{{item}}</p></el-col>
                        </el-row>
                        <el-row v-if="!isApproveProcess" style="margin-top: 15px;">
                            <el-col :span="12"  style="text-align:center;">
                                <el-button type="primary" @click="submitProcess('ruleForm')" class="submit">提交申请</el-button>
                            </el-col>
                            <el-col :span="12"  style="text-align:center;">
                                <el-button type="primary" @click="$router.back(-1)" class="submit">取消申请</el-button>
                            </el-col>
                        </el-row>
                    </el-form>
                </div>
                <el-dialog :visible.sync="processDialog" width="70%">
                    <h6>流程图</h6>
                    <div id="container"></div>
                </el-dialog>
            </div>
        </div>
        <font v-loading.fullscreen.lock="fullscreenLoading" text="流程处理中" v-if="fullscreenLoading"></font>
    </div>
</template>

<script>
    import {selectComputerDetailByAssetCode,getRecordDataTree,getRecordResonList,queryAllComputer,getEventSourceData,
        getHasRecordItem,getEventCategoryByCode,getEventSourceById,postProcess,getBusinessKey} from "@/api/terminalSecurity/recordManagement/assetRecordApply/index.js"
    import {getProcessDefineXml_key} from '@/api/user/myTask/processInfo/index.js'

    import Viewer from 'bpmn-js/lib/NavigatedViewer.js';


    export default {
        props: {
            processDetailObject:{
                type:Object,
                default: function (){
                    return {
                    }
                }
            },
            isReWrite:{
                type:Boolean,
                default: function (){
                    return false
                }
            }
        },
        computed: {
            //菜单tabs列表
            // ...mapState('userHome/branch', [
            //     'activeMenuTab',
            //     'clientMenuTabs'
            // ]),
        },
        data() {
            var validate = (rule, value, callback) => {
                if(value.length > 500){
                    callback(new Error('描述信息过长(最大为500)'));
                }
                callback();
            };
            return {
                hasRecordItem:[],
                fullscreenLoading:false,
                isApproveProcess:false,
                isSelect: this.$route.query.asset_code?true:false,
                ruleForm:{
                },
                rules:{
                    recodeType:[{
                        type: 'array',
                        required: true,
                        message: '请选择备案指标名称',
                        trigger: 'change'
                    }],
                    recodeReason:[{
                        required: true,
                        message: '请选择备案指标事由',
                        trigger: 'change'
                    }],
                    recodeDesp:[{
                        required: true,
                        message: '请输入备案申请事由',
                    },{ validator: validate, required: true,trigger: "change" }]
                },
                loophole:{
                    recodeType:[],
                    recodeReason:"",
                    recodeDesp:"",
                    recodeAppReason:"",
                    recordIndex:"false"
                },
                recordDataTree:[],
                recodeReasonList:[],
                allComputerList:[],
                currentDep: {},
                processDialog: false
            }
        },
        mounted(){
        },
        methods: {
            init(){
                if(JSON.stringify(this.processDetailObject) != JSON.stringify({})){
                    this.isSelect = true;
                    this.isApproveProcess = true;
                }

                if(this.isApproveProcess){
                    this.getComputerDetail(this.processDetailObject.asset_code);
                    this.loophole = this.processDetailObject;
                }else{
                    if(this.isSelect){
                        this.getComputerDetail(this.$route.query.asset_code);
                    }else{
                        const data = this.getCurrentUser();
                        for (let i in data.groups) {
                            if (data.groups[i].type == 2) {
                                this.currentDep = data.groups[i];
                                break;
                            }
                        }
                        var query = {
                            orgCode:this.currentDep.code
                        };
                        queryAllComputer(query).then((data)  =>{
                            if(data.data.data&&data.data.data.length>0){
                                this.allComputerList = data.data.data;
                            }
                        });
                    }
                }
                this.getRecordDataTree();
            },
            openDialog(){
                this.processDialog = true;
                getProcessDefineXml_key('P12345678').then(res => {
                    document.getElementById("container").innerHTML="";
                    var viewer = new Viewer({container: '#container'});
                    viewer.importXML(res.bpmn20Xml, (err) => {
                        var canvas = viewer.get('canvas');
                        canvas.zoom('fit-viewport');
                    });
                }).catch(err => {
                    _self.$notify.error({
                        title: '错误',
                        message: '获取流程表单错误'
                    });
                })
            },
            getRecordDataTree(){
                getRecordDataTree().then((data)  =>{
                    this.recordDataTree = data.data;

                    if(this.hasRecordItem.length>0){
                        for(var i=0;i<this.recordDataTree.length;i++){
                            for(var j=0;j<this.recordDataTree[i].children.length;j++){
                                if(this.hasRecordItem.indexOf(this.recordDataTree[i].children.value)>-1){
                                    this.recordDataTree[i].children.disabled = true;
                                }
                            }
                        }
                    }
                });
            },

            getRecordResonList(e){
                this.loophole.recodeReason = "";
                this.loophole.recodeAppReason = "";

                var id = e[e.length - 1];
                getEventSourceData().then((data)  =>{
                    for(var i=0;i<data.data.rows.length;i++){
                        if(data.data.rows[i].id == id){
                            this.loophole.recordIndex = "true";
                            break;
                        }else{
                            this.loophole.recordIndex = "false";
                        }
                    }
                });
                getRecordResonList(id).then((data)  =>{
                    this.recodeReasonList = data.data.recordItems;
                });

                getEventCategoryByCode(e[0]).then((data)  =>{
                    this.loophole.norm_type = data.data.rows[0].categoryCode;
                    this.loophole.norm_type_name = data.data.rows[0].categoryName;
                });

                getEventSourceById(id).then((data)  =>{
                    this.loophole.norm_code = data.data.sourceCode;
                    this.loophole.norm_title = data.data.recordType;
                });
            },

            getLoopholeDetail(){
                if(this.recodeReasonList.length>0){
                    this.loophole.recodeAppReason = this.recodeReasonList[0].sourceDescription;
                }
            },
            getComputerDetail(e){
                this.loophole.recodeType = [];
                this.loophole.recodeReason = "";
                this.loophole.recodeAppReason = "";

                selectComputerDetailByAssetCode(e).then((data)=>{
                    if(data.data.total>0){
                        this.ruleForm =data.data.data[0];
                    }
                    var queryAsset = {
                        asset_code:e
                    }
                    getHasRecordItem(queryAsset).then((data2)=>{
                        if(data2.data.total == 0){
                            this.hasRecordItem = [];
                            this.getRecordDataTree();
                        }else{
                            var arr = [];
                            for(var i=0;i<data2.data.data.length;i++){
                                arr.push(parseInt(data2.data.data[i]['b.recodeType'].split(',')[1]));
                            }

                            this.hasRecordItem = arr;

                            if(this.hasRecordItem.length>0){
                                for(var i=0;i<this.recordDataTree.length;i++){
                                    for(var j=0;j<this.recordDataTree[i].children.length;j++){
                                        if(this.hasRecordItem.indexOf(this.recordDataTree[i].children[j].value)>-1){
                                            this.recordDataTree[i].children[j].disabled = true;
                                        }
                                    }
                                }
                            }
                        }
                    });
                });
            },
            submitProcess(formName){
                if(JSON.stringify(this.currentDep) == JSON.stringify({})){
                    this.$alert('发起人用户所属组织未设置，流程不能处理，请联系管理员！', '提示', {
                        confirmButtonText: '确定',
                        callback: action => {
                            return false;
                        }
                    });
                    return false;
                }
                if(this.ruleForm.asset_code == undefined || this.ruleForm.asset_code == ''){
                    this.$alert('请选择需要备案的设备！', '提示', {
                        confirmButtonText: '确定',
                        callback: action => {
                            return false;
                        }
                    });
                    return false;
                }
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        getBusinessKey().then((rtn) => {
                            this.loophole.asset_code=this.ruleForm.asset_code;
                            console.log(this.loophole);
                            postProcess(this.loophole,'P12345678',rtn.businessKey).then((data) => {
                                if(data.id.length==36){
                                    this.fullscreenLoading = true;
                                    setTimeout(() => {
                                        this.$alert('发起流程成功！', '提示', {
                                            confirmButtonText: '关闭',
                                            callback: action => {
                                                this.fullscreenLoading = false;
                                                this.$router.push({
                                                    path:'/soc/task-center/pending-task'
                                                });
                                                // setTimeout(()=>this.removeTabs('socParameterManage'), 200);
                                            }
                                        });
                                    }, 1500);
                                }
                            });
                        });
                    } else {
                        return false;
                    }
                });
            },
            //满足bpmn数据格式
            formattingData(val){
                var newData={variables:{}};
                for (let i in val){
                    newData.variables[i]={value:val[i]};
                }
                return newData
            },
            //移除指定name的tabs
            // removeTabs(name){
            //     var search={};
            //     let tabs = this.clientMenuTabs;
            //     let activeName = this.activeMenuTab;
            //     if (activeName === name) {
            //         tabs.forEach((tab, index) => {
            //             if (tab.name === name) {
            //                 let nextTab = tabs[index + 1] || tabs[index - 1];
            //                 // console.log(nextTab);
            //                 if (nextTab) {
            //                     //移除后的当前tab，跳转到指定页
            //                     search.name= nextTab.name;
            //                     search.path=nextTab.path;
            //                     search.title=nextTab.title;
            //                 }
            //             }
            //         });
            //     }else{
            //         search.name= activeName;
            //     }
            //     search.type='remove';
            //     search.data=this.clientMenuTabs.filter(tab => tab.name !== name);
            //     // console.log(search);
            //     this.$store.dispatch('userHome/branch/menuTabsManage',search);
            //     //当移除完后，跳转到用户端首页
            // }
        },
        watch:{
            processDetailObject:function(){
                this.init();
            },
            'currentDep.code':function(){
                this.init();
            }
        },
        created() {
            this.init();
        },
        activated() {
            this.loophole={
                recodeType:[],
                recodeReason:"",
                recodeDesp:"",
                recodeAppReason:"",
                recordIndex:"false"
            };
            this.init();
        }
    }

</script>


<style lang="css" scoped>
    p{
        margin-bottom: 0px;
    }
    .backColor {
        background-color: #f0f0f0;
        width: 100%;
        height: auto;
    }

    .contentBox {
        width: 100%;
        height: auto;
        z-index: 1;
        background-color: #ffffff;
    }

    .pageContent {
        height: auto;
    }

    .margin {
        height: 35px;
        width: 100%;
        background-color: #f0f0f0;
    }

    .processContent {
        width: 100%;
        height: auto;
        padding: 20px 40px;
    }

    .tabsStyle {
        width: 100%;
        height: 1px;
        background-color: #000000;
        margin-bottom: 15px;
        margin-top: 30px;
    }

    .tabsStyle font {
        position: relative;
        top: -25px;
        font-weight: bold;
    }

    .backBottonStyle {
        position: absolute;
        right: 80px;
        top: 60px;
        z-index: 9999999;
    }

    #container{
        height: 600px;
        width: 100%;
        padding: 10px;
    }
</style>
