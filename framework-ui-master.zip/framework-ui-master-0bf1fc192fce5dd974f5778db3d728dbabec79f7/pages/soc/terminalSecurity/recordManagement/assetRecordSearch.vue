<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="主机编号：">
                    <el-input v-model="assetCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="责任部门：">
                    <el-input v-model="orgName" clearable></el-input>
                </el-form-item>
                <el-form-item label="主机密级：">
                    <el-select v-model="secret" clearable>
                        <el-option v-for="item,index in getCategoryData('asset_secret')" :key="index"
                                   :label="item.label" :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="接入网络：">
                    <el-select v-model="assetNetwork" clearable>
                        <el-option v-for="item,index in getCategoryData('asset_network')" :key="index"
                                   :label="item.label" :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="备案原因：">
                    <el-input v-model="normTitle" clearable></el-input>
                </el-form-item>
                <el-form-item label="设备状态：">
                    <el-select v-model="asset_status" clearable>
                        <el-option v-for="item,index in getCategoryData('asset_status')" :key="index"
                                   :label="item.label" :value="item.code">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item >
                    <el-button  @click='toDoSearch' type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="menuPersonData.data">
                <el-table-column
                    type="index"
                    width="50"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="asset_code"
                    label="主机编号"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="org_name"
                    label="责任部门"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="主机密级"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('asset_secret',scope.row.asset_secret)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_os"
                    label="操作系统"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="设备用途"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('asset_useage',scope.row.asset_useage)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="接入网络"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{getCategoryData('asset_network',scope.row.asset_network)}}
                    </template>
                </el-table-column>
                <el-table-column
                    prop="asset_ip"
                    label="IP地址"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_type_name"
                    label="备案类别"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="norm_title"
                    label="备案原因"
                    show-overflow-tooltip>
                </el-table-column>
                <el-table-column
                    prop="scope"
                    label="备案完成时间"
                    show-overflow-tooltip>
                    <template slot-scope="scope">
                        {{item.end_date?timestampToTime(scope.row.end_date):""}}
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
    </div>
</template>

<script>
    import pagination from '@/components/common/pagination.vue';
    import {getRecordDataTree,getMenuData,getRecordType} from "@/api/terminalSecurity/recordManagement/assetRecordSearch/index"

    export default {
        name: "assetRecordSearch",
        components: {
            pagination
        },
        data() {
            return {
                recordDataTree:[],
                pageNo: 1,
                assetCode: "",
                orgName: "",
                secret: "",
                assetNetwork: "",
                normTypeName: "",
                asset_status: "",
                normTitle: "",
                searchContentData:[],
                menuPersonData:{
                },
                orgCode: "",
                options: [],
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.pageNo,
                    pageSize: 10,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
            init(){
                getRecordDataTree().then((data)  =>{
                    this.recordDataTree = data.data;
                });
                let query = {
                    pageNo: "0",
                    pageSize: "10"
                };
                getMenuData(query).then(data => {
                    this.menuPersonData = data.data;
                })
            },
            getRecordType() {
                getRecordType().then((data)=>{
                    for(let i in data.data.rows){
                        this.options.push({
                            value: data.data.rows[i].categoryCode,
                            label: data.data.rows[i].categoryName
                        })
                    }
                })
            },
            toDoSearch() {
                this.pageNo = 1;
                this.doSearch();
            },
            doSearch(){
                let str = '';
                if(this.assetCode != ""){
                    if(str == '') {
                        str = 'where asset_code =' + "'" + this.assetCode + "'"
                    }else {
                        str = str + ' and asset_code =' + "'" + this.assetCode + "'"
                    }
                }
                if(this.orgName != ""){
                    if(str == '') {
                        str = 'where org_name like'+"'%"+this.orgName+"%'";
                    }else {
                        str = str + ' and org_name like'+"'%"+this.orgName+"%'";
                    }
                }
                if(this.secret != ""){
                    if(str == '') {
                        str = 'where asset_secret ='+"'"+this.secret+"'";
                    }else {
                        str = str + ' and asset_secret ='+"'"+this.secret+"'";
                    }
                }
                if(this.assetNetwork != ""){
                    if(str == '') {
                        str = 'where asset_network ='+"'"+this.assetNetwork+"'";
                    }else {
                        str = str + ' and asset_network ='+"'"+this.assetNetwork+"'";
                    }
                }
                if(this.normTypeName != ""){
                    if(str == '') {
                        str = 'where recordType ='+"'"+this.normTypeName+"'";
                    }else {
                        str = str + ' and recordType ='+"'"+this.normTypeName+"'";
                    }
                }
                if(this.normTitle != ""){
                    if(str == '') {
                        str = 'where norm_title like'+"'%"+this.normTitle+"%'";
                    }else {
                        str = str + ' and norm_title like'+"'%"+this.normTitle+"%'";
                    }
                }
                if(this.asset_status != ""){
                    if(str == '') {
                        str = 'where asset_status ='+"'"+this.asset_status+"'";
                    }else {
                        str = str + ' and asset_status ='+"'"+this.asset_status+"'";
                    }
                }
                let query = {
                    where: str,
                    page: this.pageNo,
                    size: 10
                };
                // selectAppBpmnPWhereIsAgree(query).then((data)=>{
                //     if(data.data){
                //         this.menuPersonData = data.data;
                //     }
                // })
            },
            pageChange(val){
                this.pageNo=val;
                this.doSearch();
            },
            formChange(val){
                if(this[val]){
                    this['check'+val]=true;
                }else{
                    this['check'+val]=false;
                }
            },
            toPrint(code){
                let srcHtml = "http://ureport.seadun.com:8044/ureport/preview?_u=file:formNumber.ureport.xml&Id="+code;
                this.$router.push({
                    path:"/soc/terminal-security/record-management/loople-record-cancle",
                    query: {
                        processInstanceId: code
                    }
                });
            }
        },
        created() {
            this.doSearch();
            this.getRecordType();
            this.init();
        }
    }
</script>

<style scoped>
    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .headerContent span {
        float: left;
        font-size: 14px;
        line-height: 14px;
        padding: 15px;
        cursor: pointer;
    }

    .header .hoverContent {
        height: auto;
        background-color: #ffffff;
        box-shadow: rgba(0, 0, 0, 0.14) 0px 0px 12px 2px;
        position: absolute;
        top: 46px;
        width: 960px;
        left: 120px;
        z-index: 100;
        display: none;
        padding: 15px 20px;
    }

    .hoverContent font {
        font-size: 14px;
    }

    .hoverContent font:hover {
        color: #004ea2;
    }

    .hoverContent .tags {
        width: 8px;
        height: 8px;
        background-color: #004ea2;
        margin-bottom: 10px;
        margin-left: 2px;
    }

    .headerContent span:hover {
        padding-bottom: 13px;
        border-bottom: 2px solid #004ea2;
    }

    .headerContent span:hover .hoverContent {
        display: block;
    }

    .searchInput,
    .searchCascader {
        width: 150px;
        height: 30px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        margin-top: 35px;
    }
</style>
<style lang="css">
    .el-notification.right {
        top: 100px !important;
    }
</style>

