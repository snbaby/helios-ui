<template>
    <div class="backColor" id="loopleRecordCancle">
        <div class="contentBox">
            <div class="pageContent">
                <div class="margin"></div>
                <div class="backBottonStyle">
                    <el-button type="primary" @click="$router.back(-1)" class="submit">返回</el-button>
                </div>
                <div class="processContent">
                    <el-form ref="ruleForm" :model="cancel" :rules="rules" label-width="150px" class="demo-ruleForm">
                        <el-row style="text-align:center;margin-bottom:15px;">
                            <font style="font-size: large;font-weight: bold;">主机备案取消申请</font>
                        </el-row>
                        <div class="tabsStyle">
                            <font>主机台账信息</font>
                            <font style="float: right;color: #409eff" @click = "openDialog">流程图</font>
                        </div>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机编号" >
                                    <el-input v-model="ruleForm.asset_code" :disabled="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机密级">
                                    <el-select v-model="ruleForm.asset_secret" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_secret')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="主机状态">
                                    <el-select v-model="ruleForm.asset_status" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_status')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="主机用途">
                                    <el-select v-model="ruleForm.asset_useage" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_useage')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="IP地址">
                                    <el-input v-model="ruleForm.asset_ip" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="MAC地址">
                                    <el-input v-model="ruleForm.asset_mac" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="硬盘SN">
                                    <el-input v-model="ruleForm.asset_disksn" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用网络">
                                    <el-select v-model="ruleForm.asset_network" placeholder="" style="width:100%;" :disabled="true">
                                        <el-option v-for="item,index in getCategoryData('asset_network')" :key="index" :label="item.label" :value="item.code">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="安装位置">
                                    <el-input v-model="ruleForm.asset_area" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="8">
                                <el-form-item label="责任部门">
                                    <el-input v-model="ruleForm.org_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="责任人">
                                    <el-input v-model="ruleForm.asset_duty_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="8">
                                <el-form-item label="使用人">
                                    <el-input v-model="ruleForm.asset_user_name" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <div class="tabsStyle"><font>备案详情</font></div>
                        <el-row>
                            <el-col :span="12">
                                <el-form-item label="备案类别" prop="recodeList">
                                    <!--<el-cascader-->
                                        <!--v-model="recodeList"-->
                                        <!--placeholder=""-->
                                        <!--:options="recordDataTree"-->
                                        <!--style="width:100%;"-->
                                        <!--@change="getRecordResonList"-->
                                    <!--&gt;</el-cascader>-->
                                    <el-input v-model="recodeType" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="12">
                                <el-form-item label="备案原因" prop="recodeReason">
                                    <el-input v-model="ruleForm.recodeReason" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="24">
                                <el-form-item label="详细描述" prop="recodeDesp">
                                    <el-input type="textarea"  v-model="ruleForm.recodeDesp" :readonly="true"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row style="margin-top: 10px">
                            <el-col :span="24">
                                <el-form-item label="取消原因" prop="cancelReason">
                                    <el-input type="textarea"  v-model="cancel.cancelReason"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row style="margin-top: 15px;">
                            <el-col :span="12"  style="text-align:center;">
                                <el-button type="primary" @click="submitProcess('ruleForm')" class="submit">提交申请</el-button>
                            </el-col>
                            <el-col :span="12"  style="text-align:center;">
                                <el-button type="primary" class="submit" @click="$router.back(-1)">取消申请</el-button>
                            </el-col>
                        </el-row>
                    </el-form>
                </div>
                <el-dialog :visible.sync="processDialog" width="70%">
                    <h6>流程图</h6>
                    <div id="container"></div>
                </el-dialog>
            </div>
        </div>
        <font v-loading.fullscreen.lock="fullscreenLoading" text="流程处理中" v-if="fullscreenLoading"></font>
    </div>
</template>

<script>
    import {getFormData,getRecordDataTree,getProcessDefineXml_key,getBusinessKey,postProcess} from '@/api/terminalSecurity/recordManagement/loopleRecordCancle/index.js'
    import Viewer from 'bpmn-js/lib/NavigatedViewer.js';
    export default {

        data() {
            return {
                cancel: {
                    cancelReason: ""
                },
                currentDep: "",
                ruleForm: {},
                recordDataTree: [],
                recodeList: [],
                recodeType: "",
                processDialog: false,
                rules: {
                    cancelReason: [{
                        required: true,
                        message: '请选择备案指标事由',
                        trigger: 'change'
                    }]
                },
                fullscreenLoading: false,
                processInstanceId: this.$route.query.processInstanceId
            }
        },
        mounted(){
        },
        methods: {
            init(){
                let query = {
                    flowId: this.processInstanceId
                };
                getFormData(query).then(data => {
                    this.ruleForm = data.data.data[0];
                    this.recodeList =  this.ruleForm.recodeType.split(",");
                    this.getRecordDataTree();
                });
                const data = this.getCurrentUser();
                for (let i in data.groups) {
                    if (data.groups[i].type == 2) {
                        this.currentDep = data.groups[i];
                        break;
                    }
                }
            },
            openDialog(){
                this.processDialog = true;
                getProcessDefineXml_key('cancel_record').then(res => {
                    document.getElementById("container").innerHTML="";
                    var viewer = new Viewer({container: '#container'});
                    viewer.importXML(res.bpmn20Xml, (err) => {
                        var canvas = viewer.get('canvas');
                        canvas.zoom('fit-viewport');
                    });
                }).catch(err => {
                    _self.$notify.error({
                        title: '错误',
                        message: '获取流程表单错误'
                    });
                })
            },
            getRecordDataTree(){
                getRecordDataTree().then((data)  => {
                    for(let i in data.data){
                        if(data.data[i].value == this.recodeList[0]){
                            for(let y in data.data[i].children){
                                if(data.data[i].children[y].value == this.recodeList[1]){
                                    this.recodeType = data.data[i].label + "/" + data.data[i].children[y].label;
                                }
                            }
                        }
                    }
                })
            },

            getRecordResonList(e){
                console.log(e);
            },

            getLoopholeDetail(){

            },
            getLoopholeDesp(){

            },
            getComputerDetail(e){

            },
            submitProcess(formName){
                if(JSON.stringify(this.currentDep) == JSON.stringify({})){
                    this.$alert('发起人用户所属组织未设置，流程不能处理，请联系管理员！', '提示', {
                        confirmButtonText: '确定',
                        callback: action => {
                            return false;
                        }
                    });
                    return false;
                }
                if(this.ruleForm.asset_code == undefined || this.ruleForm.asset_code == ''){
                    this.$alert('请选择需要备案的设备！', '提示', {
                        confirmButtonText: '确定',
                        callback: action => {
                            return false;
                        }
                    });
                    return false;
                }
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        let tableForm = {
                            asset_code: this.ruleForm.asset_code,
                            processId: this.processInstanceId,
                            cancelReason: this.cancel.cancelReason,
                            norm_code: this.ruleForm.norm_code,
                            norm_title: this.ruleForm.norm_title,
                            norm_type: this.ruleForm.norm_type,
                            // norm_type_name: this.ruleForm.norm_type_name,
                            recodeAppReason: this.ruleForm.recodeAppReason,
                            recodeDesp: this.ruleForm.recodeDesp,
                            recodeReason: this.ruleForm.recodeReason,
                            recodeType: this.ruleForm.recodeType,
                        };
                        console.log(tableForm);
                        getBusinessKey().then((rtn) => {
                            postProcess(tableForm,'cancel_record',rtn.businessKey).then((data) => {
                                if(data.id.length==36){
                                    this.fullscreenLoading = true;
                                    setTimeout(() => {
                                        this.$alert('发起流程成功！', '提示', {
                                            confirmButtonText: '关闭',
                                            callback: action => {
                                                this.fullscreenLoading = false;
                                                this.$router.push({
                                                    path:'/soc/task-center/pending-task'
                                                });
                                                setTimeout(()=>this.removeTabs('socParameterManage'), 200);
                                            }
                                        });
                                    }, 1500);
                                }
                            });
                        });
                    } else {
                        return false;
                    }
                });
            },
            //满足bpmn数据格式
            formattingData(val){
            },
            //移除指定name的tabs
            removeTabs(name){
            }
        },
        watch:{
        },
        created() {
            this.init();
        },
        activated() {
            this.init();

        }
    }

</script>


<style lang="css" scoped>
    p{
        margin-bottom: 0px;
    }
    .backColor {
        background-color: #f0f0f0;
        width: 100%;
        height: auto;
    }

    .contentBox {
        width: 100%;
        height: auto;
        z-index: 1;
        background-color: #ffffff;
    }

    .pageContent {
        height: auto;
    }

    .margin {
        height: 35px;
        width: 100%;
        background-color: #f0f0f0;
    }

    .processContent {
        width: 100%;
        height: auto;
        padding: 20px 40px;
    }

    .tabsStyle {
        width: 100%;
        height: 1px;
        background-color: #000000;
        margin-bottom: 15px;
        margin-top: 30px;
    }

    .tabsStyle font {
        position: relative;
        top: -25px;
        font-weight: bold;
    }

    .backBottonStyle {
        position: absolute;
        right: 80px;
        top: 128px;
        z-index: 9999999;
    }

    #container{
        height: 600px;
        width: 100%;
        padding: 10px;
    }
</style>

<style>
    #loopleRecordCancle .el-input {
        width: 100%;
    }
</style>
