<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="用户名称：">
                    <el-input v-model="userName" clearable></el-input>
                </el-form-item>
                <el-form-item label="用户编码：">
                    <el-input v-model="userCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="用户IP：">
                    <el-input v-model="userIp" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button @click="searchPersonTable" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="dataOperationLog.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="crtName"
                    label="用户名称">
                </el-table-column>
                <el-table-column
                    prop="crtUser"
                    label="用户编码">
                </el-table-column>
                <el-table-column
                    prop="tableName"
                    label="数据表">
                </el-table-column>
                <el-table-column
                    prop="operation"
                    label="操作类型">
                </el-table-column>
                <el-table-column
                    prop="crtHost"
                    label="用户IP">
                </el-table-column>
                <el-table-column
                    prop="crtTime"
                    label="操作时间">
                </el-table-column>
            </el-table>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
    </div>
</template>
<script>
    import {fetch} from '@/core/fetch.js';
    import pagination from '@/components/common/pagination.vue';

    export default {
        components: {
            pagination
        },
        data() {
            return {
                userCode: "",
                userName: "",
                userIp: "",
                pageNo: 1,
                pageSize: 10,
                dataOperationLog: {
                    pageNo: 0,
                    pageSize: 10,
                    total: 0,
                    rows: [],
                }

            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.dataOperationLog.pageNo,
                    pageSize: this.dataOperationLog.pageSize,
                    total: this.dataOperationLog.total
                }
            },
        },
        created() {
            this.refreshPersonTable();
        },
        methods: {
            //刷新表格
            refreshPersonTable() {
                var search = {
                    page: this.pageNo,
                    limit: this.pageSize
                }
                if (this.userCode != '') {
                    search.username = this.userCode;
                }
                if (this.userName != '') {
                    search.name = this.userName;
                }
                if (this.userIp != '') {
                    search.crtHost = this.userIp;
                }
                fetch({
                    "url": '/api/admin/dbLog/getPager',
                    "params": search,
                    "method": "post"
                })
                    .then((data) => {
                        this.dataOperationLog = data.data;
                    });
            },
            //翻页
            pageChange(val) {
                this.pageNo = val;
                this.refreshPersonTable();
            },
            //条件查询
            searchPersonTable() {
                this.refreshPersonTable();
            },
        }
    }

</script>
