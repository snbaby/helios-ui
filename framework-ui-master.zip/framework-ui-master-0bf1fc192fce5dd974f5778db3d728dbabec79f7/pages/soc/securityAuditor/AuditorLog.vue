<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="用户名称：">
                    <el-input v-model="userName" clearable></el-input>
                </el-form-item>
                <el-form-item label="用户编码：">
                    <el-input v-model="userCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="用户IP：">
                    <el-input v-model="userIp" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button @click="searchPersonTable" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="auditorLog.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="crtName"
                    label="用户名称">
                </el-table-column>
                <el-table-column
                    prop="username"
                    label="用户编码">
                </el-table-column>
                <el-table-column
                    prop="tableDesc"
                    label="访问功能">
                </el-table-column>
                <el-table-column
                    prop="tableName"
                    label="数据表">
                </el-table-column>
                <el-table-column
                    prop="operation"
                    label="操作类型">
                </el-table-column>
                <el-table-column
                    prop="crtHost"
                    label="用户IP">
                </el-table-column>
                <el-table-column
                    prop="crtTime"
                    label="操作时间">
                </el-table-column>
            </el-table>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
    </div>
</template>

<script>
    import {fetch} from '@/core/fetch.js';
    import pagination from '@/components/common/pagination.vue';

    export default {
        components: {
            pagination
        },
        data() {
            return {
                userCode: "",
                userName: "",
                userIp: "",
                pageNo: 1,
                pageSize: 10,
                auditorLog: {
                    pageNo: 0,
                    pageSize: 10,
                    total: 0,
                    rows: [],
                }

            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.auditorLog.pageNo,
                    pageSize: this.auditorLog.pageSize,
                    total: this.auditorLog.total
                }
            }
        },
        created() {
            this.refreshRolePerson;
        },
        methods: {
            //当用户输入查询条件时，级联选中对应检查
            formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
            //刷新人员表格
            refreshRolePerson() {
                let str = {
                    page: this.pageNo,
                    limit: 10,
                    groupType: 'auditor'
                }
                if (this.userCode != '') {
                    str.name = this.userCode

                }
                if (this.userName != '') {
                    str.username = this.userName

                }
                if (this.userIp != '') {
                    str.crtHost = this.userIp
                }

                fetch({
                    url: "/api/admin/dbLog/getPager",
                    params: search,
                    method: "post"
                }).then(data => {
                    this.auditorLog = data.data;
                });

            },
            //人员表翻页
            pageChange(val) {
                this.pageNo = val;
                this.refreshRolePerson();
            },
            //条件查询人员表格
            searchPersonTable() {
                this.refreshRolePerson();
            },
        },
    }
</script>
