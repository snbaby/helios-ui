<template>
    <div class="framework-content">
        <div class="framework-search-form">
            <el-form :inline="true">
                <el-form-item label="员工工号：">
                    <el-input v-model="userCode" clearable></el-input>
                </el-form-item>
                <el-form-item label="姓名：">
                    <el-input v-model="userName" clearable></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button @click="searchPersonTable" type="primary">查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <div>
            <el-table :data="loginLog.rows">
                <el-table-column
                    type="index"
                    width="50">
                </el-table-column>
                <el-table-column
                    prop="crtName"
                    label="用户名称">
                </el-table-column>
                <el-table-column
                    prop="username"
                    label="员工工号">
                </el-table-column>
                <el-table-column
                    prop="crtHost"
                    label="用户IP">
                </el-table-column>
                <el-table-column
                    prop="crtTime"
                    label="操作时间">
                </el-table-column>
            </el-table>
            <pagination :option="pageOption" @pageChange="pageChange"></pagination>
        </div>
    </div>
</template>
<script>
    import {fetch} from '@/core/fetch.js';
    import pagination from '@/components/common/pagination.vue';

    export default {
        components: {
            pagination
        },
        data() {
            return {
                userCode: "",
                userName: "",
                pageNo: 1,
                pageSize: 10,
                loginLog: {
                    pageNo: 0,
                    pageSize: 10,
                    total: 0,
                    rows: [],
                }

            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.loginLog.pageNo,
                    pageSize: this.loginLog.pageSize,
                    total: this.loginLog.total
                }
            },
        },
        created() {
            this.refreshPersonTable();
        },
        methods: {
            //刷新表格
            refreshPersonTable() {
                var search = {
                    page: this.pageNo,
                    limit: this.pageSize,
                    type: 'login'
                }
                if (this.userCode != '') {
                    search.username = this.userCode;
                }
                if (this.userName != '') {
                    search.name = this.userName;
                }
                fetch({
                    "url": '/api/admin/gateLog/getPager',
                    "params": search,
                    "method": "post"
                })
                    .then((data) => {
                        this.loginLog = data.data;
                    });
            },
            //翻页
            pageChange(val) {
                this.pageNo = val;
                this.refreshPersonTable();
            },
            //条件查询
            searchPersonTable() {
                this.refreshPersonTable();
            },
        },
    }

</script>
