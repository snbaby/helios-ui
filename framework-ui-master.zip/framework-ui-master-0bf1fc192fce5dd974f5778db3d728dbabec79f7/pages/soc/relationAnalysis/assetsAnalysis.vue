<template>
    <div class="backColor">
        <div class="contentBox" style="margin: auto;">
            <div class="left">
                <tree :treedata="menuList"></tree>
            </div>
            <div class="right">
                <personAnalysis :clickParameter="data"></personAnalysis>
            </div>
        </div>
    </div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import tree from '@/components/common/tree.vue';
    import personAnalysis from '@/components/relationAnalysis/personAnalysis.vue';
    import {getHead,getTableHead,getTableData,getTreeData,getOneForButton,getButtonDetail} from '@/api/parameterManage/index.js';

    export default {
        components: {
            personAnalysis
        },
        data() {
            return {
                data:{
                    "isTree": true,
                    "tableType": "org_business_person",
                    "treeId": "org_code",
                    "treeLabel": "org_name",
                    "treeType": "org_business",
                    "lable": "业务人员",
                    "index": "org_business",
                    "id": "organization|||org_business|||org_business_person",
                    "type": "org_business_person"
                }
            }
        },
        computed: {

        },
        methods: {
            init(){
                getHead().then((data)=>{
                    this.parameterHeadData = data;
                })
            }
        },
        watch:{

        },
        created() {

        },
        activated() {

        }
    }

</script>
