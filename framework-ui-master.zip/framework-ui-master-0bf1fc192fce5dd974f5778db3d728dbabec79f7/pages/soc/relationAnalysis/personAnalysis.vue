<template>
    <personAnalysis :clickParameter="data"></personAnalysis>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import personAnalysis from '@/components/relationAnalysis/personAnalysis.vue';

    export default {
        components: {
            personAnalysis
        },
        data() {
            return {
                data:{
                    "isTree": true,
                    "tableType": "org_business_person",
                    "treeId": "org_code",
                    "treeLabel": "org_name",
                    "treeType": "org_business",
                    "lable": "业务人员",
                    "index": "org_business",
                    "id": "organization|||org_business|||org_business_person",
                    "type": "org_business_person"
                }
            }
        },
        computed: {

        },
        methods: {

        },
        watch:{

        },
        created() {

        },
        activated() {

        }
    }

</script>
