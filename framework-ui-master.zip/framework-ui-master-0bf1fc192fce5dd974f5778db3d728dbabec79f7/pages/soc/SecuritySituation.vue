<template>
    <div class="backColor" :style="`height:${screenHeight}px;`" id="socSafetyCockpit">
        <mu-row :gutter="true" class="pageHead">
            <div class="cockpitTitle"></div>
        </mu-row>
        <mu-row :gutter="true" class="pageContent" :style="`width:${rowWidth};height:${colHeight}`">
            <mu-row style="width:100%;height: 100%;" gutter>
                <mu-col width="25" tablet="25" desktop="25" class="contentBox">
                    <mu-row class="socContentChild" :style="`height:${saidTopHeightRow};`">
                        <mu-row class="socContentTopHead">
                            <div class="left">
                                <font>终端环境安全</font>
                            </div>
                            <div class="right">
                                <font>当前终端在线数： <font class="socCount">12,562</font> (台)</font>
                            </div>
                        </mu-row>
                        <mu-row class="socContentRow" style="height:18.4%;margin-top:20px;">
                            <mu-row style="height:20%;width:100%;">
                                <div class="targetImg">
                                    <font class="pageContentFontStyle1 targetImgBehand">违规监测</font>
                                </div>
                            </mu-row>
                            <mu-row style="height:80%;width:100%;padding-top:20px;padding-right:10px;">
                                <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                    <div class="socleftTopRow1">
                                        <div class="standTop">
                                            <font>非法外联</font>
                                        </div>
                                        <div class="standBottom">
                                            <font :style="getShowColor(violationsCount.ffwl.level)">{{violationsCount.ffwl.count}}</font>
                                        </div>
                                    </div>
                                </mu-col>
                                <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                    <div class="socleftTopRow1">
                                        <div class="standTop">
                                            <font>违规接入</font>
                                        </div>
                                        <div class="standBottom">
                                            <font :style="getShowColor(violationsCount.wgjr.level)">{{violationsCount.wgjr.count}}</font>
                                        </div>
                                    </div>
                                </mu-col>
                                <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                    <div class="socleftTopRow1">
                                        <div class="standTop">
                                            <font>嗅探登录</font>
                                        </div>
                                        <div class="standBottom">
                                            <font :style="getShowColor(violationsCount.xtdl.level)">{{violationsCount.xtdl.count}}</font>
                                        </div>
                                    </div>
                                </mu-col>
                                <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                    <div class="socleftTopRow1">
                                        <div class="standTop">
                                            <font>违规登录</font>
                                        </div>
                                        <div class="standBottom">
                                            <font :style="getShowColor(violationsCount.wgdl.level)">{{violationsCount.wgdl.count}}</font>
                                        </div>
                                    </div>
                                </mu-col>
                            </mu-row>
                        </mu-row>
                        <mu-row class="socContentRow" style="height:27.067%;">
                            <mu-row style="height:13%;width:100%;">
                                <div class="targetImg">
                                    <font class="pageContentFontStyle1 targetImgBehand">防护监测</font>
                                </div>
                            </mu-row>
                            <mu-row style="height: 113%;width: 100%;position: relative;top: -13%;">
                                <div class="fhjcCountStyle">
                                    <mu-row style="height:100%;padding-left: 5%;">
                                        <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                            <div class="socCountImg">
                                                <div class="socCountImgHead">资产总数</div>
                                                <font>{{apprendZore(protectionDetection.zsbf)}}</font>
                                            </div>
                                        </mu-col>
                                        <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                            <div class="socCountImg">
                                                <div class="socCountImgHead">资产总数</div>
                                                <font>{{apprendZore(protectionDetection.zjsj)}}</font>
                                            </div>
                                        </mu-col>
                                        <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                            <div class="socCountImg">
                                                <div class="socCountImgHead">资产总数</div>
                                                <font>{{apprendZore(protectionDetection.shy)}}</font>
                                            </div>
                                        </mu-col>
                                        <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                            <div class="socCountImg">
                                                <div class="socCountImgHead">资产总数</div>
                                                <font>{{apprendZore(protectionDetection.fbd)}}</font>
                                            </div>
                                        </mu-col>
                                    </mu-row>
                                </div>
                                <div id="protectionDetectionEcharts" style="width:100%;height:100%;"></div>
                            </mu-row>
                        </mu-row>
                        <mu-row class="socContentRow" style="height:22.133%;">
                            <mu-row style="height:16.3%;width:100%;">
                                <div class="targetImg">
                                    <font class="pageContentFontStyle1 targetImgBehand">高危漏洞</font>
                                </div>
                            </mu-row>
                            <mu-row style="height: 116.3%; width: 100%;position: relative;top: -16.3%;">
                                <div id="highRiskVulnerabilitiesEcharts" style="width:100%;height:100%;"></div>
                            </mu-row>
                        </mu-row>
                        <mu-row class="socContentRow" style="height:22%;">
                            <mu-row style="height:16.4%;width:100%;">
                                <div class="targetImg">
                                    <font class="pageContentFontStyle1 targetImgBehand">开放端口</font>
                                </div>
                            </mu-row>
                            <mu-row style="height:83.6%;width:100%;">
                                <div id="openPortsEcharts" style="width:100%;height:100%;"></div>
                            </mu-row>
                        </mu-row>
                    </mu-row>
                    <mu-row class="socContentChild" :style="`height:${saidBottomHeightRow};margin-top:20px;`">
                        <mu-row class="socContentBottomHead">
                            <div class="left">
                                <font>网络环境安全</font>
                            </div>
                            <div class="right">
                                <font>当天网络日志数： <font class="socCount">351,562</font> (条)</font>
                            </div>
                        </mu-row>
                        <mu-row class="socContentBottomBottom">
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(networkSafetyCount.zrkz.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(networkSafetyCount.zrkz.level)"
                                              class="fontWeightBold">{{networkSafetyCount.zrkz.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">准入控制</font>
                                </div>
                            </mu-col>
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(networkSafetyCount.fwkz.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(networkSafetyCount.fwkz.level)"
                                              class="fontWeightBold">{{networkSafetyCount.fwkz.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">访问控制</font>
                                </div>
                            </mu-col>
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(networkSafetyCount.rqjc.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(networkSafetyCount.rqjc.level)"
                                              class="fontWeightBold">{{networkSafetyCount.rqjc.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">入侵检测</font>
                                </div>
                            </mu-col>
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(networkSafetyCount.rqfh.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(networkSafetyCount.rqfh.level)"
                                              class="fontWeightBold">{{networkSafetyCount.rqfh.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">入侵防护</font>
                                </div>
                            </mu-col>
                        </mu-row>
                    </mu-row>
                </mu-col>
                <mu-col width="50" tablet="50" desktop="50">
                    <mu-row :style="`height:${centerTopHeightRow};width:100%;padding-top:20px;`">
                        <div class="socMapStyle">
                            <div id="mymap" refs="mymap">
                            </div>
                            <div id="mypoint" refs="mypoint"></div>
                            <div class="riskValueEchartsConent">
                                <div id="socRiskTrendEcharts" style="width:100%;height:100%;"></div>
                                <div class="riskValueContent" style="top:99%;">
                                    当前风险值：<font class="riskValueStyle" :style="getShowColor(socRisk.level)">{{socRisk.value}}</font>
                                    分
                                </div>
                            </div>
                            <div class="manageValueEchartsConent">
                                <div id="manageRiskTrendEcharts" style="width:100%;height:100%;"></div>
                                <div class="riskValueContent">
                                    管理水平值：<font class="riskValueStyle" :style="getShowColor(manageRisk.level)">{{manageRisk.value}}</font>
                                    分
                                </div>
                            </div>
                            <div class="asstesRiskEchartsConent">
                                <div class="riskTop5Style">
                                    <div class="riskTop5Title"><font>终端风险TOP5</font></div>
                                    <div class="riskTop5Table">
                                        <div style="witdh:100%;height:100%;">
                                            <mu-row :gutter="true" v-for="item,index in assetsRiskTop5"
                                                    :key="item.name">
                                                <mu-col width="15" tablet="15" desktop="15">
                                                    {{index+1}}
                                                </mu-col>
                                                <mu-col width="65" tablet="65" desktop="65">
                                                    {{item.name}}
                                                </mu-col>
                                                <mu-col width="20" tablet="20" desktop="20" style="text-align: right;">
                                                    {{item.value}}
                                                </mu-col>
                                            </mu-row>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="orgRiskEchartsConent">
                                <div class="riskTop5Style">
                                    <div class="riskTop5Title"><font>部门风险TOP5</font></div>
                                    <div class="riskTop5Table">
                                        <div style="witdh:100%;height:100%;">
                                            <mu-row :gutter="true" v-for="item,index in orgRiskTop5" :key="item.name">
                                                <mu-col width="15" tablet="15" desktop="15">
                                                    {{index+1}}
                                                </mu-col>
                                                <mu-col width="65" tablet="65" desktop="65">
                                                    {{item.name}}
                                                </mu-col>
                                                <mu-col width="20" tablet="20" desktop="20" style="text-align: right;">
                                                    {{item.value}}
                                                </mu-col>
                                            </mu-row>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </mu-row>
                    <mu-row class="socContentChild"
                            :style="`height:${centerBottomHeightRow};margin-top:20px;padding:20px;`">
                        <div class="centerBottomHead">
                            <font class="targetImgBehand">安全事件列表</font>
                        </div>
                        <div class="centerBottomTable">
                            <mu-row :gutter="true" style="padding-top: 5px;">
                                <mu-col width="15" tablet="15" desktop="15">
                                    <font class="fontWhite">事件等级</font>
                                </mu-col>
                                <mu-col width="10" tablet="10" desktop="10">
                                    <font class="fontWhite">事件类别</font>
                                </mu-col>
                                <mu-col width="10" tablet="10" desktop="10">
                                    <font class="fontWhite">事件状态</font>
                                </mu-col>
                                <mu-col width="10" tablet="10" desktop="10">
                                    <font class="fontWhite">来源主机</font>
                                </mu-col>
                                <mu-col width="10" tablet="10" desktop="10">
                                    <font class="fontWhite">来源人员</font>
                                </mu-col>
                                <mu-col width="30" tablet="30" desktop="30">
                                    <font class="fontWhite">事件标题</font>
                                </mu-col>
                                <mu-col width="15" tablet="15" desktop="15">
                                    <font class="fontWhite">发生时间</font>
                                </mu-col>
                            </mu-row>
                            <div class="scroll-contaner" @click="changePage(eventsMessage)">
                                <div class="eventOverflow" style="height:100%;width:100%;"
                                     v-if="securityEvents.length>5">
                                    <div class="textContentChild">
                                        <mu-row :gutter="true" v-for="item,index in securityEvents" :key="item.name"
                                                :class="index%2 == 0?'haveBackGroundColor':''"
                                                :style="getTableShowColor(item.incident_level)">
                                            <mu-col width="15" tablet="15" desktop="15" style="height:100%;">
                                                <div :class="getTableShowImg(item.incident_level)">
                                                    <div style="position: absolute;left: 20%;">
                                                        <font>
                                                            {{getTableShowName(item.incident_level)}}
                                                        </font>
                                                    </div>
                                                </div>
                                            </mu-col>
                                            <mu-col width="10" tablet="10" desktop="10">
                                                {{getCategoryData('incident_type',item.incident_type?item.incident_type:'')}}
                                            </mu-col>
                                            <mu-col width="10" tablet="10" desktop="10">
                                                {{getCategoryData('incident_status',item.incident_status)}}
                                            </mu-col>
                                            <mu-col width="10" tablet="10" desktop="10">
                                                {{item.incident_source_host}}
                                            </mu-col>
                                            <mu-col width="10" tablet="10" desktop="10">
                                                {{item.incident_source_person}}
                                            </mu-col>
                                            <mu-col width="30" tablet="30" desktop="30">
                                                {{item.incident_title}}
                                            </mu-col>
                                            <mu-col width="15" tablet="15" desktop="15">
                                                {{item.incident_time}}
                                            </mu-col>
                                        </mu-row>
                                    </div>
                                </div>
                                <div class="scroll-contaner" v-else>
                                    <div style="height:100%;witdh:100%;">
                                        <div class="textContentChild2">
                                            <mu-row :gutter="true" v-for="item,index in securityEvents"
                                                    :key="item.incident_source_host"
                                                    :class="index%2 == 0?'haveBackGroundColor':''"
                                                    :style="getTableShowColor(item.incident_level)">
                                                <mu-col width="15" tablet="15" desktop="15" style="height:100%;">
                                                    <div :class="getTableShowImg(item.incident_level)">
                                                        <div style="position: absolute;left: 20%;">
                                                            <font>
                                                                {{getTableShowName(item.incident_level)}}
                                                            </font>
                                                        </div>
                                                    </div>
                                                </mu-col>
                                                <mu-col width="10" tablet="10" desktop="10">
                                                    {{getCategoryData('incident_type',item.incident_type?item.incident_type:'')}}
                                                </mu-col>
                                                <mu-col width="10" tablet="10" desktop="10">
                                                    {{getCategoryData('incident_status',item.incident_status)}}
                                                </mu-col>
                                                <mu-col width="10" tablet="10" desktop="10">
                                                    {{item.incident_source_host}}
                                                </mu-col>
                                                <mu-col width="10" tablet="10" desktop="10">
                                                    {{item.incident_source_person}}
                                                </mu-col>
                                                <mu-col width="30" tablet="30" desktop="30">
                                                    {{item.incident_title}}
                                                </mu-col>
                                                <mu-col width="15" tablet="15" desktop="15">
                                                    {{item.incident_time}}
                                                </mu-col>
                                            </mu-row>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </mu-row>
                </mu-col>
                <mu-col width="25" tablet="25" desktop="25" class="contentBox">
                    <mu-row class="socContentChild" :style="`height:${saidTopHeightRow};`">
                        <mu-row class="socContentTopHead">
                            <div class="left">
                                <font>数据环境安全</font>
                            </div>
                            <div class="right">
                                <font>当天打印刻录输出数： <font class="socCount">{{printoutAndBurnTheOutput}}</font> (份)</font>
                            </div>
                        </mu-row>
                        <mu-row class="socContentRow" style="height:44.78%;margin-top:20px;">
                            <mu-row style="height:7.4%;width:100%;">
                                <div class="targetImg">
                                    <font class="pageContentFontStyle1 targetImgBehand">打印输出</font>
                                </div>
                            </mu-row>
                            <mu-row style="height:92.6%;width:100%;padding-top: 20px;">
                                <mu-col width="50" tablet="50" desktop="50" style="height:100%;">
                                    <mu-row style="height:11.2%;width:100%;">
                                        <div class="socRightEchartsCount">
                                            <div class="standLeft">
                                                <font>当天打印输出数</font>
                                            </div>
                                            <div class="standRight">
                                                <font :style="getShowColor(printoutCount.count.level)"
                                                      class="fontWeightBold point" @click="changePage(reqMessage)">{{printoutCount.count.count}}</font>
                                                次
                                            </div>
                                        </div>
                                    </mu-row>
                                    <mu-row style="height:88.8%;width:100%;padding-top:20px;">
                                        <div id="printoutTrendEcharts" style="width:100%;height:100%;"></div>
                                    </mu-row>
                                </mu-col>
                                <mu-col width="50" tablet="50" desktop="50" style="height:100%;">
                                    <mu-row style="height:11.2%;width:100%;">
                                        <div class="socRightEchartsCount">
                                            <div class="standLeft">
                                                <font>风险事件</font>
                                            </div>
                                            <div class="standRight">
                                                <font :style="getShowColor(printoutCount.riskCount.level)"
                                                      class="fontWeightBold point" @click="toRisk('print_out')">{{printoutCount.riskCount.count}}</font>
                                                件
                                            </div>
                                        </div>
                                    </mu-row>
                                    <mu-row style="height:88.8%;width:100%;padding-top:20px;">
                                        <div class="echartsBoxStyle">
                                            <div class="echartsBoxTitle">
                                                <font>部门打印TOP5</font>
                                            </div>
                                            <div id="printoutTop5Echarts" style="width:100%;height:100%;"></div>
                                        </div>
                                    </mu-row>
                                </mu-col>
                            </mu-row>
                        </mu-row>
                        <mu-row class="socContentRow" style="height:44.78%;">
                            <mu-row style="height:7.4%;width:100%;">
                                <div class="targetImg">
                                    <font class="pageContentFontStyle1 targetImgBehand">刻录输出</font>
                                </div>
                            </mu-row>
                            <mu-row style="height:92.6%;width:100%;padding-top: 20px;">
                                <mu-col width="50" tablet="50" desktop="50" style="height:100%;">
                                    <mu-row style="height:11.2%;width:100%;">
                                        <div class="socRightEchartsCount">
                                            <div class="standLeft">
                                                <font>当天刻录输出数</font>
                                            </div>
                                            <div class="standRight">
                                                <font :style="getShowColor(burnTheOutputCount.count.level)"
                                                      class="fontWeightBold point" @click="changePage(burnOutMessage)">{{burnTheOutputCount.count.count}}</font>
                                                次
                                            </div>
                                        </div>
                                    </mu-row>
                                    <mu-row style="height:88.8%;width:100%;padding-top:20px;">
                                        <div id="burnTheOutputTrendEcharts" style="width:100%;height:100%;"></div>
                                    </mu-row>
                                </mu-col>
                                <mu-col width="50" tablet="50" desktop="50" style="height:100%;">
                                    <mu-row style="height:11.2%;width:100%;">
                                        <div class="socRightEchartsCount">
                                            <div class="standLeft">
                                                <font>风险事件</font>
                                            </div>
                                            <div class="standRight">
                                                <font :style="getShowColor(burnTheOutputCount.riskCount.level)"
                                                      class="fontWeightBold point" @click="toRisk('record_out')">{{burnTheOutputCount.riskCount.count}}</font>
                                                件
                                            </div>
                                        </div>
                                    </mu-row>
                                    <mu-row style="height:88.8%;width:100%;padding-top:20px;">
                                        <div class="echartsBoxStyle">
                                            <div class="echartsBoxTitle">
                                                <font>部门刻录TOP5</font>
                                            </div>
                                            <div id="burnTheOutputTop5Echarts" style="width:100%;height:100%;"></div>
                                        </div>
                                    </mu-row>
                                </mu-col>
                            </mu-row>
                        </mu-row>
                    </mu-row>
                    <mu-row class="socContentChild" :style="`height:${saidBottomHeightRow};margin-top:20px;`">
                        <mu-row class="socContentBottomHead">
                            <div class="left">
                                <font>应用环境安全</font>
                            </div>
                            <div class="right">
                                <font>当天合法用户数： <font class="socCount">9,562</font> (个)</font>
                            </div>
                        </mu-row>
                        <mu-row class="socContentBottomBottom">
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(appSafetyCount.wfzh.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(appSafetyCount.wfzh.level)" class="fontWeightBold">{{appSafetyCount.wfzh.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">违法账户</font>
                                </div>
                            </mu-col>
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(appSafetyCount.jszh.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(appSafetyCount.jszh.level)" class="fontWeightBold">{{appSafetyCount.jszh.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">僵尸账户</font>
                                </div>
                            </mu-col>
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(appSafetyCount.wgdl.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(appSafetyCount.wgdl.level)" class="fontWeightBold">{{appSafetyCount.wgdl.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">违规登录</font>
                                </div>
                            </mu-col>
                            <mu-col width="25" tablet="25" desktop="25" style="height:100%;">
                                <div class="socRoundStyle" :style="getRunderShowColor(appSafetyCount.wfsq.level)">
                                    <div class="socRoundStyleCenterCount">
                                        <font :style="getShowColor(appSafetyCount.wfsq.level)" class="fontWeightBold">{{appSafetyCount.wfsq.count}}</font>
                                    </div>
                                </div>
                                <div class="socRoundTitleStyle">
                                    <font class="pageContentFontStyle1">违法授权</font>
                                </div>
                            </mu-col>
                        </mu-row>
                    </mu-row>
                </mu-col>
            </mu-row>
        </mu-row>
    </div>
</template>

<script>
    import echarts from "echarts";
    import zrender from "zrender";
    import {socket} from '@/core/io.js'

    export default {
        name: 'safetyCockpit',
        props: {},
        data() {
            return {
                socketInstanse: null,
                screenWidth: document.body.offsetWidth,
                screenHeight: document.body.offsetHeight,
                protectionDetectionOption: {},
                highRiskVulnerabilitiesOption: {},
                openPortsOption: {},
                printoutTrendOption: {},
                burnTheOutputTrendOption: {},
                printoutTop5Option: {},
                burnTheOutputTop5Option: {},
                socRiskTrendOption: {},
                manageRiskTrendOption: {},

                printoutTrendEcharts: null,


                socRisk: {
                    value: 2.5,
                    level: 3
                },
                manageRisk: {
                    value: 4.1,
                    level: 5
                },

                protectionDetection: {
                    zsbf: 1620,
                    zjsj: 12978,
                    shy: 125,
                    fbd: 4574221
                },
                violationsCount: {
                    ffwl: {
                        count: 0,
                        level: 1
                    },
                    wgjr: {
                        count: 15,
                        level: 3
                    },
                    xtdl: {
                        count: 0,
                        level: 1
                    },
                    wgdl: {
                        count: 325,
                        level: 4
                    }
                },
                printoutAndBurnTheOutput: "",
                printoutCount: {
                    count: {
                        count: 0,
                        level: 2
                    },
                    riskCount: {
                        count: 0,
                        level: 4
                    }
                },
                burnTheOutputCount: {
                    count: {
                        count: 0,
                        level: 2
                    },
                    riskCount: {
                        count: 0,
                        level: 4
                    }
                },
                networkSafetyCount: {
                    zrkz: {
                        count: 135,
                        level: 4
                    },
                    fwkz: {
                        count: 35,
                        level: 3
                    },
                    rqjc: {
                        count: 0,
                        level: 1
                    },
                    rqfh: {
                        count: 0,
                        level: 1
                    }
                },
                appSafetyCount: {
                    wfzh: {
                        count: 0,
                        level: 1
                    },
                    jszh: {
                        count: 15,
                        level: 3
                    },
                    wgdl: {
                        count: 325,
                        level: 4
                    },
                    wfsq: {
                        count: 15,
                        level: 3
                    }
                },
                securityEvents: [],
                assetsRiskTop5: [{
                    name: "W17005",
                    value: "4.02"
                }, {
                    name: "W16051",
                    value: "3.97"
                }, {
                    name: "W16301",
                    value: "3.95"
                }, {
                    name: "W15401",
                    value: "3.62"
                }, {
                    name: "W14297",
                    value: "2.87"
                }],
                orgRiskTop5: [{
                    name: "信息技术部",
                    value: "4.02"
                }, {
                    name: "安全保卫部",
                    value: "3.97"
                }, {
                    name: "保密办公室",
                    value: "3.95"
                }, {
                    name: "经理部",
                    value: "3.62"
                }, {
                    name: "成品采购部",
                    value: "2.87"
                }],
                setval: {
                    lastFrameAlpha: 0.97,
                    density: 50,
                    lineWidth: 2,
                    radianHeight: 70
                },
                pointAndLines: [{
                    start: '45',
                    end: '25',
                    level: 4,
                    eventType: 'asset',
                    message: {
                        name: "JPC20124",
                        secretLevel: "内部",
                        title: "发现病毒入侵发现病毒入侵发现病毒入侵"
                    }
                }, {
                    start: '106',
                    end: '630',
                    level: 3,
                    eventType: 'asset',
                    message: {
                        name: "JPC20124",
                        secretLevel: "内部",
                        title: "发现病毒入侵"
                    }
                }, {
                    start: '11A',
                    end: '630',
                    level: 4,
                    eventType: 'system',
                    message: {
                        name: "JPC20124",
                        secretLevel: "内部",
                        title: "发现病毒入侵"
                    }
                }, {
                    start: '607',
                    end: '630',
                    level: 3,
                    eventType: 'system',
                    message: {
                        name: "JPC20124",
                        secretLevel: "内部",
                        title: "发现病毒入侵"
                    }
                }, {
                    start: '202',
                    end: '630',
                    level: 4,
                    eventType: 'asset',
                    message: {
                        name: "JPC20124",
                        secretLevel: "内部",
                        title: "发现病毒入侵"
                    }
                }],

                ws_printoutTrend: [],
                ws_printNo_dep: [],
                ws_burnOutputTrend: [],
                ws_burnOut_dep: [],
                reqMessage: {
                    searchCodeBefor: 'print_out',
                    searchCode: 'print_out_result_analyse',
                    dateName: 'printer_time',
                    name: '打印输出',
                },
                eventsMessage: {
                    searchCodeBefor: 'incident',
                    searchCode: 'incident',
                    dateName: 'incident_time',
                    name: '安全事件'
                },
                burnOutMessage: {
                    searchCodeBefor: 'record_out',
                    searchCode: 'burn_out_result_analyse',
                    dateName: 'burn_record_time',
                    name: '刻录输出',
                }
            }
        },
        computed: {
            rowWidth: function () {
                return this.screenWidth - 90 + "px";
            },
            colHeight: function () {
                return this.screenHeight - 110 + "px";
            },

            saidTopHeightRow: function () {
                return ((this.screenHeight * 0.927 - 44) * 0.78288) + "px";
            },

            saidBottomHeightRow: function () {
                return (((this.screenHeight * 0.927 - 44) * 0.21712) - 20) + "px";
            },

            centerTopHeightRow: function () {
                return (((this.screenHeight * 0.927 - 44) * 0.74948) - 20) + "px";
            },

            centerBottomHeightRow: function () {
                return ((this.screenHeight * 0.927 - 44) * 0.25052) + "px";
            },

            mapContentWidth: function () {
                return ((this.screenWidth - 90) * 0.5);
            },
            mapContentHeight: function () {
                return ((((this.screenHeight * 0.927 - 44) * 0.74948) - 20) - 20);
            },

            mapShowPointAndLines: function () {
                var arr = [];
                for (var i = 0; i < this.pointAndLines.length; i++) {
                    arr.push(this.getPointCoordinates(this.pointAndLines[i]))
                }
                return arr;
            }
        },
        mounted() {
            const that = this;
            window.onresize = function () {
                that.screenWidth = document.body.offsetWidth
                that.screenHeight = document.body.offsetHeight

                setTimeout(() => {
                    that.getProtectionDetectionOption();
                    that.getHighRiskVulnerabilitiesOption();
                    that.getOpenPortsOption();
                    that.getPrintoutTrendOption();
                    that.getBurnTheOutputTrendOption();
                    that.getPrintoutTop5Option();
                    that.getBurnTheOutputTop5Option();
                    that.getSocRiskTrendOption();
                    that.getManageRiskTrendOption();
                }, 500);
            };

            this.getProtectionDetectionOption();
            this.getHighRiskVulnerabilitiesOption();
            this.getOpenPortsOption();
            /*this.getPrintoutTrendOption();*/
            // this.getBurnTheOutputTrendOption();
            // this.getPrintoutTop5Option();
            // this.getBurnTheOutputTop5Option();
            this.getSocRiskTrendOption();
            this.getManageRiskTrendOption();

            setTimeout(() => {
                var self = this;
                require(
                    ['zrender'],
                    function (zrender) {
                        var zr = zrender.init(document.getElementById('mymap'));

                        zr.configLayer(0, {
                            motionBlur: true,
                            lastFrameAlpha: self.setval.lastFrameAlpha
                        });

                        for (var i = 0; i < self.mapShowPointAndLines.length; i++) {
                            let p = self.mapShowPointAndLines[i];
                            self.drawLine(p.start, p.end, zr, p.fill);
                        }
                        ;

                    }
                );
                var str = '';
                for (var i = 0; i < self.mapShowPointAndLines.length; i++) {
                    str += '<div class="socBowen" style="top: ' + self.mapShowPointAndLines[i].start[1] + 'px; left: ' + self.mapShowPointAndLines[i].start[0] + 'px;">\
						<span class="' + self.mapShowPointAndLines[i].img + '"></span>\
						<span class="' + self.mapShowPointAndLines[i].img + '"></span>\
						<span class="' + self.mapShowPointAndLines[i].img + '"></span>\
						<div class="showPointMessage">\
							<li>名称：' + self.mapShowPointAndLines[i].message.name + '</li>\
							<li>描述：' + self.mapShowPointAndLines[i].message.title + '</li>\
							<li>等级：' + self.mapShowPointAndLines[i].message.secretLevel + '</li>\
						</div>\
					</div> '
                    str += '<div class="socBowen" style="top: ' + self.mapShowPointAndLines[i].end[1] + 'px; left: ' + self.mapShowPointAndLines[i].end[0] + 'px;">\
						<span class="' + self.mapShowPointAndLines[i].img + '"></span>\
						<span class="' + self.mapShowPointAndLines[i].img + '"></span>\
						<span class="' + self.mapShowPointAndLines[i].img + '"></span>\
					</div> '
                }
                ;

                document.getElementById('mypoint').innerHTML = str;
            }, 1000);
        },
        methods: {
            init() {
                this.socketInstanse = socket();
                this.socketInstanse.on('incident-list', (data, ack) => {
                    this.securityEvents = JSON.parse(data.data).data;
                    console.log(ack);
                    ack(data);
                });
                this.socketInstanse.on('printNo-dep', (data, ack) => {
                    this.ws_printNo_dep = JSON.parse(data.data).aggs.print_org.buckets;
                    this.getPrintoutTop5Option();
                    console.log(ack);
                    ack(data);
                });
                this.socketInstanse.on('printer-file-secret', (data, ack) => {
                    this.ws_printoutTrend = JSON.parse(data.data).aggs.printer_file_secret.buckets;
                    this.printoutCount.count.count = JSON.parse(data.data).total;
                    this.getPrintoutTrendOption();

                    var totleCount = 0;
                    totleCount = this.printoutCount.count.count + this.burnTheOutputCount.count.count;

                    this.printoutAndBurnTheOutput = this.numberInsertDH(totleCount);
                    console.log(ack);
                    ack(data);
                });
                this.socketInstanse.on('burn-out-count', (data, ack) => {
                    this.ws_burnOutputTrend = JSON.parse(data.data).aggs.burn_secret.buckets;
                    this.burnTheOutputCount.count.count = JSON.parse(data.data).total;
                    this.getBurnTheOutputTrendOption();
                });
                this.socketInstanse.on('burn-out-count-dep', (data, ack) => {
                    this.ws_burnOut_dep = JSON.parse(data.data).aggs.burn_org.buckets;
                    this.getBurnTheOutputTop5Option();
                    console.log(ack);
                    ack(data);
                });
                this.socketInstanse.on('print-incident-count', (data, ack) => {
                    this.printoutCount.riskCount.count = JSON.parse(data.data).total;
                    console.log(ack);
                    ack(data);
                });
                this.socketInstanse.on('burn-incident-count', (data, ack) => {
                    this.burnTheOutputCount.riskCount.count = JSON.parse(data.data).total;
                    console.log(ack);
                    ack(data);
                });
            },
            numberInsertDH(str) {
                var newStr = "";
                var count = 0;
                for (var i = str.toString().length - 1; i >= 0; i--) {
                    if (count % 3 == 0 && count != 0) {
                        newStr = str.toString().charAt(i) + "," + newStr;
                    } else {
                        newStr = str.toString().charAt(i) + newStr;
                    }
                    count++;
                }
                return newStr;
            },
            changePage(val) {
                var that = this;
                this.$router.push({
                    path: '/secret/user/tablePage',
                    query: val
                })
            },

            toRisk(val) {
                this.eventsMessage.dataCode = 'incident_source_index';
                this.eventsMessage.searchData = val;
                this.changePage(this.eventsMessage);
                this.eventsMessage.searchData = '';
                this.eventsMessage.dataCode = '';
            },

            getShowColor(level) {
                if (level == 1) {
                    return 'color:#08E69A !important'
                }
                if (level == 2) {
                    return 'color:#00A1FF !important'
                }
                if (level == 3) {
                    return 'color:#1F67FB !important'
                }
                if (level == 4) {
                    return 'color:#FF800A !important'
                }
                if (level == 5) {
                    return 'color:#FF0000 !important'
                }
            },
            getRunderShowColor(level) {
                if (level == 1) {
                    return 'border: 2px solid #08E69A;font-size: 1vw;'
                }
                if (level == 2) {
                    return 'border: 2px solid #00A1FF;font-size: 1vw;'
                }
                if (level == 3) {
                    return 'border: 2px solid #1F67FB;font-size: 1vw;'
                }
                if (level == 4) {
                    return 'border: 2px solid #FF800A;font-size: 1vw;'
                }
                if (level == 5) {
                    return 'border: 2px solid #FF0000;font-size: 1vw;'
                }
            },
            getTableShowImg(level) {
                if (level == 3) {
                    return 'tableShowColorlevel3'
                }
                if (level == 4) {
                    return 'tableShowColorlevel4'
                }
            },
            getTableShowName(level) {
                if (level == 1) {
                    return '一般'
                }
                if (level == 2) {
                    return '较大'
                }
                if (level == 3) {
                    return '重大'
                }
                if (level == 4) {
                    return '非常重大'
                }
            },
            getTableShowColor(level) {
                if (level == 3) {
                    return 'color:#FF800A !important'
                }
                if (level == 4) {
                    return 'color:#FF0000 !important'
                }
            },
            apprendZore(val) {
                if (val.toString().length == 1) {
                    return "0000" + val
                }
                else if (val.toString().length == 2) {
                    return "000" + val
                }
                else if (val.toString().length == 3) {
                    return "00" + val
                }
                else if (val.toString().length == 4) {
                    return "0" + val
                }
                else if (val.toString().length == 5) {
                    return val
                }
                else if (val.toString().length >= 6) {
                    return "99999"
                }
                else {
                    return val
                }
            },
            randomData() {
                return Math.round(Math.random() * 25);
            },
            randomDataForCompany() {
                return Math.round(Math.random() * 100);
            },

            randomDataForCarrir() {
                return Math.round(Math.random() * 300);
            },
            bezier(p0, p1, p2, t) {
                var ps = [p0[0], p0[1]]; // 起点
                var x = (1 - t) * (1 - t) * p0[0] + 2 * t * (1 - t) * p1[0] + t * t * p2[0];
                var y = (1 - t) * (1 - t) * p0[1] + 2 * t * (1 - t) * p1[1] + t * t * p2[1];
                return {x: x, y: y};
            },
            judgeXX(p0, p2) {
                var x = '';
                if (p0[0] <= p2[0] && p0[1] >= p2[1]) {
                    x += 1;
                }
                if (p0[0] >= p2[0] && p0[1] >= p2[1]) {
                    x += 2;
                }
                if (p0[0] >= p2[0] && p0[1] <= p2[1]) {
                    x += 3;
                }
                if (p0[0] <= p2[0] && p0[1] <= p2[1]) {
                    x += 4;
                }
                return x;
            },
            countP1(p0, p2, R, deg) {
                deg = Math.abs(deg);
                var h = this.setval.radianHeight - (2 * this.setval.radianHeight * deg / Math.PI);
                var p3 = [(p2[0] + p0[0]) / 2, (p2[1] + p0[1]) / 2];
                var p1 = [];

                // 向限
                var x = this.judgeXX(p0, p2);
                if (['1', '3'].indexOf(x) !== -1) {
                    p1[0] = p3[0] - h * Math.sin(deg);
                    p1[1] = p3[1] - h * Math.cos(deg);
                } else {
                    p1[0] = p3[0] + h * Math.sin(deg);
                    p1[1] = p3[1] - h * Math.cos(deg);
                }
                return p1;
            },
            drawLine(p0, p2, zr, fill) {
                var curve = new zrender.Circle({
                    position: [0, 0],
                    scale: [1, 1],
                    shape: {
                        cx: p0[0],
                        cy: p0[1],
                        r: this.setval.lineWidth
                    },
                    style: {
                        fill: fill
                    }
                });
                zr.add(curve);

                // 弧线动画
                var R = Math.sqrt((p2[1] - p0[1]) * (p2[1] - p0[1]) + (p2[0] - p0[0]) * (p2[0] - p0[0]));
                var deg = Math.atan((p2[1] - p0[1]) / (p2[0] - p0[0]));
                var arr = [];
                arr.push(p0);
                var p1 = this.countP1(p0, p2, R, deg);

                for (var i = 0; i < this.setval.density; i++) {
                    var t = 1 / this.setval.density;
                    arr.push(this.bezier(p0, p1, p2, t * i));
                }

                var i = 0;
                var animate = function (p, t) {
                    curve.animateTo(
                        {
                            shape: {
                                cx: p.x,
                                cy: p.y
                            }
                        }, t ? t : 1, 0, null, function () {
                            i++;
                            if (!arr[i]) {
                                i = 0;
                                animate(arr[i]);
                                return;
                            }
                            animate(arr[i]);
                        }
                    );
                }
                animate(arr[i])
            },

            /*获取防护检测echarts*/
            getProtectionDetectionOption() {
                if (!document.getElementById('protectionDetectionEcharts')) {
                    return;
                }
                this.protectionDetectionOption = {
                    tooltip: {},
                    legend: {
                        data: ['备案总数', '失效总数'],
                        x: 'right',
                        textStyle: {
                            color: '#9ad7f8',
                            fontSize: 12
                        }
                    },
                    grid: {
                        top: '55%',
                        bottom: '11%',
                        left: 0,
                        right: 0,
                        containLabel: true
                    },
                    xAxis: [{
                        type: 'category',
                        data: ['帐实不符', '主机审计', '三合一', '防病毒'],
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            },
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                    }],
                    yAxis: [{
                        type: 'value',
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            },
                            formatter: '{value}'
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        splitLine: {
                            show: false
                        }
                    }],
                    series: [{
                        name: '备案总数',
                        type: 'bar',
                        data: [80, 65, 80, 65],
                        label: {
                            normal: {
                                show: true,
                                position: 'top',
                                color: '#9ad7f8'
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#188df0'
                            }
                        }
                    }, {
                        name: '失效总数',
                        type: 'bar',
                        data: [45, 35, 40, 30],
                        label: {
                            normal: {
                                show: true,
                                position: 'top',
                                color: '#83bff6'
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#ff0000'
                            }
                        }
                    }]
                };

                var myChart = echarts.init(document.getElementById('protectionDetectionEcharts'));
                myChart.setOption(this.protectionDetectionOption);
                myChart.resize();
            },

            /*高危漏洞设备数趋势*/
            getHighRiskVulnerabilitiesOption() {
                if (!document.getElementById('highRiskVulnerabilitiesEcharts')) {
                    return;
                }
                this.highRiskVulnerabilitiesOption = {
                    tooltip: {},
                    legend: {
                        data: ['病毒发现', '高危漏洞'],
                        x: 'right',
                        textStyle: {
                            color: '#9ad7f8',
                            fontSize: 12
                        }
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        top: '24%',
                        bottom: '10%',
                        containLabel: true
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        data: ['3/28', '3/29', '3/30', '3/31', '4/01', '4/02', '4/03']
                    },
                    yAxis: {
                        type: 'value',
                        axisLine: {
                            show: false
                        },
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        maxInterval: 30,
                        splitLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        }
                    },
                    series: [
                        {
                            name: '病毒发现',
                            type: 'line',
                            smooth: 0.5,
                            symbolSize: 12,
                            data: [28, 32, 29, 25, 35, 27, 31],
                            lineStyle: {
                                normal: {
                                    color: '#08e69a'
                                }
                            },
                            itemStyle: {
                                normal: {
                                    color: '#08e69a'
                                }
                            }
                        },
                        {
                            name: '高危漏洞',
                            type: 'line',
                            smooth: 0.5,
                            symbolSize: 12,
                            data: [110, 102, 68, 100, 120, 68, 69],
                            lineStyle: {
                                normal: {
                                    color: '#00a1ff'
                                }
                            },
                            itemStyle: {
                                normal: {
                                    color: '#00a1ff'
                                }
                            }
                        }
                    ]
                };

                var myChart = echarts.init(document.getElementById('highRiskVulnerabilitiesEcharts'));
                myChart.setOption(this.highRiskVulnerabilitiesOption);
                myChart.resize();
            },

            /*开放端口统计*/
            getOpenPortsOption() {
                if (!document.getElementById('openPortsEcharts')) {
                    return;
                }
                this.openPortsOption = {
                    tooltip: {},
                    grid: {
                        top: '5%',
                        bottom: '0%',
                        left: 0,
                        right: 15,
                        containLabel: true
                    },
                    xAxis: [{
                        type: 'value',
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        splitLine: {
                            show: false
                        }
                    }],
                    yAxis: [{
                        type: 'category',
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        data: ['USB存储', '并口', '串口', '刻录光驱', '只读光驱'],
                    }],
                    series: [{
                        type: 'bar',
                        data: [120, 210, 75, 210, 45],
                        barWidth: 9,
                        label: {
                            normal: {
                                show: true,
                                position: 'right',
                                color: '#83bff6'
                            }
                        },
                        itemStyle: {
                            normal: {
                                barBorderRadius: [0, 30, 30, 0],
                                color: new echarts.graphic.LinearGradient(
                                    1, 0, 0, 0, [{
                                        offset: 0,
                                        color: '#83bff6'
                                    },
                                        {
                                            offset: 1,
                                            color: '#188df0'
                                        }
                                    ]
                                )
                            }
                        }
                    }]
                };

                var myChart = echarts.init(document.getElementById('openPortsEcharts'));
                myChart.setOption(this.openPortsOption);
                myChart.resize();

            },

            /*打印输出历史趋势*/
            getPrintoutTrendOption() {
                var data = [];
                var that = this;
                for (var i = 0; i < this.ws_printoutTrend.length; i++) {
                    if (this.ws_printoutTrend[i].key == '公开') {
                        var map = {
                            value: this.ws_printoutTrend[i].doc_count,
                            name: '公开',
                            itemStyle: {
                                normal: {
                                    color: '#a260e2'
                                }
                            }
                        }
                        data.push(map);
                    }
                    if (this.ws_printoutTrend[i].key == '内部') {
                        var map = {
                            value: this.ws_printoutTrend[i].doc_count,
                            name: '内部',
                            itemStyle: {
                                normal: {
                                    color: '#8130ce'
                                }
                            }
                        }
                        data.push(map);
                    }
                    if (this.ws_printoutTrend[i].key == '秘密') {
                        var map = {
                            value: this.ws_printoutTrend[i].doc_count,
                            name: '秘密',
                            itemStyle: {
                                normal: {
                                    color: '#630fb2'
                                }
                            }
                        }
                        data.push(map);
                    }
                    if (this.ws_printoutTrend[i].key == '机密') {
                        var map = {
                            value: this.ws_printoutTrend[i].doc_count,
                            name: '机密',
                            itemStyle: {
                                normal: {
                                    color: '#420483'
                                }
                            }
                        }
                        data.push(map);
                    }
                }

                this.printoutTrendOption = {
                    legend: {
                        bottom: 0,
                        align: 'auto',
                        textStyle: {
                            color: '#9ad7fb',
                            fontSize: 10
                        },
                        itemWidth: 8,
                        itemHeight: 8,
                        data: ['公开', '内部', '秘密', '机密']
                    },
                    label: {
                        normal: {
                            color: '#9ad7f8'
                        }
                    },
                    series: [{
                        type: 'pie',
                        radius: ['20%', '50%'],
                        center: ['50%', '35%'],
                        roseType: 'radius',
                        label: {
                            normal: {
                                formatter: "{c}",
                                show: true
                            },
                        },
                        data: data
                    }, {
                        type: 'pie',
                        radius: ['60%', '60.5%'],
                        center: ['50%', '35%'],
                        hoverAnimation: false,
                        tooltip: {
                            normal: {
                                show: false
                            }
                        },
                        label: {
                            normal: {
                                show: false
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#9ad7f8'
                            }
                        },
                        data: [{
                            value: 1
                        }]
                    }]
                };
                if (!document.getElementById('printoutTrendEcharts')) {
                    return;
                }
                this.printoutTrendEcharts = echarts.init(document.getElementById('printoutTrendEcharts'));
                this.printoutTrendEcharts.setOption(this.printoutTrendOption, true);
                this.printoutTrendEcharts.off('click');
                this.printoutTrendEcharts.on("click", function (param) {
                    that.reqMessage.searchData = param.name;
                    that.reqMessage.dataCode = 'printer_flow_secret';
                    that.changePage(that.reqMessage);
                    that.reqMessage.searchData = '';
                    that.reqMessage.dataCode = '';
                });
                this.printoutTrendEcharts.resize();
            },

            /*打印输出部门TOP5*/
            getPrintoutTop5Option() {
                var that = this;
                var data1 = [];
                var data2 = [];
                if (!document.getElementById('printoutTop5Echarts')) {
                    return;
                }
                for (var i = 0; i < this.ws_printNo_dep.length; i++) {
                    data1.push(this.ws_printNo_dep[i].key);
                    data2.push(this.ws_printNo_dep[i].doc_count);
                }
                this.printoutTop5Option = {
                    tooltip: {},
                    grid: {
                        top: '10%',
                        bottom: '15%',
                        left: -15,
                        right: 15,
                        containLabel: true
                    },
                    xAxis: {
                        type: 'category',
                        data: data1,
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        axisLabel: {
                            rotate: 60,
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 10
                            }
                        }
                    },
                    yAxis: {
                        show: false
                    },
                    series: {
                        type: 'bar',
                        barWidth: '70%',
                        data: data2,
                        label: {
                            normal: {
                                show: true,
                                position: 'top',
                                color: '#83bff6'
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(
                                    0, 0, 0, 1, [{
                                        offset: 0,
                                        color: '#83bff6'
                                    },
                                        {
                                            offset: 1,
                                            color: '#188df0'
                                        }
                                    ]
                                )
                            }
                        }
                    }
                };

                var myChart = echarts.init(document.getElementById('printoutTop5Echarts'));
                myChart.setOption(this.printoutTop5Option);
                myChart.off('click');
                myChart.on("click", function (param) {
                    that.reqMessage.searchData = param.name;
                    that.reqMessage.dataCode = 'print_org';
                    that.changePage(that.reqMessage);
                    that.reqMessage.searchData = '';
                    that.reqMessage.dataCode = '';
                });
                myChart.resize();
            },

            /*刻录输出历史趋势*/
            getBurnTheOutputTrendOption() {
                var data = [];
                var that = this;
                for (var i = 0; i < this.ws_burnOutputTrend.length; i++) {
                    if (this.ws_burnOutputTrend[i].key == '公开') {
                        var map = {
                            value: this.ws_burnOutputTrend[i].doc_count,
                            name: '公开',
                            itemStyle: {
                                normal: {
                                    color: '#a260e2'
                                }
                            }
                        }
                        data.push(map);
                    }
                    if (this.ws_burnOutputTrend[i].key == '内部') {
                        var map = {
                            value: this.ws_burnOutputTrend[i].doc_count,
                            name: '内部',
                            itemStyle: {
                                normal: {
                                    color: '#8130ce'
                                }
                            }
                        }
                        data.push(map);
                    }
                    if (this.ws_burnOutputTrend[i].key == '秘密') {
                        var map = {
                            value: this.ws_burnOutputTrend[i].doc_count,
                            name: '秘密',
                            itemStyle: {
                                normal: {
                                    color: '#630fb2'
                                }
                            }
                        }
                        data.push(map);
                    }
                    if (this.ws_burnOutputTrend[i].key == '机密') {
                        var map = {
                            value: this.ws_burnOutputTrend[i].doc_count,
                            name: '机密',
                            itemStyle: {
                                normal: {
                                    color: '#420483'
                                }
                            }
                        }
                        data.push(map);
                    }
                }

                this.burnTheOutputTrendOption = {
                    legend: {
                        bottom: 0,
                        align: 'auto',
                        textStyle: {
                            color: '#9ad7fb',
                            fontSize: 10
                        },
                        itemWidth: 8,
                        itemHeight: 8,
                        data: ['公开', '内部', '秘密', '机密']
                    },
                    label: {
                        normal: {
                            color: '#9ad7f8'
                        }
                    },
                    series: [{
                        type: 'pie',
                        radius: ['20%', '50%'],
                        center: ['50%', '35%'],
                        roseType: 'radius',
                        label: {
                            normal: {
                                formatter: "{c}",
                                show: true
                            },
                        },
                        data: data
                    }, {
                        type: 'pie',
                        radius: ['60%', '60.5%'],
                        center: ['50%', '35%'],
                        hoverAnimation: false,
                        tooltip: {
                            normal: {
                                show: false
                            }
                        },
                        label: {
                            normal: {
                                show: false
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#9ad7f8'
                            }
                        },
                        data: [{
                            value: 1
                        }]
                    }]
                };
                if (!document.getElementById('burnTheOutputTrendEcharts')) {
                    return;
                }
                var myChart = echarts.init(document.getElementById('burnTheOutputTrendEcharts'));
                myChart.setOption(this.burnTheOutputTrendOption);
                myChart.off('click');
                myChart.on("click", function (param) {
                    that.burnOutMessage.searchData = param.name;
                    that.burnOutMessage.dataCode = 'burn_secret';
                    that.changePage(that.burnOutMessage);
                    that.burnOutMessage.searchData = '';
                    that.burnOutMessage.dataCode = '';
                });
                myChart.resize();
            },

            /*部门刻录TOP5*/
            getBurnTheOutputTop5Option() {
                var that = this;
                var data1 = [];
                var data2 = [];
                if (!document.getElementById('burnTheOutputTop5Echarts')) {
                    return;
                }
                for (var i = 0; i < this.ws_burnOut_dep.length; i++) {
                    data1.push(this.ws_burnOut_dep[i].key);
                    data2.push(this.ws_burnOut_dep[i].doc_count);
                }

                this.burnTheOutputTop5Option = {
                    tooltip: {},
                    grid: {
                        top: '10%',
                        bottom: '13%',
                        left: -15,
                        right: 15,
                        containLabel: true
                    },
                    xAxis: {
                        type: 'category',
                        data: data1,
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        axisLabel: {
                            rotate: 60,
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 10
                            }
                        }
                    },
                    yAxis: {
                        show: false
                    },
                    series: {
                        type: 'bar',
                        barWidth: '70%',
                        data: data2,
                        label: {
                            normal: {
                                show: true,
                                position: 'top',
                                color: '#83bff6'
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: new echarts.graphic.LinearGradient(
                                    0, 0, 0, 1, [{
                                        offset: 0,
                                        color: '#83bff6'
                                    },
                                        {
                                            offset: 1,
                                            color: '#188df0'
                                        }
                                    ]
                                )
                            }
                        }
                    }
                };

                var myChart = echarts.init(document.getElementById('burnTheOutputTop5Echarts'));
                myChart.setOption(this.burnTheOutputTop5Option);
                myChart.off('click');
                myChart.on("click", function (param) {
                    that.burnOutMessage.searchData = param.name;
                    that.burnOutMessage.dataCode = 'burn_org';
                    that.changePage(that.burnOutMessage);
                    that.burnOutMessage.searchData = '';
                    that.burnOutMessage.dataCode = '';
                });
                myChart.resize();
            },

            /*获取当前风险值*/
            getSocRiskTrendOption() {
                if (!document.getElementById('socRiskTrendEcharts')) {
                    return;
                }
                this.socRiskTrendOption = {
                    tooltip: {},
                    series: [
                        {
                            startAngle: 225,
                            endAngle: -45,
                            min: 0,
                            max: 5,
                            radius: '100%',
                            axisLine: {
                                show: false,
                                lineStyle: {
                                    width: 9,
                                    color: [[0.2, '#08e69a'], [0.4, '#00a1ff'], [0.6, '#1f67fb'], [0.8, '#ff800a'], [1, '#ff0000']]
                                }
                            },
                            axisLabel: {
                                distance: -20,
                                formatter: function (value) {
                                    if (value === 0) {
                                        return value
                                    } else if (value === 1) {
                                        return value
                                    } else if (value === 2) {
                                        return value
                                    } else if (value === 3) {
                                        return value
                                    } else if (value === 4) {
                                        return value
                                    } else if (value === 5) {
                                        return value
                                    }
                                }
                            },
                            splitLine: {
                                show: false
                            },
                            axisTick: {
                                show: false
                            },
                            detail: {
                                show: false
                            },
                            name: '当前风险值：',
                            type: 'gauge',
                            data: [{value: 2.5}]
                        }
                    ]
                }

                var myChart = echarts.init(document.getElementById('socRiskTrendEcharts'));
                myChart.setOption(this.socRiskTrendOption);
                myChart.resize();
            },

            /*获取管理水平值*/
            getManageRiskTrendOption() {
                if (!document.getElementById('manageRiskTrendEcharts')) {
                    return;
                }
                this.manageRiskTrendOption = {
                    tooltip: {},
                    series: [
                        {
                            startAngle: 225,
                            endAngle: -45,
                            min: 0,
                            max: 5,
                            radius: '100%',
                            axisLine: {
                                show: false,
                                lineStyle: {
                                    width: 9,
                                    color: [[0.2, '#08e69a'], [0.4, '#00a1ff'], [0.6, '#1f67fb'], [0.8, '#ff800a'], [1, '#ff0000']]
                                }
                            },
                            axisLabel: {
                                distance: -20,
                                formatter: function (value) {
                                    if (value === 0) {
                                        return value
                                    } else if (value === 1) {
                                        return value
                                    } else if (value === 2) {
                                        return value
                                    } else if (value === 3) {
                                        return value
                                    } else if (value === 4) {
                                        return value
                                    } else if (value === 5) {
                                        return value
                                    }
                                }
                            },
                            splitLine: {
                                show: false
                            },
                            axisTick: {
                                show: false
                            },
                            detail: {
                                show: false
                            },
                            name: '管理水平值：',
                            type: 'gauge',
                            data: [{value: 4.1}]
                        }
                    ]
                }

                var myChart = echarts.init(document.getElementById('manageRiskTrendEcharts'));
                myChart.setOption(this.manageRiskTrendOption);
                myChart.resize();
            },

            getPointCoordinates(obj) {
                var arr = [
                    {
                        address: "5-1",
                        top: "3%",
                        left: "60%"
                    }, {
                        address: "417A",
                        top: "6%",
                        left: "60%"
                    }, {
                        address: "417",
                        top: "11%",
                        left: "60%"
                    }, {
                        address: "485",
                        top: "9%",
                        left: "56%"
                    }, {
                        address: "483",
                        top: "12%",
                        left: "52%"
                    }, {
                        address: "583",
                        top: "16%",
                        left: "52%"
                    }, {
                        address: "314",
                        top: "20%",
                        left: "52%"
                    }, {
                        address: "494",
                        top: "29%",
                        left: "49%"
                    }, {
                        address: "106",
                        top: "36%",
                        left: "49%"
                    }, {
                        address: "51",
                        top: "34%",
                        left: "44%"
                    }, {
                        address: "424",
                        top: "44%",
                        left: "40%"
                    }, {
                        address: "330",
                        top: "49%",
                        left: "38%"
                    }, {
                        address: "624",
                        top: "55%",
                        left: "36%"
                    }, {
                        address: "70",
                        top: "60%",
                        left: "35%"
                    }, {
                        address: "604",
                        top: "59%",
                        left: "44%"
                    }, {
                        address: "404",
                        top: "54%",
                        left: "45%"
                    }, {
                        address: "406",
                        top: "45%",
                        left: "50%"
                    }, {
                        address: "606",
                        top: "45%",
                        left: "55%"
                    }, {
                        address: "8",
                        top: "41%",
                        left: "55%"
                    }, {
                        address: "631",
                        top: "56%",
                        left: "52%"
                    }, {
                        address: "620",
                        top: "80%",
                        left: "48%"
                    }, {
                        address: "607",
                        top: "73%",
                        left: "47%"
                    }, {
                        address: "411",
                        top: "72%",
                        left: "44%"
                    }, {
                        address: "605",
                        top: "80%",
                        left: "44%"
                    }, {
                        address: "636",
                        top: "73%",
                        left: "39%"
                    }, {
                        address: "601",
                        top: "71%",
                        left: "31%"
                    }, {
                        address: "450",
                        top: "76%",
                        left: "30%"
                    }, {
                        address: "412",
                        top: "80%",
                        left: "27%"
                    }, {
                        address: "638",
                        top: "81%",
                        left: "25%"
                    }, {
                        address: "602",
                        top: "83%",
                        left: "27%"
                    }, {
                        address: "332",
                        top: "86%",
                        left: "27%"
                    }, {
                        address: "311",
                        top: "91%",
                        left: "55%"
                    }, {
                        address: "321",
                        top: "91%",
                        left: "59%"
                    }, {
                        address: "310",
                        top: "91%",
                        left: "51%"
                    }, {
                        address: "382",
                        top: "95%",
                        left: "59%"
                    }, {
                        address: "22",
                        top: "88%",
                        left: "59%"
                    }, {
                        address: "12",
                        top: "86%",
                        left: "57%"
                    }, {
                        address: "630",
                        top: "81%",
                        left: "55%"
                    }, {
                        address: "35",
                        top: "76%",
                        left: "59%"
                    }, {
                        address: "620A",
                        top: "72%",
                        left: "56%"
                    }, {
                        address: "4",
                        top: "75%",
                        left: "65%"
                    }, {
                        address: "2",
                        top: "74%",
                        left: "74%"
                    }, {
                        address: "2A",
                        top: "74%",
                        left: "78%"
                    }, {
                        address: "16",
                        top: "74%",
                        left: "82%"
                    }, {
                        address: "2c",
                        top: "84%",
                        left: "82%"
                    }, {
                        address: "45",
                        top: "88%",
                        left: "82%"
                    }, {
                        address: "25",
                        top: "91%",
                        left: "85%"
                    }, {
                        address: "38",
                        top: "88%",
                        left: "74%"
                    }, {
                        address: "39",
                        top: "88%",
                        left: "64%"
                    }, {
                        address: "381",
                        top: "94%",
                        left: "64%"
                    }, {
                        address: "380",
                        top: "94%",
                        left: "75%"
                    }, {
                        address: "1",
                        top: "49%",
                        left: "63%"
                    }, {
                        address: "101",
                        top: "49%",
                        left: "73%"
                    }, {
                        address: "3",
                        top: "58%",
                        left: "73%"
                    }, {
                        address: "3A",
                        top: "58%",
                        left: "78%"
                    }, {
                        address: "105A",
                        top: "65%",
                        left: "92%"
                    }, {
                        address: "637",
                        top: "66%",
                        left: "86%"
                    }, {
                        address: "366",
                        top: "66%",
                        left: "92%"
                    }, {
                        address: "319",
                        top: "61%",
                        left: "93%"
                    }, {
                        address: "102B",
                        top: "63%",
                        left: "88%"
                    }, {
                        address: "105",
                        top: "56%",
                        left: "88%"
                    }, {
                        address: "27",
                        top: "55%",
                        left: "90%"
                    }, {
                        address: "6",
                        top: "50%",
                        left: "92%"
                    }, {
                        address: "11A",
                        top: "44%",
                        left: "88%"
                    }, {
                        address: "5-2",
                        top: "48%",
                        left: "81%"
                    }, {
                        address: "414",
                        top: "44%",
                        left: "81%"
                    }, {
                        address: "50",
                        top: "41%",
                        left: "81%"
                    }, {
                        address: "9",
                        top: "46%",
                        left: "79%"
                    }, {
                        address: "5",
                        top: "35%",
                        left: "86%"
                    }, {
                        address: "635",
                        top: "36%",
                        left: "91%"
                    }, {
                        address: "633",
                        top: "31%",
                        left: "92%"
                    }, {
                        address: "20A",
                        top: "28%",
                        left: "92%"
                    }, {
                        address: "541",
                        top: "24%",
                        left: "93%"
                    }, {
                        address: "521",
                        top: "19%",
                        left: "94%"
                    }, {
                        address: "622",
                        top: "18%",
                        left: "87%"
                    }, {
                        address: "495",
                        top: "17%",
                        left: "82%"
                    }, {
                        address: "623",
                        top: "30%",
                        left: "82%"
                    }, {
                        address: "203",
                        top: "34%",
                        left: "78%"
                    }, {
                        address: "202",
                        top: "34%",
                        left: "74%"
                    }, {
                        address: "201A",
                        top: "33%",
                        left: "69%"
                    }, {
                        address: "201",
                        top: "34%",
                        left: "64%"
                    }, {
                        address: "307",
                        top: "26%",
                        left: "62%"
                    }, {
                        address: "351-1",
                        top: "21%",
                        left: "58%"
                    }, {
                        address: "351",
                        top: "18%",
                        left: "58%"
                    }, {
                        address: "306",
                        top: "18%",
                        left: "63%"
                    }, {
                        address: "621",
                        top: "18%",
                        left: "71%"
                    }, {
                        address: "308",
                        top: "20%",
                        left: "75%"
                    }, {
                        address: "211",
                        top: "20%",
                        left: "78%"
                    }, {
                        address: "211-1",
                        top: "12%",
                        left: "78%"
                    }, {
                        address: "407",
                        top: "11%",
                        left: "68%"
                    }, {
                        address: "407A",
                        top: "3%",
                        left: "68%"
                    }, {
                        address: "341",
                        top: "64%",
                        left: "41%"
                    }, {
                        address: "341B",
                        top: "61%",
                        left: "41%"
                    }];

                var map = {};
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i].address == obj.start) {
                        var adr = [];
                        adr.push(parseInt(arr[i].left.split('%')[0]) * this.mapContentWidth * 0.01);
                        adr.push(parseInt(arr[i].top.split('%')[0]) * this.mapContentHeight * 0.01);
                        map.start = adr
                    }
                    if (arr[i].address == obj.end) {
                        var adr = [];
                        adr.push(parseInt(arr[i].left.split('%')[0]) * this.mapContentWidth * 0.01);
                        adr.push(parseInt(arr[i].top.split('%')[0]) * this.mapContentHeight * 0.01);
                        map.end = adr
                    }
                }
                if (obj.level == 4) {
                    map.fill = "#FF0000"
                } else {
                    map.fill = "#FF800A"
                }

                if (obj.eventType == 'asset') {
                    if (obj.level == 4) {
                        map.img = "showRed1"
                    } else {
                        map.img = "showOrange1"
                    }
                } else {
                    if (obj.level == 4) {
                        map.img = "showRed2"
                    } else {
                        map.img = "showOrange2"
                    }
                }

                map.message = obj.message;

                return map;
            }
        },
        created() {
            this.init();
        },
        activated() {
            this.init();
        },
        beforeDestroy: function () {
            this.socketInstanse.close();
            console.log("销毁前");
        },
    };
</script>

<style lang="css" scoped>
    * {
        font-family: initial;
    }

    .backColor {
        background-image: url(/static/img/safetyCockpit/backgroundImg.jpg);
        background-size: 100% 100%;
        width: 100%;
        height: 100%;
    }

    .pageHead {
        width: 100%;
        height: 7.3%;
    }

    .cockpitTitle {
        background-image: url(/static/img/safetyCockpit/logo.png);
        background-size: 100% 100%;
        z-index: 1;
        width: 20%;
        height: 50%;
        position: relative;
        top: 15%;
        left: 40%;
    }

    .pageContent {
        height: auto;
        margin-left: 44px;
        max-width: 100%;
    }

    .contentBox {
        margin-bottom: 10px;
        height: 100%;
    }

    .socCount {
        font-size: 1.2vw !important;
        color: #ffffff !important;
        font-weight: bold;
    }

    .fontWeightBold {
        font-weight: bold;
    }

    .pageContentFontStyle1 {
        font-size: 0.69vw;
        color: #9ad7f8;
    }

    .socContentChild {
        width: 100%;
        border-radius: 2px;
        background-color: #09265d99;
    }

    .pageContent .socContentTopHead {
        background-image: url(/static/img/safetyCockpit/title_bj.png);
        background-size: 100% 100%;
        z-index: 0;
        background-color: #051433;
        width: 100%;
        height: 7.33%;
        position: relative;
    }

    .pageContent .socContentBottomHead {
        background-image: url(/static/img/safetyCockpit/title_bj.png);
        background-size: 100% 100%;
        z-index: 0;
        background-color: #02122c;
        width: 100%;
        height: 31.382%;
        position: relative;
    }

    .pageContent .socContentBottomBottom {
        width: 100%;
        height: 68.618%;
        padding: 20px;
    }

    .socContentChild .left {
        position: relative;
        top: 34%;
        left: 4.6%;
        width: 29.5%;
        height: 63%;
        text-align: center;
    }

    .socContentChild .left font {
        font-size: 0.83vw;
        color: #ffffff;
        line-height: 2;
    }

    .socContentChild .right {
        position: relative;
        top: 0;
        right: 0;
        width: 60%;
        height: 100%;
        text-align: right;
    }

    .socContentChild .right font {
        font-size: 0.69vw;
        color: #9ad7f8;
        line-height: 2;
    }

    .socContentRow {
        width: 100%;
        position: relative;
        padding: 0 20px 20px 20px;
    }

    .targetImg {
        background-image: url(/static/img/safetyCockpit/title_img.png);
        background-size: 8px 100%;
        z-index: 0;
        width: 100%;
        height: 100%;
        display: inline-grid;
    }

    .targetImgBehand {
        padding-left: 18px;
    }

    .socleftTopRow1 {
        background-image: url(/static/img/safetyCockpit/weigui_bj.png);
        background-size: 100% 100%;
        z-index: 0;
        width: 108%;
        height: 100%;
        position: relative;
    }

    .socleftTopRow1 .standTop {
        position: absolute;
        top: 15%;
        left: 7%;
        height: 27%;
        width: 88%;
        text-align: center;
        display: inline-grid;
    }

    .socleftTopRow1 .standTop font {
        color: #ffffff;
        font-size: 0.5vw;
    }

    .socleftTopRow1 .standBottom {
        position: absolute;
        top: 43%;
        left: 7%;
        height: 57%;
        width: 88%;
        text-align: center;
        display: inline-grid;
    }

    .socleftTopRow1 .standBottom font {
        color: #ffffff;
        font-size: 1.2vw;
    }

    .socRightEchartsCount {
        background-image: url(/static/img/safetyCockpit/bj4.png);
        background-size: 100% 100%;
        z-index: 0;
        width: 95%;
        height: 100%;
        position: relative;
    }

    .socRightEchartsCount .standLeft {
        position: absolute;
        top: 0;
        left: 0;
        width: 60%;
        height: 100%;
        padding-right: 10px;
        text-align: right;
        font-size: 0.69vw;
        color: #9ad7f8;
        line-height: 2;
    }

    .socRightEchartsCount .standRight {
        position: absolute;
        top: 0;
        right: 0;
        width: 40%;
        height: 100%;
        padding-right: 10px;
        text-align: right;
        font-size: 0.69vw;
        color: #9ad7f8;
        line-height: 2;
    }

    .echartsBoxStyle {
        background-image: url(/static/img/safetyCockpit/bj3.png);
        background-size: 100% 100%;
        z-index: 0;
        width: 100%;
        height: 100%;
        position: relative;
    }

    .echartsBoxStyle .echartsBoxTitle {
        position: absolute;
        top: -2%;
        left: 14%;
        width: 80%;
        height: 10%;
        text-align: left;
        font-size: 0.75vw;
        color: #9ad7f8;
    }

    .socRoundStyle {
        width: 60%;
        height: 75%;
        border-radius: 50%;
        margin-left: 20%;
        position: relative;
    }

    .socRoundStyle .socRoundStyleCenterCount {
        position: absolute;
        top: 20%;
        left: 0;
        width: 100%;
        height: 60%;
        text-align: center;
    }

    .socRoundTitleStyle {
        width: 100%;
        height: 25%;
        text-align: center;
        margin-top: 5px;
    }

    .centerBottomHead {
        background-image: url(/static/img/safetyCockpit/bj2.png);
        background-size: 100% 100%;
        z-index: 0;
        width: 25%;
        height: 10%;
        position: relative;
        font-size: 0.75vw;
        color: #9ad7f8;
    }

    .centerBottomTable {
        width: 100%;
        height: 90%;
        padding-top: 10px;
        text-align: center;
    }

    .fontWhite {
        font-size: 0.5vw;
        color: #9ad7f8;
    }

    .scroll-contaner {
        position: relative;
        overflow: hidden;
        height: 80%;
        margin-top: 10px;
    }

    .textContentChild {
        width: 100%;
        -webkit-animation: gogogo 15s infinite linear;
        font-size: 0.75vw;
        height: 100%;
    }

    .eventOverflow {
        cursor: pointer;
        z-index: 99999999;
    }

    .eventOverflow:hover .textContentChild {
        -webkit-animation-play-state: paused;
        -moz-animation-play-state: paused;
    }

    @-webkit-keyframes gogogo {
        0% {
            -webkit-transform: translate3d(0, 0, 0);
            transform: translate3d(0, 0, 0);
        }
        100% {
            -webkit-transform: translate3d(0, -307px, 0);
            transform: translate3d(0, -307px, 0);
            display: none;
        }
    }

    .textContentChild .row {
        font-size: 0.5vw;
        height: 20%;
    }

    .textContentChild2 {
        width: 100%;
        font-size: 0.75vw;
        height: 100%;
    }

    .textContentChild2 .row {
        font-size: 0.5vw;
        height: 20%;
    }

    .haveBackGroundColor {
        background-color: #09265d;
    }

    .tableShowColorlevel3 {
        background: url(/static/img/safetyCockpit/icon_yellow.png) left center no-repeat;
        background-size: 15% 60%;
        z-index: 0;
        width: 100%;
        height: 100%;
        left: 20%;
        position: relative;
    }

    .tableShowColorlevel4 {
        background: url(/static/img/safetyCockpit/icon_red.png) left center no-repeat;
        background-size: 15% 60%;
        z-index: 0;
        width: 100%;
        height: 100%;
        left: 20%;
        position: relative;
    }

    .socMapStyle {
        background-image: url(/static/img/safetyCockpit/state.png);
        background-size: 100% 100%;
        z-index: 0;
        width: 100%;
        height: 100%;
        position: relative;
    }

    .riskValueEchartsConent {
        position: absolute;
        top: 1%;
        left: 0;
        width: 20%;
        height: 26.5%;
    }

    .manageValueEchartsConent {
        position: absolute;
        top: 5%;
        left: 20%;
        width: 17%;
        height: 21%;
    }

    .asstesRiskEchartsConent {
        position: absolute;
        top: 44%;
        left: 0;
        width: 20%;
        height: 26%;
    }

    .orgRiskEchartsConent {
        position: absolute;
        top: 74%;
        left: 0;
        width: 20%;
        height: 26%;
    }

    .riskValueContent {
        position: absolute;
        top: 105%;
        left: 0;
        width: 100%;
        height: 20%;
        text-align: center;
        color: #9ad7f8;
        font-size: 0.75vw;
    }

    .riskValueContent .riskValueStyle {
        font-size: 1.2vw;
    }

    .riskTop5Style {
        background-image: url(/static/img/safetyCockpit/bj1.png);
        background-size: 100% 100%;
        z-index: 0;
        width: 100%;
        height: 100%;
        position: relative;
    }

    .riskTop5Style .riskTop5Title {
        position: relative;
        top: 0;
        left: 14%;
        font-size: 0.75vw;
        color: #9ad7f8;
        text-align: left;
    }

    .riskTop5Style .riskTop5Table {
        padding: 10px 20px 10px 20px;
        font-size: 0.5vw;
        color: #9ad7f8;
        height: 86%;
    }

    .riskTop5Style .riskTop5Table .row {
        margin-top: 2%;
    }

    .fhjcCountStyle {
        position: absolute;
        top: 22%;
        left: 0;
        width: 100%;
        height: 19%;
    }

    .fhjcCountStyle .socCountImg {
        background-image: url(/static/img/safetyCockpit/number_bj.png);
        background-size: 100% 100%;
        z-index: 0;
        width: 70%;
        height: 68%;
        left: 15%;
        top: 40%;
        position: relative;
    }

    .fhjcCountStyle .socCountImg font {
        color: #ffffff;
        font-size: 0.8vw;
        letter-spacing: 0.17vw;
        padding-left: 5%;
        font-weight: bold;
    }

    .socCountImgHead {
        position: absolute;
        top: -80%;
        left: 0;
        width: 100%;
        height: 70%;
        text-align: center;
        color: #9ad7f8;
        font-size: 0.5vw;
    }

    #mypoint {
        position: absolute;
        width: 100%;
        height: 100%;
    }

    #mymap {
        position: absolute;
        width: 100%;
        height: 100%;
    }

    .point {
        cursor: pointer;
    }
</style>
<style lang="css">
    #socSafetyCockpit #mypoint .socBowen {
        width: 20px;
        height: 20px;
        position: absolute;
        z-index: 100;
        transform: translate(-50%, -50%);
    }

    #socSafetyCockpit #mypoint .socBowen .showRed1 {
        background-image: url(/static/img/safetyCockpit/red_01.png);
        display: inline-block;
        position: absolute;
        top: 0;
        left: -10px;
        width: 35px;
        height: 35px;
        border-radius: 100px;
        opacity: 1;
        transform: scale(.5);
        transform-origin: 50% 50%;
        animation: aBowen 3s ease infinite;
    }

    #socSafetyCockpit #mypoint .socBowen .showRed2 {
        background-image: url(/static/img/safetyCockpit/red_02.png);
        display: inline-block;
        position: absolute;
        top: 0;
        left: -10px;
        width: 35px;
        height: 35px;
        border-radius: 100px;
        opacity: 1;
        transform: scale(.5);
        transform-origin: 50% 50%;
        animation: aBowen 3s ease infinite;
    }

    #socSafetyCockpit #mypoint .socBowen .showOrange1 {
        background-image: url(/static/img/safetyCockpit/orange_01.png);
        display: inline-block;
        position: absolute;
        top: 0;
        left: -10px;
        width: 35px;
        height: 35px;
        border-radius: 100px;
        opacity: 1;
        transform: scale(.5);
        transform-origin: 50% 50%;
        animation: aBowen 3s ease infinite;
    }

    #socSafetyCockpit #mypoint .socBowen .showOrange2 {
        background-image: url(/static/img/safetyCockpit/orange_02.png);
        display: inline-block;
        position: absolute;
        top: 0;
        left: -10px;
        width: 35px;
        height: 35px;
        border-radius: 100px;
        opacity: 1;
        transform: scale(.5);
        transform-origin: 50% 50%;
        animation: aBowen 3s ease infinite;
    }

    #socSafetyCockpit #mypoint .socBowen span:nth-child(1) {
        animation-delay: 1s;
    }

    #socSafetyCockpit #mypoint .socBowen span:nth-child(2) {
        animation-delay: 2s;
    }

    @keyframes aBowen {
        0% {
            transform: scale(.5);
            opacity: 1;
        }
        100% {
            transform: scale(1.5);
            opacity: 0;
        }
    }

    #socSafetyCockpit #mypoint .socBowen .showPointMessage {
        width: auto;
        height: auto;
        visibility: hidden;
        background-color: rgba(9, 38, 93, 0.8);
        position: absolute;
        left: 30px;
        color: #9ad7f8;
        border: 1px solid #fc7f0b;
        padding: 10px;
        border-radius: 6px;
        font-size: 12px;
        white-space: nowrap;
    }

    #socSafetyCockpit #mypoint .socBowen:hover .showPointMessage {
        visibility: visible;
    }
</style>
