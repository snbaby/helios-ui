<template>
    <div id="all">
        <div id="login">
            <div class="header">
                <div class="header-img">
                    <div class="systemTitleAndImg">
                        <font>信息安全综合保障系统</font>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="back-img">
                </div>
                <div class="content-input">
                    <div class="login-input">
                        <div class="login-header">
                            <p class="login-text">系统登陆</p>
                        </div>
                        <div class="background-color">
                            <div style="color:#e8380b;position: absolute;top: 8px;left: 21px;font-weight: 600;">
                                {{errorInfo}}
                            </div>
                            <div>
                                <input class="username" v-model="loginForm.userName" placeholder="请输入用户名">
                            </div>
                            <div>
                                <input class="password" v-model="loginForm.password" type="password" placeholder="请输入密码"
                                       @keyup.enter="login">
                            </div>
                            <div class="button" @click="login">
                                <p>登录</p>
                            </div>
                            <div class="last">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-text">
                ©2018四川西盾科技有限公司
            </div>
        </div>
    </div>
</template>

<script>
    import {fetch} from "@/core/fetch.js";

    export default {
        name: 'login',
        data() {
            return {
                loginForm: {
                    userName: "",
                    password: ""
                },
                errorInfo: "",
                appCode: "soc"
            }
        },
        methods: {
            login() {
                this.errorInfo = '';
                if (this.loginForm.userName == "") {
                    this.errorInfo = '用户名为空';
                } else if (this.loginForm.password == "") {
                    this.errorInfo = '密码为空';
                } else {
                    fetch('/api/auth/jwt/token', {
                        method: "post",
                        responseType: "json",
                        data: {
                            username: this.loginForm.userName,
                            password: this.loginForm.password,
                            appCode: this.appCode
                        }
                    }).then((res) => {
                        if (res.token && res.token.length > 64) {
                            //登录成功，更新token
                            sessionStorage.setItem("token", res.token);
                            //当前appCode
                            sessionStorage.setItem("appCode", this.appCode);
                            //登录成功，更新cokie
                            document.cookie = "dun-token=" + res.token;

                            fetch({
                                "url": `/api/admin/user/front/info?appCode=${sessionStorage.getItem("appCode")}`,
                                "method": "get"
                            }).then((data) => {
                                sessionStorage.setItem('info',  JSON.stringify(data));

                                //获取码表
                                fetch('/api/admin/dict/entry/getAllDict', {
                                    method: "get",
                                    responseType: "json"
                                }).then((data) => {
                                    sessionStorage.setItem("codeTable", JSON.stringify(data.data));
                                    //获取部门码表
                                    fetch('/api/admin/group/list?groupType=2', {
                                        method: "get",
                                        responseType: "json"
                                    }).then((data) => {
                                        sessionStorage.setItem("depCodeTable", JSON.stringify(data));
                                        this.$router.push({
                                            path: '/soc/home-page'
                                        });
                                    })
                                })
                            })
                        } else {
                            if (res.hasOwnProperty("message")) {
                                this.errorInfo = res.message;
                            } else {
                                this.errorInfo = '系统异常,请稍后重试。';
                            }
                        }
                    }).catch((error) => {
                        this.errorInfo = "用户名不存在或密码错误,请5秒后重试!";
                    });
                }
            },
        }
    };
</script>

<style>
    html, body {
        height: 100%;
    }

    #all {
        width: 100%;
        height: calc(100% + 58px) !important;
        padding: 0;
        overflow-x: auto;
        position: absolute;
        top: 0px;
    }

    #login {
        min-height: 748px;
        min-width: 1024px;
        width: 100%;
        height: 100%;
        padding: 0 !important;

    }

    .systemTitleAndImg {
        background-image: url(/static/img/base/login/cf_logo.png);
        background-size: 100% 100%;
        z-index: 1;
        width: 22%;
        height: 100%;
        position: relative;
    }

    .systemTitleAndImg font {
        position: absolute;
        font-size: 32px;
        color: #004ea2;
        width: 600px;
        top: 27%;
        left: 100%;
    }

    .header {
        height: 120px;
        width: 100%;
        background-color: #ffffff;
    }

    .header-img {
        height: 120px;
        width: 630px;
        position: absolute;
        left: 16.6666667%;
    }

    .content {
        position: relative;
        height: calc(100% - 225px) !important;
        width: 100%;
    }

    .back-img {
        height: 100%;
        width: 100%;
        background-image: url("/static/img/base/login/login-background.png");
        position: absolute;
        background-position-x: center;
        background-position-y: center;
        background-color: #05256e;
        background-repeat: no-repeat;
    }

    .footer-text {
        height: 50px;
        width: 100%;
        background-color: #f0f0f0;
        font-size: 16px;
        color: #666666;
        text-align: center;
        line-height: 50px;
    }

    .content-input {
        position: relative;
        max-width: 1280px;
        height: 100%;
        margin: auto;
        z-index: 2;

    }

    .login-input {
        position: absolute;
        width: 384px;
        height: 335px;
        border-radius: 8px;
        top: calc(221px + ((100% - 778px) / 2)) !important;
        top: 221px;
        /*margin-left: 816px;*/
        box-shadow: 0 0 15px #000000;
        opacity: 14;
        right: 20px;
    }

    .login-header {
        background-color: #004ea2;
        height: 64px;
        border-radius: 8px 8px 0px 0px;
    }

    .login-text {
        font-size: 18px;
        font-weight: bold;
        color: #ffffff;
        text-align: center;
        line-height: 64px;
    }

    .username, .password {
        height: 56px;
        width: 344px;
        border: 1px solid #f0f0f0;
        padding: 12px 20px;
    }

    .loginButtonStyle {
        background-color: #004ea2;
        height: 48px;
        margin-left: 20px;
        width: 344px;
        color: #000000;
        border-style: solid;
        border-color: #f0f0f0;
        border-width: 1px;
        padding-left: 12px;

    }

    .username {
        margin: 35px 20px 0px 20px !important;
        border-radius: 8px 8px 0px 0px;
        font-size: 16px;
    }

    .username::placeholder {
        color: #bbbbbb;
        font-size: 16px;
    }

    .username:focus, .password:focus {
        /*outline-color: unset;*/
        outline-style: none;
    }

    .password::placeholder {
        color: #bbbbbb;
        font-size: 16px;
        letter-spacing: normal;

    }

    .password {
        margin: 0px 20px 10px 20px !important;
        border-radius: 0px 0px 8px 8px;
        font-size: 16px;
        letter-spacing: 3px;
    }

    .button {
        width: 344px;
        height: 48px;
        font-size: 18px;
        background-color: #004ea2;
        color: #ffffff;
        border-radius: 8px;
        margin: 0px 20px;
        text-align: center;
        line-height: 48px;
        cursor: pointer;

    }

    .background-color {
        background-color: white;
        border-radius: 0px 0px 8px 8px;
        position: relative;
    }

    .last {
        width: 100%;
        height: 66px;
    }

    .warning-message {
        position: absolute;
        font-size: 12px;
        color: #fc3423;
        left: 20px;
        top: 75px;
    }

    .systemType {
        margin: 30px 20px -20px 20px;
        font-size: 16px;
        height: 56px;
        width: 344px;
        border: 1px solid #f0f0f0;
        padding: 12px 20px;
    }
</style>
