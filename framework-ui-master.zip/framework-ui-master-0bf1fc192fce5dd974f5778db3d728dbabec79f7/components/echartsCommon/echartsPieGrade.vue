<template>
    <div :style="{height:height,width:width}" :ref="lineRef">
    </div>
</template>
<script>
    import echarts from "echarts";
    export default {
        props: {
            span: {
                type: String,
                default: "6",
            },
            lineRef: {
                type: String,
                required: true,
            },
            name: {
                type: String,
            },
            width: {
                type: String,
                default: '100%',
            },
            height: {
                type: String,
                default: '100%',
            },
            pieData: {
                type: Array,
            }
        },
        data() {
            return {
                chart: null,

            };
        },
        mounted() {
            this.initChart();
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        methods: {
            initChart() {
                var that = this;
                this.chart = echarts.init(this.$refs[this.lineRef]);
                const option = {
                    tooltip: {
                        trigger: "item",
                        formatter: "{b} : {c}台 ({d}%)"
                    },
                    series: [
                        {
                            name: '0',
                            type: "pie",
                            center: ["50.0%", "50%"],
                            hoverAnimation: false,
                            data: this.pieData,
                        }
                    ]
                };
                // 把配置和数据放这里
                this.chart.setOption(option);
                this.chart.on("click",function (param){
                    that.$emit('getSearch',param.name);
                });
            },
        },

    };
</script>
<style scoped>
    .rightBorder {
        width: 308px;height: 100%;border-right: 1px solid #e5e5e5;
    }

    .titleHeader {
        padding-left: 20px;
        height: 48px;
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        line-height: 48px;
    }
</style>
