<template>
    <div :style="{height:height,width:width}" :ref="lineRef">
    </div>
</template>
<script>
    import echarts from "echarts";
    export default {
        name: 'echartsBar',
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            width: {
                type: String,
                default: '100%',
            },
            height: {
                type: String,
                default: '100%',
            },
            name: {
                type: String,
                default: '打印机风险分布',
            },
            num: {
                type: Array,
                default: function () {
                    return []
                }
            }
        },
        data() {
            return {
                chart: null,
            };
        },
        mounted() {
            this.initChart();
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        watch: {
            num: {
                handler(newValue, oldValue) {
                    this.initChart();
                },
                deep: true
            }
        },
        methods: {
            initChart() {
                console.log(this.num);
                this.chart = echarts.init(this.$refs[this.lineRef]);
                const option = {
                    tooltip: {
                        trigger: "item",
                        formatter: "{b} : {c}台 ({d}%)"
                    },
                    color: [ "#ff0000","#ff800a","#1f67fb"],
                    series: {
                            hoverAnimation: false,
                            name: "服务器风险分布",
                            type: "pie",
                            radius: "50%",
                            center: ["50%", "50%"],
                            label: {
                                normal: {
                                    formatter: "{b}:" + "{c}" + "台" + "\n" + "{d}%",
                                    textStyle: {
                                        fontSize: 12,
                                        color: "#35393c",
                                        shadowColor: "rgba(0, 0, 0, 0.5)"
                                    }
                                }
                            },
                            data: this.num
                        }
                };
                // 把配置和数据放这里
                this.chart.setOption(option);
            },
        },

    };
</script>

<style scoped>

</style>
