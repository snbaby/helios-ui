<template>
    <div :style="{height:height,width:width}" :ref="lineRef">
    </div>
</template>
<script>
    import echarts from "echarts";
    export default {
        name: 'echartsline',
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            width: {
                type: String,
                default: '100%',
            },
            height: {
                type: String,
                default: '100%',
            },
            countData: {
                type: Object,
                default: function () {
                    return {
                        time: [],
                        count: []
                    }
                }
            },
        },
        data() {
            return {
                chart: null,
            };
        },
        mounted() {
            this.initChart();
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        methods: {
            initChart() {
                this.chart = echarts.init(this.$refs[this.lineRef]);
                const option = {
                    tooltip: {
                        trigger: 'axis',
                        borderWidth: '1',
                        backgroundColor: '#ffffff',
                        borderColor: '#e5e5e5',
                        textStyle: {
                            color: '#666',
                            fontSize: '14'
                        },
                        padding: 15,
                        formatter: function(params, ticket, callback) {
                            let date = params[0].name
                            let num = params[0].value
                            date = date.substring(3, 5) + '月' + date.substring(0, 2) + '号' + '</br><li>' + num
                            return date
                        }
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        axisLabel: {
                            show: true,
                            formatter: function(data) {
                                let month = data.substring(3, 5)
                                let day = data.substring(0, 2)
                                let time = month + '月' + day + '号'
                                return time
                            }
                        },
                        data: this.countData.time,
                    },
                    yAxis: {
                        type: 'value',
                        splitLine: {
                            show: false
                        },
                    },
                    series: {
                        itemStyle: {
                            normal: {
                                color: '#5d9efa',
                                lineStyle: {
                                    color: '#5d9efa',
                                    width: 2
                                }
                            }
                        },
                        data: this.countData.count,
                        type: 'line',
                        areaStyle: {
                            normal: {
                                color: '#dbeefc'
                            }
                        }
                    }
                };
                // 把配置和数据放这里
                this.chart.setOption(option);
            },
        },

    };
</script>
