<template>
    <div style="height: 100%;">
        <div class="titleHeader" style="border: 0px">{{name}}</div>
        <div style="height: 216px;border-right: 1px solid #e5e5e5;">
            <echarts-pie :line-ref="lineRef" :num="num"></echarts-pie>
        </div>
    </div>
</template>

<script>
    import echartsPie from "@/components/echartsCommon/echartsPie"

    export default {
        name: "situationUsePie",
        components: {
            echartsPie,
        },
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            name: {
                type: String,
            },
            num: {
                type: Array,
                default: function () {
                    return []
                }
            }
        },
    }
</script>

<style scoped>
    .titleHeader {
        padding-left: 20px;
        height: 48px;
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        line-height: 48px;
    }
</style>
