<template>
    <div style="height:100%;">
        <div class="titleHeader" v-if="name">{{name}}</div>
        <div style="height: 216px;border-right: 1px solid #e5e5e5;">
            <echarts-pie-two :line-ref="lineRef" :pieData="pieData" v-if="isTrue"></echarts-pie-two>
        </div>
    </div>
</template>

<script>
    import echartsPieTwo from "@/components/echartsCommon/echartsPieTwo"
    export default {
        name: "situationUsePieTwo",
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            name: {
                type: String,
            },
            isTrue: {
                type: Boolean,
            },
            pieData: {
                type: Array,
                default: function () {
                    return [];
                }
            }
        },
        components: {
            echartsPieTwo,
        }
    }
</script>

<style scoped>
    .titleHeader {
        padding-left: 20px;
        height: 48px;
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        line-height: 48px;
    }
</style>
