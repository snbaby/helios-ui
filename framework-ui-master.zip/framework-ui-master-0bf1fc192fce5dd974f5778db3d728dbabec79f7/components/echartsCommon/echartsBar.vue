<template>
    <div class="rightBorder">
        <div class="titleHeader">{{name}}</div>
        <div style="height: calc(100% - 48px) !important;height:100%;width: 100%" :ref="lineRef"></div>
    </div>
</template>
<script>
    import echarts from "echarts";
    export default {
        name: 'echartsBar',
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            name: {
                type: String,
                default: '100%',
            },
            num: {
                type: Array,
                default: function () {
                    return []
                }
            }

        },
        data() {
            return {
                chart: null,
            };
        },
        mounted() {
            this.initChart();
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        watch: {
            num: {
                handler(newValue, oldValue) {
                    this.initChart();
                },
                deep: true
            }
        },
        methods: {
            initChart() {
                this.chart = echarts.init(this.$refs[this.lineRef]);
                const option = {
                    tooltip: {},
                    grid: {
                        top: '40',
                        bottom: '10%',
                        containLabel: true
                    },
                    xAxis: {
                        type: 'category',
                        data: ['服务器', '台式计算机', '交换机', '打印机'],
                        axisLabel: {
                            rotate:60,
                            textStyle: {
                                color: '#666',
                                fontSize: 12
                            },
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#ebebeb'
                            }
                        },
                    },
                    yAxis: {
                        type: 'value',
                        axisLabel: {
                            textStyle: {
                                color: '#666',
                                fontSize: 12
                            },
                            // formatter: '{value}'
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#ebebeb'
                            }
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    series: {
                        name: '',
                        type: 'bar',
                        barWidth: '40%',

                        data: this.num,
                        itemStyle: {
                            normal: {
                                color: 'rgb(93,158,250)'
                            }
                        }
                    }
                };
                // 把配置和数据放这里
                this.chart.setOption(option);
            },
        },

    };
</script>

<style scoped>

    .rightBorder {
        width: 100%;height: 100%;border-right: 1px solid #e5e5e5;
    }

    .titleHeader {
        padding-left: 20px;
        height: 48px;
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        line-height: 48px;
    }
</style>
