<template>
    <mu-row style="height: 100%;width: 100%">
        <div style="width: 145px;height: 100%;padding: 40px">
            <div class="fontStyle" style="margin-bottom: 16px;">ERP系统</div>
            <div class="imgBackground"></div>
            <div class="fontStyle" >机密</div>
        </div>
        <div style="width: calc(100% - 145px) !important;width 100%;height: 100%">
            <div class="fontPosition"><font class="fontLeft">当前风险：</font>
                <div class="buttonStyle" style="background-color: rgb(0,161,255);" v-if="ERPSystem.currentRisk<5">{{ERPSystem.currentRisk}}</div>
                <div class="buttonStyle" style="background-color: #ff800a" v-else-if="ERPSystem.currentRisk>=5 && ERPSystem.currentRisk<7">{{ERPSystem.currentRisk}}</div>
                <div class="buttonStyle" style="background-color: #ff0000" v-else-if="ERPSystem.currentRisk>=7">{{ERPSystem.currentRisk}}</div>
            </div>
            <div class="fontPosition"><font class="fontLeft">主管单位：</font>{{ERPSystem.company}}</div>
            <div class="fontPosition"><font class="fontLeft">关联主机：</font>{{ERPSystem.associatedHost}}</div>
            <div class="fontPosition"><font class="fontLeft">高危主机：</font>
                <font class="highFont">{{ERPSystem.highRiskHosts}}</font>/{{ERPSystem.hosts}}</div>
            <div class="fontPosition"><font class="fontLeft">高危漏洞：</font>
                <font class="highFont">{{ERPSystem.highRiskVulnerability}}</font>/{{ERPSystem.riskVulnerability}}</div>
            <div class="fontPosition"><font class="fontLeft">扫描时间：</font>{{ERPSystem.times}}</div>
        </div>
    </mu-row>
</template>

<script>
    export default {
        name: "systemRiskProfile",
        props: {
            ERPSystem: {
                type: Object,
                default: {},
            }
        },
    }
</script>

<style scoped>
    .imgBackground {
        height: 65px;
        width: 100%;
        background-image: url("/static/img/businessCenter/erp_icon.png");
        background-size: 100% 100%;
        margin-bottom: 16px;
    }

    .fontStyle {
        width: 100%;
        text-align: center;
        font-size: 14px;
        font-weight: bold;
        color: rgb(0,161,255);
    }

    .fontPosition {
        width: 100%;
        margin-top: 12px
    }

    .fontLeft {
        font-size: 14px;
        color: #a6a6a6;
    }

    .highFont {
        color:#ff0000;
    }

    .buttonStyle {
        height: 30px;
        width: 40px;
        color: #ffffff;
        border: 1px solid;
        border-radius: 8px;
        position: absolute;
        margin-top: -25px;
        margin-left: 72px;
        text-align: center;
        line-height: 30px;
    }
</style>
