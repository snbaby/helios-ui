<template>
    <div :style="{height:height,width:width}" :ref="lineRef">
    </div>
</template>
<script>
    import echarts from "echarts";
    export default {
        name: 'echartsPieThree',
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            width: {
                type: String,
                default: '100%',
            },
            height: {
                type: String,
                default: '100%',
            },
            pieData: {
                type: Array,
                default: function () {
                    return []
                }
            }
        },
        data() {
            return {
                chart: null,
            };
        },
        mounted() {
            this.initChart();
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        methods: {
            initChart() {
                this.chart = echarts.init(this.$refs[this.lineRef]);
                const option = {
                    tooltip : {
                        trigger: 'item',
                        formatter: "{b} : {c} ({d}%)"
                    },
                    series : [
                        {
                            name: '访问来源',
                            type: 'pie',
                            radius : '55%',
                            center: ['50%', '50%'],
                            data: this.pieData,
                            label: {
                                normal: {
                                    formatter: "{b}: {c}",
                                }
                            }
                        }
                    ]};
                // 把配置和数据放这里
                this.chart.setOption(option);
            },
        },

    };
</script>

<style scoped>

</style>
