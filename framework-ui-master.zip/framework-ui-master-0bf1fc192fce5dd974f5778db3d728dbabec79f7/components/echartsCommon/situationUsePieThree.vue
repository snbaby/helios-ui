<template>
    <div style="height:100%;width: 100%">
        <div class="titleHeader" v-if="name">{{name}}</div>
        <div style="height: 216px; width: 100%">
            <echarts-pie-three :line-ref="lineRef" :pieData="pieData"  v-if="isTrue"></echarts-pie-three>
        </div>
    </div>
</template>

<script>
    import echartsPieThree from "../echartsCommon/echartsPieThree"
    export default {
        name: "situationUsePieTwo",
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            name: {
                type: String,
            },
            isTrue: {
                type: Boolean,
            },
            pieData: {
                type: Array,
                default: function () {
                    return [];
                }
            }
        },
        components: {
            echartsPieThree,
        }
    }
</script>

<style scoped>
    .titleHeader {
        padding-left: 20px;
        height: 48px;
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        line-height: 48px;
        position: absolute;
    }
</style>
