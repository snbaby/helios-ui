<template>
    <div :style="{height:height,width:width}" :ref="lineRef">
    </div>
</template>
<script>
    import echarts from "echarts";
    export default {
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            width: {
                type: String,
                default: '100%',
            },
            height: {
                type: String,
                default: '100%',
            },
            riskNum: {
                type: Number,
                default: null
            }
        },
        data() {
            return {
                chart: null,
            };
        },
        mounted() {
            this.initChart();
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        methods: {
            initChart() {
                this.chart = echarts.init(this.$refs[this.lineRef]);
                const option = {
                    tooltip: {},
                    series: [
                        {
                            startAngle: 225,
                            endAngle: -45,
                            min: 0,
                            max: 5,
                            radius: '70%',
                            axisLine: {
                                show: false,
                                lineStyle: {
                                    width: 9,
                                    color: [[0.2, '#08e69a'], [0.4, '#00a1ff'], [0.6, '#1f67fb'], [0.8, '#ff800a'], [1, '#ff0000']]
                                }
                            },
                            axisLabel: {
                                distance: -20,
                                formatter: function (value) {
                                    if (value === 0) {
                                        return value
                                    } else if (value === 1) {
                                        return value
                                    } else if (value === 2) {
                                        return value
                                    } else if (value === 3) {
                                        return value
                                    } else if (value === 4) {
                                        return value
                                    } else if (value === 5) {
                                        return value
                                    }
                                }
                            },
                            splitLine: {
                                show: false
                            },
                            axisTick: {
                                show: false
                            },
                            detail: {
                                show: false
                            },
                            name: '当前风险值：',
                            type: 'gauge',
                            data: [{value: 1}]
                        }
                    ]
                };
                // 把配置和数据放这里
                this.chart.setOption(option);
            },
        },

    };
</script>
<style scoped>
    .rightBorder {
        width: 308px;height: 100%;border-right: 1px solid #e5e5e5;
    }

    .titleHeader {
        padding-left: 20px;
        height: 48px;
        width: 100%;
        font-size: 16px;
        font-weight: bold;
        color: #666666;
        line-height: 48px;
    }
</style>
