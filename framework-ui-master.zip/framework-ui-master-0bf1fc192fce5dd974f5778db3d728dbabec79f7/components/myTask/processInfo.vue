<template>
    <div class="content">
        <el-card shadow="hover">
            <div>
                <div id="processDefineContainer"></div>
            </div>
        </el-card>
        <el-card shadow="hover">
            <div>
                <el-row>
                    <el-col :span="8">
                        <el-card shadow="hover" style="margin-right:10px;">
                            <div slot="header">
                                <span>申请内容</span>
                            </div>
                            <div class="item" style="height: 400px;overflow: auto">
                                <template v-for="items in startFormVariablesShow">
                                    <el-row style="border-bottom:1px dashed #000;border-top:1px solid #000;">
                                        <el-col style="text-align: center;font-size: 20px">{{items.label}}</el-col>
                                    </el-row>
                                    <template v-for="item in items.props">
                                        <el-row>
                                            <el-col :span="8" style="text-align: right">{{item.label}}:</el-col>
                                            <el-col :span="16">{{getCategoryData(item.id,item.value?item.value:"")?getCategoryData(item.id,item.value?item.value:""):item.value}}</el-col>
                                        </el-row>
                                    </template>
                                </template>
                            </div>
                        </el-card>
                    </el-col>
                    <el-col :span="8">
                        <el-card shadow="hover" style="margin-right:10px;">
                            <div slot="header">
                                <span>审批人</span>
                            </div>
                            <div class="item" style="height: 400px;overflow: auto">
                                <template v-for="flowTaskInfo in flowTaskInfos">
                                    <!--<el-row>
                                        <el-col :span="8" style="text-align: right">流程实例:</el-col>
                                        <el-col :span="16">{{flowTaskInfo.flow_instance_id}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">流程节点标识:</el-col>
                                        <el-col :span="16">{{flowTaskInfo.flow_task_id}}</el-col>
                                    </el-row>-->
                                    <el-row style="border-bottom:1px dashed #000;border-top:1px solid #000;">
                                        <el-col style="text-align: center;font-size: 20px">{{flowTaskInfo.flow_task_name}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">流程节点状态:</el-col>
                                        <el-col :span="16">{{flowTaskInfo.flow_task_status=='complete'?'已审批':'待审批'}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">办理人工号:</el-col>
                                        <el-col :span="16">{{flowTaskInfo.flow_tasker_code}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">办理人姓名:</el-col>
                                        <el-col :span="16">{{flowTaskInfo.flow_tasker_name}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">办理人状态:</el-col>
                                        <el-col :span="16">{{getCategoryData('person_status',flowTaskInfo.flow_tasker_status?flowTaskInfo.flow_tasker_status:"")}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">办理人密级:</el-col>
                                        <el-col :span="16">{{getCategoryData('person_secret',flowTaskInfo.flow_tasker_secret?flowTaskInfo.flow_tasker_secret:"")}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">办理人组织:</el-col>
                                        <el-col :span="16">{{flowTaskInfo.flow_tasker_org_name?flowTaskInfo.flow_tasker_org_name:flowTaskInfo.org_name}}</el-col>
                                    </el-row>
                                    <el-row>
                                        <el-col :span="8" style="text-align: right">联系方式:</el-col>
                                        <el-col :span="16">{{flowTaskInfo.flow_tasker_contact}}</el-col>
                                    </el-row>
                                    <el-row v-if="flowTaskInfo.hasOwnProperty('flow_start_time')&&flowTaskInfo.flow_start_time != null && flowTaskInfo.flow_start_time != ''">
                                        <el-col :span="8" style="text-align: right">开始时间:</el-col>
                                        <el-col :span="16">{{timestampToTime(flowTaskInfo.flow_start_time)}}</el-col>
                                    </el-row>
                                    <el-row v-if="flowTaskInfo.hasOwnProperty('flow_end_time')&&flowTaskInfo.flow_end_time != null && flowTaskInfo.flow_end_time != ''">
                                        <el-col :span="8" style="text-align: right">结束时间:</el-col>
                                        <el-col :span="16">{{timestampToTime(flowTaskInfo.flow_end_time)}}</el-col>
                                    </el-row>
                                    <el-row v-if="flowTaskInfo.hasOwnProperty('flow_start_time')&&flowTaskInfo.flow_start_time != null && flowTaskInfo.flow_start_time != ''&&flowTaskInfo.hasOwnProperty('flow_end_time')&&flowTaskInfo.flow_end_time != null && flowTaskInfo.flow_end_time != ''">
                                        <el-col :span="8" style="text-align: right">运行时长:</el-col>
                                        <el-col :span="16">{{formatDateBetween(flowTaskInfo.flow_end_time,flowTaskInfo.flow_start_time)}}</el-col>
                                    </el-row>
                                </template>
                            </div>
                        </el-card>
                    </el-col>
                    <el-col :span="8">
                        <el-card shadow="hover">
                            <div slot="header">
                                <span>审批意见</span>
                            </div>
                            <div class="item" style="height: 400px;overflow-y: auto;overflow-x: hidden">
                                <template v-for="items in tasksFormVariablesShow">
                                    <el-row style="border-bottom:1px dashed #000;border-top:1px solid #000;">
                                        <el-col style="text-align: center;font-size: 20px">{{items.taskName}}</el-col>
                                    </el-row>
                                    <template v-for="item in items.props">
                                        <el-row :gutter="10">
                                            <el-col :span="8" style="text-align: right">{{item.label}}:</el-col>
                                            <el-col :span="16">{{item.value}}</el-col>
                                        </el-row>
                                    </template>
                                </template>
                            </div>
                        </el-card>
                    </el-col>
                </el-row>
            </div>
        </el-card>
    </div>
</template>

<script>

    import {
        getProcessDefineXml_key,
        getProcessDefineForm_key,
        postProcessInInstance_executionId,
        getProcessApproveUser,
        postProcessApplyDetail,
        postProcessApplyDetail_applyDetailTbName_flowInstanceId,
        queryFlowApplyInfo_flowInstanceId,
        selectAssetUserByUserCodes,
        getUserObj
    } from '@/api/user/myTask/processInfo/index.js';
    import Viewer from 'bpmn-js/lib/NavigatedViewer.js';

    const _ = require("underscore");
    export default {
        props: {
            processDefinitionkey: {
                type: String,
                required: true,
            },
            flowInstanceId: {
                type: String,
                required: true,
            },
            // flowBusinessKey: {
            //     type: String,
            //     required: true,
            // }
        },
        data() {
            return {
                startFormVariables: [],
                startFormResult: null,
                tasksFormVariables: [],

                instanceHistoryValues: [],

                taskNodeId: "",
                flowTaskName: "",
                applyDetailTbName: "",

                flowApplyInfo: null,

                flowTaskInfos: []
            };
        },
        computed: {
            startFormVariablesShow() {
                let tempValue = null;
                if (this.startFormVariables.length > 0 && this.startFormResult != null) {
                    tempValue = this.startFormResult;
                }

                if (tempValue != null) {
                    for (var i in this.startFormVariables) {
                        var tab = this.startFormVariables[i];
                        for (var j in tab.props) {
                            var prop = tab.props[j];
                            prop.value = tempValue[prop.id];
                        }
                    }
                }
                return this.startFormVariables;
            },
            tasksFormVariablesShow(){
                const _self = this;
                let result = [];

                if(_self.tasksFormVariables.length>0 && _self.instanceHistoryValues.length > 0){
                    for(var i in _self.instanceHistoryValues){
                        let instanceHistoryValue = _self.instanceHistoryValues[i];
                        if(_self.applyDetailTbName == ''){//查询表单信息所对应的表结构
                            _self.applyDetailTbName = instanceHistoryValue.process_definition_key;
                        }
                        if(instanceHistoryValue.flow_task_status != 'complete'){
                            continue;
                        }
                        for(var j in _self.tasksFormVariables){
                            let tasksFormVariable = _self.tasksFormVariables[j];
                            if(tasksFormVariable.taskId == instanceHistoryValue.flow_task_key){
                                var temp =  JSON.parse(JSON.stringify(tasksFormVariable));
                                for(var k in temp.props){
                                    if(temp.props[k].dataType == 'enum'){
                                        for(var h in temp.props[k].options){
                                            if(_.has(temp.props[k].options[h],instanceHistoryValue[temp.props[k].id])){
                                                temp.props[k].value =  temp.props[k].options[h][instanceHistoryValue[temp.props[k].id]];
                                                break;
                                            }
                                        }
                                    }else if(temp.props[k].dataType == 'date'){
                                        temp.props[k].value =  this.timestampToTime(instanceHistoryValue[temp.props[k].id]);
                                    }else{
                                        temp.props[k].value =  instanceHistoryValue[temp.props[k].id];
                                    }
                                }
                                result.push(temp);
                                break;
                            }
                        }
                    }
                }

                return result;
            }
        },
        watch: {
            taskNodeId(newVal) {
                const _self  = this;
                this.flowTaskInfos = [];
                if (newVal === "") {
                    this.flowTaskInfos = [];
                } else {
                    var thisNodeInstanceHistoryValues = _.filter(_self.instanceHistoryValues,function(instanceHistoryValue){
                        return (instanceHistoryValue.flow_task_key == newVal)&&instanceHistoryValue.hasOwnProperty("flow_tasker_code");
                    });
                    var thisNodeCurrentValues = _.filter(_self.instanceHistoryValues,function(instanceHistoryValue){
                        return (instanceHistoryValue.flow_task_key == newVal)&&(!instanceHistoryValue.hasOwnProperty("flow_tasker_code"));
                    });
                    if(thisNodeInstanceHistoryValues && thisNodeInstanceHistoryValues.length>0){
                        //to-do 判断当前节点是否处于已完成状态
                        this.flowTaskInfos = JSON.parse(JSON.stringify(thisNodeInstanceHistoryValues));
                    }
                    if(thisNodeCurrentValues && thisNodeCurrentValues.length>0){
                        //to-do 判断当前节点是否处于已完成状态
                    }else{
                        if(this.flowTaskInfos.length>0){
                            return;
                        }
                    }
                    if(_self.flowApplyInfo.flow_status == 'COMPLETED'){
                        return;
                    }
                    async function main() {
                        try{
                            let tempApprovers = [];
                            let processApproveUserRes = await getProcessApproveUser(_self.flowInstanceId,newVal);
                            if(processApproveUserRes.hasOwnProperty("rel")&& processApproveUserRes.rel == true){
                                tempApprovers = processApproveUserRes.data;
                            }else{
                                throw "";
                            }
                            _self.flowTaskInfos = [];
                            for(var i in tempApprovers){
                                var tempApprover = tempApprovers[i];
                                let result =  {
                                    flow_instance_id: _self.flowInstanceId,
                                    flow_task_id: newVal,
                                    flow_task_name: _self.flowTaskName,
                                    flow_task_status: "待审批",
                                    flow_tasker_code: tempApprover,
                                    flow_tasker_name: "",
                                    flow_tasker_status: "",
                                    flow_tasker_secret: "",
                                    flow_tasker_org_name: "",
                                    org_name: "",
                                    flow_tasker_contact: "",
                                    flow_tasker_content: "",
                                    flow_start_time: "",
                                    flow_end_time: "",
                                    flow_run_time: "",
                                    flow_tasker_org_code: "",
                                    flow_tasker_org_path: "",
                                }
                                const userParams = {
                                    username : tempApprover
                                }
                                let userInfoRes = await getUserObj(userParams);
                                if(userInfoRes.hasOwnProperty("rel")&& userInfoRes.rel == true){
                                    result.flow_tasker_name = userInfoRes.data.name;
                                }else{
                                    _self.$notify.error({
                                        title: '错误',
                                        message: '获取'+tempApprover +'人员信息错误'
                                    });
                                    continue;
                                }
                                let userBusinessInfoRes = await selectAssetUserByUserCodes(result.flow_tasker_code);
                                if(userBusinessInfoRes.hasOwnProperty("rel")&& userBusinessInfoRes.rel == true && userBusinessInfoRes.hasOwnProperty("data")){
                                    userBusinessInfoRes = userBusinessInfoRes.data;
                                }else{
                                    userBusinessInfoRes = null;
                                }
                                if(userBusinessInfoRes && userBusinessInfoRes.hasOwnProperty("rel")&& userBusinessInfoRes.rel == true&& userBusinessInfoRes.hasOwnProperty("data")&& userBusinessInfoRes.data.length>0){
                                    if(userBusinessInfoRes.data[0].hasOwnProperty("person_secret")){
                                        result.flow_tasker_status = userBusinessInfoRes.data[0].person_status;
                                    }else{
                                        result.flow_tasker_status =  "";
                                    }
                                    if(userBusinessInfoRes.data[0].hasOwnProperty("person_secret")){
                                        result.flow_tasker_secret = userBusinessInfoRes.data[0].person_secret;
                                    }else{
                                        result.flow_tasker_secret =  "";
                                    }
                                    if(userBusinessInfoRes.data[0].hasOwnProperty("org_name")){
                                        result.org_name = userBusinessInfoRes.data[0].org_name;
                                        result.flow_tasker_org_name = userBusinessInfoRes.data[0].org_name;
                                    }else{
                                        result.org_name =  "";
                                        result.flow_tasker_org_name =  "";
                                    }
                                    if(userBusinessInfoRes.data[0].hasOwnProperty("person_phone")){
                                        result.flow_tasker_contact = userBusinessInfoRes.data[0].person_phone;
                                    }else{
                                        result.flow_tasker_contact =  "";
                                    }
                                    result.flow_tasker_content = "";
                                    result.flow_start_time = "";
                                    result.flow_end_time = "";
                                    result.	flow_run_time = "";
                                    if(userBusinessInfoRes.data[0].hasOwnProperty("org_code")){
                                        result.flow_tasker_org_code = userBusinessInfoRes.data[0].org_code;;
                                    }else{
                                        result.flow_tasker_org_code =  "";
                                    }
                                    if(userBusinessInfoRes.data[0].hasOwnProperty("org_full_path")){
                                        result.flow_tasker_org_path = userBusinessInfoRes.data[0].org_full_path;
                                    }else{
                                        result.flow_tasker_org_path =  "";
                                    }
                                }else{
                                    result.flow_tasker_status = "";
                                    result.flow_tasker_secret =  "";
                                    result.flow_tasker_org_name =  "";
                                    result.org_name = "";
                                    result.flow_tasker_contact =  "";
                                    result.flow_tasker_content = "";
                                    result.flow_start_time = "";
                                    result.flow_end_time = "";
                                    result.	flow_run_time = "";
                                    result.flow_tasker_org_code =  "";
                                    result.flow_tasker_org_path =  "";
                                }
                                _self.flowTaskInfos.push(result);
                            }
                        }catch(err){
                            _self.$notify.error({
                                title: '错误',
                                message: '查询审核信息错误'
                            });
                        }
                    };
                    main();
                }
            },
            applyDetailTbName(newVal){
                const _self  = this;
                if(newVal!=""){
                    let data = {
                        "applyDetailTbName": newVal,
                        "flowInstanceId": _self.flowInstanceId,
                    };
                    postProcessApplyDetail_applyDetailTbName_flowInstanceId(data).then(res=>{
                        if(res&&res.hasOwnProperty('rel')&&res.rel == true&& res.hasOwnProperty('data')&& res.data.hasOwnProperty('data')&& res.data.data.length>0){
                            _self.startFormResult = res.data.data[0];
                        }
                        else{
                            _self.$notify.error({
                                title: '错误',
                                message: '获取申请表单错误'
                            });
                        }
                    }).catch(err=>{
                        _self.$notify.error({
                            title: '错误',
                            message: '获取申请表单错误'
                        });
                    })
                }
            }
        },
        created() {
            this.init();
        },
        methods: {
            initXml() {
                const _self = this;
                getProcessDefineXml_key(this.processDefinitionkey).then(res => {
                    var viewer = new Viewer({container: '#processDefineContainer'});
                    viewer.importXML(res.bpmn20Xml, (err) => {
                        var canvas = viewer.get('canvas');
                        canvas.zoom('fit-viewport');
                        var eventBus = viewer.get('eventBus');
                        var events = [
                            'element.click'
                        ];

                        for (var i in _self.instanceHistoryValues) {//颜色渲染
                            if (_self.instanceHistoryValues[i].hasOwnProperty("flow_task_status") && _self.instanceHistoryValues[i].flow_task_status == "complete" ) {
                                canvas.addMarker(_self.instanceHistoryValues[i].flow_task_key, 'completeProcHighlight');
                            } else {
                                canvas.addMarker(_self.instanceHistoryValues[i].flow_task_key, 'activeProcessHighlight');
                            }
                        }
                        canvas.addMarker('StartEvent_0497nnm', 'completeProcHighlight');
                        if(_self.flowApplyInfo.flow_status == 'COMPLETED'){
                            canvas.addMarker('EndEvent_14rmd3k', 'completeProcHighlight');
                        }
                        events.forEach(function (event) {
                            eventBus.on(event, function (e) {
                                _self.approvalStation = [];
                                if (e.element.type == "bpmn:UserTask") {//人工任务
                                    _self.taskNodeId = e.element.id;
                                    _self.flowTaskName = e.element.businessObject.name;
                                } else {//其他
                                    _self.taskNodeId = "";
                                    _self.flowTaskName = "";
                                }
                            });
                        });
                    });
                }).catch(err => {
                    _self.$notify.error({
                        title: '错误',
                        message: '获取流程表单错误'
                    });
                })
            },
            init(){
                const _self = this;
                async function main() {
                    try {
                        let processDefineFormRes = await  getProcessDefineForm_key(_self.processDefinitionkey);
                        if (processDefineFormRes && processDefineFormRes.hasOwnProperty("status")&& processDefineFormRes.status==200) {
                            var startFormFields = processDefineFormRes.form.fields;
                            for (var i in startFormFields) {
                                if(startFormFields[i].hasOwnProperty('props')){
                                    var jsonArray = _.map(JSON.parse(startFormFields[i].props), temp => {
                                        temp['value'] = "";
                                        return temp;
                                    });
                                    let obj = {
                                        label: startFormFields[i].label,
                                        props: jsonArray
                                    };
                                    _self.startFormVariables.push(obj);
                                }
                            }
                            var tasksFormFields = processDefineFormRes.tasks;
                            for(var i in tasksFormFields){
                                var tasksFormField = tasksFormFields[i];
                                var jsonArray = _.map(tasksFormField.fields, temp => {
                                    temp['value'] = "";
                                    return temp;
                                });
                                let obj = {
                                    taskId: tasksFormField.id,
                                    taskName: tasksFormField.taskName,
                                    props: jsonArray
                                };
                                _self.tasksFormVariables.push(obj);
                            }
                        };
                        let data = {
                            "flowInstanceId": _self.flowInstanceId
                        };
                        let postProcessInInstanceRes = await postProcessInInstance_executionId({"flowInstanceId": _self.flowInstanceId});
                        if (postProcessInInstanceRes && postProcessInInstanceRes.hasOwnProperty('rel') && postProcessInInstanceRes.rel == true && postProcessInInstanceRes.hasOwnProperty('data') && postProcessInInstanceRes.data.hasOwnProperty('rel') &&  postProcessInInstanceRes.data.rel == true && postProcessInInstanceRes.data.hasOwnProperty('data') ) {
                            if (postProcessInInstanceRes.data.data.length > 0) {
                                _self.instanceHistoryValues = postProcessInInstanceRes.data.data;
                            }else{
                                throw "";
                            }
                        }

                        let queryFlowApplyInfoRes = await queryFlowApplyInfo_flowInstanceId({"flowInstanceId": _self.flowInstanceId});
                        if (queryFlowApplyInfoRes && queryFlowApplyInfoRes.hasOwnProperty('rel') && queryFlowApplyInfoRes.rel == true && queryFlowApplyInfoRes.hasOwnProperty('data') && queryFlowApplyInfoRes.data.hasOwnProperty('rel') &&  queryFlowApplyInfoRes.data.rel == true && queryFlowApplyInfoRes.data.hasOwnProperty('data') ) {
                            if (queryFlowApplyInfoRes.data.data.length > 0) {
                                _self.flowApplyInfo = queryFlowApplyInfoRes.data.data[0];
                            }else{
                                throw "";
                            }
                        }
                        _self.initXml();
                    }catch (e) {
                        _self.$notify.error({
                            title: '错误',
                            message: '查询流程审批记录错误'
                        });
                    }

                };
                main();
            },
            formatDateBetween(start,end){
                var nTime = (start-end)/1000;
                var day = Math.floor(nTime/86400);
                var hour = Math.floor(nTime%86400/3600);
                var minute = Math.floor(nTime%86400%3600/60);
                var sec = Math.floor(nTime%86400%3600%60);
                let result = "";
                if(day>0){
                    result = result + day+"天";
                }
                if(hour>0){
                    result = result + hour+"小时";
                }
                if(minute>0){
                    result = result + minute+"分";
                }
                if(sec>0){
                    result = result + sec+"秒";
                }

                return result;
            }
        }
    };
</script>

<style lang="css">
    .content {
        width: 100%;
        height: calc(100% - 58px);
    }

    #processDefineContainer {
        height: 200px;
        width: 100%;
    }

    .completeProcHighlight:not(.djs-connection) .djs-visual > :nth-child(1) {
        fill: green !important; /* color elements as green */
        stroke: green !important; /* color elements as green */
    }

    .activeProcessHighlight:not(.djs-connection) .djs-visual > :nth-child(1) {
        fill: red !important; /* color elements as green */
        stroke: red !important; /* color elements as green */
    }

</style>
