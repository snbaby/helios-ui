<template>
    <div style="width: 100%;height: 100%;">
        <div :ref="lineRef" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            leakTrendData: {
                type: Object,
                default: function () {
                    return {
                        time: [],
                        count: []
                    }
                }
            },
            name: {
                type: String
            }
        },
        data() {
            return {
                chart: null,
            };
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        watch: {
            leakTrendData: {
                handler(newValue, oldValue) {
                    this.leakTrendCountEcharts();
                },
                deep: true
            }
        },
        methods: {
            leakTrendCountEcharts(){
                this.chart = echarts.init(this.$refs[this.lineRef]);
                this.chart.setOption({
                    grid: {
                        right: '40px'
                    },
                    title: {
                        text: this.name,
                        textStyle: {
                            color: '#9ad7f8',
                            fontWeight: 'bold',
                            fontSize: 14
                        },
                        padding: [30, 0, 0, 24]
                    },
                    tooltip: {
                        trigger: 'axis',
                        backgroundColor: 'rgba(0,78,162,0.8)',
                        borderWidth: '1',
                        borderColor: 'rgba(5,37,110,0.8)',
                        axisPointer: {
                            label: {
                                backgroundColor: 'rgba(131,158,68,0.4)'
                            }
                        },
                        textStyle: {
                            color: '#9ad7f8',
                            fontSize: '12'
                        },
                        formatter: function (params, ticket, callback) {
                            let date = params[0].name
                            let num = params[0].value
                            date = date.substring(3, 5) + '月' + date.substring(0, 2) + '号' + '</br><li>' + '漏洞数 :' + num
                            return date
                        }
                    },
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,

                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: '12',
                                marginTop: '4'
                            },
                            interval: 1,
                            rotate:70,
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#1e4673'
                            }
                        },
                        data: this.leakTrendData.time
                    },
                    yAxis: {
                        type: 'value',
                        minInterval: 1,
                        axisLabel: {
                            show: true,
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: '12',
                                marginTop: '4'
                            }
                        },
                        axisLine: {
                            show: true,
                            lineStyle: {
                                color: '#1e4673'
                            }
                        },
                        splitLine: {show: false},
                    },
                    series: [{
                        type: 'line',
                        itemStyle: {
                            normal: {
                                color: '#08e69a',
                                lineStyle: {
                                    color: '#08e69a',
                                    width: 2
                                }
                            }
                        },
                        name: '漏洞数',
                        data: this.leakTrendData.count,
                        markLine: {
                            silent: true,
                            data: [ {
                                name: '平均线',
                                type: 'average',
                            }],
                            label:{
                                show: false
                            },
                            symbol: 'none',
                            formatter: '',
                        }
                    }]
                });
                this.chart.resize();
            },
        },
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
