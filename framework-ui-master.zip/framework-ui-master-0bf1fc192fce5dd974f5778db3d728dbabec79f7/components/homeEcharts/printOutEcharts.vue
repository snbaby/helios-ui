<template>
    <div style="width: 100%;height: 100%;">
        <div id="printOutEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'printOutEcharts',
        props: ["printOutData"],
        data() {
            return {
                chart: null,
            };
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        watch: {
            printOutData: {
                handler(newValue, oldValue) {
                    this.processMonitorEcharts();
                },
                deep: true
            }
        },
        methods: {
            processMonitorEcharts(){
                this.chart = echarts.init(document.getElementById('printOutEcharts'));
                this.chart.setOption({
                    title: {
                        text: '部门打印输出统计',
                        textStyle: {
                            color: '#9ad7f8',
                            fontWeight: 'bold',
                            fontSize: 14
                        },
                        padding: [30, 0, 0, 24]
                    },
                    legend: {
                        bottom: 0,
                        align: 'auto',
                        textStyle: {
                            color: '#9ad7fb',
                            fontSize: 10
                        },
                        itemWidth: 8,
                        itemHeight: 8,
                        data: ['公开', '内部', '秘密', '机密']
                    },
                    label: {
                        normal: {
                            color: '#9ad7f8'
                        }
                    },
                    series: [{
                        type: 'pie',
                        radius: ['20%', '50%'],
                        center: ['50%','50%'],
                        roseType: 'radius',
                        label: {
                            normal: {
                                formatter: "{c}",
                                show: true
                            },
                        },
                        data: [{
                            value: this.printOutData[0],
                            name:'公开',
                            itemStyle: {
                                normal: {
                                    color: '#ea7efa'
                                }
                            }
                        },{
                            value: this.printOutData[1],
                            name:'内部',
                            itemStyle: {
                                normal: {
                                    color: '#d953fa'
                                }
                            }
                        },{
                            value:this.printOutData[2],
                            name:'秘密',
                            itemStyle: {
                                normal: {
                                    color: '#be22e5'
                                }
                            }
                        },{
                            value: this.printOutData[3],
                            name:'机密',
                            itemStyle: {
                                normal: {
                                    color: '#910bc9'
                                }
                            }
                        }
                        ]
                    }, {
                        type: 'pie',
                        radius: ['60%', '60.5%'],
                        center: ['50%','50%'],
                        hoverAnimation: false,
                        tooltip: {
                            normal: {
                                show: false
                            }
                        },
                        label: {
                            normal: {
                                show: false
                            }
                        },
                        itemStyle: {
                            normal: {
                                color: '#9ad7f8'
                            }
                        },
                        data: [{
                            value: 1
                        }]
                    }]
                });
                this.chart.resize();
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
