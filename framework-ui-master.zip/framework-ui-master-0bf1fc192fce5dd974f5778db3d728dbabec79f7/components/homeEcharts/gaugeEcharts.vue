<template>
    <div :style="{height:height,width:width}" :ref="lineRef">
    </div>
</template>
<script>
    import echarts from "echarts";
    export default {
        props: {
            lineRef: {
                type: String,
                required: true,
            },
            width: {
                type: String,
                default: '100%',
            },
            height: {
                type: String,
                default: '100%',
            },
            riskNum: {
                type: Number,
                default: 0
            }
        },
        data() {
            return {
                chart: null,
            };
        },
        mounted() {
            this.initChart();
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        methods: {
            initChart() {
                this.chart = echarts.init(this.$refs[this.lineRef]);
                const option = {
                    series: [{
                        name: "最外层环仪表盘",
                        z: 3,
                        type: "gauge",
                        min: 0,
                        max: 10,
                        startAngle: 220,
                        endAngle: -40,
                        splitNumber: 10,
                        axisLine: {
                            lineStyle: {
                                color: [
                                    [1, "#1c3971"]
                                ],
                                width: 10
                            }
                        },
                        axisTick: {
                            length: 0,
                            splitNumber: 1
                        },
                        axisLabel: {
                            distance: -25,
                            textStyle: {
                                color: "#9ad7f8"
                            }
                        },
                        splitLine: {
                            show: true,
                            length: 10,
                            lineStyle: {
                                color: "#09255c",
                                width: 2
                            }
                        },
                        detail: {
                            show: false
                        },
                        title: {
                            show: false
                        },
                        pointer: {
                            length: 0
                        },
                    },
                        {
                            name: "内环仪表盘五段颜色",
                            type: "gauge",
                            min: 0,
                            max: 10,
                            radius: "60%",
                            startAngle: 220,
                            endAngle: -40,
                            splitNumber: 10,
                            axisLine: {
                                lineStyle: {
                                    show: true,
                                    color: [
                                        [0.5, "#08e69a"],
                                        [0.7, "#ff800a"],
                                        [1, "#ff0000"]
                                    ],
                                    width: 15
                                }
                            },
                            axisTick: {
                                show: false
                            },
                            axisLabel: {
                                show: true,
                                distance: -10,
                                formatter: function(e) {
                                    switch (e + "") {
                                        case "0":
                                            return "";
                                        case "5":
                                            return "非常安全";
                                        case "7":
                                            return "比较危险";
                                        case "9":
                                            return "非常危险";
                                        default:
                                            return "";
                                    }
                                },
                                textStyle: {
                                    color: "#9ad7f8",
                                    fontWeight: 400,
                                    fontSize: 10
                                }
                            },
                            splitLine: {
                                show: false
                            },
                            pointer: {
                                length: "65%"
                            },
                            data: [{
                                name: "",
                                value: this.riskNum
                            }],
                            detail: {
                                show: false
                            }
                        }
                    ]
                };
                // 把配置和数据放这里
                this.chart.setOption(option);
            },
        },

    };
</script>
