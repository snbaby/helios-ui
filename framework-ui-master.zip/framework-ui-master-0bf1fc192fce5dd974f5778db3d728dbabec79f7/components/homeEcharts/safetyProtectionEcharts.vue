<template>
    <div style="width: 100%;height: 100%;">
        <div id="safetyProtectionEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'safetyProtectionEcharts',
        props: {
            safetyProtectionData: {
                type: Array,
                default: () =>[]
            }
        },
        data() {
            return {
                chart: null,
            };
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        watch: {
            safetyProtectionData: {
                handler(newValue, oldValue) {
                    this.safetyProtectionEcharts();
                },
                deep: true
            }
        },
        methods: {
            safetyProtectionEcharts(){
                const that = this;
                if(!document.getElementById('safetyProtectionEcharts')){
                    return;
                }
                this.chart = echarts.init(document.getElementById('safetyProtectionEcharts'));
                this.chart.setOption({
                    title: {
                        text: '安全保护',
                        textStyle: {
                            color: '#9ad7f8',
                            fontWeight: 'bold',
                            fontSize: 14
                        },
                        padding: [30, 0, 0, 24]
                    },
                    legend: {
                        show: true,
                        top: '25px',
                        left: '100px',
                        textStyle: {
                            color: '#9ad7fb',
                            fontSize: 11
                        },
                        itemWidth: 15,
                        itemHeight: 15,
                        data: ['已安装', '已备案', '未安装','未检查']
                    },
                    tooltip : {
                        trigger: 'axis',
                        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                        }
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis:  {
                        type: 'value',
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    yAxis: {
                        type: 'category',
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        data: ['网盾保护','防病毒','三合一','主机审计'],
                    },
                    series: [
                        {
                            name: '已安装',
                            type: 'bar',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#08e69b'
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            stack: '总量',
                            data: this.safetyProtectionData[0],
                        },{
                            name: '已备案',
                            type: 'bar',
                            stack: '总量',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#1f67fb'
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            data: this.safetyProtectionData[1],
                        },{
                            name: '未安装',
                            type: 'bar',
                            stack: '总量',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#ff0000'
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            data: this.safetyProtectionData[2],
                        },{
                            name: '未检查',
                            type: 'bar',
                            stack: '总量',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#afacac',
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            data: this.safetyProtectionData[3],
                        },
                    ]
                });
                this.chart.off('click');
                this.chart.on("click",function (param){
                    let searchData = '';
                    if(param.name == '主机审计'){
                        searchData = 'HostAudit';
                    }else if(param.name == '三合一'){
                        searchData = 'AllInOne';
                    }else if(param.name == '防病毒'){
                        searchData = 'AntiVirus';
                    }else if(param.name == '网盾保护'){
                        searchData = 'IdProtect';
                    }
                    that.changePage(searchData);
                });
                this.chart.resize();
            },
            changePage(val) {
                this.$router.push({
                    path: '/soc/terminal-security/confidentiality-inspection/target-analysis?searchCode='+val,
                })
            },
        },
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
