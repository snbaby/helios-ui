<template>
    <div style="width: 100%;height: 100%;">
        <div id="recordStatisticsEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'recordStatisticsEcharts',
        props: ["recordStatisticsData"],
        data() {
            return {
                chart: null,
            };
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        watch: {
            recordStatisticsData: {
                handler(newValue, oldValue) {
                    this.processMonitorEcharts();
                },
                deep: true
            }
        },
        methods: {
            processMonitorEcharts(){
                this.chart = echarts.init(document.getElementById('recordStatisticsEcharts'));
                this.chart.setOption({
                    title: {
                        text: '备案信息',
                        textStyle: {
                            color: '#9ad7f8',
                            fontWeight: 'bold',
                            fontSize: 14
                        },
                        padding: [30, 0, 0, 24]
                    },
                    tooltip: {},
                    grid: {
                        // top: '5%',
                        bottom: '5%',
                        left: 15,
                        right: 15,
                        containLabel: true
                    },
                    xAxis: [{
                        type: 'value',
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        splitLine: {
                            show: false
                        },
                        minInterval: 1,
                    }],
                    yAxis: [{
                        type: 'category',
                        axisLabel: {
                            textStyle: {
                                color: '#9ad7f8',
                                fontSize: 12
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#1e469b'
                            }
                        },
                        data: ['管理员权限','域管理','系统补丁','日志'],
                    }],
                    series: [{
                        type: 'bar',
                        data: this.recordStatisticsData,
                        barWidth: 15,
                        label: {
                            normal: {
                                show: true,
                                position: 'right',
                                color: '#83bff6'
                            }
                        },
                        itemStyle: {
                            normal: {
                                barBorderRadius: [0, 30, 30, 0],
                                color: new echarts.graphic.LinearGradient(
                                    1, 0, 0, 0, [{
                                        offset: 0,
                                        color: '#83bff6'
                                    },
                                        {
                                            offset: 1,
                                            color: '#188df0'
                                        }
                                    ]
                                )
                            }
                        }
                    }]
                });
                this.chart.resize();
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
