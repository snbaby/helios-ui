<template>
    <div style="width: 100%;height: 100%;">
        <div id="processMonitorEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'processMonitorEcharts',
        props: ["processMonitorData"],
        data() {
            return {
                normTotal:0,
                total:0,
                compliance:0,
                nocompliance:0,
                matched:0,
                nomatched:0,
                chart: null,
            };
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        mounted(){
            this.processMonitorEcharts();
        },
        watch: {
            processMonitorData: {
                handler(newValue, oldValue) {
                    this.processMonitorEcharts();
                },
                deep: true
            }
        },
        methods: {
            processMonitorEcharts(){
                let title = '园区网终端检查覆盖率:'+ Math.floor((this.processMonitorData.compliance/(this.processMonitorData.compliance+this.processMonitorData.nocompliance))*10000)/100 + '%';
                var option={
                    title: {
                        text: title,
                        textStyle: {
                            color: '#9ad7f8',
                            fontWeight: 'bold',
                            fontSize: 14
                        },
                        padding: [30, 0, 0, 24]
                    },
                    series: [
                        // {
                        //     type:'pie',
                        //     radius: [0, '30%'],
                        //     center : [ '50%', '55%' ],
                        //     label: {
                        //         normal: {
                        //             position: 'inner'
                        //         }
                        //     },
                        //     labelLine: {
                        //         normal: {
                        //             show: false
                        //         }
                        //     },
                        //     data:[
                        //         {
                        //             value:this.processMonitorData.compliance,
                        //             name:'已完成',
                        //             itemStyle: {
                        //                 normal: {
                        //                     "color": "#08e69a"
                        //                 }
                        //             }
                        //         },
                        //         {
                        //             value:this.processMonitorData.nocompliance,
                        //             name:'未完成',
                        //             itemStyle: {
                        //                 normal: {
                        //                     "color": "#afacac"
                        //                 }
                        //             }
                        //
                        //         }
                        //     ]
                        // },
                        {
                            type:'pie',
                            radius: ['0%', '50%'],
                            center : [ '50%', '55%' ],
                            label: {
                                normal: {
                                    formatter: '{b|{b}：}\n{per|{d}%}\n({c}台) ',
                                    rich: {
                                        hr: {
                                            borderColor: '#aaa',
                                            width: '100%',
                                            borderWidth: 0.5,
                                            height: 0
                                        },
                                        b: {
                                            align: 'center',
                                            fontSize: 10,
                                            lineHeight: 20
                                        },
                                        c: {
                                            align: 'center',
                                            fontSize: 10,
                                            lineHeight: 20
                                        },
                                        per: {
                                            padding: [2, 4],
                                            borderRadius: 2
                                        }
                                    }
                                }
                            },
                            data:[
                                {
                                    value:this.processMonitorData.matched,
                                    name:'合规',
                                    itemStyle: {
                                        normal: {
                                            "color": "#08e69a"
                                        }
                                    }
                                },
                                {
                                    value:this.processMonitorData.nomatched,
                                    name:'不合规',
                                    itemStyle: {
                                        normal: {
                                            "color": "#ff800a"
                                        }
                                    }
                                },
                                {
                                    value:this.processMonitorData.nocompliance,
                                    name:'未完成',
                                    itemStyle: {
                                        normal: {
                                            "color": "#afacac"
                                        }
                                    }

                                }
                            ]
                        }
                    ]
                };
                this.chart = echarts.init(document.getElementById('processMonitorEcharts'));
                this.chart.setOption(option);
                this.chart.resize();
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
