<template>
    <div class="backColor">
        <div class="contentBox" style="margin: auto;">
            <div class="pageContent">
                <template v-if="clickParameter.isTree">
                    <div style="width:100%;height:100%;">
                        <div class="left" v-if="menuList&&treeProps">
                            <tree :treedata="menuList" :defaultEpandedKeys="defaultEpandedKeys" @getValue="getTableDataByTree" :props="treeProps" :filterCode="clickParameter.treeLabel"></tree>
                        </div>
                        <div class="right">
                            <el-row class="searchForm" v-if="searchContentData.length!=0">
                                <el-col :span="21" style="padding-left:30px;">
                                    <el-row>
                                        <el-col :span="8" v-for="item,index in searchContentData" :key="index">
                                            <template v-if="item.dict">
                                                <el-checkbox v-model="searchContentData[index][item.checkCode]" class="searchCheckBox">{{item.name}}：</el-checkbox>
                                                <el-select v-model="searchContentData[index][item.code]" placeholder="" class="searchInput" @input="formChange(item.code)">
                                                    <el-option v-for="item1,index in getCategoryData(item.dict)" :key="index" :label="item1.label" :value="item1.code">
                                                    </el-option>
                                                </el-select>
                                            </template>
                                            <template v-else>
                                                <el-checkbox v-model="searchContentData[index][item.checkCode]" class="searchCheckBox">{{item.name}}：</el-checkbox>
                                                <el-input v-model="searchContentData[index][item.code]" placeholder="" class="searchInput" @input="formChange(item.code)"></el-input>
                                            </template>
                                        </el-col>
                                    </el-row>
                                </el-col>
                                <el-col :span="3">
                                    <el-row>
                                        <el-button class="search" style="float:right;" @click='doSearch'>查询</el-button>
                                    </el-row>
                                </el-col>
                            </el-row>
                            <el-row>
                                <div class="contentTable">
                                    <mu-table :showCheckbox="false">
                                        <mu-thead slot="header">
                                            <mu-tr>
                                                <mu-th tooltip="序号" width="50">序号</mu-th>
                                                <mu-th :tooltip="item.metaCode" v-for="item,index in tableHeadData" v-if="item.attr9 === '1'" :key="index">{{item.metaName}}</mu-th>
                                                <mu-th tooltip="操作" width="100" style="text-align:center !important;" v-if="isButton">操作</mu-th>
                                            </mu-tr>
                                        </mu-thead>
                                        <mu-tbody v-if="menuPersonData">
                                            <mu-tr v-for="item,index in menuPersonData.rows" :key="index">
                                                <mu-td width="50">{{pageNo*menuPersonData.pageSize+index+1}}</mu-td>
                                                <template v-for="col in tableShowSort">
                                                    <mu-td :title="item[col.code]" v-if="col.dict">{{getCategoryData(col.dict,item[col.code]?item[col.code]:'')}}</mu-td>
                                                    <mu-td :title="item[col.code]" v-else>{{item[col.code]}}</mu-td>
                                                </template>
                                                <mu-td width="100" style="text-align:center !important;" v-if="isButton">
                                                    <el-dropdown @command="handleClick($event,item)" trigger="click">
                                                        <span class="el-dropdown-link">
                                                            操作<i class="el-icon-arrow-down el-icon--right"></i>
                                                        </span>
                                                        <el-dropdown-menu slot="dropdown">
                                                            <el-dropdown-item v-for="(message, index) in buttonDetail" :key="index" :command=message>{{message.buttonName}}</el-dropdown-item>
                                                        </el-dropdown-menu>
                                                    </el-dropdown>
                                                </mu-td>
                                            </mu-tr>
                                        </mu-tbody>
                                    </mu-table>
                                </div>
                            </el-row>
                            <div style="position: relative;bottom: -30px;text-align: center;" v-if="menuPersonData.total">
                                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
                            </div>
                            <div class="norows" v-else style="text-align: center;margin-top:50px;">
                                <font>暂无数据</font>
                            </div>
                        </div>
                    </div>
                </template>
                <template v-else>
                    <div style="width:100%;height:100%;">
                        <el-row>
                            <el-row class="searchForm" v-if="searchContentData.length!=0">
                                <el-col :span="21" style="padding-left:30px;">
                                    <el-row>
                                        <el-col :span="8" v-for="item,index in searchContentData" :key="index">
                                            <template v-if="item.dict">
                                                <el-checkbox v-model="searchContentData[index][item.checkCode]" class="searchCheckBox">{{item.name}}：</el-checkbox>
                                                <el-select v-model="searchContentData[index][item.code]" placeholder="" class="searchInput" @input="formChange(item.code)">
                                                    <el-option v-for="item1,index in getCategoryData(item.dict)" :key="index" :label="item1.label" :value="item1.code">
                                                    </el-option>
                                                </el-select>
                                            </template>
                                            <template v-else>
                                                <el-checkbox v-model="searchContentData[index][item.checkCode]" class="searchCheckBox">{{item.name}}：</el-checkbox>
                                                <el-input v-model="searchContentData[index][item.code]" placeholder="" class="searchInput" @input="formChange(item.code)"></el-input>
                                            </template>
                                        </el-col>
                                    </el-row>
                                </el-col>
                                <el-col :span="3">
                                    <el-row>
                                        <el-button class="search" style="float:right;" @click='doSearch'>查询</el-button>
                                    </el-row>
                                </el-col>
                            </el-row>
                            <el-row>
                                <div class="contentTable">
                                    <mu-table :showCheckbox="false">
                                        <mu-thead slot="header">
                                            <mu-tr>
                                                <mu-th tooltip="序号" width="50" v-if="tableHeadData.length>0">序号</mu-th>
                                                <mu-th :tooltip="item.metaCode" v-for="item,index in tableHeadData"  v-if="item.attr9 === '1'" :key="index">{{item.metaName}}</mu-th>
                                                <mu-th tooltip="操作" width="100" style="text-align:center !important;" v-if="isButton">操作</mu-th>
                                            </mu-tr>
                                        </mu-thead>
                                        <mu-tbody v-if="menuPersonData">
                                            <mu-tr v-for="item,index in menuPersonData.rows" :key="index">
                                                <mu-td width="50" :title="pageNo*menuPersonData.pageSize+index+1">{{pageNo*menuPersonData.pageSize+index+1}}</mu-td>
                                                <template v-for="col in tableShowSort">
                                                    <mu-td :title="item[col.code]" v-if="col.dict">{{getCategoryData(col.dict,item[col.code]?item[col.code]:'')}}</mu-td>
                                                    <mu-td :title="item[col.code]" v-else>{{item[col.code]}}</mu-td>
                                                </template>
                                                <mu-td width="100" style="text-align:center !important;" v-if="isButton">
                                                    <el-dropdown @command="handleClick($event,item)" trigger="click">
                                                        <span class="el-dropdown-link">
                                                            操作<i class="el-icon-arrow-down el-icon--right"></i>
                                                        </span>
                                                        <el-dropdown-menu slot="dropdown">
                                                            <el-dropdown-item v-for="message in buttonDetail" :key="message.buttonName" :command=message>{{message.buttonName}}</el-dropdown-item>
                                                        </el-dropdown-menu>
                                                    </el-dropdown>
                                                </mu-td>
                                            </mu-tr>
                                        </mu-tbody>
                                    </mu-table>
                                </div>
                            </el-row>
                            <div style="position: relative;bottom: -30px;text-align: center;" v-if="menuPersonData.total">
                                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
                            </div>
                            <div class="norows" v-else style="text-align: center;margin-top:50px;">
                                <font>暂无数据</font>
                            </div>
                        </el-row>
                    </div>
                </template>
            </div>
        </div>
    </div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import axios from "axios";
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import {getHead,getTableHead,getTableData,getTreeData,getOneForButton,getButtonDetail} from '@/api/parameterManage/index.js';
    import {
        fetch,
        json2Param
    } from "@/core/fetch.js";

    export default {
        components: {
            tree,
            pagination
        },
        props:["clickParameter"],
        data() {
            return {
                pageNo: 0,
                parameterType:localStorage.getItem("socParameterManage")?JSON.parse(localStorage.getItem("socParameterManage")).id:"",
                tableHeadData:[],
                parameterHeadData:{

                },
                org_code:'',
                searchContentData:[],
                menuList:[],
                menuPersonData:{

                },
                treeProps:"",
                selectTreeObject:{

                },
                isButton:false,
                buttonDetail: []
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo+1,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
            defaultEpandedKeys:function(){
                var arr = [];
                if(this.selectTreeObject.hasOwnProperty(this.treeProps.id)){
                    arr.push(this.selectTreeObject[this.treeProps.id]);
                }
                return arr;
            },
            showParameterType: function () {
                return this.parameterType.split("|||")[0];
            },
            tableShowSort:function () {
                var arr = [];
                for(var i=0;i<this.tableHeadData.length;i++){
                    if(this.tableHeadData[i].attr9=='1'){
                        var map = {};
                        map.code = this.tableHeadData[i].metaCode;
                        if(this.tableHeadData[i].metaSource != ""){
                            map.dict = this.tableHeadData[i].metaSource;
                        }
                        arr.push(map);
                    }
                }
                return arr;
            }
        },
        methods: {
            init(){
                getHead().then((data)=>{
                    this.parameterHeadData = data;
                    if(this.parameterType == ""){
                        return false;
                    }
                    var clickitem = this.parameterType.split('|||')[0];
                    for(var i=0;i<this.parameterHeadData.data.length;i++){
                        if(this.parameterHeadData.data[i].hasOwnProperty("children")){
                            if(this.parameterHeadData.data[i].id == clickitem){
                                this.parameterHeadData.data[i].isSelected = true;
                            }else{
                                this.parameterHeadData.data[i].isSelected = false;
                            }
                        }else{
                            if(this.parameterHeadData.data[i].id == this.parameterType){
                                this.parameterHeadData.data[i].isSelected = true;
                            }else{
                                this.parameterHeadData.data[i].isSelected = false;
                            }
                        }
                    }

                    this.treeProps = {
                        children: 'children',
                        label:this.clickParameter.treeLabel,
                        id:this.clickParameter.treeId
                    }

                    getTableHead(this.clickParameter.isTree?this.clickParameter.tableType:this.clickParameter.type).then((data)=>{
                        this.tableHeadData = data.data;

                        var arr = [];
                        for(var i=0;i<this.tableHeadData.length;i++){
                            if(this.tableHeadData[i].attr8 == 1){
                                var map = {};
                                map[this.tableHeadData[i].metaCode] = "";
                                map[this.tableHeadData[i].metaCode+"Checked"] = false;
                                map["name"] = this.tableHeadData[i].metaName;
                                map["code"] = this.tableHeadData[i].metaCode;
                                map["checkCode"] = this.tableHeadData[i].metaCode+"Checked";
                                if(this.tableHeadData[i].metaSource!=""){
                                    map["dict"] = this.tableHeadData[i].metaSource;
                                }

                                arr.push(map);
                            }
                        }

                        this.searchContentData = arr;
                    });


                    var query = {
                        page:this.pageNo,
                        size:10
                    };
                    for(var i=0;i<this.searchContentData.length;i++){
                        if(this.searchContentData[i][this.searchContentData[i].checkCode]){
                            query[this.searchContentData[i].code] = this.searchContentData[i][this.searchContentData[i].code]
                        }
                    }
                    if(this.org_code){
                        query["org_code"] = this.org_code;
                    }
                    if(this.clickParameter.isTree){
                        getTreeData(this.clickParameter.index,this.clickParameter.treeType).then((tree)=>{
                            this.menuList = tree;
                            getTableData(this.clickParameter.index,this.clickParameter.tableType,query).then((data)=>{
                                if(data.status == 200){
                                    this.menuPersonData = data.data;
                                }else{
                                    var obj = {
                                        pageNo:0,
                                        pageSize:10,
                                        total:0,
                                        rows:[]
                                    }
                                    this.menuPersonData = obj;
                                }

                            });
                        });

                    }else{
                        getTableData(this.clickParameter.index,this.clickParameter.type,query).then((data)=>{
                            if(data.status == 200){
                                this.menuPersonData = data.data;
                            }else{
                                var obj = {
                                    pageNo:0,
                                    pageSize:10,
                                    total:0,
                                    rows:[]
                                }
                                this.menuPersonData = obj;
                            }
                        });
                    }

                    var queryButton = {
                        page:1,
                        limit:-1,
                        kindCode:this.clickParameter.index,
                        categoryCode:this.clickParameter.type
                    }
                    getOneForButton(queryButton).then((buttonDetail)=>{
                        if(buttonDetail.data.rows[0].button == 1){
                            this.isButton = true;
                            getButtonDetail(buttonDetail.data.rows[0].id).then((item)=>{
                                var arr = [];
                                for(var that in item.data.rows){
                                    if(item.data.rows[that].validity == 1){
                                        arr.push(item.data.rows[that]);
                                    }
                                }
                                if(arr.length == 0){
                                    this.isButton = false;
                                }
                                this.buttonDetail = arr;

                            });
                        }
                    });

                });
            },
            search(item,clickobj){
                this.pageNo = 0;
                this.menuPersonData = {};
                this.tableHeadData = [];
                this.buttonDetail = [];
                this.isButton = false;

                if(clickobj.hasOwnProperty('children')){
                    return false;
                }
                this.clickParameter = clickobj;
                this.treeProps = {
                    children: 'children',
                    label:this.clickParameter.treeLabel,
                    id:this.clickParameter.treeId
                }
                localStorage.setItem("socParameterManage", JSON.stringify(clickobj));
                this.parameterType = clickobj.id;


                this.init();
            },
            formChange(val) {
                for(var i=0;i<this.searchContentData.length;i++){
                    if(this.searchContentData[i].code == val){
                        this.searchContentData[i][this.searchContentData[i].checkCode] = true;
                        break;
                    }
                }
            },
            getTableDataByTree(val){
                this.selectTreeObject = val;

                var	query = {
                    page: 0,
                    size: 10,
                }
                query[this.treeProps.id] = val[this.treeProps.id];
                if(this.org_code){
                    query["org_code"] = this.org_code;
                }
                getTableData(this.clickParameter.index,this.clickParameter.tableType,query).then((data)=>{
                    this.menuPersonData = data.data;
                });
            },
            pageChange(val) {
                this.pageNo = val-1;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = {
                    page:this.pageNo,
                    size:10
                };
                for(var i=0;i<this.searchContentData.length;i++){
                    if(this.searchContentData[i][this.searchContentData[i].checkCode]){
                        query[this.searchContentData[i].code] = this.searchContentData[i][this.searchContentData[i].code]
                    }
                }
                if(this.org_code){
                    query["org_code"] = this.org_code;
                }
                if(this.clickParameter.isTree){
                    getTableData(this.clickParameter.index,this.clickParameter.tableType,query).then((data)=>{
                        this.menuPersonData = data.data;
                    });
                }else{
                    getTableData(this.clickParameter.index,this.clickParameter.type,query).then((data)=>{
                        this.menuPersonData = data.data;
                    });
                }
            },
            doSearch(){
                var query = {
                    page:0,
                    size:10
                };
                for(var i=0;i<this.searchContentData.length;i++){
                    if(this.searchContentData[i][this.searchContentData[i].checkCode]){
                        query[this.searchContentData[i].code] = this.searchContentData[i][this.searchContentData[i].code]
                    }
                }
                if(this.org_code){
                    query["org_code"] = this.org_code;
                }
                if(this.clickParameter.isTree){
                    getTableData(this.clickParameter.index,this.clickParameter.tableType,query).then((data)=>{
                        this.menuPersonData = data.data;
                    });
                }else{
                    getTableData(this.clickParameter.index,this.clickParameter.type,query).then((data)=>{
                        this.menuPersonData = data.data;
                    });
                }
            },
            handleClick(command,item) {
                var query = {};
                if(command.hasOwnProperty("routerParam")&&command.routerParam!=undefined&&command.routerParam!=''){
                    var param = command.routerParam.split(',');
                    for(var i in param){
                        query[param[i]] = item[param[i]]
                    }
                }
                this.$router.push({
                    path:command.buttonRouter,
                    query:query
                });
            }
        },
        created() {
            this.init();
        },
        activated() {
            this.init();
        }
    }

</script>


<style lang="css" scoped>
    .backColor {
        background-color: #f0f0f0;
        width: 100%;
        height: 100%;
    }

    .contentBox {
        width: 100%;
        height: 100%;
        z-index: 1;
        background-color: #ffffff;
    }

    .pageContent {
        height: 100%;
    }

    .margin {
        height: 35px;
        width: 100%;
        background-color: #f0f0f0;
    }

    .header {
        width: 100%;
        padding-bottom: 15px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .headerContent {
        overflow: hidden;
        margin-left: 120px;
    }

    .headerContent span {
        float: left;
        font-size: 14px;
        line-height: 14px;
        padding: 15px;
        cursor: pointer;
    }

    .header .hoverContent {
        height: auto;
        background-color: #ffffff;
        box-shadow: rgba(0, 0, 0, 0.14) 0px 0px 12px 2px;
        position: absolute;
        top: 46px;
        width: 960px;
        left: 120px;
        z-index: 100;
        visibility:hidden;
        padding: 15px 20px;
    }

    .headactive {
        color: #004ea2;
        font-weight: 900;
    }

    .hoverContent font {
        font-size: 14px;
    }

    .hoverContent font:hover {
        color: #004ea2;
    }

    .hoverContent .tags {
        width: 8px;
        height: 8px;
        background-color: #004ea2;
        margin-bottom: 10px;
        margin-left: 2px;
    }

    .headerContentSelect {
        padding-bottom: 13px !important;
        border-bottom: 2px solid #004ea2;
    }

    .headerContent span:hover {
        padding-bottom: 13px;
        border-bottom: 2px solid #004ea2;
    }

    .headerContent span:hover .hoverContent {
        visibility:visible;
    }

    .headerContent span .hoverContent{
        -webkit-transition:all 0.2s ease;
        -moz-transition:all 0.2s ease;
        -o-transition:all 0.2s ease;
        -ms-transition:all 0.2s ease;
        transition:all 0.2s ease;
    }

    .hoverContent {
        display: block;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px !important;
        height: 30px;
    }

    .tableOperation {
        text-align: center !important;
        padding-right: 40px !important;
        width: 140px;
    }

    .tableView {
        text-align: center !important;
        padding-right: 40px !important;
        width: 140px;
        color: #004ea2;
        cursor: pointer;
    }

    .tdFirst {
        text-align: center !important;
    }

    a {
        color: #333333
    }

    span{
        line-height: 0;
    }

    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

    .searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

    .searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

    .contentTable {
        padding-left: 40px;
        padding-right: 40px;
    }

    .tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

    .demo-ruleForm {
        padding-right: 35px;
    }

    .el-dropdown-link {
        cursor: pointer;
        color: #409EFF;
    }
    .el-icon-arrow-down {
        font-size: 12px;
    }
</style>
