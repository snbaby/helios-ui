<template>
    <div style="width: 100%;height: 100%;">
        <div id="checkMonitorEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";
    import async1 from "async";
    export default {
        name: 'checkMonitorEcharts',
        props: ["recordMonitorData"],
        data() {
            return {
                normTotal:0,
                total:0,
                hasCompleted:0,
                noCompleted:0
            };
        },
        mounted(){
            this.checkMonitorEcharts();
        },
        methods: {
            checkMonitorEcharts(){
                var echartData = [{
                    value:this.recordMonitorData.matched,
                    itemStyle: {
                        normal: {
                            "color": "#004ea2"
                        }
                    }
                },{
                    value:this.recordMonitorData.nomatched,
                    itemStyle: {
                        normal: {
                            "color": "#afacac"
                        }
                    }
                }];
                var option = {
                    title: {
                        "text":Math.round(this.recordMonitorData.matched / this.recordMonitorData.normTotal * 100) + '%',
                        "x": '50%',
                        "y": '40%',
                        textAlign: "center",
                        "textStyle": {
                            "fontWeight": 'normal',
                            "fontSize": 20
                        }
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: "{d}%"
                    },
                    legend: {
                        orient: 'vertical',
                        x: 'left',
                        data:[]
                    },
                    series: [
                        {
                            name:'已完成',
                            type:'pie',
                            radius: ['50%', '60%'],
                            avoidLabelOverlap: false,
                            label: {
                                normal: {
                                    show: false,
                                    position: 'center'
                                },
                                emphasis: {
                                    show: true,
                                    textStyle: {
                                        fontSize: '30',
                                        fontWeight: 'bold'
                                    }
                                }
                            },
                            labelLine: {
                                normal: {
                                    show: false
                                }
                            },
                            data:echartData
                        }
                    ]
                };
                var myChart = echarts.init(document.getElementById('checkMonitorEcharts'));
                myChart.setOption(option);
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
