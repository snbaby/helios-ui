<template>
    <div style="width: 100%;height: 100%;">
        <div id="recordIndicatorsEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'recordIndicatorsEcharts',
        props: ["recordIndicatorsData"],
        data() {
            return {

            };
        },
        mounted(){
            this.recordIndicatorsEcharts();
        },
        methods: {
            recordIndicatorsEcharts(){
                var echartData = [{
                    value:this.recordIndicatorsData.hasCompleted,
                    name:'已完成',
                    itemStyle: {
                        normal: {
                            "color": "#08e69a"
                        }
                    }
                },{
                    value:this.recordIndicatorsData.noCompleted,
                    name:'未完成',
                    itemStyle: {
                        normal: {
                            "color": "#afacac"
                        }
                    }

                }];
                var option ={
                    title: {
                        "text": '备案统计',
                        "x": '50%',
                        "y": '60%',
                        textAlign: "center",
                        "textStyle": {
                            "fontWeight": 'normal',
                            "fontSize": 14
                        }
                    },
                    legend: {
                        selectedMode:false,
                        formatter: '{total|' + this.recordIndicatorsData.total + '}',
                        data: [echartData[0].name],
                        left: 'center',
                        top: 'center',
                        icon: 'none',
                        align:'center',
                        textStyle: {
                            color: "#afacac",
                            fontSize: 20,
                            rich: {
                                total: {
                                    color: "#004ea2",
                                    fontSize: 20,
                                    align: 'center'
                                }
                            }
                        },
                    },
                    series: [{
                        type:'pie',
                        radius: ['60%', '75%'],
                        center : [ '50%', '55%' ],
                        label: {
                            normal: {
                                formatter: '{b|{b}：}\n{per|{d}%}\n({c}项) ',
                                rich: {
                                    hr: {
                                        borderColor: '#aaa',
                                        width: '100%',
                                        borderWidth: 0.5,
                                        height: 0
                                    },
                                    b: {
                                        align: 'center',
                                        fontSize: 10,
                                        lineHeight: 20
                                    },
                                    c: {
                                        align: 'center',
                                        fontSize: 10,
                                        lineHeight: 20
                                    },
                                    per: {
                                        padding: [2, 4],
                                        borderRadius: 2
                                    }
                                }
                            }
                        },
                        data:echartData
                    }]
                };
                var myChart = echarts.init(document.getElementById('recordIndicatorsEcharts'));
                myChart.setOption(option);
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
