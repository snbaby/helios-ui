<template>
    <div style="width: 100%;height: 100%;">
        <div id="doneIndicatorsEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'doneIndicatorsEcharts',
        props: ["doneIndicatorsData"],
        data() {
            return {
                normTotal:0,
                total:0,
                compliance:0,
                nocompliance:0,
                matched:0,
                nomatched:0,
            };
        },
        mounted(){
            this.doneIndicatorsEcharts();
        },
        watch: {
            doneIndicatorsData: {
                handler(newValue, oldValue) {
                    this.doneIndicatorsEcharts();
                },
                deep: true
            }
        },
        methods: {
            doneIndicatorsEcharts(){
                var option={
                    series: [
                        {
                            type:'pie',
                            radius: [0, '46%'],
                            center : [ '50%', '55%' ],
                            label: {
                                normal: {
                                    position: 'inner'
                                }
                            },
                            labelLine: {
                                normal: {
                                    show: false
                                }
                            },
                            data:[
                                {
                                    value:this.doneIndicatorsData.compliance,
                                    name:'已完成',
                                    itemStyle: {
                                        normal: {
                                            "color": "#08e69a"
                                        }
                                    }
                                },
                                {
                                    value:this.doneIndicatorsData.nocompliance,
                                    name:'未完成',
                                    itemStyle: {
                                        normal: {
                                            "color": "#afacac"
                                        }
                                    }

                                }
                            ]
                        },
                        {
                            type:'pie',
                            radius: ['60%', '75%'],
                            center : [ '50%', '55%' ],
                            label: {
                                normal: {
                                    formatter: '{b|{b}：}\n{per|{d}%}\n({c}项) ',
                                    rich: {
                                        hr: {
                                            borderColor: '#aaa',
                                            width: '100%',
                                            borderWidth: 0.5,
                                            height: 0
                                        },
                                        b: {
                                            align: 'center',
                                            fontSize: 10,
                                            lineHeight: 20
                                        },
                                        c: {
                                            align: 'center',
                                            fontSize: 10,
                                            lineHeight: 20
                                        },
                                        per: {
                                            padding: [2, 4],
                                            borderRadius: 2
                                        }
                                    }
                                }
                            },
                            data:[
                                {
                                    value:this.doneIndicatorsData.matched,
                                    name:'合规',
                                    itemStyle: {
                                        normal: {
                                            "color": "#00a1ff"
                                        }
                                    }
                                },
                                {
                                    value:this.doneIndicatorsData.nomatched,
                                    name:'不合规',
                                    itemStyle: {
                                        normal: {
                                            "color": "#ff800a"
                                        }
                                    }
                                },
                                {
                                    value:this.doneIndicatorsData.nocompliance,
                                    name:'未完成',
                                    itemStyle: {
                                        normal: {
                                            "color": "#afacac"
                                        }
                                    }

                                }
                            ]
                        }
                    ]
                };
                var myChart = echarts.init(document.getElementById('doneIndicatorsEcharts'));
                myChart.setOption(option);
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
