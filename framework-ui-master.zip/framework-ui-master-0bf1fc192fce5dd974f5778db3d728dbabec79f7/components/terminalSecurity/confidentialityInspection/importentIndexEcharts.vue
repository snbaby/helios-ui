<template>
    <div style="width: 100%;height: 100%;">
        <div id="importentIndexEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'importentIndexEcharts',
        props: ['importentIndexData'],
        data() {
            return {

            };
        },
        mounted(){
            this.importentIndexEcharts();
        },
        methods: {
            importentIndexEcharts(){
                var datax = this.importentIndexData.datax;
                var datay = this.importentIndexData.datay;
                var option = {
                    color: ['#3398DB'],
                    tooltip : {
                        trigger: 'axis',
                        axisPointer : {
                            type : 'shadow'
                        },
                        formatter: "{b} <br> 合规占比: {c}%"
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis : [
                        {
                            type : 'category',
                            data : datax,
                            axisTick: {
                                alignWithLabel: true
                            }
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value',
                            axisLabel: {
                                formatter: '{value}%'
                            }
                        }
                    ],
                    series : [
                        {
                            name:'合规占比',
                            type:'bar',
                            label: {
                                normal: {
                                    show: true,
                                    position: 'top'
                                }
                            },
                            formatter: '{value}%',
                            barWidth: '60%',
                            data:datay
                        }
                    ]
                };
                var myChart = echarts.init(document.getElementById('importentIndexEcharts'));
                myChart.setOption(option);
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
