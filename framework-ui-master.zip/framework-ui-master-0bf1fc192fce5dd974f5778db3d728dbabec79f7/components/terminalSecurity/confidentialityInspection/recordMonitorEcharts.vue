<template>
    <div style="width: 100%;height: 100%;">
        <div id="recordMonitorEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";
    import async1 from "async";
    export default {
        name: 'recordMonitorEcharts',
        props: ["recordMonitorData"],
        data() {
            return {
                normTotal:0,
                total:0,
                hasCompleted:0,
                noCompleted:0
            };
        },
        mounted(){
            console.log(this.recordMonitorData);
            this.recordMonitorEcharts();
        },
        methods: {
            recordMonitorEcharts(){
                var echartData = [{
                    value:this.recordMonitorData.hasCompleted,
                    name:'已完成',
                    itemStyle: {
                        normal: {
                            "color": "#08e69a"
                        }
                    }
                },{
                    value:this.recordMonitorData.noCompleted,
                    name:'未完成',
                    itemStyle: {
                        normal: {
                            "color": "#afacac"
                        }
                    }

                }];
                let unit = '{b|{b}：}\n{per|{d}%}\n({c}'+(this.recordMonitorData.unit || '台')+')';
                var option ={
                    title: {
                        "text":this.recordMonitorData.text || '人工处理',
                        "x": '50%',
                        "y": '60%',
                        textAlign: "center",
                        "textStyle": {
                            "fontWeight": 'normal',
                            "fontSize": 14
                        }
                    },
                    legend: {
                        selectedMode:false,
                        formatter: '{total|' + this.recordMonitorData.total + '}',
                        data: [echartData[0].name],
                        left: 'center',
                        top: 'center',
                        icon: 'none',
                        align:'center',
                        textStyle: {
                            color: "#afacac",
                            fontSize: 20,
                            rich: {
                                total: {
                                    color: "#004ea2",
                                    fontSize: 20,
                                    align: 'center'
                                }
                            }
                        },
                    },
                    series: [{
                        type:'pie',
                        radius: ['60%', '75%'],
                        center : [ '50%', '55%' ],
                        label: {
                            normal: {
                                formatter: unit,
                                rich: {
                                    hr: {
                                        borderColor: '#aaa',
                                        width: '100%',
                                        borderWidth: 0.5,
                                        height: 0
                                    },
                                    b: {
                                        align: 'center',
                                        fontSize: 10,
                                        lineHeight: 20
                                    },
                                    c: {
                                        align: 'center',
                                        fontSize: 10,
                                        lineHeight: 20
                                    },
                                    per: {
                                        padding: [2, 4],
                                        borderRadius: 2
                                    }
                                }
                            }
                        },
                        data:echartData
                    }]
                };
                var myChart = echarts.init(document.getElementById('recordMonitorEcharts'));
                myChart.setOption(option);
            }
        }
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
