<template>
    <div style="width: 100%;height: 100%;">
        <div id="safetyCheckEcharts" style="width: 100%; height: 100%;"></div>
    </div>
</template>

<script>
    import echarts from "echarts";

    export default {
        name: 'safetyCheckEcharts',
        props: ["safetyCheckData"],
        data() {
            return {
                chart: null,
            };
        },
        beforeDestroy() {
            if (!this.chart) {
                return;
            }
            this.chart.dispose();
            this.chart = null;
        },
        mounted(){
            this.safetyCheckEcharts();
        },
        methods: {
            safetyCheckEcharts(){
                const that = this;
                console.log(that.safetyCheckData);
                if(!document.getElementById('safetyCheckEcharts')){
                    return;
                }
                this.chart = echarts.init(document.getElementById('safetyCheckEcharts'));
                this.chart.setOption({
                    legend: {
                        show: true,
                        top: '30px',
                        right: '50px',
                        textStyle: {
                            color: '#9ad7fb',
                            fontSize: 11
                        },
                        itemWidth: 15,
                        itemHeight: 15,
                        data: ['合规', '不合规','未完成','未检查']
                    },
                    tooltip : {
                        trigger: 'axis',
                        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                        }
                    },
                    grid: {
                        left: '0%',
                        right: '30%',
                        bottom: '40%',
                        containLabel: true
                    },
                    xAxis:  {
                        show: false,
                    },
                    yAxis: {
                        type: 'category',
                        axisLabel: {
                            textStyle: {
                                color: '#04110d',
                                fontSize: 16
                            }
                        },
                        axisTick:{
                          show : false
                        },
                        axisLine: {
                            show: false
                        },
                        data: ['进度监控 ('+this.safetyCheckData.matched+'/'+this.safetyCheckData.total+')'],
                    },
                    series: [
                        {
                            name: '合规',
                            code: 'matched',
                            type: 'bar',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#08e69b'
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            stack: '总量',
                            data: this.safetyCheckData.data[0],
                        },{
                            name: '不合规',
                            code: 'nomatched',
                            type: 'bar',
                            stack: '总量',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#fe0000'
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            data: this.safetyCheckData.data[1],
                        },{
                            name: '未完成',
                            code: 'nocomplete',
                            type: 'bar',
                            stack: '总量',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#ff800a'
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            data: this.safetyCheckData.data[2],
                        },{
                            name: '未检查',
                            code: 'nocompliance',
                            type: 'bar',
                            stack: '总量',
                            barWidth: 15,
                            itemStyle: {
                                normal:{
                                    color: '#8c939d'
                                }
                            },
                            label: {
                                normal: {
                                    show: true,
                                    position: 'insideLeft'
                                }
                            },
                            data: this.safetyCheckData.data[3],
                        }
                    ]
                });
                this.chart.off('click');
                this.chart.on("click",function (param){
                    if(param.seriesName == "合规"){
                        that.clickEvent("1");
                    }else if(param.seriesName == "不合规"){
                        that.clickEvent("2");
                    }else if(param.seriesName == "未完成"){
                        that.clickEvent("3");
                    }else if(param.seriesName == "未检查"){
                        that.clickEvent("0");
                    }
                });
                this.chart.resize();
            },
            clickEvent(status){
                this.$emit('clickEvent',status);
            }
        },
    }
</script>
<style lang="css" scoped>
    .titlefont {
        font-size:14px;
        font-weight:600;
    }
</style>
