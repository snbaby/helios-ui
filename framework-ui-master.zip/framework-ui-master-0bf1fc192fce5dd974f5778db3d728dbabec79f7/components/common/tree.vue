<template>
    <div class="framework-tree" >
        <div class="framework-tree-search">
            <input placeholder="请输入关键字进行过滤" v-model="filterText" />
        </div>
        <el-tree :data="treedata" :props="props?props:defaultProps" accordion @node-click="handleNodeClick"
                 node-key="id" :filter-node-method="filterNode"
                 ref="tree2" class="framework-tree-style" :default-expanded-keys="defaultEpandedKeys" :expand-on-click-node="false"
                 :default-expand-all="true" :highlight-current="true">
        </el-tree>
    </div>
</template>
<script>
    export default {
        components: {},
        props: {
            treedata: {
                required: true
            },
            props: {},
            defaultEpandedKeys: {
                type: Array,
                default: function () {
                    return [];
                }
            },
            filterCode: {
                default: "label"
            }
        },
        data() {
            return {
                filterText: "",

                defaultProps: {
                    children: 'children',
                    label: 'label'
                },
            }
        },
        methods: {
            filterNode(value, data) {
                if (!value) return true;
                return data[this.filterCode].indexOf(value) !== -1;
            },
            handleNodeClick(data) {
                this.$emit('getValue', data);
                setTimeout(() => {
                    $('.el-tree-node__label').each(function () {
                        var title = $(this).text();
                        $(this).attr("title", title);
                    });
                }, 1000);
            }
        },
        watch: {
            filterText(val) {
                this.$refs.tree2.filter(val);
            },
        }
    }

</script>
<style lang="css" scoped>
    .framework-tree {
        width: 100%;
        height: 100%;
    }

    .framework-tree-style {
        overflow: auto;
        max-height: calc(100% - 50px) !important;
        background-color: #eeeeee;
    }

    .framework-tree-search {
        padding: 10px 0;
        background-color: #cecece;
        text-align: center;
    }

    .framework-tree-search input{
        width: 180px;
        height: 30px;
        border: 1px solid #f0f0f0;
        outline: 0;
        padding: 7px 8px 7px 12px;
        border-radius: 16px;
    }

</style>
