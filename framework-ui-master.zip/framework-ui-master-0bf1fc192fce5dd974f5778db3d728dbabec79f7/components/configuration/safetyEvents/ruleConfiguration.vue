<template>
    <div :class="isFull?'fullUruleStyle':'uruleStyle'">
		<div class="fullButton">
			<el-button class="add" style="float:right;margin-left:10px;" @click="changeFull" >{{isFull?'缩小':'全屏'}}</el-button>
		</div>
        <iframe id="show-iframe"  frameborder=0 name="showHere" scrolling=auto src="http://192.168.2.4:8809/urule/frame"></iframe>
    </div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import axios from "axios";

    export default {
        components: {
        },
        data() {
            return {
				isFull:false
            }
        },
        computed: {
        },
        mounted(){

        },
        methods: {
			changeFull(){
				this.isFull = !this.isFull;
			}
        },
        created() {
        },
        activated() {
        }
    }

</script>


<style lang="css" scoped>
	#show-iframe {
		width: 100%;
		height: 100%;
	}

	.fullUruleStyle {
		position: fixed;
		width: 100%;
		height: 100%;
		top:0;
		left:0;
		z-index: 9999999;
	}

	.uruleStyle {
		height:calc(100% - 138px) !important;
        height: 100%;
	}

	.fullButton {
		position: absolute;
		right: 40px;
	}
</style>
