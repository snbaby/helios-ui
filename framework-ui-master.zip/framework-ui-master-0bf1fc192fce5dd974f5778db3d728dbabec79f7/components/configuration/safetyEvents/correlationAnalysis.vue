<template>
    <div style="height:calc(100% - 138px);">
        <div style="width:100%;height:100%;">
            <div class="left" v-if="menuList">
                <tree :treedata="menuList" @getValue="getTableDataByTree" :defaultEpandedKeys="defaultEpandedKeys"></tree>
            </div>
            <div class="right">
                <div id="graph" style="height: 100%;width: 100%"></div>
            </div>
        </div>
    </div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import axios from "axios";
    import {getDictTree,getDatas} from "@/api/configuration/safetyEvents/correlationAnalysis/index.js"
    import echarts from "echarts";

    export default {
        components: {
            pagination,
            tree,
        },
        data() {
            return {
                menuList: [],
                data:[],
                selectTreeObject:{
                    id:"",
                    code:"-1",
                    label:"",
                    type:"",
                    children:["1"]
                },
                chart: null
            }
        },
        computed: {
            defaultEpandedKeys:function(){
                var arr = [];
                arr.push(this.selectTreeObject.id);
                return arr;
            }
        },
        mounted(){

        },
        methods: {
            initChart() {
                const option = {
                    tooltip: {
                        formatter: function(data) {
                            let message = "模型编码："+ data.data.moudleCode + '<br/>'+ "分析规则：" + data.data.rules;
                            return message
                        }
                    },
                    series: {
                        name: '树图',
                        type: 'tree',
                        orient: 'horizontal',
                        symbol: 'circle',
                        initialTreeDepth: 'null',
                        symbolSize: [200, 60],
                        itemStyle: {
                            normal: {
                                color: '#f0f0f0',
                                borderColor: '#f0f0f0',
                            },emphasis: {
                                color: '#f0f0f0',
                                borderColor: '#f0f0f0',
                            }
                        },
                        label: {
                            normal: {
                                color: '#6f7180'
                            },emphasis: {
                                color: '#6f7180'
                            }
                        },
                        data: this.data
                    }
                };
                this.chart = echarts.init(document.getElementById('graph'));
                this.chart.setOption(option,true,false);

            },
            init(){
                getDictTree().then((data)=>{
                    this.menuList =data.data;
                });
            },
            getTableDataByTree(val){
                // echarts.init(document.getElementById('graph')).clean;
                let code = val.code;
                if (this.chart) {
                    this.chart.dispose();
                }
                getDatas(code).then((datas)=>{
                    if(datas.data.length != 0){
                        this.data =datas.data;
                        this.initChart();
                    }
                });
            }
        },
        created() {
            this.init();
        },
        activated() {
            this.init();
        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        height: 100%;
        width: 980px;
    }
</style>
