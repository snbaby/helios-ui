<template>
    <div class="framework-content">
        <div class="framework-left">
            <tree :treedata="menuList" @getValue="getTableDataByTree" :defaultEpandedKeys="defaultEpandedKeys"></tree>
        </div>
        <div class="framework-right">
            <div class="framework-search-form">
                <el-form :inline="true">
                    <el-form-item label="模型编码：">
                        <el-input v-model="searchcode" clearable></el-input>
                    </el-form-item>
                    <el-form-item label="模型名称：">
                        <el-input v-model="searchname" clearable></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button @click="doSearch" type="primary">查询</el-button>
                        <el-button :disabled="addIsDisabled" @click="add">添加</el-button>
                    </el-form-item>
                </el-form>
            </div>
            <div>
                <el-table :data="menuPersonData.rows">
                    <el-table-column
                        type="index"
                        width="50">
                    </el-table-column>
                    <el-table-column
                        prop="categoryCode"
                        label="模型编码">
                    </el-table-column>
                    <el-table-column
                        prop="categoryName"
                        label="模型名称">
                    </el-table-column>
                    <el-table-column
                        prop="remark"
                        label="模型描述">
                    </el-table-column>
                    <el-table-column
                        label="是否台账">
                        <template slot-scope="scope">
                            <el-switch
                                v-model="scope.row.parameter"
                                :active-value="1"
                                :inactive-value="0"
                                @change="changeParameter(scope.row)"
                            >
                            </el-switch>
                        </template>
                    </el-table-column>
                    <el-table-column
                        prop="address"
                        label="操作">
                        <template slot-scope="scope">
                            <el-button
                                v-if="scope.row.parameter == 1"
                                @click.native.prevent="editParameterType(scope.row)"
                                type="text"
                                size="small">
                                台账
                            </el-button>
                            <el-button
                                @click.native.prevent="link(scope.row.id)"
                                type="text"
                                size="small">
                                维护
                            </el-button>
                            <el-button
                                @click.native.prevent="edit(scope.row)"
                                type="text"
                                size="small">
                                编辑
                            </el-button>
                            <el-button
                                @click.native.prevent="remove(scope.row.id)"
                                type="text"
                                size="small">
                                删除
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <pagination :option="pageOption" @pageChange="pageChange"></pagination>
            </div>
        </div>
        <el-dialog title="模型配置" :visible.sync="dialog">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm">
                <el-form-item label="模型编码" prop="categoryCode">
                    <el-input v-model="ruleForm.categoryCode"></el-input>
                </el-form-item>
                <el-form-item label="模型名称" prop="categoryName">
                    <el-input v-model="ruleForm.categoryName"></el-input>
                </el-form-item>
                <el-form-item label="模型描述" prop="remark">
                    <el-input v-model="ruleForm.remark"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
        <el-dialog title="台账配置" :visible.sync="parameterDialog">
            <el-form :model="parameterRuleForm" :rules="parameterRules" ref="parameterRuleForm">
                <el-form-item label="是否树形展示">
                    <el-radio-group v-model="parameterRuleForm.tree">
                        <el-radio :label="0">否</el-radio>
                        <el-radio :label="1">是</el-radio>
                    </el-radio-group>
                </el-form-item>
                <template v-if="parameterRuleForm.tree == 1">
                    <el-form-item label="树类型" prop="treeType">
                        <el-select v-model="parameterRuleForm.treeType" clearable @change="getTreeConfigArr($event)">
                            <el-option
                                v-for="item in menuPersonData.rows"
                                :key="item.categoryCode"
                                :label="item.categoryName"
                                :value="item.categoryCode">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="树编码" prop="treeShowId">
                        <el-select v-model="parameterRuleForm.treeShowId">
                            <el-option
                                v-for="item in treeConfigArr"
                                :key="item.metaCode"
                                :label="item.metaName"
                                :value="item.metaCode">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="树名称" prop="treeShowLabel">
                        <el-select v-model="parameterRuleForm.treeShowLabel" clearable>
                            <el-option
                                v-for="item in treeConfigArr"
                                :key="item.metaCode"
                                :label="item.metaName"
                                :value="item.metaCode">
                            </el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="表类型" prop="tableType">
                        <el-select v-model="parameterRuleForm.tableType" clearable>
                            <el-option
                                v-for="item in menuPersonData.rows"
                                :key="item.categoryCode"
                                :label="item.categoryName"
                                :value="item.categoryCode">
                            </el-option>
                        </el-select>
                    </el-form-item>
                </template>
                <el-form-item label="是否操作">
                    <el-radio-group v-model="parameterRuleForm.button">
                        <el-radio :label="0">否</el-radio>
                        <el-radio :label="1">是</el-radio>
                    </el-radio-group>
                </el-form-item>
                <template v-if="parameterRuleForm.button == 1">
                    <el-row>
                        <el-table :data="buttonDetail">
                            <el-table-column
                                type="index">
                            </el-table-column>
                            <el-table-column
                                label="按钮名称">
                                <template slot-scope="scope">
                                    <el-input v-model="scope.row.buttonName"></el-input>
                                </template>
                            </el-table-column>
                            <el-table-column
                                label="跳转路由">
                                <template slot-scope="scope">
                                    <el-input v-model="scope.row.buttonRouter"></el-input>
                                </template>
                            </el-table-column>
                            <el-table-column
                                label="路由参数">
                                <template slot-scope="scope">
                                    <el-select v-model="scope.row.routerParam" multiple>
                                        <el-option
                                            v-for="item in treeConfigArr"
                                            :key="item.metaCode"
                                            :label="item.metaName"
                                            :value="item.metaCode">
                                        </el-option>
                                    </el-select>
                                </template>
                            </el-table-column>
                            <el-table-column
                                label="是否有效">
                                <template slot-scope="scope">
                                    <el-switch
                                        v-model="scope.row.validity"
                                        :active-value="1"
                                        :inactive-value="0"
                                    >
                                    </el-switch>
                                </template>
                            </el-table-column>
                            <el-table-column
                                prop="address"
                                label="操作">
                                <template slot-scope="scope">
                                    <el-button
                                        @click.native.prevent="addTableRow"
                                        type="text"
                                        size="small">
                                        +
                                    </el-button>
                                    <el-button
                                        @click.native.prevent="delTableRow(scope)"
                                        type="text"
                                        size="small">
                                        -
                                    </el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                    </el-row>
                </template>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="parameterDialog = false">取 消</el-button>
                <el-button type="primary" @click="doEditParameterType('parameterRuleForm')">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import axios from "axios";
    import {
        getDictTree,
        getTableData,
        add,
        edit,
        deleteone,
        insertButtonList,
        getButtonDetail
    } from "@/api/configuration/manageObject/kindManageCategory/index.js";
    import {getMetaTableData} from "@/api/configuration/manageObject/categoryMetaConfig/index.js";

    export default {
        components: {
            pagination,
            tree,
        },
        props: ["categoryType"],
        data() {
            return {
                pageNo: 1,
                dialog: false,
                parameterDialog: false,
                searchcode: "",
                searchname: "",
                menuList: [],
                menuPersonData: {},
                ruleForm: {
                    categoryCode: "",
                    categoryName: "",
                    kindCode: "",
                    remark: "",
                    categoryType: ""
                },
                parameterRuleForm: {
                    tree: "",
                    treeType: "",
                    tableType: "",
                    treeShowId: "",
                    treeShowLabel: "",
                    button: ""
                },
                buttonDetail: [{
                    buttonName: "",
                    buttonRouter: "",
                    routerParam: "",
                    validity: 1
                }],
                parameterRules: {
                    treeType: [{
                        required: true,
                        message: '请输入树类型',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入树类型',
                        trigger: 'blur'
                    }],
                    tableType: [{
                        required: true,
                        message: '请输入表类型',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入表类型',
                        trigger: 'blur'
                    }],
                    treeShowId: [{
                        required: true,
                        message: '请输入树编码',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入树编码',
                        trigger: 'blur'
                    }],
                    treeShowLabel: [{
                        required: true,
                        message: '请输入树名称',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入树名称',
                        trigger: 'blur'
                    }]
                },
                rules: {
                    categoryCode: [{
                        required: true,
                        message: '请输入编码',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入编码',
                        trigger: 'blur'
                    }],
                    categoryName: [{
                        required: true,
                        message: '请输入名称',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入名称',
                        trigger: 'blur'
                    }],
                    remark: [{
                        required: true,
                        message: '请输入描述信息',
                        trigger: 'change'
                    }, {
                        required: true,
                        message: '请输入描述信息',
                        trigger: 'blur'
                    }]
                },
                selectTreeObject: {
                    id: "",
                    code: "",
                    label: "",
                    type: "",
                    children: ["1"]
                },
                treeConfigArr: []
            }
        },
        computed: {
            pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
            addIsDisabled: function () {
                return this.selectTreeObject.children.length == 0 ? false : true;
            },
            defaultEpandedKeys: function () {
                var arr = [];
                arr.push(this.selectTreeObject.id);
                return arr;
            }
        },
        methods: {
            init() {
                getDictTree(this.categoryType).then((data) => {
                    this.menuList = data.data;
                });

                var query = {
                    page: this.pageNo,
                    limit: 10,
                    kindCode: this.selectTreeObject.code,
                    categoryType: this.categoryType
                }
                if (this.searchcode != '') {
                    query.categoryCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.categoryName = this.searchname;
                }
                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            getTableDataByTree(val) {
                this.selectTreeObject = val;

                var query = {};
                if (val.children.length == 0) {
                    query = {
                        page: 1,
                        limit: 10,
                        kindCode: val.code,
                        categoryType: this.categoryType
                    }
                } else {
                    return false;
                }

                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
            refreshTableData() {
                var query = {
                    page: this.pageNo,
                    limit: 10,
                    kindCode: this.selectTreeObject.code,
                    categoryType: this.categoryType
                }

                if (this.searchcode != '') {
                    query.categoryCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.categoryName = this.searchname;
                }

                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            add() {
                this.ruleForm = {
                    categoryCode: "",
                    categoryName: "",
                    kindCode: this.selectTreeObject.code,
                    remark: "",
                    categoryType: this.categoryType
                };
                this.dialog = true;
            },
            edit(item) {
                this.dialog = true;
                this.ruleForm = item;
            },
            remove(id) {
                this.$confirm('删除后不能恢复, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                })
                    .then(() => {
                        deleteone(id).then((data) => {
                            if (data.status == 200) {
                                this.$alert('删除成功!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        this.init();
                                    }
                                });
                            } else {
                                this.$alert('删除失败!', '提示', {
                                    confirmButtonText: '确定',
                                    callback: action => {
                                        return false;
                                    }
                                });
                            }
                        });
                    }).catch(() => {
                });
            },
            doSubmit(formName) {
                var addObj = this.ruleForm;
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        this.dialog = false;
                        if (addObj.id) {
                            edit(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        } else {
                            add(addObj).then((data) => {
                                this.init();
                                this.$refs[formName].resetFields();
                            });
                        }
                    } else {
                        return false;
                    }
                });
            },
            doSearch() {
                var query = {
                    page: 1,
                    limit: 10,
                    categoryType: this.categoryType
                };
                this.selectTreeObject.code = '';
                if (this.searchcode != '') {
                    query.categoryCode = this.searchcode;
                }
                if (this.searchname != '') {
                    query.categoryName = this.searchname;
                }

                getTableData(query).then((data) => {
                    this.menuPersonData = data.data;
                });
            },
            link(id) {
                this.$router.push({
                    path: "/soc/business-configuration/object/category-meta-config",
                    query: {
                        id: id
                    }
                });
            },
            changeParameter(row) {
                var editobj = {
                    id: row.id,
                    parameter: row.parameter
                }

                edit(editobj).then((data) => {
                    this.init();
                });
            },
            editParameterType(item) {
                this.treeConfigArr = [];
                this.parameterDialog = true;
                this.parameterRuleForm = item;

                if (item.treeType != "") {
                    this.getTreeConfigArr(item.treeType);
                }

                getButtonDetail(item.id).then((data) => {
                    var arr = [];
                    for (var i in data.data.rows) {
                        var map = {
                            buttonName: data.data.rows[i].buttonName,
                            buttonRouter: data.data.rows[i].buttonRouter,
                            routerParam: data.data.rows[i].routerParam ? data.data.rows[i].routerParam.split(',') : [],
                            validity: data.data.rows[i].validity
                        };

                        arr.push(map);
                    }
                    if (arr.length > 0) {
                        this.buttonDetail = arr;
                    }
                });
            },
            doEditParameterType(formName) {
                this.$refs[formName].validate((valid) => {
                    if (valid) {
                        edit(this.parameterRuleForm).then((data) => {
                            var map = {
                                categroyId: this.parameterRuleForm.id,
                                buttonDetail: this.buttonDetail
                            }

                            insertButtonList(map).then((data) => {
                                this.init();
                                this.parameterDialog = false;
                            });
                        });
                    } else {
                        return false;
                    }
                });
            },
            getTreeConfigArr(e) {
                var query = {
                    page: 1,
                    limit: -1,
                    kindCode: this.selectTreeObject.code,
                    categoryType: this.categoryType
                }
                getTableData(query).then((data) => {
                    for (var i = 0; i < data.data.rows.length; i++) {
                        if (data.data.rows[i].categoryCode == e) {
                            var q = {
                                page: 1,
                                limit: -1,
                                kindId: data.data.rows[i].id.toString()
                            }
                            getMetaTableData(q).then((ren) => {
                                this.treeConfigArr = ren.data.rows;
                            });
                            break;
                        }
                    }
                });
            },
            delTableRow(scope) {
                this.buttonDetail.splice(scope.$index, 1);

                if (this.buttonDetail.length == 0) {
                    var map = {
                        buttonName: "",
                        buttonRouter: "",
                        routerParam: "",
                        validity: 1
                    }
                    this.buttonDetail.push(map);
                }
            },
            addTableRow() {
                this.buttonDetail.push({
                    buttonName: "",
                    buttonRouter: "",
                    routerParam: "",
                    validity: 1
                })
            },
        },
        watch: {
            categoryType: function () {
                this.init();
            }
        },
        created() {
            this.init();
        }
    }

</script>
