<template>
    <div style="height:calc(100% - 138px);" id="kindMetaConfig">
		<div style="width:100%;height:100%;">
			<div class="left" v-if="menuList">
                <tree :treedata="menuList" @getValue="getTableDataByTree" :defaultEpandedKeys="defaultEpandedKeys"></tree>
            </div>
			<div class="right">
				<el-row class="searchForm">
					<el-button class="add" style="float:right;margin-left:10px;" @click="add" :disabled="addIsDisabled">添加</el-button>
				</el-row>
				<el-row>
                    <div class="contentTable">
                        <mu-table :showCheckbox="false">
                            <mu-thead slot="header">
                                <mu-tr>
                                    <mu-th tooltip="序号" width="80">序号</mu-th>
                                    <mu-th tooltip="分类编码">元数据编码</mu-th>
                                    <mu-th tooltip="元数据名称">元数据名称</mu-th>
									<mu-th tooltip="元数据类型">元数据类型</mu-th>
									<mu-th tooltip="元数据长度">元数据长度</mu-th>
									<mu-th tooltip="能否为空">能否为空</mu-th>
									<mu-th tooltip="元数据描述">元数据描述</mu-th>
									<mu-th tooltip="元数据码表">元数据码表</mu-th>
                                    <mu-th tooltip="操作" width="100" style="text-align:center !important;">操作</mu-th>
                                </mu-tr>
                            </mu-thead>
                            <mu-tbody v-if="menuPersonData">
                                <mu-tr v-for="item,index in menuPersonData.rows" :key="index">
                                    <mu-td width="80">{{index+1}}</mu-td>
                                    <mu-td :title="item.metaCode">{{item.metaCode}}</mu-td>
									<mu-td :title="item.metaName">{{item.metaName}}</mu-td>
                                    <mu-td :title="getCategoryData('metaData',item.metaDataType)">{{getCategoryData('metaData',item.metaDataType)}}</mu-td>
									<mu-td :title="item.metaLength">{{item.metaLength}}</mu-td>
									<mu-td :title="item.metaIsnull==0?'否':'是'">{{item.metaIsnull==0?'否':'是'}}</mu-td>
									<mu-td :title="item.metaDescribe">{{item.metaDescribe}}</mu-td>
									<mu-td :title="item.metaSource">{{item.metaSource}}</mu-td>
                                    <mu-td width="100" style="text-align:center !important;">
                                        <button @click="remove(item.attr1)" class="tableButtonStyle">删除</button>
                                    </mu-td>
                                </mu-tr>
                            </mu-tbody>
                        </mu-table>
                    </div>
                </el-row>
				<div style="position: relative;bottom: -30px;text-align: center;" v-if="menuPersonData.total">
                    <pagination :option="pageOption" @pageChange="pageChange"></pagination>
                </div>
                <div class="norows" v-else style="text-align: center;margin-top:50px;">
                    <font>暂无数据</font>
                </div>
			</div>
		</div>
		<el-dialog title="元数据配置" :visible.sync="dialog" width="1200px">
            <el-transfer
				filterable
				:filter-method="filterMethod"
				filter-placeholder="请输入元数据名称"
				:titles="['未配置', '已配置']"
				v-model="selectMetaArr"
				:data="transferData"
				:render-content="renderFunc"
				:props="{
      				key: 'id',
					code:'metaCode',
      				label: 'metaName'
    			}">
		  	</el-transfer>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit()">确 定</el-button>
            </span>
        </el-dialog>
	</div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import axios from "axios";
	import {getDictTree,getTableData,add,deleteone,getMetaAll,getMetaTableData} from "@/api/configuration/manageObject/branchAndPerson/index.js"

    export default {
        components: {
            pagination,
			tree,
        },
        data() {
            return {
				pageNo:1,
				dialog:false,
                menuList:[],
				menuPersonData:{
				},
				selectTreeObject:{
					id:"",
					code:"-1",
					label:"",
					type:"",
					children:["1"]
				},
				transferData:[],
				selectMetaArr:[]
			}
        },
        computed: {
			pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
			addIsDisabled: function(){
				return this.selectTreeObject.children.length == 0 ? false :true;
			},
			defaultEpandedKeys:function(){
				var arr = [];
				arr.push(this.selectTreeObject.id);
				return arr;
			}
        },
        methods: {
			init(){
				getDictTree().then((data)=>{
					this.menuList =data.data;
				});

				getMetaAll().then((data)=>{
					this.transferData =data;
				});

				var query = {
					page:this.pageNo,
					limit:10,
					kindId:this.selectTreeObject.id.toString()
				}
				getMetaTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			getTableDataByTree(val){
				this.selectTreeObject = val;

				var query = {};
				if(val.children.length==0){
					query = {
						page: 1,
						limit: 10,
						kindId:val.id.toString()
					}

					getMetaTableData(query).then((data)=>{
						this.menuPersonData =data.data;
					});
				}else{
					return false;
				}
			},
			pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
			refreshTableData() {
				var query = {
                    page: this.pageNo,
                    limit: 10,
					kindId:this.selectTreeObject.id.toString()
                }
				getMetaTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			add(){
				var query = {
					page:1,
					limit:-1,
					kindId:this.selectTreeObject.id.toString()
				}

				getTableData(query).then((data)=>{
					var arr = [];
					for(var i=0;i<data.data.rows.length;i++){
						arr.push(parseInt(data.data.rows[i].metaId));
					}
					this.selectMetaArr = arr;
					this.dialog = true;
				});
			},
			remove(id){
				this.$confirm('删除后不能恢复, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				})
				.then(() => {
					deleteone(id).then((data)=>{
						if(data.status == 200){
							this.$alert('删除成功!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									this.init();
								}
							});
						}else{
							this.$alert('删除失败!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									return false;
								}
							});
						}
					});
				}).catch(() => {
				});
			},
			doSubmit(){
				this.dialog = false;

				var obj = {
					kindId:this.selectTreeObject.id.toString(),
					metaids:this.selectMetaArr.toString(),
					kindType:'organization'
				}

				add(obj).then((data)=>{
					this.init();
				});
			},
			renderFunc(h, option) {
          		return <span>{ option.metaName } [ { option.metaCode } ]</span>;
        	},
			filterMethod(query, item) {
				if(item.metaName.indexOf(query) > -1){
					return item.metaName.indexOf(query) > -1;
				}
			  	if(item.metaCode.indexOf(query) > -1){
					return item.metaCode.indexOf(query) > -1;
				}
			}
        },
        created() {
			this.init();
		},
        activated() {
			this.init();
        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

	.searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
		float: right;
		z-index: 1000;
    }

	.searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

	.contentTable {
		padding-left: 40px;
		padding-right: 40px;
	}

	.tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

	.demo-ruleForm {
		padding-right: 35px;
	}

	.transferStyle {

	}
</style>
