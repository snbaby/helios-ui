<template>
    <div style="height:calc(100% - 138px) !important;height: 100%;">
		<div style="width:100%;height:100%;">
			<div class="left" v-if="menuList">
                <tree :treedata="menuList" @getValue="getTableDataByTree"></tree>
            </div>
			<div class="right">
				<el-row class="searchForm">
					<el-col :span="18" style="padding-left:30px;">
                        <el-row>
                            <el-col :span="10">
                                <el-checkbox v-model="searchcodeChecked" class="searchCheckBox">编码：</el-checkbox>
                                <el-input v-model="searchcode" placeholder="" class="searchInput" @input="formChange('searchcode')"></el-input>
                            </el-col>
                            <el-col :span="10">
                                <el-checkbox v-model="searchnameChecked" class="searchCheckBox">名称：</el-checkbox>
                                <el-input v-model="searchname" placeholder="" class="searchInput" @input="formChange('searchname')"></el-input>
                            </el-col>
                        </el-row>
                    </el-col>
					<el-col :span="6">
                        <el-row>
                            <el-button class="add" style="float:right;margin-left:10px;" @click="add" :disabled="selectTreeCode==''">添加</el-button>
                            <el-button class="search" style="float:right;" @click='doSearch'>查询</el-button>
                        </el-row>
                    </el-col>
				</el-row>
				<el-row>
                    <div class="contentTable">
                        <mu-table :showCheckbox="false">
                            <mu-thead slot="header">
                                <mu-tr>
                                    <mu-th tooltip="序号" width="80">序号</mu-th>
                                    <mu-th tooltip="元数据编码">元数据编码</mu-th>
                                    <mu-th tooltip="元数据名称">元数据名称</mu-th>
									<mu-th tooltip="元数据类型">元数据类型</mu-th>
									<mu-th tooltip="元数据长度">元数据长度</mu-th>
									<mu-th tooltip="元数据描述">元数据描述</mu-th>
									<mu-th tooltip="是否非空">是否非空</mu-th>
									<mu-th tooltip="是否主键">是否主键</mu-th>
                                    <mu-th tooltip="操作" width="150" style="text-align:center !important;">操作</mu-th>
                                </mu-tr>
                            </mu-thead>
                            <mu-tbody v-if="menuPersonData">
                                <mu-tr v-for="item,index in menuPersonData.rows" :key="index">
                                    <mu-td width="80">{{index+1}}</mu-td>
                                    <mu-td :title="item.itemCode">{{item.itemCode}}</mu-td>
                                    <mu-td :title="item.itemName">{{item.itemName}}</mu-td>
									<mu-td :title="item.itemType">{{getCategoryData('metaData',item.itemType)}}</mu-td>
									<mu-td :title="item.itemLength">{{item.itemLength}}</mu-td>
									<mu-td :title="item.itemDescribe">{{item.itemDescribe}}</mu-td>
									<mu-td :title="item.isNull">{{item.isNull == 0?'否':'是'}}</mu-td>
									<mu-td :title="item.isKey">{{item.isKey == 0?'否':'是'}}</mu-td>
                                    <mu-td width="150" style="text-align:center !important;">
                                        <button @click="edit(item)" class="tableButtonStyle">编辑</button>
                                        <button @click="remove(item.id)" class="tableButtonStyle">删除</button>
                                    </mu-td>
                                </mu-tr>
                            </mu-tbody>
                        </mu-table>
                    </div>
                </el-row>
				<div style="position: relative;bottom: -30px;text-align: center;" v-if="menuPersonData.total">
                    <pagination :option="pageOption" @pageChange="pageChange"></pagination>
                </div>
                <div class="norows" v-else style="text-align: center;margin-top:50px;">
                    <font>暂无数据</font>
                </div>
			</div>
		</div>
		<el-dialog title="模板数据配置" :visible.sync="dialog">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<el-row>
					<el-col :span="12">
						<el-form-item label="元数据编码" prop="itemCode">
    						<el-input v-model="ruleForm.itemCode"></el-input>
  						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="元数据名称" prop="itemName">
    						<el-input v-model="ruleForm.itemName"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="12">
						<el-form-item label="元数据类型" prop="itemType">
							<el-select v-model="ruleForm.itemType" placeholder="" style="width:100%;">
								<el-option v-for="item,index in getCategoryData('metaData')" :key="index" :label="item.label" :value="item.code">
								</el-option>
							</el-select>
  						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="元数据长度" prop="itemLength">
    						<el-input type="number" v-model="ruleForm.itemLength"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="是否非空" prop="isNull">
							<el-radio-group v-model="ruleForm.isNull">
								<el-radio :label="0">否</el-radio>
								<el-radio :label="1">是</el-radio>
						  	</el-radio-group>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="是否主键" prop="isKey">
    						<el-radio-group v-model="ruleForm.isKey">
								<el-radio :label="0">否</el-radio>
								<el-radio :label="1">是</el-radio>
						  	</el-radio-group>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="元数据分类">
							<el-select v-model="ruleForm.kindCode" placeholder="" style="width:100%;" :disabled="true">
								<el-option v-for="item,index in selectKindAll" :key="index" :label="item.kindName" :value="item.kindCode">
								</el-option>
							</el-select>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="元数据描述" prop="itemDescribe">
    						<el-input type="textarea" v-model="ruleForm.itemDescribe"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
	</div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import axios from "axios";
	import {getDictTree,getTableData,add,edit,deleteone,queryAll} from "@/api/configuration/moudleDataSetting/index.js"

    export default {
        components: {
            pagination,
			tree,
        },
        data() {
            return {
				pageNo:1,
				dialog:false,
				searchcode:"",
				searchcodeChecked:false,
				searchname:"",
				searchnameChecked:false,
                menuList:[],
				menuPersonData:{

				},
				ruleForm:{
					itemCode:"",
					itemName:"",
					itemType:"",
					itemLength:"",
					itemDescribe:"",
					isNull:0,
					isKey:0,
					kindCode:""
				},
				rules:{
					itemCode:[{
						required: true,
						message: '请输入编码',
						trigger: 'change'
					},{
						required: true,
						message: '请输入编码',
						trigger: 'blur'
					}],
					itemName:[{
						required: true,
						message: '请输入名称',
						trigger: 'change'
					},{
						required: true,
						message: '请输入名称',
						trigger: 'blur'
					}],
					itemType:[{
						required: true,
						message: '请选择类型',
						trigger: 'change'
					},{
						required: true,
						message: '请选择类型',
						trigger: 'blur'
					}],
					itemLength:[{
						required: true,
						message: '请输入长度',
						trigger: 'change'
					},{
						required: true,
						message: '请输入长度',
						trigger: 'blur'
					}],
					itemDescribe:[{
						required: true,
						message: '请输入描述',
						trigger: 'change'
					},{
						required: true,
						message: '请输入描述',
						trigger: 'blur'
					}],
					isNull:[{
						required: true,
						message: '请选择是否非空',
						trigger: 'change'
					},{
						required: true,
						message: '请选择是否非空',
						trigger: 'blur'
					}],
					isKey:[{
						required: true,
						message: '请选择是否主键',
						trigger: 'change'
					},{
						required: true,
						message: '请选择是否主键',
						trigger: 'blur'
					}]
				},
				selectKindAll:[],
				selectTreeCode:""
			}
        },
        computed: {
			pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
			init(){
				getDictTree().then((data)=>{
					this.menuList =data;
				});

				queryAll().then((data)=>{
					this.selectKindAll =data;
				});

				var query = {
					page:1,
					limit:10,
					kindCode:this.selectTreeCode
				}
				if(this.searchcodeChecked){
					query.itemCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.itemName = this.searchname;
				}

				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
			getTableDataByTree(val){
				if(val.hasOwnProperty("children")){
					return false;
				}else{
					this.selectTreeCode = val.value;

					var query = {
						page: 1,
						limit: 10,
						kindCode:val.value
					}

					getTableData(query).then((data)=>{
						this.menuPersonData =data.data;
					});
				}
			},
			pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
			refreshTableData() {
				var query = {
                    page: this.pageNo,
                    limit: 10
                }
				if(this.searchcodeChecked){
					query.itemCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.itemName = this.searchname;
				}
				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			add(){
				this.ruleForm={
					itemCode:"",
					itemName:"",
					itemType:"",
					itemLength:"",
					itemDescribe:"",
					isNull:0,
					isKey:0,
					kindCode:this.selectTreeCode
				};
				this.dialog = true;
			},
			edit(item){
				this.dialog = true;
				this.ruleForm = item;
			},
			remove(id){
				this.$confirm('删除后不能恢复, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				})
				.then(() => {
					deleteone(id).then((data)=>{
						if(data.status == 200){
							this.$alert('删除成功!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									this.init();
								}
							});
						}else{
							this.$alert('删除失败!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									return false;
								}
							});
						}
					});
				}).catch(() => {
					this.$alert('删除失败!', '提示', {
						confirmButtonText: '确定',
						callback: action => {
							return false;
						}
					});
				});
			},
			doSubmit(formName){
				var addObj = this.ruleForm;
				this.$refs[formName].validate((valid) => {
          			if (valid) {
						if(addObj.id){
						    edit(addObj).then((data)=>{
								this.init();
								this.dialog = false;
								this.$refs[formName].resetFields();
							});
					   	}else{
							add(addObj).then((data)=>{
								this.init();
								this.dialog = false;
								this.$refs[formName].resetFields();
							});
						}
          			} else {
            			return false;
          			}
        		});
			},
			doSearch(){
				var query = {
					page:1,
					limit:10
				}
				if(this.searchcodeChecked){
					query.itemCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.itemName = this.searchname;
				}

				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			}
        },
		created() {
			this.init();
		},
        activated() {
			this.init();
        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

	.searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

	.searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

	.contentTable {
		padding-left: 40px;
		padding-right: 40px;
	}

	.tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

	.demo-ruleForm {
		padding-right: 35px;
	}
</style>
