<template>
    <div style="height:calc(100% - 138px) !important;height: 100%;">
		<div style="width:100%;height:100%;">
			<div class="left" v-if="menuList">
                <tree :treedata="menuList" @getValue="getTableDataByTree"></tree>
            </div>
			<div class="right">
				<el-row class="searchForm">
					<el-col :span="18" style="padding-left:30px;">
                        <el-row>
                            <el-col :span="10">
                                <el-checkbox v-model="searchcodeChecked" class="searchCheckBox">模型目录编码：</el-checkbox>
                                <el-input v-model="searchcode" placeholder="" class="searchInput" @input="formChange('searchcode')"></el-input>
                            </el-col>
                            <el-col :span="10">
                                <el-checkbox v-model="searchnameChecked" class="searchCheckBox">模型目录名称：</el-checkbox>
                                <el-input v-model="searchname" placeholder="" class="searchInput" @input="formChange('searchname')"></el-input>
                            </el-col>
                        </el-row>
                    </el-col>
					<el-col :span="6">
                        <el-row>
                            <el-button class="add" style="float:right;margin-left:10px;" @click="add">添加</el-button>
                            <el-button class="search" style="float:right;" @click='doSearch'>查询</el-button>
                        </el-row>
                    </el-col>
				</el-row>
				<el-row>
                    <div class="contentTable">
                        <mu-table :showCheckbox="false">
                            <mu-thead slot="header">
                                <mu-tr>
                                    <mu-th tooltip="序号" width="80">序号</mu-th>
                                    <mu-th tooltip="模型目录编码">模型目录编码</mu-th>
                                    <mu-th tooltip="模型目录名称">模型目录名称</mu-th>
									<mu-th tooltip="模型目录序号">模型目录序号</mu-th>
									<mu-th tooltip="模型目录描述">模型目录描述</mu-th>
                                    <mu-th tooltip="操作" width="150" style="text-align:center !important;">操作</mu-th>
                                </mu-tr>
                            </mu-thead>
                            <mu-tbody v-if="menuPersonData">
                                <mu-tr v-for="item,index in menuPersonData.rows" :key="index">
                                    <mu-td width="80">{{index+1}}</mu-td>
                                    <mu-td :title="item.catalogCode">{{item.catalogCode}}</mu-td>
                                    <mu-td :title="item.catalogName">{{item.catalogName}}</mu-td>
									<mu-td :title="item.catalogNum">{{item.catalogNum}}</mu-td>
									<mu-td :title="item.catalogDescribe">{{item.catalogDescribe}}</mu-td>
                                    <mu-td width="150" style="text-align:center !important;">
                                        <button @click="edit(item)" class="tableButtonStyle">编辑</button>
                                        <button @click="remove(item.id)" class="tableButtonStyle">删除</button>
                                    </mu-td>
                                </mu-tr>
                            </mu-tbody>
                        </mu-table>
                    </div>
                </el-row>
				<div style="position: relative;bottom: -30px;text-align: center;" v-if="menuPersonData.total">
                    <pagination :option="pageOption" @pageChange="pageChange"></pagination>
                </div>
                <div class="norows" v-else style="text-align: center;margin-top:50px;">
                    <font>暂无数据</font>
                </div>
			</div>
		</div>
		<el-dialog title="模型目录配置" :visible.sync="dialog" >
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
				<el-row>
					<el-col :span="12">
						<el-form-item label="目录编码" prop="catalogCode">
    						<el-input v-model="ruleForm.catalogCode"></el-input>
  						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="目录名称" prop="catalogName">
    						<el-input v-model="ruleForm.catalogName"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="12">
						<el-form-item label="目录排序" prop="catalogNum">
    						<el-input type="number" v-model="ruleForm.catalogNum"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="目录描述" prop="catalogDescribe">
    						<el-input type="textarea" v-model="ruleForm.catalogDescribe"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
	</div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import tree from '@/components/common/tree.vue';
    import pagination from '@/components/common/pagination.vue';
    import axios from "axios";
	import {getDictTree,getTableData,add,edit,deleteone} from "@/api/configuration/moudleDirSetting/index.js"

    export default {
        components: {
            pagination,
			tree,
        },
        data() {
            return {
				pageNo:1,
				dialog:false,
				searchcode:"",
				searchcodeChecked:false,
				searchname:"",
				searchnameChecked:false,
                menuList:[],
				menuPersonData:{

				},
				ruleForm:{
					catalogCode:"",
					catalogName:"",
					catalogNum:"",
					catalogDescribe:""
				},
				rules:{
					catalogCode:[{
						required: true,
						message: '请输入编码',
						trigger: 'change'
					},{
						required: true,
						message: '请输入编码',
						trigger: 'blur'
					}],
					catalogName:[{
						required: true,
						message: '请输入名称',
						trigger: 'change'
					},{
						required: true,
						message: '请输入名称',
						trigger: 'blur'
					}],
					catalogNum:[{
						required: true,
						message: '请输入排序',
						trigger: 'change'
					},{
						required: true,
						message: '请输入排序',
						trigger: 'blur'
					}],
					catalogDescribe:[{
						required: true,
						message: '请输入描述',
						trigger: 'change'
					},{
						required: true,
						message: '请输入描述',
						trigger: 'blur'
					}]
				}
			}
        },
        computed: {
			pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
			init(){
				getDictTree().then((data)=>{
					this.menuList =data;
				});

				var query = {
					page:1,
					limit:10
				}
				if(this.searchcodeChecked){
					query.catalogCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.catalogName = this.searchname;
				}

				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
			getTableDataByTree(val){

			},
			pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
			refreshTableData() {
				var query = {
                    page: this.pageNo,
                    limit: 10
                }
				if(this.searchcodeChecked){
					query.catalogCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.catalogName = this.searchname;
				}
				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			add(){
				this.ruleForm={
					catalogCode:"",
					catalogName:"",
					catalogNum:"",
					catalogDescribe:""
				};
				this.dialog = true;
			},
			edit(item){
				this.dialog = true;
				this.ruleForm = item;
			},
			remove(id){
				this.$confirm('删除后不能恢复, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				})
				.then(() => {
					deleteone(id).then((data)=>{
						if(data.status == 200){
							this.$alert('删除成功!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									this.init();
								}
							});
						}else{
							this.$alert('删除失败!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									return false;
								}
							});
						}
					});
				}).catch(() => {
					this.$alert('删除失败!', '提示', {
						confirmButtonText: '确定',
						callback: action => {
							return false;
						}
					});
				});
			},
			doSubmit(formName){
				var addObj = this.ruleForm;
				this.$refs[formName].validate((valid) => {
          			if (valid) {
						this.dialog = false;
						if(addObj.id){
						    edit(addObj).then((data)=>{
								this.init();
								this.$refs[formName].resetFields();
							});
					   	}else{
							add(addObj).then((data)=>{
								this.init();
								this.$refs[formName].resetFields();
							});
						}
          			} else {
            			return false;
          			}
        		});
			},
			doSearch(){
				var query = {
					page:1,
					limit:10
				}
				if(this.searchcodeChecked){
					query.catalogCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.catalogName = this.searchname;
				}

				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			}
        },
		created() {
			this.init();
		},
        activated() {
			this.init();
        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

	.searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

	.searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

	.contentTable {
		padding-left: 40px;
		padding-right: 40px;
	}

	.tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

	.demo-ruleForm {
		padding-right: 35px;
	}
</style>
