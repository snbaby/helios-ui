<template>
    <div style="height:calc(100% - 138px);">
		<div style="width:100%;height:100%;">
			<el-row>
				<el-row class="searchForm">
					<el-col :span="21" style="padding-left:30px;">
						<el-row>
							<el-col :span="8">
								<el-checkbox v-model="searchcodeChecked" class="searchCheckBox">元数据编码：</el-checkbox>
								<el-input v-model="searchcode" placeholder="" class="searchInput" @input="formChange('searchcode')"></el-input>
							</el-col>
							<el-col :span="8">
								<el-checkbox v-model="searchnameChecked" class="searchCheckBox">元数据名称：</el-checkbox>
								<el-input v-model="searchname" placeholder="" class="searchInput" @input="formChange('searchname')"></el-input>
							</el-col>
							<el-col :span="8">
								<el-checkbox v-model="searchtypeChecked" class="searchCheckBox">元数据类型：</el-checkbox>
								<el-select v-model="searchtype" placeholder="" class="searchInput" @input="formChange('searchtype')">
									<el-option v-for="item,index in getCategoryData('metaData')" :key="index" :label="item.label" :value="item.code">
									</el-option>
								</el-select>
							</el-col>
						</el-row>
					</el-col>
					<el-col :span="3">
						<el-row>
							 <el-button class="search" style="float:right;" @click='doSearch'>查询</el-button>
                        </el-row>
						<el-row style="margin-top:10px;">
							<el-button class="add" style="float:right;margin-left:10px;" @click="add">添加</el-button>
						</el-row>
					</el-col>
				</el-row>
				<el-row>
                    <div class="contentTable">
                        <mu-table :showCheckbox="false">
                            <mu-thead slot="header">
                                <mu-tr>
                                    <mu-th tooltip="序号" width="80">序号</mu-th>
                                    <mu-th tooltip="元数据编码">元数据编码</mu-th>
                                    <mu-th tooltip="元数据名称">元数据名称</mu-th>
                                    <mu-th tooltip="元数据类型">元数据类型</mu-th>
									<mu-th tooltip="元数据长度">元数据长度</mu-th>
									<mu-th tooltip="是否为空">能否为空</mu-th>
									<mu-th tooltip="元数据描述">元数据描述</mu-th>
									<mu-th tooltip="元数据码表">元数据码表</mu-th>
                                    <mu-th tooltip="操作" width="150" style="text-align:center !important;">操作</mu-th>
                                </mu-tr>
                            </mu-thead>
                            <mu-tbody v-if="menuPersonData">
                                <mu-tr v-for="item,index in menuPersonData.rows" :key="index">
                                    <mu-td width="80" :title="(menuPersonData.pageNo-1)*menuPersonData.pageSize+index+1">
                                        {{(menuPersonData.pageNo-1)*menuPersonData.pageSize+index+1}}</mu-td>
                                    <mu-td :title="item.metaCode">{{item.metaCode}}</mu-td>
                                    <mu-td :title="item.metaName">{{item.metaName}}</mu-td>
                                    <mu-td :title="item.metaDataType">{{getCategoryData('metaData',item.metaDataType)}}</mu-td>
									<mu-td :title="item.metaLength">{{item.metaLength}}</mu-td>
									<mu-td :title="item.metaIsnull==0?'否':'是'">{{item.metaIsnull==0?'否':'是'}}</mu-td>
									<mu-td :title="item.metaDescribe">{{item.metaDescribe}}</mu-td>
									<mu-td :title="item.metaSource">{{item.metaSource}}</mu-td>
                                    <mu-td width="150" style="text-align:center !important;">
                                        <button @click="edit(item)" class="tableButtonStyle">编辑</button>
                                        <button @click="remove(item.id)" class="tableButtonStyle">删除</button>
                                    </mu-td>
                                </mu-tr>
                            </mu-tbody>
                        </mu-table>
                    </div>
                </el-row>
				<div style="position: relative;bottom: -30px;text-align: center;" v-if="menuPersonData.total">
                    <pagination :option="pageOption" @pageChange="pageChange"></pagination>
                </div>
                <div class="norows" v-else style="text-align: center;margin-top:50px;">
                    <font>暂无数据</font>
                </div>
			</el-row>
		</div>
		<el-dialog title="元数据配置" :visible.sync="dialog" >
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="150px" class="demo-ruleForm">
				<el-row>
					<el-col :span="12">
						<el-form-item label="元数据编码" prop="metaCode">
    						<el-input v-model="ruleForm.metaCode"></el-input>
  						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="元数据名称" prop="metaName">
    						<el-input v-model="ruleForm.metaName"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="12">
						<el-form-item label="元数据类型" prop="metaDataType">
							<el-select v-model="ruleForm.metaDataType" placeholder="" style="width:100%;">
								<el-option v-for="item,index in getCategoryData('metaData')" :key="index" :label="item.label" :value="item.code">
								</el-option>
							</el-select>
  						</el-form-item>
					</el-col>
					<el-col :span="12">
						<el-form-item label="元数据长度" prop="metaLength">
    						<el-input type="number" v-model="ruleForm.metaLength"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="能否为空" prop="metaIsnull">
							<el-radio-group v-model="ruleForm.metaIsnull">
								<el-radio :label="0">否</el-radio>
								<el-radio :label="1">是</el-radio>
						  	</el-radio-group>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="数据字典编码">
							<el-select v-model="ruleForm.metaSource" clearable filterable placeholder="" style="width:100%;">
								<el-option
								  v-for="item in entryAll"
								  :key="item.dictEntryCode"
								  :label="`${item.dictEntryName} [ ${item.dictEntryCode} ]`"
								  :value="item.dictEntryCode">
								</el-option>
						  	</el-select>
  						</el-form-item>
					</el-col>
				</el-row>
				<el-row>
					<el-col :span="24">
						<el-form-item label="目录描述" prop="metaDescribe">
    						<el-input type="textarea" v-model="ruleForm.metaDescribe"></el-input>
  						</el-form-item>
					</el-col>
				</el-row>
			</el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="dialog = false">取 消</el-button>
                <el-button type="primary" @click="doSubmit('ruleForm')">确 定</el-button>
            </span>
        </el-dialog>
	</div>
</template>

<script>
    import {
        mapActions,
        mapState
    } from 'vuex';
    import pagination from '@/components/common/pagination.vue';
    import axios from "axios";
	import {getTableData,add,edit,deleteOne,getEntryAll} from "@/api/configuration/metadataSetting/index.js"

    export default {
        components: {
            pagination,
        },
        data() {
            return {
				pageNo:1,
				dialog:false,
				searchcode:"",
				searchcodeChecked:false,
				searchname:"",
				searchnameChecked:false,
				searchtype:"",
				searchtypeChecked:false,
				menuPersonData:{

				},
				ruleForm:{
					metaCode:"",
					metaName:"",
					metaDataType:"",
					metaLength:"",
					metaIsnull:1,
					metaDescribe:"",
					metaSource:""
				},
				rules:{
					metaCode:[{
						required: true,
						message: '请输入编码',
						trigger: 'change'
					},{
						required: true,
						message: '请输入编码',
						trigger: 'blur'
					}],
					metaName:[{
						required: true,
						message: '请输入名称',
						trigger: 'change'
					},{
						required: true,
						message: '请输入名称',
						trigger: 'blur'
					}],
					metaDataType:[{
						required: true,
						message: '请选择类型',
						trigger: 'change'
					},{
						required: true,
						message: '请选择类型',
						trigger: 'blur'
					}],
					metaLength:[{
						required: true,
						message: '请输入长度',
						trigger: 'change'
					},{
						required: true,
						message: '请输入长度',
						trigger: 'blur'
					}],
					metaIsnull:[{
						required: true,
						message: '请选择能否为空',
						trigger: 'change'
					},{
						required: true,
						message: '请选择能否为空',
						trigger: 'blur'
					}],
					metaDescribe:[{
						required: true,
						message: '请输入描述信息',
						trigger: 'change'
					},{
						required: true,
						message: '请输入描述信息',
						trigger: 'blur'
					}]
				},
				entryAll:[]
			}
        },
        computed: {
			pageOption: function () {
                return {
                    pageNo: this.menuPersonData.pageNo,
                    pageSize: this.menuPersonData.pageSize,
                    total: this.menuPersonData.total
                }
            },
        },
        methods: {
			init(){
				getEntryAll().then((data)=>{
					this.entryAll =data;
				});

				var query = {
					page:this.pageNo,
					limit:10
				}
				if(this.searchcodeChecked){
					query.metaCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.metaName = this.searchname;
				}
				if(this.searchtypeChecked){
					query.metaDataType = this.searchtype;
				}

				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			formChange(val) {
                if (this[val]) {
                    this[val + 'Checked'] = true;
                } else {
                    this[val + 'Checked'] = false;
                }
            },
			getTableDataByTree(val){

			},
			pageChange(val) {
                this.pageNo = val;
                this.refreshTableData();
            },
			refreshTableData() {
				var query = {
                    page: this.pageNo,
                    limit: 10
                }

				if(this.searchcodeChecked){
					query.metaCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.metaName = this.searchname;
				}
				if(this.searchtypeChecked){
					query.metaDataType = this.searchtype;
				}

				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
			add(){
				this.ruleForm={
					metaCode:"",
					metaName:"",
					metaDataType:"",
					metaLength:"",
					metaIsnull:1,
					metaDescribe:"",
					metaSource:""
				};
				this.dialog = true;
			},
			edit(item){
				this.dialog = true;
				this.ruleForm = item;

				var map = {
					id:item.id,
					metaCode:item.metaCode,
					metaName:item.metaName,
					metaDataType:item.metaDataType,
					metaIsnull:parseInt(item.metaIsnull),
					metaLength:item.metaLength,
					metaDescribe:item.metaDescribe,
					metaSource:item.metaSource.toString()
				}
				this.ruleForm = map;
			},
			remove(id){
				this.$confirm('删除后不能恢复, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				})
				.then(() => {
					deleteOne(id).then((data)=>{
						if(data.status == 200){
							this.$alert('删除成功!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									this.init();
								}
							});
						}else{
							this.$alert('删除失败!', '提示', {
								confirmButtonText: '确定',
								callback: action => {
									return false;
								}
							});
						}
					});
				}).catch(() => {
				});
			},
			doSubmit(formName){
				var addObj = this.ruleForm;
				this.$refs[formName].validate((valid) => {
          			if (valid) {
						this.dialog = false;
						if(addObj.id){
						    edit(addObj).then((data)=>{
								this.init();
								this.$refs[formName].resetFields();
							});
					   	}else{
							add(addObj).then((data)=>{
								this.init();
								this.$refs[formName].resetFields();
							});
						}
          			} else {
            			return false;
          			}
        		});
			},
			doSearch(){
				var query = {
					page:1,
					limit:10
				}
				if(this.searchcodeChecked){
					query.metaCode = this.searchcode;
				}
				if(this.searchnameChecked){
					query.metaName = this.searchname;
				}
				if(this.searchtypeChecked){
					query.metaDataType = this.searchtype;
				}

				getTableData(query).then((data)=>{
					this.menuPersonData =data.data;
				});
			},
        },
        created() {
			this.init();
		},
        activated() {
			this.init();
        }
    }

</script>


<style lang="css" scoped>
    .left {
        width: 220px;
        background: #f0f0f0;
        height: 100%;
        float: left;
        border: 1px #dddddd solid;
    }

    .right {
        float: right;
        width: 980px;
    }

	.searchForm {
        padding: 10px 0;
        background: #f0f0f0;
        height: auto;
    }

	.searchCheckBox {
        float: left;
        line-height: 30px;
    }

    .searchInput {
        float: left;
        width: 150px;
        height: 30px;
    }

	.contentTable {
		padding-left: 40px;
		padding-right: 40px;
	}

	.tableButtonStyle {
        width: 50px;
        color: #004ea2;
        cursor: pointer;
    }

	.demo-ruleForm {
		padding-right: 35px;
	}
</style>
