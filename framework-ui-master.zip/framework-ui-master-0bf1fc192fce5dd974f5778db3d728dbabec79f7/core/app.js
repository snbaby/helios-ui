/**
 * @file entry
 * @author sn_baby(sn_baby@qq.com)
 */

import Vue from 'vue';
import Meta from 'vue-meta';

import {createRouter} from '@/.lavas/router';
import {createStore} from '@/.lavas/store';
import AppComponent from './App.vue';

import Vuetify from 'vuetify';
import ElementUI from 'element-ui';
import MuseUI from 'muse-ui'; //UI组件
import {
    getCategoryData,
    getDepName,
    getDepNameById,
    getMenuTree,
    getMenus,
    getCurrentUser,
    fetchTree,
    pagedGroups,
    depTree
} from "@/api/common/sessionStorage.js";

import {
    formatDateTime,
    getDataTime,
    timeStr2timeStamp,
    timestampToTime,
    timestampToTimes
} from "@/api/common/util.js";

import {
    getDepTree,
    getSqlResult,
    getSqlResultWithQuery
} from "@/api/common/index.js";

Vue.use(Meta);

Vue.use(Vuetify);
Vue.use(ElementUI);
Vue.use(MuseUI);

Vue.config.productionTip = false;

Vue.prototype.getCategoryData = getCategoryData;
Vue.prototype.getDepName = getDepName;
Vue.prototype.getDepNameById = getDepNameById;
Vue.prototype.getMenuTree = getMenuTree;
Vue.prototype.getMenus = getMenus;
Vue.prototype.getCurrentUser = getCurrentUser;
Vue.prototype.fetchTree = fetchTree;
Vue.prototype.pagedGroups = pagedGroups;
Vue.prototype.depTree = depTree;

Vue.prototype.timestampToTime = timestampToTime;
Vue.prototype.formatDateTime = formatDateTime;
Vue.prototype.getDataTime = getDataTime;
Vue.prototype.timestampToTimes = timestampToTimes;
Vue.prototype.getDepTree = getDepTree;
Vue.prototype.getSqlResultWithQuery = getSqlResultWithQuery;
Vue.prototype.getSqlResult = getSqlResult;

export function createApp() {
    let router = createRouter();
    let store = createStore();
    let App = Vue.extend({
        router,
        store,
        ...AppComponent
    });
    return {App, router, store};
}

if (module.hot) {
    module.hot.accept();
}
