import ElementUI from 'element-ui';
import io from 'socket.io-client';

const instance = function(){
    const tempSocket = io('ws://192.168.2.4:2018',{
        path: '/ws',
        query:{
            token: sessionStorage.getItem("token")
        },
        transports: ['websocket']
    });
    tempSocket.on('connect', function(){
        ElementUI.Message.info({
            message: '连接成功!'
        });


    });

    tempSocket.on('disconnect', function(){
        ElementUI.Message.warning({
            message: '连接断开!'
        });
        console.log('disconnect')
    });

    tempSocket.on('error', (error) => {
        console.log('error',error)
        ElementUI.Message.warning({
            message: '连接异常!'
        });
    });

    tempSocket.on('reconnect_attempt', () => {
        instance.io.opts.query = {
            token: sessionStorage.getItem("token")
        }
    });
    return tempSocket;
}



export default {
    install(Vue) {
        Vue.prototype.$socket = instance;
    }
};

export const socket = instance;
